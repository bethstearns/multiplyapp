/**
 * 
 * Multiply App Functions
 * Created 08/01/2016
 * 
 */ 
function startMult(fromMobile)
{
/*
 * placeholder for loading body page
 */	
	//03182017: added global var when coming from mobile device
	document.getElementById("hiddenfrommobile").style.display="none";
	if (fromMobile) {
		document.getElementById("hiddenfrommobile").innerHTML=fromMobile;
	} else {
		document.getElementById("hiddenfrommobile").innerHTML="";
	}
	
	//add onload call for mobile devices
    document.addEventListener("deviceready", onDeviceReady, false);
	
	//display problem entry table
	document.getElementById("decimalarea").style.display="none";
	document.getElementById("nextproblemButton").style.display="";

	document.getElementById("hiddenVariables").style.display="none"; //jcs112716 hide hidden variables
	document.getElementById("multiplytable").style.display="";
	document.getElementById("solveButton").style.display="";
	
	document.getElementById("topEntry").focus();	//jcs120916 set focus on top entry input
	openStorageObject("TestUser");
	//writeToStorage("Starting multiply application".bold());
}

//special cordova functions for device APIs 
//
function onDeviceReady() {
    document.addEventListener("pause", onPause, false);
    document.addEventListener("resume", onResume, false);
    document.addEventListener("menubutton", onMenuKeyDown, false);
    // Add similar listeners for other events
}

function onPause() {
    // Handle the pause event
}

function onResume() {
    // Handle the resume event
}

function onMenuKeyDown() {
    // Handle the menubutton event
}
//end of special cordova functions

function doAnotherProblem(fromMobile)
{
	/* 
	 * reset tables for a new problem
	 */
	//document.getElementById("nextproblemButton").style.display="none";
    document.getElementById("multiplymsgarea").style.display="";
    //clear any error msgs
	document.getElementById("redoMsg").innerHTML="";
    document.getElementById("multiplytable").style.display="";
	document.getElementById("solveButton").style.display="";
    if (!fromMobile) document.getElementById("entrytable").style.display="";
   //hide decimal prompt area
	document.getElementById("decimalarea").style.display="none";
    
    //document.getElementById("answerMsg").innerHTML=""; 
    //document.getElementById("answerMsg").style.display="none";
	//display enter problem prompt
	document.getElementById("answerMsg").innerHTML="Enter the problem:";
   
    // clear problem entry table rows
    document.getElementById("topEntry").value="";
    document.getElementById("timesEntry").value="";   
	document.getElementById("topEntry").focus();	//jcs120916 set focus on top entry input
  
	clearData("solvemultiply");
	clearData("decimallist");
	
	// clear hidden vars
	clearHiddenVars();
    if (fromMobile=='1')	{//display work button pressed
    	//clear tswcomments text area
    	var commentArea=document.getElementById("mobileHW");
        $(commentArea).empty();
    	window.location.assign("#pageone");		
    } else {
        document.getElementById("displayhw").style.display="";
    }

	return;
}

function clearData (dataAreaName) {
	/*
	 * Removes children of the named table/form
	 */	
	var j=document.getElementById(dataAreaName);
	var anotherChild = true;
	while (anotherChild) {
		anotherChild=j.hasChildNodes();
		if (anotherChild) {
			j.removeChild(j.childNodes[0]);
		}
	}
	return;
}

function clearHiddenVars()
{
	/*
	 * Clears all hidden variables before doing another problem
	 */
	document.getElementById("hiddentopentry").innerHTML="";
	document.getElementById("hiddentopdecimal").innerHTML="";
	document.getElementById("hiddentimesentry").innerHTML="";
	document.getElementById("hiddentimesdecimal").innerHTML="";
	document.getElementById("hiddenrow").innerHTML="";
	document.getElementById("hiddencol").innerHTML="";
	document.getElementById("hiddencarrycell").innerHTML="";
	document.getElementById("hiddencarrytoadd").innerHTML="";
	document.getElementById("hiddentopfactor").innerHTML="";
	document.getElementById("hiddentimesfactor").innerHTML="";
	document.getElementById("hiddenprodcell").innerHTML="";
	document.getElementById("hiddenprodcol").innerHTML="";
	document.getElementById("hiddentopcol").innerHTML="";
	document.getElementById("hiddentimescol").innerHTML="";
	document.getElementById("hiddenprevcarry").innerHTML="";
	document.getElementById("hiddenaddcol").innerHTML="";
	document.getElementById("hiddenleftcarrycol").innerHTML="";
	document.getElementById("hiddenfinalproduct").innerHTML="";
	document.getElementById("hiddenanswerlength").innerHTML="";	
	document.getElementById("hiddentotaladdcols").innerHTML="";	
	document.getElementById("hiddenentryfield").innerHTML="";	
	document.getElementById("hiddenfrommobile").innerHTML="";
	return;
}
function displayNextProblem()
{
	/*
	 * displays next problem button area
	 * Display button for viewing/sending solved problem set?
	 */
	
	//03142017: comment out displaying next problem button
	//document.getElementById("nextproblemButton").style.display="";
}


function getMultEntry()
{
	/*
	 * Get multiplication problem entries
	 */
	var topEntryNum;
	var timesEntryNum;
	var continueProblem;
	var decimalCol,decimalFlag;
	var repString;
	var product;
	var answerLength;
	
	topEntryNum=document.getElementById("topEntry").value;
	timesEntryNum=document.getElementById("timesEntry").value;
	
	/*
	 * check for valid numbers; return if invalid
	 * else continue processing loop
	 */
	if (isNaN(topEntryNum) || isNaN(timesEntryNum)) {
		alert("Enter a valid number. Try again.");	
		continueProblem=false;
	} else {
		continueProblem=true;
		//erase entry lines
		document.getElementById("multiplytable").style.display="none";
		document.getElementById("solveButton").style.display="none";	
	}
	if (!continueProblem) return;
	
	//write problem to storage
	//010117: add line break before problem and make entire line bold
	var tempLine="Problem: "+topEntryNum+"*"+timesEntryNum;
	writeToStorage(tempLine.bold());
	//writeToStorage("Problem: "+topEntryNum+"*"+timesEntryNum.bold());

	/*
	 * put numbers into multiplication table array: topRow and
	 * timesRow; get back each number with decimal stripped out
	 */
	var topEntryNoDec, timesNoDec;
	var topEntryLen, timesEntryLen;

	// build tables first; compute length of entry numbers w/o decimal pt
	topEntryLen=topEntryNum.length;
	timesEntryLen=timesEntryNum.length;
	
	decimalCol=topEntryNum.lastIndexOf(".");
	if (decimalCol>-1) {
		topEntryLen--;
		decimalCol=topEntryLen-decimalCol;
	} else decimalCol=0;
	document.getElementById("hiddentopdecimal").innerHTML=decimalCol;	

	decimalCol=timesEntryNum.lastIndexOf(".");
	if (decimalCol>-1) {
		timesEntryLen--;
		decimalCol=timesEntryLen-decimalCol;
	} else decimalCol=0;
	document.getElementById("hiddentimesdecimal").innerHTML=decimalCol;	

	// switch top/times entries to put single digit in times row
	var holdNum;
	if (timesEntryLen > topEntryLen) {
		//switch decimal place pointers
		document.getElementById("hiddentimesdecimal").innerHTML=
			document.getElementById("hiddentopdecimal").innerHTML;	
		document.getElementById("hiddentopdecimal").innerHTML=decimalCol;	
		holdNum=topEntryNum;
		topEntryNum=timesEntryNum;
		timesEntryNum=holdNum;
		document.getElementById("topEntry").value=topEntryNum;
		document.getElementById("timesEntry").value=timesEntryNum;
		document.getElementById("redoMsg").innerHTML=
			"When multiplying, it is better to have the larger factor on "+
			"top. We did this for you.";
		document.getElementById("redoMsg").style.display="";
		buildTable(timesEntryLen, topEntryLen); //jcs121016 reversed order of top and times to get correct number of carry rows
	} else
		buildTable(topEntryLen,timesEntryLen);

	//set values in top, times rows
	// save decimal location to hidden vars
	topEntryNoDec=setValInRow("top",topEntryNum);	
	timesNoDec=setValInRow("times",timesEntryNum);
	//insert multiply sign
	//document.getElementById("times"+String(timesNoDec.length)).innerHTML="x";
	
	//save top, times numbers
	document.getElementById("hiddentopentry").innerHTML=topEntryNoDec;	
	document.getElementById("hiddentimesentry").innerHTML=timesNoDec;
	
	//jcs111416 save product and answer length
	product=Number(topEntryNoDec)*Number(timesNoDec);
	document.getElementById("hiddenfinalproduct").innerHTML=product;
	answerLength=String(product);
	document.getElementById("hiddenanswerlength").innerHTML=answerLength.length;
	
	//display first column multiply hint
	buildMultHint(true);//rightmost column
	return;
}

function computeProd(ansEntry,carryEntry,prevCarryEntry) {
	/*
	 * Computes product, returns flag if correct or not
	 */
	var correctAns;	
	var prodVal;
	var inputAns="";
	var computeAns;
	var topCellVal,timesCellVal,topLoc,timesLoc;
	var tempVal="";

	inputAns = String(carryEntry)+String(ansEntry);
	
	topLoc=document.getElementById("hiddentopfactor").innerHTML;
	topCellVal=document.getElementById(topLoc).innerHTML;
	timesLoc=document.getElementById("hiddentimesfactor").innerHTML;
	timesCellVal=document.getElementById(timesLoc).innerHTML;

	computeAns=0;
	if (timesCellVal=="") timesCellVal=0;
	if (topCellVal=="") topCellVal=0;
	//strip single digit from end of times/top values in case 
	//	there is a decimal point
	tempVal = timesCellVal.charAt(timesCellVal.length-1);
	timesCellVal=tempVal;
	tempVal = topCellVal.charAt(topCellVal.length-1);
	topCellVal=tempVal;
	
	computeAns=Number(topCellVal)*Number(timesCellVal);

	//add carry if it exists
	if (prevCarryEntry){
		computeAns=computeAns+Number(prevCarryEntry);
	}

	if (Number(inputAns) == Number(computeAns)) {
		correctAns=0; //answer is correct
	} else {
		//3152017: check if digits were reversed
		correctAns=checkForReverseDigits(inputAns,computeAns);
	}
	return(correctAns);
}

function checkForReverseDigits(inputAns,computeAns)
{
	/*
	 * Checks if digits were reversed. If correct after reversing, fix and continue
	 * 
	 */
	var reverseAns;
	var correctAns=1; //wrong answer entered
	
	if (inputAns.length>1) {
		reverseAns=inputAns.charAt(1)+inputAns.charAt(0);
		if (Number(reverseAns)==computeAns) {
		//may have reversed digits; display appropriate msg and they reenter
			correctAns=2; //reversed digits
		}
	}
	return(correctAns);
}

function doNextMult(doneFlag)
{
	/*
	 * do the next logical multiplication
	 * check that answer entered is correct for multiply and carry fields
	 * 
	 */
	var multVal;
	var carryVal, prevCarry;
	var topVal,timesVal, hRow, hCol, carryLoc,ansEntry,carryEntry;
	var timesDigit, topDigit;
	var strikeCell;
	var inputAns="";
	var prevCarryEntry, prevCarryLoc, prodCellLoc, parentCarryCell;
	var doneFlag=false; //jcs120916 Added doneflag to test for early finish
	var prefix="Wrong product answer: "; 
	
	//jcs111916 find cell containing user entries - prod anf carry
	hRow=document.getElementById("hiddenrow").innerHTML;
	hCol=document.getElementById("hiddenprodcol").innerHTML;
	prodCellLoc="prod"+hRow+hCol; 
	parentCarryCell=document.getElementById("hiddencarrycell").innerHTML; //jcs111916 cell ID containing carry
	
	ansEntry=document.getElementById("prodInput").value;
	carryEntry=document.getElementById("carryInput").value;	//jcs111916 
		
	//compute multiply answer: add prevCarry value if it exists
	prevCarryLoc=document.getElementById("hiddenprevcarry").innerHTML;
	if (prevCarryLoc) 
		prevCarryEntry=document.getElementById(prevCarryLoc).innerHTML;
	 else 
		prevCarryEntry="";

	var correctMult=computeProd(ansEntry,carryEntry,prevCarryEntry);	
	if (correctMult>0) {
		inputAns = String(carryEntry)+String(ansEntry);
		if (correctMult==1) {//wrong answer
			document.getElementById("redoMsg").innerHTML="Wrong product answer: "+
				inputAns+ " Try again.";
		} else {
			document.getElementById("redoMsg").innerHTML="You're close: " + inputAns+ 
					".<br /> Put the 1s digit in the box below the line. <br />" +
							"The 10s digit goes in the carry box.";			
		}
		document.getElementById("redoMsg").style.display="";
		playSound("errsound");
		writeToStorage(prefix.bold().fontcolor("red")+inputAns.bold().fontcolor("red")); //jcs121016 set result to red
		//jcs112916 clear prod and carry inputs
		document.getElementById("prodInput").value="";
		document.getElementById("carryInput").value="";
		document.getElementById("prodInput").focus();  //jcs112916 set focus on prodinput 
		return;
	} else {
		document.getElementById("redoMsg").innerHTML="";
	}
	
	//correct answer: delete input attribute of cell and display correct value
	var parentCell=document.getElementById(prodCellLoc);
	parentCell.removeChild(parentCell.childNodes[0]);
	parentCell.innerHTML=ansEntry;

	//check if this is leftmost carry cell
	var leftCarryCol=document.getElementById("hiddenleftcarrycol").innerHTML;
	if (leftCarryCol) {
		parentCarryCell=leftCarryCol;
	} 
	parentCell=document.getElementById(parentCarryCell);
	parentCell.removeChild(parentCell.childNodes[0]);

	if (carryEntry)
		parentCell.innerHTML=carryEntry;
	
	//jcs111516 if there is a prev carry added, strike thru the entry
	prevCarryCell=document.getElementById("hiddenprevcarry");
	if (prevCarryCell.innerHTML) {
		strikeCell=prevCarryCell.innerHTML;
		document.getElementById(strikeCell).className="struck"; 
	}
	
	//jcs111016 if there is a new carry entered, set the hiddenprevcarry 
	//variable to the carry entry, otherwise set it to null
	if ((carryEntry)&&(!leftCarryCol)) {
		document.getElementById("hiddenprevcarry").innerHTML=parentCarryCell;		
	} else {
		document.getElementById("hiddenleftcarrycol").innerHTML="";
		document.getElementById("hiddenprevcarry").innerHTML="";
	}
	
	//change to next input cell location
	var addColumns=changeCell();
	
	//display hint for next input if still multiplying
	if (addColumns==0) {//continue with multiplying
		//play success bell sound
		playSound("midway");
		buildMultHint(false);//not first column
	} else if (addColumns==1) {
		var decimalPlace=checkForDecimal();
		if (decimalPlace != 0) {
			//set special msg for decimal point input
			setDecimalPrompt();
			document.getElementById("decimalarea").style.display="";
			//play success bell sound
			playSound("midwaywinsound");
			doneFlag=true;  //jcs120916 Added doneFlag to test for early finish
		} else if (decimalPlace==0) {
			successFinish();
			doneFlag=true;  //jcs120916 Added doneFlag to test for early finish
		}		
	}
	if (!doneFlag)
		document.getElementById("prodInput").focus();   
	return;
}

function checkForDecimal(fromVerify)
{
	/*
	 * Checks if decimal place needs to be entered 
	 * Builds selection list if decimal place required
	 * If fromVerify, then in verifying user entry--do not build select list
	 */
	var decimalTop,decimalTimes;
	var decimalPlace, i;
	
	//erase any hints or redo msgs
	document.getElementById("answerMsg").style.display="none";
	document.getElementById("redoMsg").style.display="none";
	
	decimalTop=document.getElementById("hiddentopdecimal").innerHTML;
	decimalTimes=document.getElementById("hiddentimesdecimal").innerHTML;

	decimalPlace=Number(decimalTop)+Number(decimalTimes);
	
	if (!fromVerify && decimalPlace>0) {//build select list
		var topLen=document.getElementById("hiddentopentry").innerHTML.length;
		var timesLen=document.getElementById("hiddentimesentry").innerHTML.length;
		var numAnswerPlaces=topLen + timesLen;
		var decList=document.getElementById("decimallist");
		var finalAns=document.getElementById("hiddenfinalproduct").innerHTML;
		var numFinalAns=Number(finalAns);
		var radioButton;
		var buttonText;
		var buttonTextObj;
		var buttonLabel;
		var listBreak;
		
		var decimalField=document.getElementById("mobileradiobuttons");
		for (i=0;i<numAnswerPlaces+1;i++) {
			listBreak=document.createElement("BR");
			if (i==0) {
				buttonText=finalAns+".";
			} else {
				numFinalAns=numFinalAns*.1;
				buttonText=String(numFinalAns.toFixed(i));
			}

			//change label to span
			//buttonLabel=document.createElement("label");
			buttonLabel=document.createElement("span");
			buttonTextObj=document.createTextNode(buttonText);
			//buttonLabel.setAttribute("for", i);
			//buttonLabel.appendChild(buttonTextObj);
			//buttonLabel.appendChild(listBreak);
			//append to fieldset rather than form
			//decList.appendChild(buttonLabel);
			//decimalField.appendChild(buttonLabel);

			
			radioButton=document.createElement("input");
			radioButton.setAttribute("type","radio");
			radioButton.name="decimalpointcell";
			radioButton.id=i;
			radioButton.value=i;
			radioButton.setAttribute("onchange","verifyDecimal(this.id)");
			//append to fieldset rather than form
			//decimalField.appendChild(radioButton);
			decimalField.appendChild(radioButton);
			decimalField.appendChild(buttonTextObj);
			decimalField.appendChild(listBreak);
			//decList.appendChild(radioButton);

			/*
			var listBreak=document.createElement("BR");
			buttonLabel=document.createElement("label");
			buttonTextObj=document.createTextNode(buttonText);
			buttonLabel.setAttribute("for", i);
			buttonLabel.appendChild(buttonTextObj);
			//buttonLabel.appendChild(listBreak);
			//append to fieldset rather than form
			//decList.appendChild(buttonLabel);
			decimalField.appendChild(buttonLabel);
			*/
		}
	}
	return(decimalPlace);
}

function verifyDecimal(decimalPt)
{
	/*
	 * Verifies decimal place entered
	 */
	//var decimalPtInput=document.getElementById("decimalPlaces");
	//var decimalPt=decimalPtInput.value; 	
	var decimalPlace;
	var prefix="Wrong decimal place: ";
	//compute decimal place and verify selected number is correct
	decimalPlace=checkForDecimal(true);
	if (isNaN(decimalPt)) decimalPt=-999;//force alpha decimal pt to wrong # 
	if (decimalPlace == Number(decimalPt)) {
		document.getElementById("redoMsg").innerHTML="";		
		document.getElementById("decimalarea").style.display="none";
		//insert decimal in final answer
		//check sum row cell first; if empty, use prodrow cell
		var cellLoc = decimalPlace-1;
		var cellId;
		var decPt="\<strong>.\</strong>";
		
		//jcs010817 determine if single prod row or sum row START HERE
		if (document.getElementById("sum0").innerHTML) 
			cellId=document.getElementById("sum"+String(cellLoc));
		else 
			cellId=document.getElementById("prod"+"0"+String(cellLoc));
			
		if (cellId.innerHTML=="") 
			cellId.innerHTML="0";

		cellId.innerHTML=decPt+cellId.innerHTML;
	
		writeToStorage("Correctly placed decimal point: "+decimalPt.bold());
		successFinish();		
	} else {
		document.getElementById("redoMsg").innerHTML="Wrong decimal place."
			+" Try again.";
		document.getElementById("redoMsg").style.display="";
		playSound("errsound");
		document.getElementById("decimalPlaces").value="";
		writeToStorage(prefix.bold().fontcolor("red")+inputAns.bold().fontcolor("red")); //jcs121016 set result to red
	}
	return;
}

function playSound(soundType)
{
	/*
	 * plays random error or success sounds 
	 */
	
	var soundSrc;
	var soundElement;
	var randomNum,i;
	var playsound="midwaysound0.mp3";	
	
	if (soundType=="midway") {
		soundSrc="sound/"+playsound;
	} else {
		//get a random number betw 1-10 for the sound file
		randomNum = Math.floor((Math.random() * 5) + 1);
		playsound=soundType;
	    soundSrc="sound/"+playsound+String((randomNum)-1)+".mp3";
	}
	//set src to an error or winning sound
	soundElement=document.getElementById("errorSound");	
	if (soundElement.volume !=0.2) soundElement.volume=0.2;
	soundElement.src=soundSrc;
	soundElement.play();
	return;
}

function buildMultHint(firstCol)
{
	/*
	 * Builds hint for multiplication steps
	 */
	var stringAddVals="";
	var timesLoc,topLoc,carryLoc;
	var timesVal,topVal,carryVal;
	var tempString="";
	
	timesLoc=document.getElementById("hiddentimesfactor").innerHTML;
	if (timesLoc) timesVal=document.getElementById(timesLoc).innerHTML;
	topLoc=document.getElementById("hiddentopfactor").innerHTML;
	if (topLoc) topVal=document.getElementById(topLoc).innerHTML;
	carryLoc=document.getElementById("hiddenprevcarry").innerHTML;
	if (carryLoc) carryVal=document.getElementById(carryLoc).innerHTML;
	
	//strip out leading decimals from top,times values
	tempString=topVal;
	topVal=tempString.replace(".","");
	tempString=timesVal;
	timesVal=tempString.replace(".","");
	
	if (firstCol) {
		stringAddVals="Multiply "+topVal+"*"+timesVal;
	} else {
		if (topVal != "") {
			stringAddVals="Multiply "+topVal;
		}
		if (timesVal !="") {
			stringAddVals=stringAddVals+"*"+timesVal;
		}
		if (carryVal !="" && carryVal!==undefined) {
			stringAddVals=stringAddVals+" Then add carry value "+carryVal;
		}
	}
	document.getElementById("answerMsg").innerHTML=stringAddVals;
	writeToStorage(stringAddVals);
	return;
}

function buildAddHint(addCol) 
{
	/*
	 * Builds the hint for adding columns
	 * Should be called before the next input cell displays
	 */
	var stringAddVals="";
	var addFlag=true;
	var i, prodVal,numToAdd;
	var prevProdVal="";
	var doneWithAdd;
	var numRows=document.getElementById("hiddentimesentry").innerHTML.length;
	
	addCol=Number(addCol)+1;
	
	for (i=0;i<numRows;i++) {
		prodVal=document.getElementById("prod"+String(i)+String(addCol)).innerHTML;
		if (prodVal !="") numToAdd=true;
		if (i==numRows-1) {
			if (prodVal != "" && prevProdVal !="") 
				stringAddVals=stringAddVals+"+" +prodVal;
			if (prodVal != "" && prevProdVal =="") {
				stringAddVals=stringAddVals+"+"+prodVal;
				addFlag=false;
			}	
			if (prodVal == "" && prevProdVal =="") {
				//stringAddVals=stringAddVals+"+"+prodVal;
				addFlag=false;
			}
			if (prodVal == "" && prevProdVal !="") {
				stringAddVals=stringAddVals+"+"+prevProdVal;
				addFlag=false;
			}	
		} else {
			if (i==0 && prodVal != "") {
				stringAddVals=stringAddVals+prodVal;
			} else if (i>0 && prodVal != "") {
				stringAddVals=stringAddVals+"+" +prodVal;
			}
			prevProdVal=prodVal;
		}
	}
	if (addCol > 0) {
		//carry exists possibly
		if (document.getElementById("addCarry"+String(addCol).innerHTML) == "") {
			addCarryVal="";
		} else {
			addCarryVal=Number(document.getElementById("addCarry"+String(addCol)).innerHTML);
		}	
		if (addCarryVal != 0) {
			stringAddVals=addCarryVal+"+" +stringAddVals;
			addFlag=true;
		}
		if (addFlag) stringAddVals="Add: "+stringAddVals;
		if (!addFlag) {
			var numTest=stringAddVals.charAt(0);
			if (isNaN(numTest)) {
				stringAddVals=stringAddVals.slice(1);
			} 
			numTest=stringAddVals.charAt(stringAddVals.length-1);
			if (isNaN(numTest)) {
				stringAddVals=stringAddVals.slice(0,2);
			}
			stringAddVals="Enter: "+stringAddVals;
		}
		//remove any ++ combos
		var testStr=stringAddVals;
		stringAddVals=testStr.replace("++","+");
	}
	document.getElementById("answerMsg").innerHTML=stringAddVals;
	writeToStorage(stringAddVals);
	return;
}

function doAddCols(doneFlag)
{
	/*
	 * adds individual columns with product results, carry vals
	 */
		
	var colToAdd;
	var hintMsg;
	var ansHintId;
	var stringAddVals="Add: ";
	var ansEntry;
	var carryEntry="";
	var addCol,carryLoc,ansLoc, computeAns,inputAns, carryCol, testCol, testLoc;
	var i, numRows;
	var addCarryVal=0;
	var prodVal=0;
	var parentCell;
	var lastCol=false;
	var finalProduct=document.getElementById("hiddenfinalproduct").innerHTML;
	var currentEntry;
	var strikeCell; //jcs111616 test to strike out carry
	var colLimit=document.getElementById("hiddentotaladdcols").innerHTML;
	var prefix="Error-Expected: ";
	var prefix2=", entered: ";
	//jcs010917 need to find prod row
	var numRows=document.getElementById("hiddentimesentry").innerHTML;
	var bottomProdRow=numRows.length-1;
	var prodId, prodCell;
	
	addCol=document.getElementById("hiddenaddcol").innerHTML; //current col to be added
	ansEntry=document.getElementById("sumInput").value; //Number entered in the input box
	
	if (addCol=="0") {
		//First column has no carry and is always added to 0
		prodVal=document.getElementById("prod00").innerHTML;
		if (prodVal != ansEntry) {
			document.getElementById("redoMsg").innerHTML="Wrong answer. Try again";
			document.getElementById("redoMsg").style.display="";
			document.getElementById("prodInput").value="";  //jcs120916 clear wrong answers and refocus
			document.getElementById("carryInput").value="";
			document.getElementById("prodInput").focus();
		} else {
			//correct answer: increment addcol, remove input attrib
			parentCell=document.getElementById("sum0");
			parentCell.removeChild(parentCell.childNodes[0]);
			parentCell.innerHTML=ansEntry;
			//set addCol hidden var to next column
			document.getElementById("hiddenaddcol").innerHTML=Number(addCol)+1;
			//play different sounds 
			buildAddHint(addCol);
			playSound("midway");
			doneFlag=nextAddCol(); //jcs010817 test make sure that doneflag value changes 
		}
		return (doneFlag);
	}
	
	carryCol=Number(addCol)+1;
	
	//jcs010817 these 6 lines are a test
	if (document.getElementById("carryInput")) {
		carryEntry=document.getElementById("carryInput").value;
		if (carryEntry == null || carryEntry ==undefined)
			carryEntry="";	//jcs111916 carryEntry=0;
		inputAns=String(carryEntry)+String(ansEntry);			
	} else
		inputAns=String(ansEntry);			

	computeAns=0;
	numRows=document.getElementById("hiddentimesentry").innerHTML.length;
	//for (var j=0;j<;j++)	//loop thru columns
	for (i=0;i<numRows;i++) {
		prodVal=document.getElementById("prod"+String(i)+addCol).innerHTML;
		computeAns=computeAns+Number(prodVal);
	}
	//jcs010817 this test may be redundant
	if (document.getElementById("addCarry"+addCol)) {
		addCarryVal=document.getElementById("addCarry"+addCol).innerHTML;			
		computeAns=computeAns+Number(addCarryVal);
	}	
	
	if (Number(inputAns) != computeAns) {
		//3232017: check if digits were reversed
		var correctAns=checkForReverseDigits(inputAns,computeAns);
		if (correctAns==2) {
			//digits may have been reversed
			document.getElementById("redoMsg").innerHTML="You're close: " + inputAns+ 
						".<br /> Put the 1s digit in the box below the line. <br />" +
								"The 10s digit goes in the carry box.";			
		} else {
			document.getElementById("redoMsg").innerHTML="Wrong answer. Try again";
		}
		document.getElementById("redoMsg").style.display="";
		writeToStorage(prefix.bold().fontcolor("red")+String(computeAns).bold().fontcolor("red")+prefix2.bold().fontcolor("red")+inputAns.bold().fontcolor("red"));  //jcs121016 set result to red
		playSound("errsound");
		document.getElementById("sumInput").value=""; //jcs121016 clear wrong answers and refocus
		document.getElementById("carryInput").value="";
		document.getElementById("sumInput").focus(); 
		return;
	} else {
		document.getElementById("redoMsg").innerHTML="";
		//jcs111616 test to strike out carry
		if (addCarryVal) {
			strikeCell=document.getElementById("addCarry"+addCol);
			strikeCell.className="struck";
		}
	}
	
	//play success sound
	playSound("midway");

	//correct answer: increment addcol, remove input attrib
	ansLoc="sum"+addCol;
	var parentCell=document.getElementById(ansLoc);
	parentCell.removeChild(parentCell.childNodes[0]);
	parentCell.innerHTML=ansEntry;
	
	//jcs111916 test for carry in sum row
	testCol=Number(addCol)+1;
	testLoc=document.getElementById("sum"+testCol);
	if (testLoc) {
		if (testLoc.childElementCount>0) { //jcs111916 yes means remove from sum row, otherwise from carry
			parentCell=testLoc;
		} else {
			carryLoc="addCarry"+String(Number(addCol)+1);
			parentCell=document.getElementById(carryLoc);
		}
	
		if (parentCell.childElementCount>0) {
			parentCell.removeChild(parentCell.childNodes[0]);
			if (carryEntry=="0") carryEntry="";
			parentCell.innerHTML=carryEntry;
		}
	}		

	//jcs111416 test sum
	currentEntry=testSum(testCol);
	//jcs010917 get bottom prod row and check if it's empty
	prodId="prod"+String(bottomProdRow)+String(testCol);
	prodCell=document.getElementById(prodId);

	
	if ((Number(currentEntry)==Number(finalProduct))&&(prodCell.innerHTML=="")) {
		setColColor (addCol, "gray"); 
		var decimalPlace=checkForDecimal();
		if (decimalPlace != 0) {
			//set special msg for decimal point input
			setDecimalPrompt();
			document.getElementById("decimalarea").style.display="";
			//play success bell sound
			playSound("midwaywinsound");
		} else if (decimalPlace==0) {
			successFinish();
			doneFlag=true;  //jcs120916 Added doneFlag to test for early finish
		}
		return;	
	}

	//increment addCol hidden var
	document.getElementById("hiddenaddcol").innerHTML=Number(addCol)+1;	
	//display next step hint 
	buildAddHint(addCol);
	lastCol=nextAddCol();
	if (lastCol) {
		//check for decimal flag and user places decimal point START HERE		
		setColColor (addCol, "gray"); //jcs111716 change final column color
		var decimalPlace=checkForDecimal();
		if (decimalPlace != 0) {
			//set special msg for decimal point input
			var decimalSpecialMsg=setDecimalPrompt();
			document.getElementById("decimalpoint").innerHTML=
				decimalSpecialMsg+document.getElementById("decimalpoint").innerHTML;
			document.getElementById("decimalarea").style.display="";
			//play success bell sound
			playSound("midwaywinsound");
		} else if (decimalPlace==0) {
			successFinish();
			doneFlag=true;  //jcs120916 Added doneFlag to test for early finish
		}

		document.getElementById("answerMsg").innerHTML="Congratulations!";
		//display next problem button
		displayNextProblem();
	}
	return(doneFlag); //jcs010817 test
}

function setDecimalPrompt()
{
	var message;
	var decimalMsg=[];
	decimalMsg[0]="You're almost done. Just pick where the decimal goes. \<br>";
	decimalMsg[1]="You're doing great. One more step to go. \<br>";
	decimalMsg[2]="Last step. All you need is the decimal point. \<br>";
	
	var randomNum = Math.floor((Math.random() * 2) + 1);
	message=decimalMsg[String((randomNum)-1)];
	document.getElementById("decimalpoint").innerHTML=
		message+" Select the correct answer: ";
	return;
}

function successFinish()
{
	/*
	 * displays successful finish message
	 */
	playSound("winsound");
	document.getElementById("answerMsg").innerHTML="Congratulations!";	
	document.getElementById("answerMsg").style.display="";
	writeToStorage("Problem solved successfully.");
	displayNextProblem();
	return;
}

function nextAddCol() { 
	/* 
	 * displays next column to add
	 *  returns indicator if there are no more columns to add 
	*/ 
	var addCol,newCol, timesEntry, doneFlag, row, testCol, testCell, testVal; 
	addCol=document.getElementById("hiddenaddcol").innerHTML;
	newCol=Number(addCol)+1; 
	setColColor (addCol-1, "gray"); //jcs111716 change previous column color
	setColColor (addCol, "black"); //jcs111716 change new column color
	//jcs122216 change colLimit
	//colLimit=document.getElementById("hiddenanswerlength").innerHTML;
	//jcs010417 new way of getting colLimit
	var colLimit=document.getElementById("hiddentotaladdcols").innerHTML;
	colLimit=Number(colLimit);
	
	if (newCol>colLimit) {
		doneFlag=true;
		return(doneFlag);
	} 
	
	//jcs111916 add input cells. Check location of carry input cell
	appendInput("sum"+addCol,"sumInput","sumCell"); 
	if (newCol<(colLimit-1))
		//jcs010817 in this case carry input box is in addCarry row
		appendInput("addCarry"+newCol,"carryInput","carryCell");
	if (newCol==(colLimit-1)) {
		row=document.getElementById("hiddentimesentry").innerHTML.length;
		row--;
		testCell="prod"+String(row)+String(newCol);
		testVal=document.getElementById(testCell).innerHTML;
		//jcs010817 in this case carry input box may be in sum row or addCarry row
		// possibility of a bug here
		if (testVal) {
			appendInput("addCarry"+newCol,"carryInput","carryCell");
		} else {
			appendInput("sum"+newCol,"carryInput","carryCell");
		}
	}		
	//jcs011017 test
	if (newCol>=colLimit) {
//	if (newCol>colLimit) {
		appendInput("sum"+newCol,"carryInput","carryCell");	
	}
	
	return(doneFlag); 
}

function setValInRow(rowName,entryNum)
{
	var singleDigit, multcellID;
	var i, decimalFound, colAdjust;
	var numberNoDec="";
	var decLoc;
	
	//numLen=0;
	multcellID=rowName+"0";
	decimalFound=false;
	colAdjust=0;
	var decPt="\<strong>.\</strong>";

	decLoc=entryNum.indexOf(".");
	if (decLoc>-1) {		
		numberNoDec=entryNum.slice(0,decLoc);
		numberNoDec=numberNoDec+entryNum.slice(decLoc+1);
	} else {
		numberNoDec=entryNum;		
	}
	
	for (i=0;i<entryNum.length;i++) {
		singleDigit=entryNum.charAt(entryNum.length-(i+1));
		if (singleDigit==".") {
			decimalFound=true;
			document.getElementById(multcellID).innerHTML=decPt+
					document.getElementById(multcellID).innerHTML;
		} else {
			if (decimalFound) {
				colAdjust=i-1;
			} else {
				colAdjust=i;
			}
			multcellID=rowName+String(colAdjust);
			document.getElementById(multcellID).innerHTML=singleDigit;
		}
	}

	return(numberNoDec);
}

function buildTable (topLength, timesLength) {
	
	var rows=topLength+6;
	var cols=topLength+timesLength;
	var newTable= document.getElementById("solvemultiply");
	var prefix = ["carry", "top", "times", "addCarry", "prod", "sum"];
	var i;
		
	for (i=0; i<6; i++) {
	createRows (newTable, prefix[i], rows, timesLength, cols);
	}
	
	var underRow=document.getElementById("timesRow");
	underRow.setAttribute("class","under");
	var overRow=document.getElementById("addCarryRow");
	overRow.setAttribute("class","over");
	document.getElementById("addCarryRow").style.display="none";
	document.getElementById("sumRow").style.display="none";

	insertInputs(topLength, timesLength);

	//jcs101216 need x in times row
	var timesSign="times"+(cols-1);
	document.getElementById(timesSign).innerHTML="x";

	return;	
}

function createRows (newTable, prefix, rows, timesLength, cols) {
	
	var i;
	var newRow=document.createElement("tr");
	if ((prefix=="carry")||(prefix=="prod")) {
		rowBuilder(newTable, prefix, timesLength, cols);
	} else {
		newRow.id=prefix+"Row";
		newRow.style.color="gray";
		newTable.appendChild(newRow);
		createCells (newRow, prefix, cols);			
	}
	return;
}	

function rowBuilder(newTable, prefix, timesLength, cols) {
	var newRow;
	var i;
	var j;
	var k;
	var endRow;
	var cellPrefix; //jcs122216 test
	
	if (prefix=="carry") {
		i=timesLength-1;	
		j=-1;
		endRow=-1; 
	} else {
		i=0;
		j=1;
		endRow=timesLength;
	}

	k=0;
	while (i != endRow) {
		newRow=document.createElement("tr");
		newRow.id=prefix+"Row"+i;
		
		//jcs101116 put italics font and purple color in carry row
		if (prefix=="carry") {
			newRow.className="carryRow";
		}

		//jcs101116 put gray color in prod row
		if (prefix=="prod") {
			newRow.className="prodRow";
		}

		newTable.appendChild(newRow);
		cellPrefix=prefix+i;			
		createCells (newRow, cellPrefix, cols);
		i=i+j;
		k++;
	}
	return;
}

function createCells (newRow, prefix, cols) {
	
	var i;
	for (i=cols; i>-1; i--) {
		newCell=document.createElement("td");
		newCell.id=prefix+i;
		if (prefix=="carry") {
			newCell.style.color="purple";
		}	
		newRow.appendChild(newCell);
	}
	return;
}

function insertInputs(topLength, timesLength) {
	var newCell;
	var cell;

	if ((topLength==1)&&(timesLength==1)) {
		appendInput("prod01", "carryInput", "carryCell");
		document.getElementById("hiddencarrycell").innerHTML="prod01";
	} else {
		appendInput("carry01", "carryInput", "carryCell");
		document.getElementById("hiddencarrycell").innerHTML="carry01";
	}
	appendInput("prod00", "prodInput", "cell");	//jcs111916
	
	document.getElementById("hiddenrow").innerHTML="0";
	document.getElementById("hiddenprodcol").innerHTML="0";

	//jcs101216 load the new factors and set highlight color
	document.getElementById("hiddentopfactor").innerHTML="top0";
	document.getElementById("top0").style.color="black"; 
	document.getElementById("hiddentimesfactor").innerHTML="times0";
	document.getElementById("times0").style.color="black"; 
	
	//jcs102616 
	document.getElementById("hiddenprodcell").innerHTML="prod00";					
	document.getElementById("hiddenprodcol").innerHTML="0";					
	document.getElementById("hiddentopcol").innerHTML="0";					
	document.getElementById("hiddentimescol").innerHTML="0";					
	return;
}

function getProdAns (currentID) 
{
	var x=1;
}


function changeCell (startSum) {
	
	var topEntry=document.getElementById("hiddentopentry").innerHTML;
	var topEntryLen=topEntry.length;
	var timesEntry=document.getElementById("hiddentimesentry").innerHTML;
	var timesEntryLen=timesEntry.length;

	var currentRow=document.getElementById("hiddenrow").innerHTML;
	var maxInputCol=topEntryLen+Number(currentRow);
	var timesNum=Number(currentRow);
	var currentTopCol=document.getElementById("hiddentopcol").innerHTML; //ID of current column
	var topNum=Number(currentTopCol); //current top number
	//is this needed? var carryinput=document.getElementById("hiddencarryinput").innerHTML;
	//jcs110816 new variable
	var currentProdCol=document.getElementById("hiddenprodcol").innerHTML; //ID of current column
	var prodColNum=Number(currentProdCol); //current top number	
	var colCtr=0; //keeps track of column in product area
	var newinput;
	var prodCell;
	var cell;
	var topLoc, timesLoc;
	var startSum=0;
	var carryLoc=document.getElementById("hiddenprevcarry").innerHTML;
	
	topLoc=document.getElementById("hiddentopfactor").innerHTML; // get ID for current top number
	document.getElementById(topLoc).style.color="gray"; // turn it gray

	//jcs110816 test if (topNum<(topEntryLen+timesNum-1)) {  
	if (topNum<(topEntryLen-1)) {  
	// next cell is 1 col to the left
		// change new cell to black
		topNum++; // calculate new top number
		topLoc="top"+topNum; // create ID for new top number
		document.getElementById("hiddentopfactor").innerHTML=topLoc; // set topfactor var to new top number ???TODO Number not a location
		//document.getElementById("hiddenprodcol").innerHTML=String(topNum); // set current col var to new top number ???TODO Number not a location
		document.getElementById(topLoc).style.color="black"; // turn new top number black
		
		prodColNum++; //jcs110816 increment prod col location
		prodCell="prod"+String(timesNum)+prodColNum;
		appendInput(prodCell, "prodInput", "cell"); //jcs111916 new function to append input element

		//jcs102616 test
		//jcs110716 document.getElementById("hiddenprodcell").innerHTML=prodCell;					
		document.getElementById("hiddenprodcol").innerHTML=String(prodColNum);					
		document.getElementById("hiddentopcol").innerHTML=String(topNum);					
	
	} else {
		//jcs112816 check for single-digit times factor
		if (timesEntryLen==1)	{
			document.getElementById("times0").style.color="gray"; 
			return(1);
		}
		document.getElementById("top0").style.color="black"; //turn reset top number to top0
		topNum=0;
		document.getElementById("hiddentopfactor").innerHTML="top0"; 
		// change times number
		timesLoc="times"+currentRow; // create ID for old times number
		document.getElementById(timesLoc).style.color="gray"; // turn current times number gray
		timesNum++; // calculate new times number
		timesLoc="times"+timesNum; // create ID for new times number
		document.getElementById("hiddentimesfactor").innerHTML=timesLoc; // set timesfactor var to new one
		document.getElementById("hiddenrow").innerHTML=String(timesNum); // set current times var to new one
		maxInputCol=topEntryLen+Number(timesNum); //jcs111716 test Number() need to increment maxinputcol if row has changed
		document.getElementById(timesLoc).style.color="black"; 
		if (timesNum==timesEntryLen) {	//No more multiplications, Start adding
			startSum=2;
			document.getElementById("top0").style.color="gray"; // turn current times number gray
			document.getElementById(timesLoc).style.color="gray"; // turn current times number gray
			 setupSum(); //jcs101216 change from multiplying to adding
			return(2);
		}
		
		//pad new product row with zeros	
		while (colCtr < timesNum) {	//pad right cells with zero
			prodCell="prod"+String(timesNum)+String(colCtr);
			document.getElementById(prodCell).innerHTML="0";
			colCtr++;
		}
		//topNum=colCtr;
		topLoc="top"+topNum; // create ID for new top number
		prodCell="prod"+String(timesNum)+String(colCtr);
		appendInput(prodCell, "prodInput", "cell"); //jcs111916 changed input to prodInput

		//jcs102616 test
		//document.getElementById("hiddenprodcell").innerHTML=prodCell;					
		document.getElementById("hiddentopfactor").innerHTML=topLoc; // set topfactor var to new top number
		document.getElementById("hiddenprodcol").innerHTML=String(colCtr);					
		document.getElementById("hiddentopcol").innerHTML=String(topNum);					
		document.getElementById("hiddentimescol").innerHTML=String(timesNum);					
	}
	
	document.getElementById("hiddenprodcell").innerHTML=prodCell;
	if (colCtr) {
		getCarryCell(colCtr, timesNum, maxInputCol); //get carry cell location
	} else {
		getCarryCell(prodColNum, timesNum, maxInputCol); //jcs110816 get carry cell location jcs110816
	}
	return(startSum);
}	

	
function getCarryCell(carryCol, timesNum, maxInputCol) {
	/*
	 * find next carry cell
	 */
	//var carryCol=topNum+1;
	var carryRow=0;
	var carryCell;
	var foundIt=false;
	var foundCell;
	var newInput;
	
	carryCol++;
	
	/* jcs111016 This puts the carry cell in the prod row. */
	if (carryCol==maxInputCol) {	//input element is as far as it goes on the left
		carryCell="prod"+String(timesNum)+String(carryCol);	//carry parent goes in prod row
		appendInput(carryCell, "carryInput", "carryCell"); //jcs111916 test
		document.getElementById("hiddenleftcarrycol").innerHTML=carryCell;
		return;
	}
		
	//jcs102716 need to get old carry
	//TODO var prevcarry=document.getElementById("hiddencarryval");
		
	while (foundIt==false) {	// carry input goes to first available cell in carry rows 
		carryCell="carry"+String(carryRow)+String(carryCol);
		if (document.getElementById(carryCell).innerHTML) { //carry cell is occupied. Go one higher
			carryRow++;
		} else {
			foundIt=true;
		}
	}
	// reference carry cell location and append input field
	foundCell=document.getElementById(carryCell);
	appendInput(carryCell, "carryInput", "carryCell"); //jcs110316 new function to append input element
	document.getElementById("hiddencarrycell").innerHTML="carry"+String(carryRow)+String(carryCol);
	return;
}

function setupSum () {
	
	var congratMsgs=[];
	var randomNum, colLimit;
	
	document.getElementById("hiddenaddcol").innerHTML="0";
	document.getElementById("addCarryRow").style.display="";
	document.getElementById("addCarryRow").style.color="purple";
	document.getElementById("addCarryRow").className="carryRow";	//jcs111616 set row to purple italics
	document.getElementById("sumRow").style.display="";
	appendInput("sum0", "sumInput", "sumCell");
	
	//build special msg when transitioning to adding from multiplying
	congratMsgs[0]="Good job! You're almost done. \<br>";
	congratMsgs[1]="Great! You're done with multiplying. Get ready to add. \<br>";
	congratMsgs[2]="Nice going. You just have to add the columns. \<br>";
	congratMsgs[3]="Terrific. Now add the columns and you're done. \<br>";
	randomNum = Math.floor((Math.random() * 4) + 1);

	//play success bell sound
	playSound("midwaywinsound");

	var ansHintId=document.getElementById("answerMsg");
	ansHintId.innerHTML = congratMsgs[String((randomNum)-1)]+"Add each column from right to left.";
	
	setColColor (0, "black"); //jcs111716 change column color
	
	//jcs010417 get total number of cols to add
	colLimit=getTotalAddCols();
	document.getElementById("hiddentotaladdcols").innerHTML=colLimit;
	
	return;
}


function appendInput(parent, child, classID){
	/*
	 * Takes a parent string with a 2-digit suffix, child name,
	 * and class. Creates an input element with the same suffix and
	 * appends it to the parent
	 */
	
	var parentCell, newParentCell;
	var newInput;
	
	//03182017: get fromMobile value from hidden vars
	var fromMobile=document.getElementById("hiddenfrommobile").innerHTML;

	parentCell=document.getElementById(parent);
	//jcs010917 if parent does not exist return
	if ((!parentCell)&&(classID=="carryCell"))
		return;
	newInput=document.createElement("input");	
	newInput.placeholder="?";
	newInput.id=child;
	newInput.className=classID;
	
	//03092017: add new attriute to newInput for using keypad entry
	//	this.id references the new child field
	//03182017: test for coming from mobile device
	if (fromMobile) {
		newInput.setAttribute("type","number");
	} else {
		newInput.setAttribute("onfocus","typeInEntryField(this.id)");
	}
	
	parentCell.appendChild(newInput);
	
	//jcs120116 change to switch statement
	switch (classID){
	case "cell":
		newInput.setAttribute("onkeyup", "getProdEntry()");
		document.getElementById("prodInput").focus();
		break;

	case "carryCell":
		newInput.setAttribute("onkeyup", "getCarryEntry()");
		document.getElementById("carryInput").focus();
		break;

	case "sumCell":
		newInput.setAttribute("onkeyup", "getSumEntry()");
		document.getElementById("sumInput").focus();
		break;
	}

	return;
}


function stripNumbers(stringWithNums)
{
	/*
	 * Strips off numbers at end of string and returns them
	 * Returns empty string if no numbers found at end of passed in string
	 */
	var foundNums="";
	var i;
	var x="";
	var number;
	
	i=stringWithNums.length;
	while (!number) {
		i--;
		x=stringWithNums.charAt(i);
		number=isNaN(x);		
	}
	foundNums=stringWithNums.slice(i+1);
	return(foundNums);
}

//jcs111416 test sum
function testSum(addCol) {
	var i;
	var userAnswer="";

	for (i=addCol; i>-1; i--) {
		sumLoc="sum"+i;
		if ((document.getElementById(sumLoc))&&(document.getElementById(sumLoc).innerHTML))
			userAnswer=userAnswer+document.getElementById(sumLoc).innerHTML;
	}
	return(userAnswer);		
}

//jcs111716 changes a column to a given color: black or gray
function setColColor (col, color) {
	var numRows=document.getElementById("hiddentimesentry").innerHTML;
	var lastRow=numRows.length;
	var i, cell;

	for (i=0; i<lastRow; i++) {
		cell="prod"+String(i)+String(col);
		document.getElementById(cell).style.color=color;
	}
	return;
}

function getProdEntry() {
	var topLoc=document.getElementById("hiddentopfactor").innerHTML;
	var topCellVal=document.getElementById(topLoc).innerHTML;
	var timesLoc=document.getElementById("hiddentimesfactor").innerHTML;
	var timesCellVal=document.getElementById(timesLoc).innerHTML;
	var prodEntry=document.getElementById("prodInput").value;
	var carryEntry=document.getElementById("carryInput").value;
	var answer, tempVal, doneFlag; //jcs120916 Added doneflag to test for early finish
	var prevCarryLoc=document.getElementById("hiddenprevcarry").innerHTML;
	
	tempVal = timesCellVal.charAt(timesCellVal.length-1);
	timesCellVal=tempVal;
	tempVal = topCellVal.charAt(topCellVal.length-1);
	topCellVal=tempVal;
	
	answer=Number(topCellVal)*Number(timesCellVal);

	if (prevCarryLoc) { //jcs120916 need to handle cases with previous carry value
		prevCarryEntry=document.getElementById(prevCarryLoc).innerHTML;
		answer=answer+Number(prevCarryEntry);
	}
	
	if (prodEntry!="") {		
		if ((answer<10)||(carryEntry>0)) {
			doNextMult(doneFlag);  //jcs120916 Added doneflag to test for early finish
			if (!doneFlag)
				document.getElementById("prodInput").focus();
			return;
		}

		if (carryEntry=="")
			document.getElementById("carryInput").focus(); 
	}		
	return;
}

function getCarryEntry() {
	var prodEntry, sumEntry, doneFlag; //jcs120916 added doneFlag
	var sumCell=document.getElementById("sumInput");
	
	//jcs112916 if no prod entry focus on field
	if (!sumCell) {
		prodEntry=document.getElementById("prodInput").value;
		if (prodEntry=="") {
			document.getElementById("prodInput").focus();
			return;
		} else {
			doNextMult(doneFlag);
			if (!doneFlag)
				document.getElementById("prodInput").focus();  
			return;
		}
	} 
		
	if (sumCell) {
		sumEntry=document.getElementById("sumInput").value;
		if (sumEntry=="") {
			document.getElementById("sumInput").focus();
			return;
		} else {
			doAddCols(doneFlag);
			if (!doneFlag)
				document.getElementById("sumInput").focus();
			return;
		}
	}
}

function getSumEntry() {
	var sumEntry=document.getElementById("sumInput").value;
	var carryEntry;
	var addCol=document.getElementById("hiddenaddcol").innerHTML;
	var answer;
	
	answer=getColSum(addCol);

	if (answer<10) {
		doAddCols();		
		document.getElementById("sumInput").focus();
		return;
	} else {
		carryEntry=document.getElementById("carryInput").value;
		if (carryEntry=="") {
			document.getElementById("carryInput").focus();
			return;
		} else {
			doAddCols();		
			document.getElementById("sumInput").focus();
			return;
		}	
	} 
}

//jcs111716 changes a column to a given color: black or gray
function getColSum(col) {
	var numRows=document.getElementById("hiddentimesentry").innerHTML;
	var lastRow=numRows.length;
	var i, cell, prodVal;
	var sum=0;

	for (i=0; i<lastRow; i++) {
		cell="prod"+String(i)+String(col);
		prodVal=document.getElementById(cell).innerHTML;
		sum=sum+Number(prodVal);
	}
	
	var carryVal=document.getElementById("addCarry"+col).innerHTML;
	if (carryVal>0)
		sum=sum+Number(carryVal);
	return(sum);
}

function testForReturn(event) {
	var key=event.which;
	if (key==13) {
		getMultEntry();
		if (document.getElementById("prod00").childElementCount>0)
			document.getElementById("prod00").focus();	//jcs010817 
		return;
	} else
		return;
}

//jcs010417 col col limit by finding end of bottom prod row
function getTotalAddCols(){
	var numRows=document.getElementById("hiddentimesentry").innerHTML;
	var bottomProdRow=numRows.length-1;
	var i, prodCell, prodId;
	var topLen=document.getElementById("hiddentopentry").innerHTML.length;
	var timesLen=document.getElementById("hiddentimesentry").innerHTML.length;
	var numColLimit=topLen + timesLen;
	
	for (i=0; i<numColLimit; i++) {
		prodId="prod"+String(bottomProdRow)+String(i);
		prodCell=document.getElementById(prodId);
		if (prodCell.innerHTML) 
			totalAddCols=i+1;
		else
			return(totalAddCols);
	}
	return(totalAddCols);
}

//jcs010817 adds zero to sum row as needed
function addZeros(decimalPlace) {
	var i=decimalPlace-2;
	var testContent;
	for (i; i>0; i--) {
		testContent=document.getElementById("sum"+String(i));
		if (testContent.innerHTML=="")
			testContent.innerHTML="0";
		else
			return;
	}	
}
