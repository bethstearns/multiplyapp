/*
 * Math Assister
 * Copyright (c) 2016 by John and Beth Stearns, J&B Software
 */
var element = new pe;
var elementArray = [];
var selExpType;
var opType;
var equationFlag;
var prevStepsArray=[];

//bts 09162015: add global vars to time problem solving
var solveTimer;
var timerIsOn=0;

//bts 09162015: functions for timing problem solving elapsed time
function startSolveTimer()
{
	/*
	 * Starts timer for recording how long it takes to solve a problem 
	 */
    if (!timerIsOn) {
    	timerIsOn = 1;
        timedCount();
    }	
	return;
}
function timedCount() 
{
	var count;
    count=document.getElementById("problemTimer").value;
    if (!count || count==undefined || count==null) count=0;
    count++;
    document.getElementById("problemTimer").value=count;
    
	var mins=count/60;
	var strMins=mins.toFixed(0);
	var secs=(count % 60)/100;
	var fSecs=secs.toFixed(2);
	var pSecs=fSecs.slice(2);
	var formatElapsedTime=strMins+":"+pSecs;

    document.getElementById("problemTimer").innerHTML="Elapsed time: "+
    			formatElapsedTime;
    solveTimer = setTimeout(function(){timedCount();}, 1000);
    return;
}
function stopCount() {
    clearTimeout(solveTimer);
    timerIsOn = 0;
    return;
}

function writeToBoard(textToDisplay)
{	
	var node=document.createElement("p");
	var textnode=document.createTextNode(textToDisplay);
	node.appendChild(textnode);
	document.getElementById("expressionLine").appendChild(node);
	return;
}

function writeCancelMark(objectPt, newNumber, numeratorIndicator, arrayLength)
{
	//arrayLength - length of elementArray before removing calc answer
	//objectPt- point in prev expression for cancelling numerator or denominator
	// numeratorIndicator- true indicates numerator; false is denominator
	//newNumber; new numerator or denominator
	
	var expnTableEl;
	expnTableEl=document.getElementById("expnTable");
	var list=expnTableEl.getElementsByTagName("td");
	
	var strikelength = 1; // will always have only 1 cell to handle
	var j;
	var x = list.length-arrayLength;
	x = x+Number(objectPt)-1;
	var y = x+strikelength;
	
	var cellText, tempText;
	var slashPtr;
	var htmlSlashPtr=0;
	var trueSlash, strLen;
	
	var newNumberString = String(newNumber);
	
	for (j=x;j<y;j++){
		// use textContent instead of innerHTML
		slashPtr = list[j].textContent.indexOf("/");
		//slashPtr=-1: whole number
		if (slashPtr == -1) {
			cellText = list[j].textContent.fontcolor("red").strike().sup();
			newNumberString=newNumberString.sup().fontcolor("blue");
			list[j].innerHTML=newNumberString+" "+cellText+"/1";
			return;
		}

		if (numeratorIndicator) { 
			// change fontcolor of cell text before the slash
			// newNumber is the new numerator or denominator			
			// find denominator portion within innerhtml
			strLen = list[j].innerHTML.length-1;
			trueSlash = false;
			while (!trueSlash) {
				htmlSlashPtr = list[j].innerHTML.lastIndexOf("/",strLen);
				if (list[j].innerHTML.charAt(htmlSlashPtr-1)=="<") {
					strLen = htmlSlashPtr-1;
					if (strLen < slashPtr) trueSlash=true;
				} else {
					trueSlash=true;
				}
			}
			cellText = list[j].textContent.slice(0,slashPtr).fontcolor("red").strike().sup();
			tempText = list[j].innerHTML.slice(htmlSlashPtr);//denominator portion
			newNumberString=newNumberString.sup().fontcolor("blue");
			list[j].innerHTML=newNumberString+" "+cellText+tempText;
		} else {
			//change fontcolor of cell contents after the slash
			// find denominator portion within innerhtml
			var slashPtrText = slashPtr;
			strLen = list[j].innerHTML.length-1;
			trueSlash = false;
			while (!trueSlash) {
				htmlSlashPtr = list[j].innerHTML.lastIndexOf("/",strLen);
				if (list[j].innerHTML.charAt(htmlSlashPtr-1)=="<") {
					strLen = htmlSlashPtr-1;
					if (strLen < slashPtrText) trueSlash=true;
				} else {
					trueSlash=true;
					slashPtr = htmlSlashPtr;
				}
			}			
			cellText = list[j].innerHTML.slice(slashPtr+1).fontcolor("red").strike();
			tempText = list[j].innerHTML.slice(0,slashPtr+1);//numerator with formatting
			list[j].innerHTML=tempText+cellText+" "+newNumberString.sub().fontcolor("blue");			
		}
	}
	return;
}

function addAsterisk(expArray)
{
	var i=1;
	var j;
		
	while (expArray[i] != null)
	{	
		// j always reflects current length of expArray
		j = expArray.length;
	 	switch(expArray[i]) 
	 	 {
	 	 	case "[":
	 	 	 	// check previous element right bracket/paren. If so,
	 	 	 	// assume multiplication; insert asterisk at current position
	 	 		// check if prev element is number or variable.
	 	 	 	if (expArray[i-1] == "]" || expArray[i-1]==")") {
	 	 	 		expArray.splice(i,0,"*");
	 	 	 		i++;
	 	 	 	} 
	 	 	 	else if (parseString(expArray[i-1],4) !== null){ //variable
	 	 	 		expArray.splice(i,0,"*");
	 	 	 		i++;
	 	 	 	} else if (parseString(expArray[i-1],2)!==null){
	 	 	 		expArray.splice(i,0,"*");
	 	 	 		i++;
	 	 	 	} 	 	 	
	 	 		break;
	 	 	 case "(":
	 	 	 	if (expArray[i-1] == "]" || expArray[i-1]==")") {
	 	 	 		expArray.splice(i,0,"*");
	 	 	 		i++;
	 	 	 	} 
	 	 	 	else if (parseString(expArray[i-1],4)!==null) { //variable
	 	 	 		expArray.splice(i,0,"*");
	 	 	 		i++;
		 	 	} else if (parseString(expArray[i-1],2)!==null){
	 	 	 		expArray.splice(i,0,"*");
	 	 	 		i++;
	 	 	 	} 
	 	 	 	break;	
	 	 	case ")":
	 	 		 // next element is number; add asterisk for multiplication
	 	 		 if (i < j-1) {
	 	 			 if (parseString(expArray[i+1],2)!==null){
		 	 	 		expArray.splice(i+1,0,"*");
		 	 	 		i++;
		 	 	 		j++;
	 	 			 } else if (parseString(expArray[i+1],4)!==null){
			 	 	 	expArray.splice(i+1,0,"*");
			 	 	 	i++;
		 	 	 		j++;
		 	 		 }	 	 				 
	 	 		 }
		 	 	 break;	
	 	 	case "]":
	 	 		 // next element is number; add asterisk
	 	 		 if (i < j-1) {
	 	 			 if (parseString(expArray[i+1],2)!==null){
		 	 	 		expArray.splice(i+1,0,"*");
		 	 	 		i++;
	 	 			 } else if (parseString(expArray[i+1],4)!==null){
				 	  	expArray.splice(i+1,0,"*");
				 	  	i++;
			 	 	 }	 	 				 
	 	 		 }
		 	 	 break;	
	 	 }
	 	i++;
	}	
	return(expArray);
}

function checkArrayNumeric(testArray)
{
	var arraynumeric = [];
	var i = 0;
	var j=0;
	var opmatchprev;
	opmatchprev=0;
	
	if (testArray.length == 3){
		arraynumeric = testArray;
	} else {
		while (i < testArray.length){
			if (testArray[i] == "-") {
				if (i==0){
					arraynumeric[j]=Number(testArray[i]+testArray[i+1]);
					i++;
				} else if (testArray[i+1] == "-") {
					arraynumeric[j] = testArray[i];
					arraynumeric[j+1] = Number(testArray[i+1]+testArray[i+2]);
					j++;
					i=i+2;
				} else {
					opmatchprev = parseString(testArray[i-1],3);
					if (opmatchprev !=null) {
						arraynumeric[j] = Number(testArray[i]+testArray[i+1]);
						i++;
					} else {
						arraynumeric[j]=testArray[i];
					}
				}
			} else {
				arraynumeric[j]=testArray[i];
			}
			i++;
			j++;
		}
	}
	return(arraynumeric);
}

function calculateAnswer(tempArray,absolVal)	{
	var arrayToSolve = [];
	var oper1, oper2;
	var calcAnswer;

	// calculate the correct answer
	// ensure that tempArray consists of 3 elements & second element is operator
	if (!absolVal) {
		arrayToSolve = checkArrayNumeric(tempArray);
	} else {
		arrayToSolve=tempArray;
	}
	oper1=arrayToSolve[0];
	oper2=arrayToSolve[2];
	
	switch(arrayToSolve[1])
	{
	case "*":
		calcAnswer = oper1 * oper2;
		break;
	case "/":
		calcAnswer = oper1/oper2;
		break;
	case "\u00F7":
		calcAnswer = oper1/oper2;
		break;	
	case "+": 
		calcAnswer = Number(oper1) + Number(oper2);
		break;
	case "-": 
		calcAnswer = oper1-oper2;
		break;
	case "^": 
		calcAnswer = Math.pow(oper1, oper2);
		break;
	}
	if (calcAnswer!== 0) {
		calcAnswer = calcAnswer.toFixed(3);
		return(Number(calcAnswer));
	} else {
		return(calcAnswer);
	}
}

function calculateFractionAnswer(tempArray,beginObj,endObj)	{
	
	var tempArray;
	var arrayToSolve = [];
	var numerator1, numerator2, denom1, denom2;
	var calcAnswerArray=[];

	arrayToSolve = checkArrayNumeric(tempArray);
	numerator1 = Number(elementArray[beginObj].numerator);
	numerator2 = Number(elementArray[endObj].numerator);
	denom1 = Number(elementArray[beginObj].denominator);
	denom2 = Number(elementArray[endObj].denominator);
	// treat divide operation as multiply since divisor has been flipped
	if (arrayToSolve[1] == "\u00F7") arrayToSolve[1]="*";
	
	switch(arrayToSolve[1]) // indicates the operator
	{
	case "*":
		calcAnswerArray[0] = numerator1*numerator2;
		calcAnswerArray[1] = denom1*denom2;		
		break;
	case "/":
		//do nothing
		break;
	case "\u00F7":
		//do nothing
		break;	
	case "+": 
		calcAnswerArray[0] = numerator1+numerator2;
		break;
	case "-": 
		calcAnswerArray[0] = numerator1-numerator2;
		break;
	case "^": 
		var exponVal = Number(elementArray[endObj].string);
		if (exponVal <0){ // exponent is negative so make it positive;change fraction to reciprocal
			exponVal = Math.abs(exponVal);
		}
		calcAnswerArray[0] = Math.pow(numerator1,exponVal);
		calcAnswerArray[1] = Math.pow(denom1,exponVal);	
		break;
	}
	
	for (var i=0;i<calcAnswerArray.length;i++) {
		if (calcAnswerArray[i]!== 0) {
			calcAnswerArray[i] = Number(calcAnswerArray[i].toFixed(3));
		} 
	}
	return(calcAnswerArray);
}	


function checkBrackets(count, lbarray, rbarray, avlPosArray, avrPosArray, m)
{
	var j = 0;
	var checkRightside = false;
	var invalidExp = false;
	
	while (j < count) 
	{
		if (lbarray[j] < avlPosArray[m]) checkRightside = true;
			if (checkRightside) {
				if ((rbarray[j] > avlPosArray[m]) && (rbarray[j]<avrPosArray[m])) {
					invalidExp = true;
			}
		} 
		checkRightside = false;
		if (lbarray[j] > avlPosArray[m]){
			if(lbarray[j] < avrPosArray[m] && rbarray[j] > avrPosArray[m]){
				invalidExp = true;
			}
		}
		checkRightside = false;
		j++;
	}
	return(invalidExp);
}

function checkParens(expression)
{
	var expression;
	var match, lpmatch;
	var eqIndex=[];
	var i, j;
	
	i = 0;
	j=0;
	match = false;
	eqIndex[0] = -1;
	
	while (expression[i] != null && match == false) {
		switch(expression[i]) 
		{
	 	 case ")":
	 		 //find previous left paren
	 		 match = true;
	 		 eqIndex[0] = 0;
	 		 eqIndex[1] = i;
	 		 j = i-1;
	 		 break;
	 	 case "]":
	 		 //find previous left bracket
	 		 match = true;
	 		 eqIndex[0] = 0;
	 		 eqIndex[1] = i;
	 		 j = i-1;
	 		 break;	 	 
		}
		i++;
	}
	lpmatch = false;
	if (match == true){
		//  j>-1  controls loop
	    while (!lpmatch || j>-1) {
	    	if (expression[j] == "(" || expression[j]=="[") {
	    		lpmatch = true;
	    		eqIndex[0]=j+1;
	    		j=0;
	    	} 
	    	j=j-1;
	    	if (j<0) {
	    		lpmatch=true;
	    	}
	    }
	}
	return(eqIndex);	
}

function buildStructure(expArray, elementArray) 
{
    var lsb = [];
    var rsb = [];
    var lsbCount = 0;
    var rsbCount = 0;
    var lparen = [];
    var rparen = [];
    var lparenCount = 0;
    var rparenCount = 0;
    var invalidExp = false;
    var errorCode = 0;
    var lastResult;
    var absvalCount = 0;
    var absvalPairCnt = 0;
    var absvalLeftCnt = 0;
    var absvalRightCnt = 0;
    var avlPos = [];
    var avrPos = [];
    var j = 0;
	var i = 0;
	var checkRightside = false;
	var exponPtr, negExpon;
	
	// variables for data structure objects
	var elemtype;
	var elname;
	var elem;
	var skip=false;
	var ctr = 0; 
	var stringval;
	var num;
	var denom;
	var denomFlag;
	var expFlag;
	var var1, var2, var3, var4;
	var expn1, expn2, expn3, expn4;
	var strikenum,strikedenom;
	var expnCnt;
	var numsetFlag;
	var errMsgText = "";
	
	elname = "elem0";	
	// define buildTerm function
	var buildTerm = (function() { 
		return function(buildTerm){
			denomFlag = false;
			var timetoexit = false;
			while (i<expArray.length-1 && !timetoexit) { 
				if (expArray[i+1] == "/") {
					 if ((expArray[i+2] == "(")||(expArray[i+2] == "[")) {
						 //slash should be a divide sign
						 timetoexit = true;
						 i=i--;  //JCS - May not be needed here, since i-- us=is below
						 break;
					 }
					denomFlag=true;
					stringval = stringval+expArray[i+1];
					i++;
				} else if (expArray[i+1] == "^") {
					//if prev element is number, then this ^ is an operator
					if (parseString(expArray[i],2) !== null) {
						timetoexit = true;
						break;
					} else {
						stringval = stringval+expArray[i+1];
						i++; 
						exponPtr = i+1;// 1st digit or sign of the exponent
						negExpon = false;
						if (expArray[exponPtr]== "-") {
							negExpon = true;
							stringval=stringval+expArray[i+1];
							i++;
						}						
						
						numsetFlag=true;
						if (expn1 == 1 && var2 == null) {
							expn1 = expArray[i+1];
							if (negExpon) expn1 = expn1*-1;
						} else if (expn2 == 1 && var3 == null) {
							expn2 = expArray[i+1];
							if (negExpon) expn2 = expn2*-1;
						} else if (expn3 == 1 && var4 == null) {
							expn3 = expArray[i+1];
							if (negExpon) expn3 = expn3*-1;
						} else if (expn4 == 1) {
							expn4 = expArray[i+1];
							if (negExpon) expn4 = expn4*-1;
						} else {
							errorCode = 1; // too many variables
							errMsgText=errorMsg(errorCode,errMsgText);
							var errorLocale="entry";
							displayErrMsg(errMsgText, errorLocale);
							return;
						}
					}
				}
				if (!timetoexit && parseString(expArray[i+1],6) !== null){//integer,letter match
					stringval = stringval+expArray[i+1];
				} else {
					timetoexit = true;
					i--;
				}

				if (!timetoexit && parseString(expArray[i+1],2) !== null){ //integer match
					if (!denomFlag && !numsetFlag) { //set the numerator
						if (expArray[i] == "-") {
							var negNumHolder = Number(expArray[i] +expArray[i+1]);
							num = num+String(negNumHolder);
						} else {
							num = num+expArray[i+1];
						}
					} else if (denomFlag){ // set denominator
						if (expArray[i] == "-"){
							var negDenomHolder = Number(expArray[i] +expArray[i+1]);
							if (denom=="") denom = denom+String(negNumHolder);
						} else {
							if (denom=="") denom = denom+expArray[i+1];
						}	
					}
				} else if (!timetoexit && parseString(expArray[i+1],4) !== null){ //letter match
					if (!denomFlag && !numsetFlag) { //set the numerator
						numsetFlag = true;
						if (expArray[i] == "-") {
							num = -1;
						}
					} else if (denomFlag){ // set denominator
						if (expArray[i] == "-"){
							denom = -1;
						}	
					}
					
					if (var1 == null) {
						var1 = expArray[i+1];
					} else if (var2 == null) {
						var2 = expArray[i+1];
					} else if (var3 == null) {
						var3 = expArray[i+1];
					} else if (var4 == null) {
						var4 = expArray[i+1];
					} else  {
						errorCode = 1; // too many variables
						errMsgText=errorMsg(errorCode,errMsgText);
						var errorLocale="entry";
						displayErrMsg(errMsgText, errorLocale);
						return;
					}
				}
				i++;		
			}
			i--;
			return;
		};
	}()); // end of buildTerm function
		
	while (expArray[i] != null)
	{	
	 	switch(expArray[i]) 
	 	 {
	 	 	case "|":
	 	 		if (absvalCount%2 != 0) {
	 	 			avrPos[absvalRightCnt] = i;
	 	 			absvalRightCnt++;
		 	 		elemtype = "rightgrp";
	 	 		} else {
	 	 			avlPos[absvalLeftCnt] = i;
	 	 			absvalLeftCnt++;
		 	 		elemtype = "leftgrp";
	 	 		}
	 	 		absvalCount++;
	 	 		break;	 		
	 	 	case "[":
	 	 	 	lsb[lsbCount] = i;
	 	 	 	lsbCount++;
	 	 		elemtype = "leftgrp";
	 	 		break;
	 	 	 case "(":
	 	 	 	lparen[lparenCount] = i;
	 	 	 	lparenCount++;
	 	 		elemtype = "leftgrp";
	 	 	 	break;	 	 
	 	 	 case ")":
	 	 	 	rparen[rparenCount] = i;
	 	 	 	rparenCount++;
	 	 		elemtype = "rightgrp";
	 	 	 	break; 
	 	 	 case "]":
	 	 	 	rsb[rsbCount] = i;
	 	 	 	rsbCount++;
	 	 		elemtype = "rightgrp";
	 	 	 	break;
	 	 	 case "*":
	 	 		 elemtype = "oper";
	 	 		 break;
	 	 	 case "+":
	 	 		 if (elname.elemtype == null || elname.elemtype == "oper") {
	 	 				 expArray.splice(i,1);
	 	 				 skip = true;	 	 			  
	 	 		 }
	 	 		 elemtype = "oper";
	 	 		 break;	 
	 	 	 case "/":
		 	 case "\u00F7": //jcs121714test
	 	 	 case "^":
	 	 		 if (!equationFlag) {
	 	 			 if (selExpType==20) {
	 	 				if (expArray[i]=="/") {
	 		 	 			document.getElementById("hiddeneqfractionexpn").innerHTML="equation";
	 	 				}
	 	 			 }
	 	 		 } else if (equationFlag) {
	 	 			if (expArray[i]=="/") {	 	 			 
	 	 				document.getElementById("hiddeneqfractionexpn").innerHTML="equation";
	 	 			}
	 	 		 }
	 	 		 elemtype = "oper";
	 	 		 break;	 	 		 
	 	 	 case "=":
	 	 	 case "\u003c": //utf for <
	 	 	 case "\u003e": //utf for <
	 	 	 case "\u2264": //u2264 is <=
	 	 	 case "\u2265": //u2265 is >=
	 	 	 case "\u225f": // u225f is ?=
	 	 		 elemtype="equality";
	 	 		 break;	
	 	 			 
	 	 	 default: 	 	 
	 	 		 if (expArray[i] == "-") {
	 	 		 	 if (i>0) {
	 	 		 		 if (elname.elemtype == "term" || elname.elemtype == "rightgrp") {
	 	 		 			 elemtype = "oper";
	 	 		 			 break;
	 	 		 		 }
	 	 		 	 }
	 	 		 }	 	 	 	 	 		 
	 	 		 //if - precedes grouped expression insert -1 term followed by * oper
	 	 		 if (expArray[i] == "-" && 
	 	 				 (expArray[i+1]== "(" || expArray[i+1] == "[")) {  
	 			 	elemtype = "term";
	 			 	elname = addElementToArray(ctr, "-1",elemtype,-1,1);
	 			 	ctr++;
	 			 	elname=addElementToArray(ctr,"*","oper");
	 			 	skip = true;
	 			 	i++;
	 			 	ctr++;
	 			 	break;
	 	 		 }
	 	 		 // build complete term
	 	 		 elemtype = "term";
		 	 	 stringval = expArray[i];
		 	 	 if (parseString(expArray[i],2) !== null) {
		 	 		num = expArray[i];
		 	 	 } else {
		 	 		 num="";
		 	 	 }
		 	 	 denom="";
	 			 var1=null;
	 			 var2=null;
	 			 var3=null;
	 			 var4=null;
	 			 expn1 = 1;
	 			 expn2 = 1;
	 			 expn3 = 1;
	 			 expn4 = 1;
	 			 strikenum = null;
	 			 strikedenom = null;

	 			 if (parseString(expArray[i],4) != null) {
	 				 var1 = expArray[i];
	 			 }
	 	 		 buildTerm();
	 	 		 //errMsgText not null, too many variables error
	 	 		 // buildTerm returns when it finds more than 4 vars.
	 	 		 if (errMsgText) return(errMsgText);
	 	 		numsetFlag=false;
	 	 		i++;
	 	 		} //end of switch/case code	 			 

	 	if (!skip){
	 		if (elemtype != "term") {
	 			elname=addElementToArray(ctr,expArray[i],elemtype);
	 		} else {
	 			if (num == "") num = 1;
	 			if (denom== "") denom=1;
	 			num = Number(num);
	 			denom=Number(denom);
	 			// stringval includes fraction & var, format: num/denom+var+expon
	 			if (stringval.indexOf("/") > -1 && var1 !== null) {
	 				stringval = String(num)+"/"+String(denom)+var1;
	 				if (expn1>1) stringval = stringval+"^"+String(expn1);
	 				if (var2 !== null) {
	 					stringval = stringval+var2;
		 				if (expn2>1) stringval = stringval+"^"+String(expn2);
	 				}
	 				if (var3 !== null) {
	 					stringval = stringval+var3;
		 				if (expn3>1) stringval = stringval+"^"+String(expn3);
	 				}
	 				if (var4 !== null) {
	 					stringval = stringval+var4;
		 				if (expn4>1) stringval = stringval+"^"+String(expn4);
	 				}
	 			}
	 			
	 			elname=addElementToArray(ctr, stringval,elemtype,num, denom, 
	 					var1, expn1,var2, expn2,var3,expn3,var4, expn4,strikenum, strikedenom);
	 			if (selExpType == 22 || selExpType == 23) {	//jcs126 added 23 for other evals
	 				// skip sort for eval alg expn
	 			}
	 			else { 
		 			if (var2 != null) {
		 				var orderChanged=sortVariables(ctr);
		 				if (orderChanged) {
		 					var changedString=String(num);
		 					if ((num == 1 || num==-1) && denom == 1) {
		 						changedString = "";
		 					} 
		 					if (stringval.indexOf("/") > -1) {
		 						changedString = changedString+"/"+String(denom);
		 					}
		 					changedString = buildVarPortion(changedString,ctr);
		 					elementArray[ctr].string = changedString;
		 				}
		 			}
	 			}
	 		}
			i++;
			ctr++;
	 	} 	 	
	 	skip=false;
	}	
	return(errMsgText);
}

function doubleOperatorTest(stringval) {
	var invalidFlag = false;
	if ((stringval == "/")||(stringval == "*") ||(stringval == "^")){
	 	invalidFlag = true;
	}
	return(invalidFlag);
}

function checkValidity(expArray) 
{
    var lsb = [];
    var rsb = [];
    var lsbCount = 0;
    var rsbCount = 0;
    var lparen = [];
    var rparen = [];
    var lparenCount = 0;
    var rparenCount = 0;
    var invalidExp = false;
    var errorCode = 0;
    var lastResult;
    var absvalCount = 0;
    var absvalPairCnt = 0;
    var absvalLeftCnt = 0;
    var absvalRightCnt = 0;
    var avlPos = [];
    var avrPos = [];
    var k = 0;
    var j = 0;
	var i = 0;
	var l = 0;
	var m = 0;
	var checkRightside = false;
	var errMsgText="";
		
	while (expArray[i] != null && !errMsgText)
	{	
	 	switch(expArray[i]) 
	 	 {
	 	 	case "|":
	 	 		if (expArray[i+1] == "|") {
	 	 			errorCode = 3; //2 absol value signs together
					errMsgText=errorMsg(errorCode,errMsgText);
	 	 			invalidExp = true;
	 	 		}	 	 			
	 	 		if (absvalCount%2 != 0) {
	 	 			avrPos[absvalRightCnt] = i;
	 	 			absvalRightCnt++;
	 	 		} else {
	 	 			avlPos[absvalLeftCnt] = i;
	 	 			absvalLeftCnt++;
	 	 		}
	 	 		absvalCount++;
	 	 		break;	 		
	 	 	case "[":
	 	 	 	lsb[lsbCount] = i;
	 	 	 	lsbCount++;
	 	 		break;
	 	 	 case "(":
	 	 	 	lparen[lparenCount] = i;
	 	 	 	lparenCount++;
	 	 	 	break;	 	 
	 	 	 case ")":
	 	 	 	rparen[rparenCount] = i;
	 	 	 	rparenCount++;
	 	 	 	if (rparenCount > lparenCount) {
	 	 			errorCode = 4; //right paren cannot precede left parens
					errMsgText=errorMsg(errorCode,errMsgText);
	 	 	 		invalidExp = true;
	 	 	 	}
	 	 	 	if (!invalidExp) {
			 		lastResult = parseString(expArray[i-1],3);
			 	 	if (lastResult != null && lastResult != "|") {
			 	 		invalidExp = true;
			 			errorCode = 5; //Operator cannot come before right parenthesis
						errMsgText=errorMsg(errorCode,errMsgText);
			 	 	}
	 	 	 	}
	 	 	 	break; 
	 	 	 case "]":
	 	 	 	rsb[rsbCount] = i;
	 	 	 	rsbCount++;
	 	 	 	if (rsbCount > lsbCount) {
	 	 	 		errorCode = 6; // Right square bracket cannot precede left square bracket
					errMsgText=errorMsg(errorCode,errMsgText);
	 	 	 		invalidExp = true;
	 	 	 	}
	 	 	 	if (!invalidExp) {
			 		lastResult = parseString(expArray[i-1],3);
			 	 	if (lastResult != null && lastResult != "|" && lastResult !="/") {
			 	 		invalidExp = true;	 	 	 		
			 	 		errorCode = 9; // Right square bracket cannot precede left square bracket
						errMsgText=errorMsg(errorCode,errMsgText);
			 	 	}
	 	 	 	}
	 	 	 	break;
	 	 	 // check for duplicate operators other than "--"	
	 	 	 case "*":
	 	 		 invalidExp = doubleOperatorTest(expArray[i+1]);
	 	 		 if (invalidExp) {
		 			 errorCode = 2; // operator cannot be followed by operator
		 			 errMsgText=errorMsg(errorCode,errMsgText);
	 	 		 }
	 	 		 break;
	 	 	 case "+":
	 	 		if (expArray[i+1] == "+") {
	 	 			 // eliminate second plus sign 
	 	 			 expArray.splice(i+1,1);
	 	 		 }
	 	 		invalidExp = doubleOperatorTest(expArray[i+1]);
	 	 		 if (invalidExp) {
		 			 errorCode = 2; // operator cannot be followed by operator
		 			 errMsgText=errorMsg(errorCode,errMsgText);
	 	 		 }	 	 		
	 	 		 break;	 	 		 
	 	 	 case "/":
		 	 	 invalidExp = doubleOperatorTest(expArray[i+1]);	
	 	 		 if (invalidExp) {
		 			 errorCode = 2; // operator cannot be followed by operator
		 			 errMsgText=errorMsg(errorCode,errMsgText);
	 	 		 }
	 	 		 break;
	 	 	 case "^":
		 	 	 invalidExp = doubleOperatorTest(expArray[i+1]);	 
	 	 		 if (invalidExp) {
		 			 errorCode = 2; // operator cannot be followed by operator
		 			 errMsgText=errorMsg(errorCode,errMsgText);
	 	 		 }
	 	 		break;	 
	 	 	 case "-":
	 	 		if (i == 0 && expArray[i+1]=="-"){	// first/2nd elements in expression
	 	 			errorCode = 7; //Two minus signs not allowed at start of expression.
		 			errMsgText=errorMsg(errorCode,errMsgText);
	 	 			invalidExp = true; 
	 	 		}
	 	 	 	if (!invalidExp) {
			 	 	 invalidExp = doubleOperatorTest(expArray[i+1]);
		 	 		 if (invalidExp) {
			 			 errorCode = 2; // operator cannot be followed by operator
			 			 errMsgText=errorMsg(errorCode,errMsgText);
		 	 		 }	
	 	 	 	}
		 	 	break;
	 	 			 
	 	 	 default:
		 	 	 break;	 	 	 
	 	 }
	 	 i++;	 
	}
 	// check last item for operator
	if (!errMsgText) {
	 	lastResult = parseString(expArray[i-1],3);
	 	if (lastResult != null && lastResult != "|") {
	 	 	invalidExp = true;
		 	errorCode = 8; //Cannot have an operator at end of expression
		 	errMsgText=errorMsg(errorCode,errMsgText);
	 	}
	}

	if (!errMsgText) {
		if (lsbCount != rsbCount){	 	
			errorCode = 10; //Square brackets are not balanced.
			errMsgText=errorMsg(errorCode,errMsgText);
			invalidExp = true;
		} 
	}
	if (!errMsgText) {
		if (lparenCount != rparenCount){
			errorCode = 11; //Parens are not balanced.
			errMsgText=errorMsg(errorCode,errMsgText);
			invalidExp = true;
		}
	}
	if (!errMsgText) {
		if (absvalCount > 0) {
			if (absvalCount%2 != 0) {
				invalidExp = true;
				errorCode = 12; //Absolute value sign cannot be odd number
				errMsgText=errorMsg(errorCode,errMsgText);
			} else {
				absvalPairCnt = absvalCount/2;
			}
		}
	}
	if (!errMsgText) {		
		if (absvalPairCnt > 0) {
			m = 0;
			while (m < absvalPairCnt) {
				if (lsbCount > 0 && lsbCount == rsbCount){
					invalidExp = checkBrackets(lsbCount, lsb, rsb, avlPos, avrPos,m);
				}
				if (lparenCount >0 && lparenCount == rparenCount)
				{
					invalidExp = checkBrackets(lparenCount, lparen, rparen, avlPos, avrPos, m);
				}
				m++;
			}
		}
	}
	if (!errMsgText) {
		if (expArray.length <2) {
			errorCode = 24;
			errMsgText = errorMsg(errorCode,errMsgText);
		}
	}
	
	return(errMsgText);
}

function findOperator(expressionArray,operatorLevel,arrayIndex) 
{
	var arrayIndex=[];
	var i=0;
	var foundOperator=false;
	
	arrayIndex[0]=-1;
	while (i<expressionArray.length){
		switch (operatorLevel)
		{
		case 0: 
			if (expressionArray[i] == "^") {
				foundOperator=true;
				arrayIndex[0]=i-1;
				arrayIndex[1]=i+2;
			}
			break;

		case 1: 
			if (expressionArray[i] == "*" || expressionArray[i] == "/") {
				foundOperator=true;
				arrayIndex[0]=i-1;
				arrayIndex[1]=i+2;
			}
			break;

		case 2: 
			if (expressionArray[i] == "+" || expressionArray[i] == "-") {
				foundOperator=true;
				arrayIndex[0]=i-1;
				arrayIndex[1]=i+2;
			}
			break;
		}
		if (foundOperator) i=expressionArray.length;
		i++;
	}
	return(arrayIndex);	
}

function parseString(testString, matchOption) 
{
	var matchPattern;
	var result;
	var inputString;
	
	inputString = String(testString);
	inputString = inputString.trim();
	
	switch (matchOption)
	{
	case 0: // operator number pattern: matchOption=0
		matchPattern= /(\d+)\.(\d+)|(\d+)|\.(\d+)|[\-\+\=\u2264\<\u003c\>\u003e\u2265\u225f\*\^\/\(\)\[\]\|\u00F7]/g;
		break;
		
	case 1:  //Pattern for letters, numbers, operators: matchOption=1
		matchPattern = /[a-zA-Z]|(\d+)\.(\d+)|(\d+)|\.(\d+)|[\-\+\=\u2264\<\u003c\>\u003e\u2265\u225f\*\^\/\(\)\[\]\|\u00F7]/g;
		break;
	
	case 2:  // Pattern for extracting integers: matchOption=2
		matchPattern = /(\d+)\.(\d+)|(\d+)|\.(\d+)/g;
		break;
		
	case 3:  // Pattern for extracting operators: matchOption=3
		matchPattern = /[\+\-\=\*\^\/\|\u00F7]/g;
		break;
		
	case 4:  //Pattern for letters only: matchOption = 4
		matchPattern = /[a-zA-Z]/g;
		break;
		
	case 5:  // Pattern for exponents and variables: matchOption = 5
		matchPattern = /[a-zA-Z]|\^\/(\d+)\.(\d+)|(\d+)|\.(\d+)/g;
		break;
		
	case 6:  //Pattern for numbers and letters only: matchOption = 6
		matchPattern = /(\d+)\.(\d+)|(\d+)|\.(\d+)|[a-zA-Z]/g;
		break;		
		
	case 7: //Pattern for all operators except ^, left/right brackets;
		matchPattern = /[\+\-\=\*\/\|\u00F7]|[\(\[\)\]]/g;
		break; 
		
	case 8:  // Pattern for extracting integers and minus sign: matchOption=8
		matchPattern = /(\-)|(\d+)\.(\d+)|(\d+)|\.(\d+)|(\/)/g;
		break;	
		
	case 9: // pattern for digits with embedded spaces and fraction sign
		matchPattern = /(\d+)\s(\d+)\/(\d+)/g;
		break;
		
	case 10: //Pattern for multiply/divide/minus operators; matchOption = 10
		matchPattern = /[\*\u00F7\^\-]/g;
		break; 
		
	case 11: //pattern for extra embedded space for fractions: d space d space
		matchPattern = /\d\s+\d+\s/g;
		break;
		
	case 12: //pattern for left/right brackets
		matchPattern = /[\(\[\)\]]/g;
		break;

	case 13: //"digit-alpha-digit" pattern; catches x instead of *
		matchPattern = /\d+[a-z]+\d/g;
		break;
					
	//bts 010515: add less than u003c/greater than u003e utf codes
	case 14: // checks for =,>,<, <=, >= signs 
			// u2264 is <=
			// u2265 is >= 
			// u225f for ?=
		matchPattern = /[\=\u2264\<\u003c\>\u003e\u2265\u225f]/g;
		break;
		
	case 15: //check  / sign followed by 0. or divide by 0
		matchPattern=/(\/0|\u00F70)/g; 
		break;
		
	case 16: //check if divide by 0 not followed by decimal point
		matchPattern=/(\/0\.|\u00F70\.)/g; 
		break;
		
	case 17:  // Pattern for extracting operators, no ^ or | symbols: matchOption=17
		matchPattern = /[\+\-\=\*\/\u00F7]/g;
		break;
		
	case 18: //bts 02192016: test for digits followed by %
		matchPattern=/(\d+)\%/g;
		break;
	case 19: //bts 02192016: test for fractions followed by %
		matchPattern=/(\d+)\/(\d+)\%/g;
		break;		
	}

	result = inputString.match(matchPattern);
	return(result);
}

function removeParens(expArray)
{
	var i=0;
	// remove brackets/parentheses if they contain just one operand
	while (expArray[i] != null)
	{
	 	switch(expArray[i]) 
	 	{
	 	 	case "[":
	 	 		if (expArray[i+2] == "]"){
	 	 			//block contains 1 operand; remove left/right brackets
	 	 			expArray.splice(i+2,1);
	 	 			expArray.splice(i,1);
	 	 		}
	 	 		break;
	 	 	case "(":
	 	 		if (expArray[i+2] == ")"){
	 	 			//block contains 1 operand; remove left/right brackets
	 	 			expArray.splice(i+2,1);
	 	 			expArray.splice(i,1);
	 	 		}
	 	 		break;
	 	}
	 	i++;
	}
	return(expArray);	
}

function extractOperation(operPointer)	{	
	var operation;
		
	switch(elementArray[operPointer].string) 
	{
	case "*":
		operation = "multiplication";
		break;
	case "/": 
		operation = "division";
		break;
	case "\u00F7":
		operation = "division";
		break;
	case "+": 
		operation = "addition";
		break;
	case "-": 
		operation = "subtraction";
		break;
	case "^": 
		operation = "exponentiation";
		break;
	}
	return(operation);
}

function formReset()
{
	var j=0;
	var x, y;
	var removeElement;
	var list;
	var list1;
	var blanktext=" ";
	
	displayPage();
    document.getElementById("problemEntryArea").reset();
	document.getElementById("problementryfield").focus();
    
    /*for future use
    document.getElementById("proportionentryform").reset();
    document.getElementById("equationproblemsteps").reset();
    */
	document.getElementById("getanswerform").reset();
    document.getElementById("impropernumberform").reset();
    
    /*
     * clear rows from getanswerform table
     */
    clearAnswerFormTable();
	while (elementArray.length > 0) {
		elementArray.shift();
	}
	clearDisplayData("expnTable");	
	return;
}

function clearDisplayData(ownerName)
{
	/*
	 * generic routine to clear display data: expression table, side list
	 * of solved functions, etc.
	 */
	var j=document.getElementById(ownerName);
	var anotherChild = true;
	
	if (ownerName=="cdhelptable") {
		var messageLine = document.getElementById("commondenominatormessage");
		messageLine.innerHTML = "";
		var commonDenomHint=document.getElementById("commondenominatorhint");
		commonDenomHint.innerHTML="";
	}

	while (anotherChild) {
		anotherChild=j.hasChildNodes();
		if (anotherChild) {
			j.removeChild(j.childNodes[0]);
		}
	}	
	return;
}

function clearAnswerFormTable(tableName,rowName){
	/* 
	 * remove cell rows from tables 
	 * default: no parameters-remove rows from answerprompttable
	 */	
	var tableName, rowName;
	var tableElement, rowElement,rowId;
	
	if (tableName == "" || tableName == null) {
		tableName = "answerprompttable";
	}
	if (rowName == ""||rowName== null) {
		rowName = "row";
	}
	
	tableElement = document.getElementById(tableName);
	j=0;
	var nextRow=true;
	while (nextRow) {
		rowId = rowName+j;
		rowElement = document.getElementById(rowId);
		if (rowElement != null) {
			tableElement.removeChild(rowElement);
			j++;
		} else {
			nextRow = false;
		}
	}
	return;
}

function changeBracketToParen(parseResult)
{
	var i=0;
	
	while (i < parseResult.length) {
		if (parseResult[i] == "[") parseResult[i] = "(";
		if (parseResult[i] == "]") parseResult[i] = ")";
		i++;
	}
	return(parseResult);
}

function reloadPage()
{
	location.reload();
}

function insertAstForEvalVars(expArray)
{
	/*
	 * Checks eval expns for 2 variables not separated by operators,
	 * groupers, or numbers. If found, inserts asterisk between vars
	 */
	var i;
	for (i=0;i<expArray.length-2;i++) {
	 	if (parseString(expArray[i],4) !== null){ //variable
	 		if (parseString(expArray[i+1],4)!==null) {	
	 			expArray.splice(i+1,0,"*");
	 			i++;
	 		}
	 	}
	}	
	return(expArray);
}

function checkForSpecialChars(expnString)
{
	/*
	 * checks key combos and replaces with special symbols
	 * 	le: <= or =<
	 *  ge: >= or =>
	 *  divide sign: :- or -:
	 *  
	 *  Returns expression string with new symbols or same as entered
	 *  if no match on above key combos. confirmPoly should reject an
	 *  improperly formed expression
	 */
	var newExpn=expnString;
	//replace all divide signs
	newExpn=expnString.replace(/:-/g, "\u00F7");
	expnString=newExpn;
	newExpn=expnString.replace(/-:/g, "\u00F7");
	expnString=newExpn;
	newExpn=expnString.replace("<=","\u2264");	
	expnString=newExpn;
	newExpn=expnString.replace("=<","\u2264");	
	expnString=newExpn;
	
	newExpn=expnString.replace(">=","\u2265");	
	expnString=newExpn;
	newExpn=expnString.replace("=>","\u2265");	
	expnString=newExpn;
	return(expnString);
}

function confirmPoly(convertedExpression,evalExpression)
//called when a new expression is entered
{
	var parseResult=[];
	var answer=[];
	var invalidExp = false;
	var blank = " ";
	var strIndex = [];
	var strToSolve;
	var selEq;
	var selEqArray=[];
	var goodExp;
	var correctAnswer;
	var answerEntered=false;
	var displayString;
	var firstTextLine;
	var x;
	var errMsgText="";
	var errorCode;
	var errorLocale="entry";
	var compareString;
	var mixNumString;
	var operString; // indicates operators for mixed number expressions
	var addSubOnly = false; //indicates mixed # has only add operator
	var addOpersOnly; // true for expressions with fractions & no mixed numbers & only add opers
	var mixedNumbers = false;
	var mixNumExpn;
	var convertedExpression; // holds new expn with mixed numbers converted to improper fractions
	var convertedToImproperFraction;
	var aString, bString, inputLen;
	var mixNumSpaceTest;
	var lcdNeeded; 
	
	var errorToDisplay=document.getElementById("warningMessage");
	errorToDisplay.innerHTML = ""; 
	var newMsg;
	
	var proportion=false;//for proportion problems
	var j;
	var x=document.getElementById("problementryfield");
	if (document.getElementById("hiddenproblemtype").innerHTML=="eval") {
		var entervalues=true;		
	} else {
		var entervalues=false;				
	}
	
	if (selExpType==50) {//xy plot problem NOT USED
		entervalues=true;
		document.getElementById("hiddenproblemtype").innerHTML="eval";
	}
	
	var i=0;
	if (evalExpression==""||evalExpression==null) {
		//continue
	} else {
		aString=evalExpression;
		x.value=evalExpression;
	}
	if (convertedExpression== "" || convertedExpression== null) {
		aString = document.getElementById("problementryfield").value; 
		//change key combos (=>,>=,<=,=<,divide :- or -:) to special symbols
		var specString=aString;
		specString=checkForSpecialChars(aString);
		aString=specString;
	} else {
		aString=convertedExpression;
		if (selExpType==40) {
			proportion=true;
			selExpType=10;
		}
		
		x.value=convertedExpression;
		convertedToImproperFraction = true;
	}
	
	bString = aString.trim();
	bString=bString.toLowerCase();
	inputLen = bString.length;

	var zeroFoundNum;
	parseResult=parseString(bString,15); // 0 in denom
	if (parseResult) { // denom 0 or divide by 0 found; check for decimal
		zeroFoundNum=parseResult.length;
		parseResult=parseString(bString,16);//check for decimals
		if (!parseResult || parseResult.length < zeroFoundNum) {
			errorCode=47; 
			errMsgText=errorMsg(errorCode,errMsgText);
			displayErrMsg(errMsgText, errorLocale);
			return(errMsgText);
		}
	}
		
	var checkForMult=true;	
	var charNotX=false;
	while (checkForMult) {
		parseResult = parseString(bString,13); 
		if (parseResult) {//probably x entered instead of asterisk
			var chgStr, i, flag;
			var tempString = "";
			var astString = "";
			for (i=0;i<parseResult.length;i++) {
				chgStr = parseResult[i];
				if (chgStr.charAt(1)== "x") {
					tempString = chgStr.replace("x","*");
					astString = bString.replace(chgStr,tempString);
					bString = astString;
					flag=true;
				} else {
					charNotX=true;
					checkForMult=false;				
				}	
			} 
		} else {
			checkForMult=false;
		}
	}
	if (charNotX) {
		errorCode=44;
		errMsgText=errorMsg(errorCode,errMsgText);
		displayErrMsg(errMsgText, errorLocale);
		return(errMsgText);
	}
	if (flag) {
	    var chgExpn = confirm("Math Assister uses asterisks (*) for multiply operations.\n" +
	    		"\nDid you mean:\n\n "+ bString+
	    			"\n\n If not, press Cancel and reenter expression " +
	    			"with correct operators.");
	    if (!chgExpn) {
	    		errorCode=44;//Reenter expression with correct operators.
				errMsgText=errorMsg(errorCode,errMsgText);
				displayErrMsg(errMsgText, errorLocale);
	    		return(errMsgText);
	    }
	}
	
	
	//bts 02172016: check expression/equation includes % sign: 
	//  user converts % to decimal or fraction before structure built
	/*if (bString.indexOf("%")) {
		bString=percentConvert(bString);
		return;
	}
	*/

	selExpType=Number(selExpType);
	parseResult=parseString(bString,14);
	
	if (parseResult) { // equality signs found
		if (equationFlag && convertedToImproperFraction) selExpType=30;
		if (equationFlag && proportion) selExpType=30;
		if (parseResult.length > 1) {
			errorCode=46; // equation can have only 1 eq sign
			errMsgText=errorMsg(errorCode,errMsgText);
			displayErrMsg(errMsgText, errorLocale);
			return(errMsgText);				
		} else {
			parseResult = parseString(bString,4); //tests for alpha chars
			if (parseResult) {//vars found; use type 10 now, then change to 30
				selExpType=10;
				equationFlag=true;
			} else {//no vars found in equation
				equationFlag=false;
				errorCode=45;//equation must have vars
				errMsgText=errorMsg(errorCode,errMsgText);
				displayErrMsg(errMsgText, errorLocale);
				return(errMsgText);
			}
		}
	} else {
		equationFlag=false;
		if (entervalues) {
			selExpType=22;
			document.getElementById("generalHighlight").style.display="none";		
		}
	}
	if (equationFlag) {		
		document.getElementById("simplifyMenu").style.display="none";
		document.getElementById("equationMenu").style.display="";
	} else {
		document.getElementById("simplifyMenu").style.display="";
		document.getElementById("equationMenu").style.display="none";
	}
		
	parseResult = parseString(bString,4); //tests for alpha chars
	if (parseResult && selExpType == 10) {
		selExpType = 20;
		if (bString.indexOf("\u00F7") > -1) {
			errorCode=43; // divide oper not currently allowed
			errMsgText=errorMsg(errorCode,errMsgText);
			displayErrMsg(errMsgText, errorLocale);
			return(errMsgText);
		}
		if (!equationFlag) {
			displayTip("algexp");
		}
	} else if (parseResult && selExpType==22) {
		displayTip("eval1");
	} else if (!parseResult && (selExpType==22 || selExpType==23)) { 
		// eval algebraic expn (type=22,23) must include at least 1 variable	
		errorCode = 37;				
		errMsgText = errorMsg(errorCode,errMsgText);
		displayErrMsg(errMsgText, errorLocale);
		return(errMsgText);		//	}	
	} else if (!parseResult) {
		selExpType = 10;
		displayTip("pemdas");	 
	}

	if (selExpType == 10) {
		parseResult = parseString(bString, 0);
	} else {
		parseResult = parseString(bString, 1);
	}

	if (!parseResult) {
		errorCode = 14;
		errMsgText = errorMsg(errorCode,errMsgText);
		displayErrMsg(errMsgText, errorLocale);
		return(errMsgText);	
	} 

	if (selExpType == 10) {
		mixNumString = parseString(bString,9);
		if (mixNumString != null) {
			mixedNumbers = true;
			document.getElementById("problemEntryArea").style.display="none";
			mixNumSpaceTest = parseString(bString,11);
			if (mixNumSpaceTest != null) {
				errorCode=25;
				errMsgText = errorMsg(errorCode,errMsgText);
			}
		} else {
			var hasFractions = bString.indexOf("/");
		} 
		
		compareString = parseString(document.getElementById("problementryfield").value,1);
		if (compareString.length != parseResult.length) {
			errorCode = 23;				
			errMsgText = errorMsg(errorCode,errMsgText);
		}
		
		if (hasFractions>-1) {
			var slashString;
			slashString=bString.replace(/\)\//gi,")\u00F7");
			slashString=slashString.replace(/]\//gi,"]\u00F7");
			slashString=slashString.replace(/\|\//gi,"|\u00F7");
			parseResult = parseString(slashString, 0);
			bString=slashString;
		}
		
		if (!errMsgText) {
			var tempArray=[];
			tempArray=addAsterisk(parseResult);
			var stringWithAst=tempArray.join("");
			
			if (mixedNumbers || hasFractions >-1) {
				operString=parseString(stringWithAst,10);
				
				if (operString == null) { // only "add" opers present
					if (mixedNumbers) addSubOnly = true;
					if (hasFractions > -1) addOpersOnly = true;
				}
			}
		}
	}
		
	if  (!errMsgText) {
		errMsgText = checkValidity(parseResult);
	}
	
	if (selExpType==22 || selExpType==23) {
		parseResult=insertAstForEvalVars(parseResult);
	}
	
	if (equationFlag) {
		var mixNumEqString = parseString(bString,9);
		if (mixNumEqString != null) {
			var mixedEqNumbers = true;
			document.getElementById("problemEntryArea").style.display="none";
			var mixNumEqSpaceTest = parseString(bString,11);
			if (mixNumEqSpaceTest != null) {
				errorCode=25;
				errMsgText = errorMsg(errorCode,errMsgText);
			} else {
				document.getElementById("generalHighlight").style.display="none";
				document.getElementById("mainblackboard").style.display="";
				var textToDisplay = " -- Original expression";
				writeToTableSpecial(bString,textToDisplay);
				var mixNumEqExpn = promptImproperNum(bString, mixNumEqString);
			}
			return(errMsgText);
		}
	}

	if (mixedNumbers && !errMsgText) {
		document.getElementById("generalHighlight").style.display="none";
		document.getElementById("mainblackboard").style.display="";
		var textToDisplay = " -- Original expression";
		writeToTableSpecial(bString,textToDisplay);
		if (!addSubOnly) {
			mixNumExpn = promptImproperNum(bString, mixNumString);
			return(errMsgText);
		} else if (addSubOnly) { // mixed number only has add opers
			mixNumExpn = changeMixedExpnOpers(bString, mixNumString);
			var specialWriteCase=true;
		}
		parseResult = mixNumExpn.replace(/\s/g,"");
	}
	
	if (errMsgText) {
		displayErrMsg(errMsgText, errorLocale);
		return(errMsgText);
	}

	parseResult=addAsterisk(parseResult);
    // remove parens around single operand/no operator; 	
	// this function works for expressions that are only numeric
	parseResult=removeParens(parseResult);
	errMsgText = buildStructure(parseResult, elementArray);
	//too many vars, reset to start new expression. 
	if (errMsgText) {
		return(errMsgText);
	}
		
	// remove parens around single term in structure
	// this function is for algebraic expressions
	removeParensInStructure();
	
	addAsteriskForAbsolVal();
	
	document.getElementById("problemEntryArea").style.display="none";
	
	if (equationFlag) {
		selExpType=30;
		if (entervalues) selExpType=32;//evaluate for equations type
	}
	
	if (selExpType == 10) {
        newMsg = document.getElementById("statusmsg");
        newMsg.innerHTML="Simplifying a numeric expression";
		document.getElementById("whatToDoNextArea").style.display=""; 
	    if (document.getElementById("generalHighlight").style.display==""){
	    	document.getElementById("mobileEntryField").focus();
	    };
		document.getElementById("userInstructions").style.display="";   
        document.getElementById("getanswerform").reset();
        document.getElementById("getanswerform").style.display="none";
	}
	firstTextLine = " -- Original expression";
	if (mixedNumbers || convertedToImproperFraction) firstTextLine = " -- Converted mixed numbers";
	if (proportion) {
		firstTextLine=" Set up cross products";
	}
	if (addSubOnly) {
		firstTextLine = 
			" -- Separated whole numbers from fractions";
		displayTip("separatemixed");
	}
	
	writeToTable(firstTextLine);			
	if (selExpType == 10 || selExpType == 20) {
		changeMinusToAdd();
	}
	
	goodExp = true;
	origExp = parseResult;
	
	if (addSubOnly || addOpersOnly) {
		var removedParens=false;	
		removedParens=removeParensAfterAdd(removedParens);
		if (removedParens){
			writeToTable(" -- Removed parens around added terms");
		}
	}
	
	//do not regroup if absol val bars
	if ((addOpersOnly || addSubOnly) && elementArray.length > 2) {
		var absValBar=[];
		absValBar=checkForAbsolValBars();
		if (absValBar.length==0) {//continue with original code to regroup
			document.getElementById("generalHighlight").style.display="none";
			document.getElementById("userInstructions").style.display="none";   	
			var fractBeginObj;
			var fractBeginEndObj = [];
			fractBeginObj=regroupExpn();
			fractBeginEndObj[0]=fractBeginObj;
			fractBeginEndObj[1]=elementArray.length-1;
		
			if (addOpersOnly) {
				var fractTempString = buildStrPart(0, elementArray.length-1);
				fractBeginObj = fractTempString.indexOf("/");
				hasFractions = bString.indexOf("/");
				if (fractBeginObj != hasFractions) { //expression reordered
					firstTextLine = 
						"-- Grouped whole numbers & fractions using commutation";
					writeToTable(firstTextLine);
				} 
			} else {
				firstTextLine = 
					"-- Grouped whole numbers & fractions using commutation";
				writeToTable(firstTextLine);
			}
			addWholeNumbers(fractBeginEndObj," ");
		}
	} else {
		if (selExpType == 10 && elementArray.length>3) {
			//displayTip("pemdas");
		}
	}
	
    if (selExpType == 20 || selExpType==30 || selExpType==32) { 
        newMsg = document.getElementById("statusmsg");
        if (!equationFlag) {
        	newMsg.innerHTML="Simplifying an algebraic expression";
        } else {
        	newMsg.innerHTML="Solving an equation or inequality";
        	document.getElementById("operationMenuArea").style.display=""; 
        }
    	if (document.getElementById("hiddeneqfractionexpn").innerHTML
    			=="equation") {
    		errMsgText=repositionEqFractionDenom();
    		document.getElementById("hiddeneqfractionexpn").innerHTML="";
        	if (errMsgText) {
        		return(errMsgText);
        	}
    		writeToTable(" -- Changed fraction expression");	
    	}

        document.getElementById("userInstructions").style.display="";
		document.getElementById("whatToDoNextArea").style.display="";
    	document.getElementById("workarea").style.display="";
    	document.getElementById("mainblackboard").style.display="";
        
        errMsgText=doAlgExpSteps();
    	if (errMsgText) {
    		return(errMsgText);
    	}
        if (equationFlag && !entervalues && elementArray.length==3) {
       	if (document.getElementById("hiddencaller").innerHTML
        			!="absolutevalue") {
        		var processFlag=checkForEqSolved();
        		if (processFlag !=0) return;
        	}
        }
    }
    
    if (equationFlag && entervalues) {
		document.getElementById("sidenotes").style.display="";
    	document.getElementById("testevalequation").innerHTML="testequation";
      	document.getElementById("operationMenuArea").style.display="none";        
		document.getElementById("evaluateexpressionform").style.display="";			
    	var expnArray=[];
    	var expnString=buildStrPart(0,elementArray.length-1);
    	expnArray=parseString(expnString,1);
		doAlgExpn(expnArray);
    }

    if (selExpType == 22 || selExpType == 23) {	 
        newMsg = document.getElementById("statusmsg");
        newMsg.innerHTML="Evaluating an algebraic expression";
		document.getElementById("evaluateexpressionform").style.display="";
		document.getElementById("whatToDoNextArea").style.display="";
		document.getElementById("userInstructions").style.display="";
    	document.getElementById("workarea").style.display="";		
    	document.getElementById("operationMenuArea").style.display="none";        
		doAlgExpn(parseResult);
    }
	  
    if (selExpType == 10 || selExpType == 22 || selExpType == 23) {
    	var absolValSingleTerm = [];
    	absolValSingleTerm = checkAbsolValSingleTerm();
    	if (absolValSingleTerm[0]!=-1) {//found single term within abol val
    		promptSingleAbsVal(absolValSingleTerm);
    	}
    }
    
    if (selExpType==10) {
    	var combineExponsPos=[];
    	combineExponsPos=checkExponentOpers();
    	if (combineExponsPos[0]!=-1) {
    		displayTip("combineexponents");
    	}
    }	
	return(errMsgText);
}

function checkExponentOpers(selEq) 
{
	/*
	 * checks structure for numeric terms that have the same base
	 * and exponent operators. Called when expressions are numeric only.
	 * Returns an array where first element of array is -1 if expression
	 * does not include appropriate terms w/exponents; otherwise, returns 
	 * an array of the positions of the terms with matching base vals/exponents
	 */
	var exponOpersFound = false;
	var formatCheck=false;
	var i,j;
	var posArray=[]; // holds positions of terms (numerics)
	var baseArray = []; // holds base value of term
	var baseCtr,posCtr;
	var startPos, endPos;
	var baseMatch = false;
	var saveBase = [];
	var saveBasePtr=0;
	var noMatch=false;
	var loopBegin,loopEnd;
	
	loopBegin=0;
	loopEnd=elementArray.length;
	
	if (selEq) { // find beginning point in selected expression
		var selEqStr = selEq.join("");
		var beginPt=0;
		var expnToSolve;
		loopBegin=0;
		for (beginPt = 0; beginPt<elementArray.length;beginPt++) {
			expnToSolve=buildStrPart(beginPt,elementArray.length-1);
			loopBegin=expnToSolve.indexOf(selEqStr);
			if (loopBegin==0) {//found selEq within elementArray string
				loopBegin = beginPt;//element in structure where expn starts
				beginPt = elementArray.length; // exit loop
			} else if (loopBegin==-1) {//mismatch with selection/structure
				noMatch=true;
				beginPt = elementArray.length; // exit loop
			}
		}
		if (noMatch) {
			saveBase[0]=-1;
			return(saveBase);
		}
	}
	
	baseCtr=0;
	posCtr=0;
	
	for (i=loopBegin;i<loopEnd;i++) {
		// keep track of numeric value for terms
		if (elementArray[i].elemtype=="term" && i != elementArray.length-1) {
			if (elementArray[i+1].elemtype == "oper" 
				&& elementArray[i+1].string == "^") {
				baseArray[baseCtr]=Number(elementArray[i].string);
				if (isNaN(Number(elementArray[i].string))) {
					//use fraction
					baseArray[baseCtr]=Number(elementArray[i].numerator/elementArray[i].denominator);
				} else { // whole number
					baseArray[baseCtr]=Number(elementArray[i].string);
				}
				posArray[baseCtr]=i;
				baseCtr++;
			} 
		}			
	}
	
	if (baseArray.length>1) formatCheck=true;

	while (formatCheck) {
		//check if base terms are equal
		for (i=0;i<baseArray.length-1;i++) {
			for (j=i+1;j<baseArray.length;j++) {
				if (baseArray[i] == baseArray[j]) {//at least 1 base match exists
					baseMatch = true;
					j=baseArray.length;
					i=baseArray.length;
				} 
			}
		}
		formatCheck=false;
	}

	//remove non-matching base terms from posArray
	// save matching location of base terms in saveBase
	if (baseMatch) {
		for (i=0;i<baseArray.length-1;i++) {
			for (j=i+1;j<baseArray.length;j++) {
				if (baseArray[i]==baseArray[j]) {
					if (saveBase.length == 0) saveBase[saveBase.length]=posArray[i];
					saveBase[saveBase.length]=posArray[j];
				}
			}
			if (saveBase.length > 0) i=baseArray.length; 
		}
		startPos = Number(saveBase[0]);
		endPos = Number(saveBase[saveBase.length-1]);
		formatCheck=true;
		exponOpersFound=true;
	}
	
	// check for conditions negating exponent combine operation
	var endLimit=1;
	while (formatCheck) {//terms w/expons should not be separated by +,-,brackets
		for (i=startPos+1;i<endPos+1;i++) {
			if (elementArray[i].elemtype == "oper") {
				if (elementArray[i].string == "+" ||
						elementArray[i].string == "-") {
					formatCheck=false;
					exponOpersFound=false;
				}
			} else if (elementArray[i].elemtype == "leftgrp" ||
					(elementArray[i].elemtype == "rightgrp")) {
				formatCheck=false;
				exponOpersFound=false;
			}
			if (saveBase.length > 2) {
				if (!formatCheck && i > saveBase[endLimit]) {//remove saveBase last entry, exit
					exponOpersFound=true;
					i==endPos;
					saveBase.splice(endLimit+1);
				}
			}
			if (i==endPos) formatCheck=false;
		}
	} 
	
 	if (!exponOpersFound) saveBase[0]=-1; // no suitable expon terms found
	return(saveBase);
}

function promptSingleAbsVal(absolValSingleTerm)
{
	/*
	 * Builds prompt(s) for the value of single terms within absol val markers
	 * Also calculates correct answer and updates structure before prompting
	 * user to enter answer
	 */
	var beginObj, endObj, j, i,ptr;
	var color;
	var calcAns=[];
	var userPrompt = [];
	var preprompttext;
	var objPosArray = [];
	var onePrompt, operandTotal;
	var fractFlag=false;

	document.getElementById("generalHighlight").style.display="none";			   	
	document.getElementById("UserInstructionPrompt").innerHTML="";			   	
	document.getElementById("UserInstructionPrompt").style.display="none";				
	
	preprompttext = "How much is: ";
		
	// get the single abs val terms
	for (j=0;j<absolValSingleTerm.length;j++) {
		ptr = absolValSingleTerm[j];
		userPrompt[j]= "|"+elementArray[ptr].string+"|";
		if (elementArray[ptr].string.indexOf("/")>-1) {//fraction
			fractFlag=true;
			calcAns[j]=Math.abs(Number(elementArray[ptr].numerator))+"/"+
					elementArray[ptr].denominator;
		} else {//not fraction
			calcAns[j] = Math.abs(Number(elementArray[ptr].string));
		}
	}
	
	color = "yellow";
	for (i=0;i<absolValSingleTerm.length;i++) {
		beginObj = absolValSingleTerm[i]-1;
		endObj = absolValSingleTerm[i]+1;
		for (j=beginObj;j<endObj+1;j++) {
			writeMultHighlight(j,1,elementArray.length,color);
		}
	}
	
	var loopCtr = absolValSingleTerm.length;
	for (i=loopCtr;i>0;i--) {
		ptr = absolValSingleTerm[i-1];
		elementArray[ptr].numerator = Number(elementArray[ptr].numerator);
		if (elementArray[ptr].numerator < 0){
			elementArray[ptr].numerator = elementArray[ptr].numerator*-1;
		} 
		elementArray[ptr].string = String(calcAns[i-1]);
		elementArray.splice(ptr+1,1);
		elementArray.splice(ptr-1,1);
	}
	
	var multiplier = "";
	var callerId = "simplifynumeric";
	onePrompt = true;
	var expnOperation = " solving absolute value";
	var introType=0;
	
	if (absolValSingleTerm.length > 1) onePrompt = false;
	
	setAnswerPrompt(preprompttext, userPrompt, 
			multiplier,calcAns,objPosArray,operandTotal,
			onePrompt,callerId,expnOperation,introType);
		
	return;
}

function checkAbsolValSingleTerm()
{
	/*
	 * Checks structure for absolute value brackets containing single terms
	 * Returns the element location within the structure of those terms 
	 */
	var positions = [];
	var j;
	var counter=0;
	
	positions[0]=-1;
	
	for (j=0;j<elementArray.length;j++) {
		if (elementArray[j].elemtype=="leftgrp" && 
				elementArray[j].string == "|") {
			if (elementArray[j+2].elemtype=="rightgrp") {
				if (elementArray[j+1].elemtype=="term" && 
						elementArray[j+1].variable == null) {
					positions[counter]=j+1;
					counter++;
				}
			}
		}
	}	
	return(positions);
}

function addAsteriskForAbsolVal()
{	
	var j;
	var holdElement;
	var addAstFlag;
	
	addAstFlag=false;		
	// change minus sign oper to asterisk
	if (elementArray[0].string == "-" && elementArray[0].elemtype=="term"){
		if (elementArray[1].elemtype == "leftgrp" &&
			elementArray[1].string == "|") {
				elementArray[0].string = "*";
				elementArray[0].elemtype = "oper";
				addAstFlag = true;
		}		
	}
	// create/add to structure start new element for term -1 
	if (addAstFlag) {
		holdElement = new pe(" ");
		var elemtype = "term";
		var termString = "-1";
		holdElement.addElement(termString,elemtype,-1,1);
		elementArray.unshift(holdElement);
	}	
	return;
}

function buildStrPart(startloc, endloc)
{
	var txt="";
	var i;
	
	for (i=startloc;i<endloc+1;i++) {
		if (elementArray[i] !== null) txt = txt + elementArray[i].string;
	}	
	return(txt);
}

function buildArray(startloc,endloc)
{
	var expnArray = [];
	var i,j;
	j=0;
	
	for (i=startloc;i<endloc+1;i++) {
		if (elementArray[i] !== null) expnArray[j] = elementArray[i].string;
		j++;
	}
	return(expnArray);
}

function pe(stringval, type, numerator, denominator, varval,exponent,varval2,exponent2, 
		varval3, exponent3, varval4, exponent4, strikenum, strikedenom)
{
	this.string = stringval;
	this.elemtype = type; 
	this.numerator = numerator;
	this.denominator = denominator;
	this.variable = varval;
	this.exponent = exponent;
	this.variable2 = varval2;
	this.exponent2 = exponent2;
	this.variable3 = varval3;
	this.exponent3 = exponent3;
	this.variable4 = varval4;
	this.exponent4 = exponent4;
	this.strikenum = strikenum;
	this.strikedenom = strikedenom;
	
	this.addElement=addElement;
	function addElement(stringval, type, numerator, denominator, varval,exponent,varval2,
			exponent2, varval3, exponent3,varval4, exponent4, strikenum, strikedenom)
	{
		this.string = stringval;
		this.elemtype = type; 
		this.numerator = numerator;
		this.denominator = denominator;
		this.variable = varval;
		this.exponent = exponent;
		this.variable2 = varval2;
		this.exponent2 = exponent2;
		this.variable3 = varval3;
		this.exponent3 = exponent3;
		this.variable4 = varval4;
		this.exponent4 = exponent4;	
		this.strikenum = strikenum;
		this.strikedenom = strikedenom;
	}
} 

function addElementToArray(ctr, stringval, elemtype, num, 
		denom,v1,e1,v2,e2,v3,e3,v4,e4,strikenum, strikedenom)
{
	var elname, ctr, stringval, elemtype, num, denom,strikenum, strikedenom;
	var v1,e1,v2,e2,v3,e3,v4,e4;
	
	elname = "elem"+ctr;
	elname=new pe(" ");
 	elname.addElement(stringval,elemtype,num,denom,v1,e1,v2,e2,v3,e3,v4,e4,
 			strikenum, strikedenom);

	elementArray[ctr]=elname;
	return(elname);
}

function changeMinusToAdd() 
{
	/*
	 * Checks structure for subtraction of negative number. If found, changes operation
	 * to addition and makes the negative number positive. Called after removing
	 * any unnecessary parens
	 */
	var j;
	
	for (var i=0;i<elementArray.length;i++){
		if (elementArray[i].elemtype == "oper" && elementArray[i].string == "-") {
			if (elementArray[i+1].numerator <0){
				j=i+2; // next structure element
				if (j<elementArray.length && 
						(elementArray[j].string == "*" ||
								elementArray[j].string == "^" ||
								elementArray[j].string == "\u00F7")) {					
				} else {				
					elementArray[i].string = "+";
					elementArray[i+1].numerator = elementArray[i+1].numerator*-1;
					var tempString = elementArray[i+1].string.replace("-","");
					elementArray[i+1].string = tempString;
					writeToTable(" -- Changed subtracting negative term to addition");
				}
			}
		}
	}
	
	return;
}

function removeParensAfterAdd(removedParens,specialWriteCase,displayBoard) {
	/*
	 * routine removes parentheses/brackets from structure 
	 * where the brackets are preceded by a + sign.
	 * 
	 * specialWriteCase: indicates that the original expression is for
	 * a mixed number, so highlighting removed brackets in orig expression
	 * will NOT work (skip that part if specialWriteCase is true)
	 */
	var i;
	var positions = [];
	var counter;
	var nestedBracket;
	var pos1, pos2;
	var cntLeftgrp, cntRightgrp;
	var remove;
	var firstElement = false;
	var subtractFlag;
	var revPos = [];
	var highlightColor;
	
	pos1=0;
	pos2=0;
	counter = 0;
	cntLeftgrp = 0;
	cntRightgrp = 0;
	remove = false;	
	
	for (i=0;i<elementArray.length;i++) {
		if (elementArray[i].elemtype == "leftgrp" &&
				elementArray[i].string != "|") {
			cntLeftgrp++;
			if (i>0) {
				if (elementArray[i-1].elemtype =="oper") {
					if (elementArray[i-1].string =="+") {
						pos1 = i;
						remove = true;
					}
				}
			} else {
				firstElement = true;
				pos1=i;
			}
			if (cntLeftgrp - cntRightgrp > 1) nestedBracket = true;
		}
		if (elementArray[i].elemtype == "rightgrp" &&
				elementArray[i].string != "|") {
			cntRightgrp++;
			if (firstElement || (remove && i != elementArray.length-1)) {
				if (i==elementArray.length-1) {
					if (firstElement) {
						pos2=i;
						remove=true;
					}
				} else if (elementArray[i+1].elemtype == "oper" ||
						elementArray[i+1].elemtype == "equality") {
					if (elementArray[i+1].string == "+" ||
							elementArray[i+1].string == "-" ||
							elementArray[i+1].elemtype == "equality") {
						remove = true;
						pos2=i;
					} else {
						remove = false;
					}
				} else remove = false;// if not followed by asterisk?
			} 
			firstElement = false; 
			if (i == elementArray.length-1){ // last element in array is right bracket
				if (remove)	pos2 = i;
			}
			
			if (remove && cntLeftgrp == cntRightgrp) {
				// save bracket positions to remove later
				positions[counter] = pos1;
				counter++;
				positions[counter] = pos2;
				counter++;
				pos1=0;
				pos2=0;
				remove = false;
			}	
		}
	}

	highlightColor = "orange";
	counter= counter-1;
	
	if (specialWriteCase && positions.length > 0) {
		var expnTableEl;
		expnTableEl=document.getElementById("expnTable");
		var list=expnTableEl.getElementsByTagName("td");
		var j;
		for (j=0;j<list.length;j++) {
			if (list[j].innerHTML=="(" || list[j].innerHTML==")") {
				list[j].style.backgroundColor=highlightColor;
			}
		}
		removedParens = true;
	} else if (!specialWriteCase) {		
		if (positions.length > 0) {
			if (!displayBoard) {
				for (i=0;i<positions.length;i++){
					writeMultHighlight(positions[i],1,elementArray.length,highlightColor);
				}	
			}
			removedParens = true;
		}
	}
	if (removedParens) {
		for (i=counter;i>-1;i--) {
			elementArray.splice(positions[i],1);
		}
	}	
	return(removedParens);
}

function removeParensAfterSub () {
	/*
	 * routine removes parentheses/brackets from structure 
	 * where the brackets are preceded by a - sign. Also
	 * reverses signs of terms found within the bracket
	 */
	var i;
	var positions = [];
	var counter;
	var nestedBracket;
	var pos1, pos2;
	var cntLeftgrp, cntRightgrp;
	var remove;
	var firstElement = false;
	var subtractFlag;
	var revPos = [];
	var allRevPos = [];
	var holdArray=[];
	var highlightColor;
	var removedParens;
	
	pos1=0;
	pos2=0;
	counter = 0;
	cntLeftgrp = 0;
	cntRightgrp = 0;
	remove = false;
	
	
	for (i=0;i<elementArray.length;i++) {
		if (elementArray[i].elemtype == "leftgrp" &&
				elementArray[i].string != "|") {
			cntLeftgrp++;
			if (i>0) {
				if (elementArray[i-1].elemtype =="oper") {
					if (elementArray[i-1].string =="-") {
						subtractFlag = true;
						pos1 = i;
						remove = true;
					}
				}
			} else {
				firstElement = true;
				pos1=i;
			}
			if (cntLeftgrp - cntRightgrp > 1) nestedBracket = true;
		}
		if (elementArray[i].elemtype == "rightgrp" &&
				elementArray[i].string != "|") {
			cntRightgrp++;
			if (firstElement || (remove && i != elementArray.length-1)) {
				firstElement = false;
				if (elementArray[i+1].elemtype == "oper" ||
						elementArray[i+1].elemtype=="equality") {
					if (elementArray[i+1].string == "+" ||
							elementArray[i+1].string == "-" ||
							elementArray[i+1].elemtype=="equality") {
						remove = true;
						pos2=i;
					} else {
						remove = false;
						subtractFlag=false;
					}
				} else {
					remove = false;// if not followed by asterisk?
					subtractFlag=false;
				}
			} 
			if (i == elementArray.length-1){ //last element in array is right bracket
				pos2=i;
			}
			if (subtractFlag) {
				pos2=i;
				remove = true;
				revPos = reverseOpers(pos1,pos2);
				if (allRevPos.length >0) {
					holdArray=allRevPos.concat(revPos);
					allRevPos = holdArray;
				} else {
					allRevPos = revPos;
				}
				subtractFlag = false;
				parenRemovalType=2;
			}
			
			if (remove && cntLeftgrp == cntRightgrp) {
				// save the 2 bracket positions to remove later
				positions[counter] = pos1;
				counter++;
				positions[counter] = pos2;
				counter++;
				pos1=0;
				pos2=0;
				remove = false;
			}	
		}
	}
	
	highlightColor = "red";
	if (allRevPos.length > 0) {
		for (i=0;i<allRevPos.length;i++) {
			writeMultHighlight(allRevPos[i],1,elementArray.length,highlightColor);
		}
	}

	/*
	 * if positions array contains values, remove those elements from structure
	 * -Highlight the brackets before removing them
	 */
	highlightColor = "orange";
		
	counter= counter-1;
	if (positions.length > 0) {
		for (i=0;i<positions.length;i++){
			writeMultHighlight(positions[i],1,elementArray.length,highlightColor);
		}
		removedParens = true;
		for (i=counter;i>-1;i--) {
			elementArray.splice(positions[i],1);
		}
	}
	return(removedParens);
}

    
function reverseOpers(pos1,pos2){
	var posLen;
	var revPos = [];
    var j, ctr;
    
    ctr = 0; 
    for (j=pos1+1;j<pos2;j++) {
        if (elementArray[j].elemtype == "oper") {
            if (elementArray[j].string == "+") {
                elementArray[j].string = "-";
                revPos[ctr] = j;
                ctr++;
            } else if (elementArray[j].string == "-") {
                elementArray[j].string = "+";
                revPos[ctr] = j;
                ctr++;
            }
        }      
    }
    return(revPos);
}

function removeSubtraction(startpt,endpt) {
	var i;
	var numerator;
	var subtractionRemoved;
	var holdString="";
	var tempArray= [];
	var positions = [];
	var ctr = 0;
	var nextTerm;
	var termInBracket=false;
	var insertElements=false;
	
	for (i=startpt;i<endpt+1;i++) {
		if (elementArray[i].elemtype=="rightgrp")
			termInBracket=false;
		
		if ((elementArray[i].elemtype=="term")&&(termInBracket)) {
			elementArray[i].numerator = elementArray[i].numerator * -1;
		}
		if (elementArray[i].string == "-") { 
			elementArray[i].string = "+";	//change minus oper to +
			nextTerm=i+1;
			if (elementArray[nextTerm].elemtype == "term") {
				elementArray[nextTerm].numerator = elementArray[nextTerm].numerator * -1; 
			} else {			
				if (elementArray[nextTerm].elemtype == "leftgrp") { //we have +(
					termInBracket=true;					
				}
				if (elementArray[nextTerm].elemtype == "leftgrp" &&
					elementArray[nextTerm].string == "|") {
						insertElements=true;					
				}
			}
			
			if (!insertElements) {
				holdString = elementArray[nextTerm].string;
				tempArray = holdString.split("");
				if (tempArray[0] == "-") {
					tempArray.shift();
				} else tempArray.unshift("-");
				holdString=tempArray.join("");		
				elementArray[nextTerm].string = holdString;
				positions[ctr]=i;
				ctr++;
			} else {//insert 2 elements for absol val groupers: -1*
				var holdElement = new pe(" ");
				var elemtype = "term";
				var termString = "-1";
				holdElement.addElement(termString,elemtype,-1,1);
				elementArray.splice(i+1,0,holdElement);
				holdElement=new pe(" ");
				holdElement.addElement("*","oper");
				elementArray.splice(i+2,0,holdElement);
				positions[ctr]=i;
				i=i+2;
				ctr++;
			}
			insertElements=false;
			subtractionRemoved = true;
		}
	}
	return(subtractionRemoved);
}

function doAlgExpSteps() {
	var errMsgText="";
	var errorCode;
	var errorLocale="";
	var algExpnWithAbsolVars=false;
	var absValPos=[];
	var tooManyTerms=false;
	absValPos=checkForAbsolValBars();
	if (absValPos.length>0 && 
			document.getElementById("hiddennocheck").innerHTML 
			== "") {//check if absol val block > 2 terms
		tooManyTerms=checkTermsWithinAbsolVals(absValPos);
		if (tooManyTerms) {//more than 2 terms within absol val
			errorCode=49;
			errorLocale="";
			errMsgText=errorMsg(errorCode,errMsgText);
			displayErrMsg(errMsgText, errorLocale);
			return(errMsgText);		
		}
	}

	algExpnWithAbsolVars=checkForAbsolValVars(absValPos);
	if (!equationFlag && algExpnWithAbsolVars) {
		errorCode=48;
		errorLocale="";
		errMsgText=errorMsg(errorCode,errMsgText);
		displayErrMsg(errMsgText, errorLocale);
		return(errMsgText);	
	}
	if (equationFlag) {
		if (algExpnWithAbsolVars) {//equation has terms within absol val bars
			var multVarsInAbsolVals=false;
			multVarsInAbsolVals=checkForAbsolValMultVars(absValPos);
			if (multVarsInAbsolVals) {//multiple vars within absol val bars found
				errorCode=49;
				errorLocale="";
				errMsgText=errorMsg(errorCode,errMsgText);
				displayErrMsg(errMsgText, errorLocale);
				return(errMsgText);				
			}
			addAstForAbsolValMult(absValPos);			
			//user needs to pick option; turn on split option 
		    document.getElementById("splitoption").disabled=false;
		    //turn off 2 multiply menu options until after split option chosen
		    document.getElementById("multiplyboth").disabled=true;
		    document.getElementById("multiplypart").disabled=true;	
		    document.getElementById("operationMenuArea").style.display="";		
			displayTip("erase");
			displayTip("absoluteValue");
		} 

		var newAbsValPos=[];
		absValPos=checkForAbsolValBars();
		newAbsValPos=getAbsValPosNoVars(absValPos);
		absValPos=newAbsValPos;
		if (document.getElementById("hiddennocheck").innerHTML 
				== "") {//not checking phase	
		    document.getElementById("operationMenuArea").style.display="";		
			displayTip("erase");
			displayTip("absoluteValue");
		} else {//in checking phase so display highlight menu
		   //document.getElementById("operationMenuArea").style.display="none";
		   //document.getElementById("generalHighlight").style.display="";			
		}
	}
	if (absValPos.length>0) {//equation/expn has absol values
	    document.getElementById("operationMenuArea").style.display="none";
    	var absolValSingleTerm = [];
    	absolValSingleTerm = checkAbsolValSingleTerm();
    	if (absolValSingleTerm[0]!=-1) {//found single term within abol val
    		promptSingleAbsVal(absolValSingleTerm);
    		document.getElementById("hiddensingleabsolval").innerHTML="absolutevalue"; 
    	} else {
    		promptForAbsolVal(absValPos);
    		document.getElementById("hiddensingleabsolval").innerHTML="";
   	}
		return(errMsgText);
	}

	var removedParens=false;
	document.getElementById("whatToDoNextArea").style.display="none";
	removedParens=removeParensAfterAdd(removedParens);
	if (removedParens){
		writeToTable(" -- Removed parens around added terms");
		displayTip("removeparenadd");
		document.getElementById("generalHighlight").style.display="none";						
	} else removeSubtractedExpression();
    return(errMsgText);
}

function removeSubtractedExpression() {
	var removedParens=false;	
	removedParens=removeParensAfterSub();
	if (removedParens){
		writeToTable(" -- Removed parens around subtracted terms and reversed operators");
		displayTip("removeparensub");
	} else {
		checkForSubtraction();
	}
	return;
}

function checkForSubtraction()
{
	var idxEnd = elementArray.length-1;
	var subtractionTest;
	subtractionTest=removeSubtraction(0,idxEnd);
	
	if (subtractionTest){
		writeToTable(" -- Changed subtractions to adding the opposites of the terms");
		displayTip("reversesub");
	} else {
		finishCheckingParens();
	}
	return;
}

function finishCheckingParens() {
    document.getElementById("whatToDoNextArea").style.display="";
    document.getElementById("generalHighlight").style.display="none";
    document.getElementById("operationMenuArea").style.display="";
    document.getElementById("simplifyMenu").disabled=false;	
    if (equationFlag) {
    	if (document.getElementById("hiddenproblemtype").innerHTML=="eval") {
    	    document.getElementById("operationMenuArea").style.display="none";
    		displayTip("erase");
    	} else
    		displayTip("equation");
    } else {
    	displayTip("algexp");
    } 
}

function calcBinomialAns(multiplierVal,arrayObjLoc,multiplierLoc)
{
	var answer;
	var multNumber, multVar;
	var matchVar;
	var varCounter=1;
	var i=0;
	var variableAddedorFound = false;
	var multVarMatch = [];
	var varInMultiplier = false;
	var varAns;
	var multiplier;
	
	var multExp = [];
	var exponentMarker;
	multiplierVal = String(multiplierVal);
	var isFraction = multiplierVal.indexOf("/");	
	exponentMarker = multiplierVal.indexOf("^");
	
	if (exponentMarker == -1) { //no exponents in multiplier
		multiplier=multiplierVal;
	} else {//exponents in multiplier
		var separateMults = [];
		var charInArray;
		separateMults = multiplierVal.split("^");
		multiplier = separateMults[0];
		for (i=1;i<separateMults.length;i++) {
			for (var z=0;z<separateMults[i].length;z++) {
				charInArray=separateMults[i].charAt(z);
				if (isNaN(charInArray)) {
					multiplier = multiplier+charInArray;
				}
			}
		}
	}
		
	multNumber = parseString(multiplier,8);//match digits, minus sign,slash
	if (multNumber == null) {
		multNumber = 1;
	} else if (multNumber == "-") {
		multNumber = "-1";
	} else if (isFraction >-1){
		multNumber = multNumber.join("");
	} else {
		multNumber = Number(multNumber.join(""));
	}
	elementArray[arrayObjLoc].numerator =
		Number(elementArray[multiplierLoc].numerator)*Number(elementArray[arrayObjLoc].numerator);
	elementArray[arrayObjLoc].numerator=
		parseFloat(elementArray[arrayObjLoc].numerator.toFixed(3));
	elementArray[arrayObjLoc].denominator = 
		Number(elementArray[multiplierLoc].denominator)*Number(elementArray[arrayObjLoc].denominator);
	elementArray[arrayObjLoc].denominator=
		parseFloat(elementArray[arrayObjLoc].denominator.toFixed(3));
	
	if (multNumber != multiplier) { //if not equal then multiplier includes variable
		multVar = parseString(multiplier,4);//match letters only
		varInMultiplier=true;
		for (i=0;i<multVar.length;i++) {
			multVarMatch[i]=false;
			if (i==0) multExp[0]=elementArray[multiplierLoc].exponent;
			if (i==1) multExp[1]=elementArray[multiplierLoc].exponent2;
			if (i==2) multExp[2]=elementArray[multiplierLoc].exponent3;			
			if (i==3) multExp[3]=elementArray[multiplierLoc].exponent4;
		}
	} else varInMultiplier = false;

	answer = elementArray[arrayObjLoc].numerator;
	if (isFraction>-1 || 
			elementArray[arrayObjLoc].denominator != 1) {
		if (elementArray[arrayObjLoc].numerator==
			elementArray[arrayObjLoc].denominator) {
			elementArray[arrayObjLoc].numerator=1;
			elementArray[arrayObjLoc].denominator=1;
			answer = elementArray[arrayObjLoc].numerator;
		} else {
			answer = answer+"/"+elementArray[arrayObjLoc].denominator;	
		}
		var remainder=elementArray[arrayObjLoc].numerator%
						elementArray[arrayObjLoc].denominator;
		if (remainder==0) {
			answer=elementArray[arrayObjLoc].numerator/
					elementArray[arrayObjLoc].denominator;
			elementArray[arrayObjLoc].numerator=Number(answer);
			elementArray[arrayObjLoc].denominator=1;
		} 
	}

	if (answer == 1 || answer == "1") {
		if (varInMultiplier || 
				elementArray[arrayObjLoc].variable != null) 
			answer = "";
	} else if (answer == -1 || answer == "-1") {
		if (varInMultiplier || elementArray[arrayObjLoc].variable != null)
			answer = "-";
	}

	matchVar = true;
	while (matchVar) {
		i=0;
		switch (varCounter)
		{ 
		case 1:
			if (elementArray[arrayObjLoc].variable != null) { 
				while (varInMultiplier && i <multVar.length) {
					if (multVar[i] == elementArray[arrayObjLoc].variable) {
						elementArray[arrayObjLoc].exponent=
							Number(elementArray[arrayObjLoc].exponent)+Number(multExp[i]);
						multVarMatch[i]=true;
						variableAddedorFound = true;
					}
					i++;
				}
			}
			break;
	case 2:
		if (elementArray[arrayObjLoc].variable2 != null) { 
			while (varInMultiplier && i <multVar.length) {
				if (multVar[i] == elementArray[arrayObjLoc].variable2) {
					elementArray[arrayObjLoc].exponent2=
						Number(elementArray[arrayObjLoc].exponent2)+Number(multExp[i]);
					multVarMatch[i]=true;
				}
				i++;
			}
		}
		break;
	case 3:
		if (elementArray[arrayObjLoc].variable3 != null) { 
			while (varInMultiplier && i <multVar.length) {
				if (multVar[i] == elementArray[arrayObjLoc].variable3) {
					elementArray[arrayObjLoc].exponent3=
						Number(elementArray[arrayObjLoc].exponent3)+Number(multExp[i]);
					multVarMatch[i]=true;
				}
				i++;
			}
		}
		break;
	case 4:
		if (elementArray[arrayObjLoc].variable4 != null) { 
			while (varInMultiplier && i <multVar.length) {
				if (multVar[i] == elementArray[arrayObjLoc].variable4) {
					elementArray[arrayObjLoc].exponent4=
						Number(elementArray[arrayObjLoc].exponent4)+Number(multExp[i]);
					multVarMatch[i]=true;
				}
				i++;
			}
		}
		break;	
		} // end of switch loop
		varCounter++;
		if (varCounter > 4) matchVar = false;
		i=0;
	} //end while loop
	
	i=0;
	var saveVarAdded=false;
	if (varInMultiplier)
	{
		while (multVar[i] != null) {
			variableAddedorFound = false;
			if (!multVarMatch[i]) { 
				if (elementArray[arrayObjLoc].variable == null && !variableAddedorFound) {
					elementArray[arrayObjLoc].variable = multVar[i];
					if (i==0){
						elementArray[arrayObjLoc].exponent =
							Number(elementArray[multiplierLoc].exponent);
					} else if (i==1){
						elementArray[arrayObjLoc].exponent =
							Number(elementArray[multiplierLoc].exponent2);
					} else if (i==2){
						elementArray[arrayObjLoc].exponent =
							Number(elementArray[multiplierLoc].exponent3);
					} else if (i==3){
						elementArray[arrayObjLoc].exponent =
							Number(elementArray[multiplierLoc].exponent4);
					}
					variableAddedorFound=true;
					saveVarAdded=true;
				}
				if (elementArray[arrayObjLoc].variable2 == null && !variableAddedorFound) {
					elementArray[arrayObjLoc].variable2 = multVar[i];
					if (i==0){
						elementArray[arrayObjLoc].exponent2 =
							Number(elementArray[multiplierLoc].exponent);
					} else if (i==1){
						elementArray[arrayObjLoc].exponent2 =
							Number(elementArray[multiplierLoc].exponent2);
					} else if (i==2){
						elementArray[arrayObjLoc].exponent2 =
							Number(elementArray[multiplierLoc].exponent3);
					} else if (i==3){
						elementArray[arrayObjLoc].exponent2 =
							Number(elementArray[multiplierLoc].exponent4);
					}
					variableAddedorFound=true;
					saveVarAdded=true;
				}		
				if (elementArray[arrayObjLoc].variable3 == null && !variableAddedorFound) {
					elementArray[arrayObjLoc].variable3 = multVar[i];
					if (i==0){
						elementArray[arrayObjLoc].exponent3 =
							Number(elementArray[multiplierLoc].exponent);
					} else if (i==1){
						elementArray[arrayObjLoc].exponent3 =
							Number(elementArray[multiplierLoc].exponent2);
					} else if (i==2){
						elementArray[arrayObjLoc].exponent3 =
							Number(elementArray[multiplierLoc].exponent3);
					} else if (i==3){
						elementArray[arrayObjLoc].exponent3 =
							Number(elementArray[multiplierLoc].exponent4);
					}
					variableAddedorFound=true;
					saveVarAdded=true;
				}
				if (elementArray[arrayObjLoc].variable4 == null && !variableAddedorFound) {
					elementArray[arrayObjLoc].variable4 = multVar[i];
					if (i==0){
						elementArray[arrayObjLoc].exponent4 =
							Number(elementArray[multiplierLoc].exponent);
					} else if (i==1){
						elementArray[arrayObjLoc].exponent4 =
							Number(elementArray[multiplierLoc].exponent2);
					} else if (i==2){
						elementArray[arrayObjLoc].exponent4 =
							Number(elementArray[multiplierLoc].exponent3);
					} else if (i==3){
						elementArray[arrayObjLoc].exponent4 =
							Number(elementArray[multiplierLoc].exponent4);
					}
					variableAddedorFound=true;
					saveVarAdded=true;
				}
			}
			i++;
		} // end while loop to add in new variables from multiplier
	} // end block: if varInMultiplier is true.
	
	var orderChanged = false;
	variableAddedorFound = saveVarAdded;

	if (variableAddedorFound==true) orderChanged=sortVariables(arrayObjLoc);
	answer=buildVarPortion(answer,arrayObjLoc);

	elementArray[arrayObjLoc].string = answer;
	if (elementArray[arrayObjLoc].numerator==0) {
		elementArray[arrayObjLoc].variable=null;
		elementArray[arrayObjLoc].variable2=null;
		elementArray[arrayObjLoc].variable3=null;
		elementArray[arrayObjLoc].variable4=null;
		elementArray[arrayObjLoc].exponent=1;
		elementArray[arrayObjLoc].exponent2=1;
		elementArray[arrayObjLoc].exponent3=1;
		elementArray[arrayObjLoc].exponent4=1;
		answer="0";
		elementArray[arrayObjLoc].string = answer;
	}

	return(answer);	
}  

function buildVarPortion(answer, arrayObjLoc) {
	
	/*
	 * adds variables to elementArray string field and any exponents
	 * 
	 * bts 012014: need to handle neg exponent vals. Change test from
	 * exponent>1 to exponent != 1
	 */
	
	if (elementArray[arrayObjLoc].variable != null) { 
		answer=answer+elementArray[arrayObjLoc].variable;
		if (elementArray[arrayObjLoc].exponent != 1)
			answer=answer+"^"+elementArray[arrayObjLoc].exponent;
	}
	if (elementArray[arrayObjLoc].variable2 != null) { 
		answer=answer+elementArray[arrayObjLoc].variable2;
		if (elementArray[arrayObjLoc].exponent2 != 1)
			answer=answer+"^"+elementArray[arrayObjLoc].exponent2;
	}
	if (elementArray[arrayObjLoc].variable3 != null) { 
		answer=answer+elementArray[arrayObjLoc].variable3;
		if (elementArray[arrayObjLoc].exponent3 != 1)
			answer=answer+"^"+elementArray[arrayObjLoc].exponent3;
	}
	if (elementArray[arrayObjLoc].variable4 != null) { 
		answer=answer+elementArray[arrayObjLoc].variable4;
		if (elementArray[arrayObjLoc].exponent4 != 1)
			answer=answer+"^"+elementArray[arrayObjLoc].exponent4;
	}	
	return (answer);
}

function sortVariables(arrayObjLoc) {

	var sortAgain = false;
	var i,j;
	var multVar = [];
	var newOrder = false;

	var tempvar;
	var tempexp;
	var multExp = [];
	multVar[0]=elementArray[arrayObjLoc].variable;
	multExp[0]=elementArray[arrayObjLoc].exponent;
	if (elementArray[arrayObjLoc].variable2!= null) 
		multVar[1]=elementArray[arrayObjLoc].variable2;
	multExp[1]=elementArray[arrayObjLoc].exponent2;
	if (elementArray[arrayObjLoc].variable3!=null)
		multVar[2]=elementArray[arrayObjLoc].variable3;
	multExp[2]=elementArray[arrayObjLoc].exponent3;
	if (elementArray[arrayObjLoc].variable4!=null)
			multVar[3]=elementArray[arrayObjLoc].variable4;
	multExp[3]=elementArray[arrayObjLoc].exponent4;
	var sortVars = true;
	var ctr = multVar.length;
	while (sortVars) {
		i=0;
		j=1;
		sortAgain = false;
		while (i < ctr-j) {
			while (j<ctr && (ctr-j>i)) {
				if (multVar[i]>multVar[ctr-j]) {
					tempvar = multVar[ctr-j];
					tempexp = multExp[ctr-j];
					multVar[ctr-j]= multVar[i];
					multExp[ctr-j]= multExp[i];
					multVar[i]=tempvar;
					multExp[i]=tempexp;
					sortAgain = true;
					newOrder = true;
				} 
				j++;
			}
			j=1;
			i++;
		}
		if (!sortAgain) sortVars = false;
	}
	// copy new values back to data structure
	if (newOrder) {
		elementArray[arrayObjLoc].variable = multVar[0];
		elementArray[arrayObjLoc].exponent=multExp[0];
		elementArray[arrayObjLoc].variable2= multVar[1];
		elementArray[arrayObjLoc].exponent2=multExp[1];
		elementArray[arrayObjLoc].variable3=multVar[2];
		elementArray[arrayObjLoc].exponent3=multExp[2];
		elementArray[arrayObjLoc].variable4=multVar[3];
		elementArray[arrayObjLoc].exponent4=multExp[3];
	}
	return(newOrder);
}

function resetClearData()
{
	/*
	 * new function: bts 10212015
	 * called from Start Another Exercise button
	 * clears eval data then calls resetExercise 
	 * 
	 */
	clearEvalAlgExpnVars();
	clearAnswerFormTable("evaluateexpressiontable","variablerow");
	
    var solvedlist = document.getElementById("solvedexpressionslist");
    while (solvedlist.hasChildNodes()) {
    	solvedlist.removeChild(solvedlist.firstChild);
    }
	document.getElementById("hiddenproblemtype").innerHTML="stdentry";
	document.getElementById("problemTypeMenu").selectedIndex=0;
	resetExercise();
	return;	
}

function resetExercise() {
	/*
	 * modified to move clearing eval data to resetClearData
	 * so that we only clear eval vars/vals when user changes mode
	 * from eval to another type of problem
	 * 
	 */
    document.getElementById("userio").style.display="";
    document.getElementById("workarea").style.display="";
    document.getElementById("problemEntryArea").style.display="";
    document.getElementById("stdentry").style.display="";
    document.getElementById("problementryfield").value="";
    document.getElementById("hiddendivision").innerHTML="";
	document.getElementById("hiddendivisionside").innerHTML="";
    document.getElementById("numerator1field").value="";
    document.getElementById("numerator2field").value="";
    document.getElementById("denominator1field").value="";
    document.getElementById("denominator2field").value=""; 
    stopCount();
    document.getElementById("problemTimer").innerHTML="";
	document.getElementById("problemTimer").value=0;
	document.getElementById("evalentryhelp").style.display="none";
	
	document.getElementById("changevarvaluesbutton").style.display="none";
	document.getElementById("nextevalbutton").style.display="none";
	document.getElementById("testevalequation").innerHTML="";

	elementArray.splice(0);
	prevStepsArray.splice(0);
	document.getElementById("fractioncombinetip").style.display="none";
	document.getElementById("fractioncombinetip").innerHTML="";
	var hiddenSecondExpn=document.getElementById("hiddensecondexpn");
	var hiddenFirstEqAns=document.getElementById("hiddenfirsteqans");
	var hiddenAbsValSide=document.getElementById("hiddenabsvalorigside");
	hiddenSecondExpn.innerHTML="";
	hiddenFirstEqAns.innerHTML="";
	hiddenAbsValSide.innerHTML="";
	document.getElementById("hiddendoeqchecking").innerHTML="";
	document.getElementById("hiddennocheck").innerHTML="";
	document.getElementById("hiddensecondanswer").innerHTML="";
	document.getElementById("hiddencheckingprocess").innerHTML="";
	document.getElementById("hiddensolutions").innerHTML="";
	
	writeToStorage(" ------------ ");
	
	clearDisplayData("expnTable"); //erase blackboard
	displayPage();
	
	var tipText=document.getElementById("UserInstructionPrompt");
	if (tipText) {
		tipText.innerHTML=""; 
	}

	document.getElementById("UserInstructionPrompt").innerHTML = "";
	document.getElementById("hiddeneqfractionexpn").innerHTML="";
	
	var solvedExpns = document.getElementById("solvedexpressionslist");
	var lastExpnLine = solvedExpns.lastChild;
	var retainLine = false;
	if (!equationFlag && 
			(lastExpnLine == null || selExpType<22 || selExpType>23)) {
		clearEvalAlgExpnVars();
		clearAnswerFormTable("evaluateexpressiontable","variablerow");
		return;
	}
	document.getElementById("problemTypeMenu").selectedIndex=0;
	
	if (lastExpnLine !== null) {
		if (!equationFlag) {//alg expn test
			for (var i=0;i<lastExpnLine.innerHTML.length;i++) {
				if (lastExpnLine.innerHTML[i] == "=") retainLine=true;
			}
		} else {//eq test
			var semicolonPtr=lastExpnLine.innerHTML.indexOf(";");
			for (var i=lastExpnLine.innerHTML.length-1;i>semicolonPtr;i--) {
				if (lastExpnLine.innerHTML[i] == "=" ||
						lastExpnLine.innerHTML[i] == ">" ||
						lastExpnLine.innerHTML[i] == "<" ||
						lastExpnLine.innerHTML[i] == "\u2264" ||
						lastExpnLine.innerHTML[i] == "\u2265" ||
						lastExpnLine.innerHTML[i] == "\u2260") retainLine=true;
			}
		}
		if (!retainLine) {
			solvedExpns.removeChild(lastExpnLine);
			lastExpnLine = solvedExpns.lastChild;
			if (lastExpnLine.innerHTML == undefined) { 					
				var hiddenVarList = document.getElementById("hiddenvarlist");					
				var hiddenValues = document.getElementById("hiddenvarvalues");
				hiddenVarList.innerHTML = "";
				hiddenValues.innerHTML="";
			}	
		}
	}
	return;
}

function firstTime()
{
	var ua=navigator.userAgent.toLowerCase();
	var isIE=ua.indexOf("msie");
	if (isIE>-1) alert ("Math Assister does not work with Internet Explorer." +
			" Please exit and use a different browser.");
	// create sessionStorage object as if user logged in
	openStorageObject("TestUser");
	document.getElementById("displayhw").style.display="none";
	document.getElementById("newproblembutton").disabled=true;	
	document.getElementById("hiddendivision").style.display="none";
	document.getElementById("hiddendivision").innerHTML="";
	document.getElementById("hiddendivisionside").style.display="none";
	document.getElementById("hiddendivisionside").innerHTML="";
	document.getElementById("nextevalbutton").style.display="none"; 
	
	document.getElementById("hiddenanswertext").style.display="none";
	document.getElementById("hiddenobjpostext").style.display="none";
	document.getElementById("hiddenmultipliervalue").style.display="none";
	document.getElementById("hiddencaller").style.display="none";
	document.getElementById("hiddenmorevalues").style.display="none";
	document.getElementById("hiddenmultiplybothsides").style.display="none";
	document.getElementById("hiddenentryfield").style.display="none";
	document.getElementById("hiddensecondexpn").style.display="none";
	document.getElementById("hiddenfirsteqans").style.display="none";
	document.getElementById("hiddenabsvalorigside").style.display="none";
	document.getElementById("hiddendoeqchecking").style.display="none";
	document.getElementById("hiddendoeqchecking").innerHTML="";
	document.getElementById("hiddennocheck").style.display="none";
	document.getElementById("hiddennocheck").innerHTML="";
	document.getElementById("hiddensecondanswer").style.display="none";
	document.getElementById("hiddensecondanswer").innerHTML="";
	document.getElementById("hiddencheckingprocess").style.display="none";	
	document.getElementById("hiddencheckingprocess").innerHTML="";
	document.getElementById("hiddensolutions").style.display="none";	
	document.getElementById("hiddensolutions").innerHTML="";
	document.getElementById("hiddeneqfractionexpn").innerHTML="";
	document.getElementById("hiddeneqfractionexpn").style.display="none";
	displayPage();
	
	document.getElementById("helparea").style.display="";
	document.getElementById("mainblackboard").style.display="none";

	document.getElementById("hideGenlHilite1").style.display="";
	document.getElementById("hideGenlHilite2").style.display="";
	document.getElementById("turnAudioOnButton").style.display="";
	document.getElementById("turnAudioOffButton").style.display="none";
	document.getElementById("audioarea").style.display="none";
	document.getElementById("gobackbutton").style.display="";
	document.getElementById("sidenotes").style.display="none";
	document.getElementById("testevalequation").innerHTML="";
	document.getElementById("testevalequation").style.display="none";
	document.getElementById("hiddeneqvariables").innerHTML="";
	document.getElementById("hiddeneqvalues").innerHTML="";
	document.getElementById("hiddeneqvariables").style.display="none";
	document.getElementById("hiddeneqvalues").style.display="none";
	document.getElementById("hiddeneqevalonestep").innerHTML="false";
	document.getElementById("stdentryhelp").style.display="";
	document.getElementById("evalentryhelp").style.display="none";
	document.getElementById("proportionentryhelp").style.display="none";
	document.getElementById("hiddenproblemtype").innerHTML="stdentry";
	return;
}

function displayPage()
{
	document.getElementById("hiddenVariables").style.display="none";
	var errorToDisplay=document.getElementById("warningMessage");
	errorToDisplay.innerHTML = ""; 
	document.getElementById("mainblackboard").style.display="";

	hideForms();	
	hideWorkArea();
	hideDoAnotherButtons();
    elementArray.splice(0);

    displayTip("erase");
    var newMsg = document.getElementById("statusmsg");
    newMsg.innerHTML="Waiting for next exercise.";
    
	document.getElementById("gobackbutton").disabled=true;
	document.getElementById("problementryfield").focus();
    document.getElementById("multiplyboth").disabled=false;
    document.getElementById("multiplypart").disabled=false;
    return;
}

function getEntry(formatType)
{
	var i;
	var text;
	var item;
	var errMsgText="";
	var proportionExpn="";
	
	closegetstart();
	try { 			
		document.getElementById("problemEntryArea").style.display="none";
		document.getElementById("newproblembutton").disabled=false;	
		document.getElementById("workarea").style.display="";
		switch(formatType)
		{
		case "std":
			clearDisplayData("expnTable"); //erase blackboard
			selExpType=10;
			equationFlag=false;
			break;
		case "proportion":
			clearDisplayData("expnTable"); //erase blackboard
			proportionExpn=handleProportionInput();
			// set exptype to 40 temporarily
			selExpType=40;
			equationFlag=true;
			document.getElementById("proportionInstructions").style.display="none";
			break;
		case "xy":
			var xyProblem=true;
			doXYProblem();
			selExpType=50; // new exp type code						
			break;
		}
		
		if (proportionExpn!="") {
			if (proportionExpn !="53") {
				errMsgText=confirmPoly(proportionExpn);
			} else {// errorCode is 53: proportion entry error
				errMsgText=errorMsg(53,errMsgText);
				displayErrMsg(errMsgText, "entry");
			}
		} else {
			errMsgText=confirmPoly();
		}
		if (xyProblem) selExpnType=50;
		
		if (!errMsgText) setUpEquationStruct();
		if (errMsgText) {
			while (elementArray.length > 0) {
				elementArray.shift();
			}
			document.getElementById("workarea").style.display="";	
			document.getElementById("problemEntryArea").style.display="";
			document.getElementById("whatToDoNextArea").style.display="none";	
		} else {
			document.getElementById("problemEntryArea").style.display="none";
		}
		var isTouch = (('ontouchstart' in window) || (navigator.msMaxTouchPoints > 0));
		if (!isTouch) isTouch=true;//set to true to test on laptop
		if (isTouch) {
			if (equationFlag) {
				document.getElementById("mobileEntryField2").style.display="";
			} else {
				document.getElementById("mobileEntryField").style.display="";
			}		
		} 
	}
	catch (err) {
		alert("An unspecified error occurred. Please restart the app.");
	}
	startSolveTimer();	
	return;
}

function displayTip(conceptCode) {
	
	var appendTipFlag;
	var audioHint=document.getElementById("voiceOver");
	var hint=document.getElementById("stepExplanationText");
	hint.style.display="";
	if ((conceptCode=="cancel" && hint.title=="flip") ||
		(conceptCode=="lcd" && hint.title=="separate")) {
		appendTipFlag = true;
	} else {
		hint.innerHTML="";
	}
	hint.title="";

	document.getElementById("stepExplanation").style.display="";
	document.getElementById("simpalgbutton").style.display="none";
	document.getElementById("negativenumbershint").style.display="none";
	document.getElementById("equationTipPart1").style.display="none";	
	document.getElementById("equationTipPart2").style.display="none";
	document.getElementById("absoluteValue").style.display="none";
	document.getElementById("proportionInstructions").style.display="none";
	
	switch (conceptCode) 
	{
		case "erase":
			hint.style.display="none";
			document.getElementById("stepExplanation").style.display="none";
			document.getElementById("hideGenlHilite1").style.display="none";
			document.getElementById("hideGenlHilite2").style.display="none";
		break;
		case "pemdas":
			hint.innerHTML="To simplify a \<a href='javascript\:open_glossarywin(1);' " +
			"title='An expression with numbers only, no variables' >  " +
			" numeric expression\</a>, you perform each operation in the expression " +
			"one at a time until you have a single number in its " +
			" \<a href='javascript\:open_glossarywin(5);' title='One number with no operators' >simplest form</a>. " +
			"You must work in the \<a href='javascript\:open_glossarywin(2);' title=' Parentheses &rarr; Exponents &rarr;  " +
			"Multiply/Divide going from left to right &rarr; Add/Subtract going from left to right' target='helpcard'>" +
			"recommended order of operations\</a>";	

			document.getElementById("generalHighlight").style.display="";
			findAudio("pemdas");
			break;
			
		case "eval1":
			hint.innerHTML="To evaluate an expression, you must enter the values for the " +
					"variables. Math Assister substitutes the values in the expression " +
					"automatically.";
			break;
			
		case "eval2":
			hint.innerHTML="After the values have been substituted for the variables, you "+			
			"simplify the new numeric expression by performing each operation in the " +
			"expression one at a time until you have a single number in its simplest form. " +
			"You must work in the \<a href='javascript\:open_helpwin(3);' title=' Parentheses &rarr; Exponents &rarr;  " +
			"Multiply/Divide (Work from left to right) &rarr; Add/Subtract' (Work from left to right) >recommended order of operations\</a>";	
			document.getElementById("generalHighlight").style.display="";
			document.getElementById("mobileEntryField").focus();
			break;
				
		case "combineexponents":
			hint.innerHTML="If you multiply or divide powers with the same base, you can take a " +
					"shortcut by adding or subtracting the exponents.  This avoids having to calculate exponents for  " +
					"large numbers. If your numbers are small or if you use a calculator, you can " +
					"evaluate each power separately.";

			document.getElementById("generalHighlight").style.display="none";			
		   	document.getElementById("UserInstructionPrompt").innerHTML="To add or subtract exponents, highlight the " +
		   			"powers you want to combine. <br />" +
		   			"To calculate one power at a time, highlight it.";
			document.getElementById("UserInstructionPrompt").style.display="";
			break;
		
		case "negativehint8":
			hint.innerHTML="When you add a positive number and a negative number, ignore the negative sign and " +
				"subtract the smaller value from the larger one.  The sign of "+
				"the result will be the same as the sign of the number with the larger value. For example, <br />"+
				"\<span class='warning'>-10\</span>+1\=\<span class='warning'>-9\</span> <br />"+
				"10+\<span class='warning'>-1\</span>=9";
			break;
			
		case "negativehint12":
			hint.innerHTML="When you add two negative numbers, you get a negative result. For example, <br />"+
			"\<span class='warning'>-10\</span>+<span class='warning'>-9\</span>\=\<span class='warning'>19\</span> ";
			break;
			
		case "negativehint13":
			hint.innerHTML="Subtracting a positive number from a negative number is the same as  " +
				"adding two negative numbers. The result will be negative. For example, <br />"+
				"\<span class='warning'>-10\</span>-9\=\<span class='warning'>-10" +
				"\</span>+<span class='warning'>-9\</span>\=\<span class='warning'>19\</span> ";
			break;

		case "expon":
			hint.innerHTML="When you multiply two powers with the same base, you add the exponents. " +
					"When you divide two powers with the same base, you subtract the exponent for the " +
					"divisor (the second number) from the exponent for the dividend (the first number). " +
					"You cannot combine exponents for powers with different bases.";
			break;
			
		case "separatemixed":
			hint.innerHTML="One way to add mixed numbers is to separate the whole numbers from the fractions "
				+"and add the whole numbers and fractions separately. ";
			hint.title="separate";
			break;
		
		case "liketerms":
			hint.innerHTML="Like terms must contain exactly the same combination of variables raised to the same exponents. " +
					"In the following example, only xy\<sup>2\</sup> and 4xy\<sup>2\</sup>" +
					" are like terms because they both contain xy\<sup>2\</sup>.<br /><br />" +
        				"\<img src='help/images/liketerms.jpg'>";
			break;
		
		case "associate1":
			hint.innerHTML="The \<input class='helpbutton' type='button' value='associative' onclick='open_win('associative')'>"+
			 "property lets you perform multiplication in any order when you have more than two multipliers. "+
			 "Math Assister adds an extra set of parentheses (shown in orange) around the multipliers you chose. "+
			 "This avoids confusion by separating your multiplications. ";
			document.getElementById("whatToDoNextArea").style.display="none";
			break;
			
		case "associate2":
			hint.innerHTML="The \<input class='helpbutton' type='button' value='associative' onclick='open_win('associative')'>"+
			 "property lets you perform multiplication in any order when you have more than two multipliers. "+
			 "Math Assister adds an extra set of parentheses (shown in orange) around the multipliers you chose. "+
			 "This avoids confusion by separating your multiplications. "+
			 "\<button id='associateOK' onclick='solvePolynomial1()'>Got it</button>";

			document.getElementById("whatToDoNextArea").style.display="none";
			break;
						
			
		case "flipdivisor":
			hint.innerHTML="When you divide with fractions, you flip the divisor "+
				"(put the denominator on top and the numerator on the bottom) and multiply. ";
			hint.title="flip";
			break;
		
        case "algexp":
            hint.innerHTML="In simplify algebraic expression exercises, you " +
            	"remove any unnecessary parentheses first. Then you have " +
            	"two possibilities for your next action:" +
                    "\<ul>"+
                    "\<li>Perform multiplications. \</li>" +
                    "\<li>Combine like terms. \</li>" +
                    "\</ul>";
            hint.innerHTML=hint.innerHTML+"You're done when the expression is in its simplest form.";
            document.getElementById("simpalgbutton").style.display="";
            break;
            
         case "removeparenadd":
             hint.innerHTML="You can remove parentheses around expressions used in \<strong>addition<\/strong> " +
        				"as long as the expressions are not also used in multiplication,  division, " +
                		" or exponentiation. For example, <br /><br />" +
        				"\<img src='help/images/addedExpression.jpg'><br /><br />" +       				
        				"\<button id='simplifyaddparensOK' onclick='removeSubtractedExpression()'>Next step\</button>";
                findAudio("droppedaddedparens");
                break;
 
          case "removeparensub":
              hint.innerHTML="You can remove parentheses around expressions used in \<strong>subtraction<\/strong> " +
                		" as long as the expressions are not also used in multiplication, division, " +
                		"or exponentiation.  After you drop the parens, you " +
                		"need to change the sign of each + and - operator that was inside the parens. " +
                		"For example, <br /><br />" +
        				"\<img src='help/images/subtractedExpression.jpg'><br /><br />" +       				
        				"\<button id='simplifyaddparensOK' onclick='checkForSubtraction()'>Next step\</button>";
                findAudio("droppedsubtractedparens");
                break;
                
          case "reversesub": // used the term 'opposite'
              hint.innerHTML="Subtractions can be confusing when you combine like terms.  " +
                		"Math Assister changes a subtraction to adding the opposite of the term. " +
                		"The result is the same whether you subtract a term or add its negative version. " +
                		"Here's an example of how Math Assister changes a subtraction: <br /><br />" +
        				"\<img src='help/images/changeSubtraction.jpg'><br /><br />" +       				  
        				"\<button id='simplifyaddparensOK' onclick='finishCheckingParens()'>Next step\</button>";
                findAudio("forcesubtraction");
               break;
         			
		case "cancel":
				if (appendTipFlag) {
				hint.innerHTML = hint.innerHTML+
				"If you can find a \<strong>common factor\</strong> that divides evenly into one of the numerators " +
				"and also into one of the denominators, you can take a shortcut " +
				"called \<strong>cancelling\</strong>. <br /><br />" +
				"Or if you prefer, you can simply multiply the fractions as they are.";
			} else {
				hint.innerHTML="If you're multiplying fractions and " +
				"can find a \<strong>common factor\</strong> that divides evenly into one of the numerators " +
				"and also into one of the denominators, you can take a shortcut " +
				"called \<strong>cancelling\</strong>. <br /><br />" +
				"Or if you prefer, you can simply multiply the fractions as they are.";
			}
			break;

		case "lcd":
			if (appendTipFlag) {
				hint.innerHTML = hint.innerHTML+
				"You need a common denominator because you cannot add fractions with different denominators.  " +
				"For example, you can't add 1/2 + 1/3. The number <strong>6</strong> " +
				"works as a common denominator for these fractions, because you can divide 6 by 3 and you can divide 6 by 2. " +
				"Then you convert the fractions to 1/6's: 1/2=3/<strong>6</strong> and 1/3=2/<strong>6</strong>, and add them";
			} else {	
				hint.innerHTML=
					"You need a common denominator because you cannot add fractions with different denominators.  " +
					"For example, you can't add 1/2 + 1/3. The number <strong>6</strong> " +
					"works as a common denominator for these fractions, because you can divide 6 by 3 and you can divide 6 by 2. " +
					"Then you convert the fractions to 1/6's: 1/2=3/<strong>6</strong> and 1/3=2/<strong>6</strong>, and add them";
			}

			findAudio("addfrac");
			break;
								
		case "dist1":
			document.getElementById("distribute1").style.display="";
			document.getElementById("whatToDoNextArea").style.display="none";
			findAudio("multpoly"); 
			break;
					
		case "multiplyFractions":
			hint.innerHTML=
				"When you multiply fractions, you multiply the numerators by each other " +
				"and the denominators by each other. Whole numbers have a denominator of 1.";
			document.getElementById("whatToDoNextArea").style.display="";
			break;

		case "equation":
			var algExpnWithAbsolVars=false;
			var absValPos=[];
			var tooManyTerms=false;
			absValPos=checkForAbsolValBars();
			if (absValPos.length>0) {//check for more than 2 terms
				document.getElementById("absoluteValue").style.display="";
			} else {
				document.getElementById("equationTipPart1").style.display="";
				findAudio("equations"); 
				var toggleValue=document.getElementById("eqtoggle").value;
				if (toggleValue=="Hide the steps for equations") { 
					document.getElementById("equationTipPart2").style.display="";				
				}	else {
					toggleValue.innerHTML="Show the steps for equations"; 
					document.getElementById("equationTipPart2").style.display="none";								
				}	
			}
			document.getElementById("whatToDoNextArea").style.display="";
			break;

		case "absValueProblem":
			document.getElementById("absoluteValue").style.display="";
			var toggleValue=document.getElementById("eqtoggle").value;
			if (toggleValue=="Hide the steps for equations") {
				document.getElementById("equationTipPart2").style.display="";
			}	else {
				toggleValue.innerHTML="Show the steps for equations"; denomArray[arrayCtr]=String(elementArray[ptr].denominator);
				document.getElementById("equationTipPart2").style.display="none";								
			}
	
			document.getElementById("whatToDoNextArea").style.display="";
			findAudio("absolutevaluesplit");
			break;

		case "addtobothsides":
			hint.innerHTML=
				"If you need to move a term to the other side,   " +
				"add its inverse (that is, the term multiplied by -1) to both sides.";
			document.getElementById("whatToDoNextArea").style.display="";
			break;

		case "dividebothsides":
			hint.innerHTML=
				"You can remove the coefficient of a variable by dividing both sides by the same term. " +
				"Enter the number you want to divide by. Math Assister does division by  " +
				"multiplying both sides by the reciprocal of the term you enter.";
			document.getElementById("whatToDoNextArea").style.display="";
			break;

		case "multiplybothsides":
			hint.innerHTML=
				"If the variable has a coefficient, multiply both sides by the reciprocal of the coefficient. " +
				"If the coefficient is -1, multiply both sides by -1.";
			document.getElementById("whatToDoNextArea").style.display="";
			break;

		case "afteraddtobothsides":
			hint.innerHTML=
				"After you add a term to both sides of an equation or inequality, " +
				"you combine like terms. This simplifies expressions on BOTH sides.";
			document.getElementById("whatToDoNextArea").style.display="";
			break;

		case "aftermultiplybothsides":
			hint.innerHTML=
				"After you add a multiplier to both sides of an equation, " +
				"you perform the multiplications for each side.";
			document.getElementById("whatToDoNextArea").style.display="";
			break;

		case "allvarvals":
			hint.innerHTML=
				"If you are given values for all variables in your equation or inequality, then" +
				"you have to simplify both sides entirely to prove if the equation or inequality is true or false";		
			document.getElementById("whatToDoNextArea").style.display="";
			break;

		case "mostvarvals":
			hint.innerHTML=
				"If you are given values for all variables except one in your equation, then" +
				"you have to change the equation around so that one side contains a variable " +
				"with no coefficients (including -1) and the other side has a single numeric " +
				"term in its simplest form. This is good preactice for using formulas.";		
			document.getElementById("whatToDoNextArea").style.display="";
			break;
			
		case "proportion":
			hint.innerHTML="Math Assister uses cross multiplication to solve a proportion. " +
					"For example, you change " +
					"\<strong>\<sup>2\</sup>\/<sub>x+1\</sub>=\<sup>3\</sup>\/<sub>4\</sub> \</strong> to " +
					" \<strong>2*4=3*(x+1)\</strong>. " +					
					"After Math Assister sets up the cross products, you solve the problem like any equation.";
			document.getElementById("whatToDoNextArea").style.display="";
			document.getElementById("proportionInstructions").style.display="";
			break;

		default: //erase if no argument
			hint.style.display="none";
			document.getElementById("stepExplanation").style.display="none";

		break;
	}
	document.getElementById("userInstructions").style.display="";
	return;
}

function displayHelpButton (helpType){
	var hint=document.getElementById("stepExplanation");
	
	if (helpType=="button") {
		var button = document.createElement("input");
		button.setAttribute("id", "conceptHelp");
		button.setAttribute("type", "button");
		button.setAttribute("class", "helpbutton");
		hint.appendChild(button);
	} else { //must be a an HTML link
		var link = document.createElement("a");
		link.setAttribute("id", "helpLink");
		hint.appendChild(link);		
	}
	return;	
}

function displayHintSteps (hintSteps) {
	var i;
	var text;
	var item;
	var hint=document.getElementById("stepExplanation");	
	var list=document.createElement("ol");
	
	for (i=0;i<hintSteps.length;i++){
		item=document.createElement("li");
		text=document.createTextNode(hintSteps[i]);
		item.appendChild(text);
		list.appendChild(item);
	} 	
	hint.appendChild(list);
	return;	
}

function clearEvalAlgExpnVars() 
{
	/*
	 * clears out hidden variables for evaluating algebraic expression
	 */
	document.getElementById("hiddenvarlist").innerHTML="";
	document.getElementById("hiddenvarvalues").innerHTML="";
	document.getElementById("hiddenorigexpression").innerHTML="";
	
	document.getElementById("hiddeneqvariables").innerHTML="";
	document.getElementById("hiddeneqvalues").innerHTML="";
	return;
}

function hideDoAnotherButtons ()
{
	document.getElementById("distribute1").style.display="none";
	document.getElementById("secondexpression").style.display="none";
	document.getElementById("firstterm").style.display="none";
	document.getElementById("secondterm").style.display="none";
	return;
}

function hideWorkArea ()
{
	document.getElementById("distribute1").style.display="none";
	document.getElementById("operationMenuArea").style.display="none";
	document.getElementById("simplifyMenu").selectedIndex=0;
	document.getElementById("equationMenu").selectedIndex=0;
	document.getElementById("combineliketermsform").reset();
	document.getElementById("getanswerform").reset();
	document.getElementById("generalHighlight").style.display="none";
	document.getElementById("problemEntryArea").style.display="";
	document.getElementById("whatToDoNextArea").style.display="none";
	return;
}

function hideForms()
{
	document.getElementById("combineliketermsform").style.display="none";
	document.getElementById("getanswerform").style.display="none";	
	document.getElementById("commondenominatorform").style.display="none";	
	document.getElementById("evaluateexpressionform").style.display="none";
	document.getElementById("simplifylastfractionform").style.display="none";
	document.getElementById("simplifylastfractiongotit").style.display="none";
	document.getElementById("simplifylastfraction").style.display=""; //answer button
	document.getElementById("simplifylastfraction").disabled=false;
	document.getElementById("simplifylastfractionhelpbutton").disabled=true;//I give up button
	document.getElementById("simplifylastfractionhelpbutton").style.display="";
	document.getElementById("converttomixednumberform").style.display="none";
	document.getElementById("impropernumberform").style.display="none";   
    document.getElementById("cancelfractionnumber").style.display="none"; 
    document.getElementById("converttolcdform").style.display="none"; 
	document.getElementById("converttolcdhelpbutton").disabled=true;
	clearMixedNumHiddenVals();
	document.getElementById("problemEntryArea").style.display="";
    document.getElementById("multiplyPart").style.display="none"; 
    document.getElementById("addToBothSidesArea").style.display="none";
    document.getElementById("subtractFromBothSidesArea").style.display="none"; 
    document.getElementById("multiplyBothSidesArea").style.display="none";
    document.getElementById("divideBothSidesArea").style.display="none"; 
    document.getElementById("splitoption").disabled=true;
	document.getElementById("hiddensingleabsolval").innerHTML="";
	document.getElementById("hiddensingleabsolval").style.display="none";	
    document.getElementById("fracentry").style.display="none";
	document.getElementById("stdentryhelp").style.display="";
	document.getElementById("evalentryhelp").style.display="none";
	document.getElementById("proportionentryhelp").style.display="none";

	return;
}

function open_glossarywin(glossaryterm)
{
	/*
	 * Clone of open_win. Opens glossary window in a named frame
	 */
	var fileName="";

	var cardWidth="width=700";
	var cardHeight="height=600";

	fileName="help/glossary.html#"+glossaryterm;
	window.open(fileName,"glossarypage","toolbar=no, " +
			"location=no, directories=no, status=no, menubar=no, " +
			"scrollbars=yes, resizable=no, copyhistory=yes, "+cardWidth+", "+
			cardHeight); 
	return;
}

function open_helpwin (helpCode)
{
	/*
	 * Clone of open_win
	 * Opens help files in separate browser window, called helpcard
	 * Called from javascript only. Main window uses open_wi n
	 */
	var helpCode;
	var fileName;
	var cardWidth="width=700";
	var cardHeight="height=600";
		
	switch (helpCode) 
	{
	case 1:
		fileName="helpTOC.html";
		break;	

	case 2:
		fileName="help/overview.html";
		break;
	
	case 3:
		fileName="help/pemdas.html";
		break;
		
	case 4:
		fileName="help/lcd.html";
		break;
	
	case 5: //canceling
		fileName="help/canceling.html";
		break;
		
	case 6: //converting to lcd
		fileName="help/convertingtolcd.html";
		break;
		
	case 7: //commutation
		fileName="help/commutativePropertyAdd.html";
		break;
			
	case "exercisetype":
		fileName="help/exercisetype.html";
		break;
		
	case "simplifyfraction":
		fileName="help/simplifyingfractions.html";
		break;
		
	case "enteringexpressions": //added help card for equations
		if (equationFlag) {
			fileName="help/choosingequationactions.html";
		} else {
			fileName="help/enteringexpressions.html";
		}		
		break;
		
	case "evaluations":
		fileName="help/evalalg.html";
		break;

	case "solvingequations":
		fileName="help/solvingequations.html";
		break;
		
	case "simpalg":
		fileName="help/simpalg.html";
		break;	
				
	case "associative":
		fileName="help/associativePropertyAdd.html";
		break;
		
	case "distribution":
		fileName="help/distributiveProperty.html";
		break;	
	
	case "binomialdistribution":
		fileName="help/distributiveProperty.html";
		break;
			
	case "displayDenominator":
		fileName="help/displaydenominator.html";
		break;

	case "samples":
		fileName="help/sampleProblems.html";
		break;
		
	case "highlighting":
		fileName="help/highlighting.html";
		break;
		
	case "":
		fileName="help/.html";
		break;
		
	default:
		fileName="help/overview.html";
	}
	
	// open help window in same frame 
	window.open(fileName,"helpcard","toolbar=no, " +
			"location=no, directories=no, status=no, menubar=no, " +
			"scrollbars=yes, resizable=no, copyhistory=yes, "+cardWidth+", "+
			cardHeight); 	
	return;
}

function open_win(helpCode)
{	
	var helpCode;
	var fileName;
	var cardWidth="width=700";
	var cardHeight="height=600";
		
	switch (helpCode) 
	{
	case "helptoc":
		fileName="helpTOC.html";
		break;	

	case "glossary":
		fileName="help/glossary.html";
		break;	

	case "overview":
		fileName="help/overview.html";
		break;
		
	case"pemdas":
		fileName="help/pemdas.html";
		break;
		
	case "exercisetype":
		fileName="help/exercisetype.html";
		break;
		
	case "simplifyfraction":
		fileName="help/simplifyingfractions.html";
		break;
		
	case "choosingactions": //added help card for equations
		if (equationFlag) {
			fileName="help/choosingequationactions.html";
		} else {
			fileName="help/choosingexpressionactions.html";
		}		
		break;

	case "enteringproportions":
		fileName="help/enteringproportions.html";
		break;

	case "enteringexpressions": //added help card for equations
		if (equationFlag) {
			fileName="help/choosingequationactions.html";
		} else {
			fileName="help/enteringexpressions.html";
		}		
		break;

	case "solvingequations":
		fileName="help/solvingequations.html";
		break;

	case "canceling":
		fileName="help/canceling.html";
		break;
		
	case "simpalg":
		fileName="help/simpalg.html";
		break;
		
	case "evalexp":
		fileName="help/evalexp.html";
		break;
				
	case "associative":
		fileName="help/associativePropertyAdd.html";
		break;
		
	case "distribution":
		fileName="help/distributiveProperty.html";
		break;	
	
	case "binomialdistribution":
		fileName="help/distributiveProperty.html";
		break;
		
	case "commutative":
		fileName="help/commutativePropertyAdd.html";
		break;
		
	case "displayDenominator":
		fileName="help/displaydenominator.html";
		break;

	case "samples":
		fileName="help/sampleProblems.html";
		break;
		
	case "highlighting":
		fileName="help/highlighting.html";
		break;
	
	case "workingwithfractions":
		fileName="help/workingwithfractions.html";
		break;

	case "":
		fileName="help/.html";
		break;
		
	default:
		fileName="help/overview.html";
	}
	//open help window in same frame 
	window.open(fileName,"helpcard","toolbar=no, " +
			"location=no, directories=no, status=no, menubar=no, " +
			"scrollbars=yes, resizable=no, copyhistory=yes, "+cardWidth+", "+
			cardHeight); 	
	return;
}

var customPause;
function pauseTimer(timeToWait) 
{
	var timeToWait;// # of milliseconds to pause
	var d=new Date();
	var startSec, endSec;
	
	startSec = d.getTime();
	endSec = startSec;

	while (endSec - startSec<timeToWait) {
		var updateDate = new Date();
		endSec = updateDate.getTime();
	}
	stopPause();
	return;
}
function stopPause()
{
	clearTimeout(customPause);
	return;
}

function computeFactors(myNum)
{
    var i=0;
    var j=0;
    var myRemainder;
    var myResult=0;
    var myNum, numToFactor;
    var factorList = [];
	var primeTable = [2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73,79,83,89,97];
    
	numToFactor = Number(myNum);
	if (numToFactor <= 1)
	{
		factorList[0]=1;
	}
	else 
	{
		while (myResult !== 1)
		{
			myRemainder = numToFactor%primeTable[i];
			myResult = numToFactor/primeTable[i];
			if (myRemainder == 0)
			{
				factorList[j] = primeTable[i];
				j=j+1;
				i=-1;
				numToFactor = myResult;
			}
			i=i+1;
			if (i > 24)
			{
				alert("Invalid number entered");
				break;
			}
		}
	}
	return(factorList);
}

function getFactorPairs(numberToFactor) 
{
	var factorPairList = [];
	var numToFactor;
	var remainder, result;
    var i=1; // number to divide into numToFactor
    var j=0; // array position pointer
	
	numToFactor = Number(numberToFactor);
	numToFactor = Math.abs(numToFactor);
	while (i<numToFactor) {
		remainder = numToFactor%i;
		result = numToFactor/i;
		if (remainder == 0) {
			factorPairList[j] = result;
			j++;
		}
		i=i+1;
	}
	return(factorPairList);
}

function flipDivisor(beginObj,endObj,secBeginObj,secEndObj,
		doNotDisplayFlip)
{
	var twoDivisors=false;
	var flipCnt=1;//number of divisors to flip
	var bObj,eObj;//hold beginObj and endObj in case there are 2 sets
	if (secBeginObj || secEndObj) {
		twoDivisors=true;
		flipCnt=2;
	}
	
	var tempNumerator;
	var color, j;
	var negFactor, negString;

	for (var i=0;i<flipCnt;i++) {
		negString="";
		negFactor=1;
		if (i==0) {
			bObj=beginObj;
			eObj=endObj;
		} else if (i==1) {
			bObj=secBeginObj;
			eObj=secEndObj;
		}
		elementArray[bObj+1].string="*";
		tempNumerator = elementArray[eObj].numerator;
		if (Number(tempNumerator)< 0) {
			negFactor=-1;
			negString="-";
		}
		elementArray[eObj].numerator = elementArray[eObj].denominator*negFactor;
		elementArray[eObj].denominator = tempNumerator*negFactor;
		if (elementArray[eObj].denominator==1) {//not fraction
			elementArray[eObj].string = String(elementArray[eObj].numerator);				
		} else {
			elementArray[eObj].string = String(elementArray[eObj].numerator)+
					"/"+elementArray[eObj].denominator;	
		}
	
		// highlight portion to be flipped
		color = "yellow";
		for (j=eObj;j<eObj+1;j++) {
			writeMultHighlight(j,1,elementArray.length,color);
		}
	}
	if (!doNotDisplayFlip) {
		writeToTable(" -- After flipping divisor and changing to multiplication");	
	}
	
	// highlight portion to be solved
	color = "yellow";
	for (j=beginObj;j<endObj+1;j++) {
		writeMultHighlight(j,1,elementArray.length,color);
	}
	//highlight right side of equation if divisor flipped 
	if (twoDivisors) {
		for (j=secBeginObj;j<secEndObj+1;j++) {
			writeMultHighlight(j,1,elementArray.length,color);
		}		
	}
		
	if ((document.getElementById("hiddendivfrac").innerHTML=="playme") ||
	(document.getElementById("hiddendivfrac").innerHTML=="")) {
		findAudio("divfrac");
	} else {
		findAudio("cancelling");
	}
	return;
}

function checkForFractionCancel(beginObj,endObj) 
{
	var cancelNeeded = false;
	var numerator=[];
	var denom=[];
	var numbersToFactor = [];
	var factorResults = [];
	var i,j, k,x,y,dlen,nlen;
	var matchNumbers=[];

	numbersToFactor[0] = elementArray[beginObj].numerator;
	numbersToFactor[1] = elementArray[endObj].numerator;
	numbersToFactor[2] = elementArray[beginObj].denominator;
	numbersToFactor[3] = elementArray[endObj].denominator;	
	
	for (i=0;i<4;i++) {
		factorResults[i] = getFactorPairs(numbersToFactor[i]);
	}

	i = 0;
	j = 2;
	y=0; 
	matchNumbers[0]=0;
	for (x=0;x<2;x++) { // loop thru numerators
		nlen = factorResults[x].length;
		for (i=0;i<nlen;i++) { // numerator list of factors
			for(k=2;k<4;k++) {// denominators
				dlen = factorResults[k].length;
				for (j=0;j<dlen;j++) {
					if (factorResults[x][i] == factorResults[k][j]) {
						matchNumbers[y] = factorResults[x][i];
						y++;
					}
				}
			}
		}
	}
	return (matchNumbers);
}

function setCancelPrompt(beginObj,endObj,matchNumbers)
{
	var num1, num2;
	var denom1, denom2;
	
	var hiddenBeginObj = document.getElementById("hiddenbeginobj");
	hiddenBeginObj.innerHTML = beginObj;
	hiddenBeginObj.style.display="none";
	var hiddenEndObj = document.getElementById("hiddenendobj");
	hiddenEndObj.innerHTML = endObj;
	hiddenEndObj.style.display="none";	
	var hiddenMatchNumbers = document.getElementById("hiddenmatchnumbers");
	hiddenMatchNumbers.innerHTML = matchNumbers;
	hiddenMatchNumbers.style.display="none";
	
	num1 = elementArray[beginObj].numerator;
	denom1=elementArray[beginObj].denominator;
	num2 = elementArray[endObj].numerator;
	denom2=elementArray[endObj].denominator;
	
	var cancelSpecifics = document.getElementById("specificCancelNumbers");

	cancelSpecifics.innerHTML="If you can find a \<b>common factor\</b> that can be divided into " +
	"one of the numerators &mdash; \<b>"+ num1 + "\</b> or \<b>"+num2+" \</b> &mdash; and also into one of the denominators &mdash;\<b>"+ denom1+"\</b> " +
	"or \<b>" + denom2+ "\</b>, you can use " +
	"\<a href='javascript\:open_helpwin(5);' title='Shortcut for multiplying fractions' >canceling\</a>.";
	//"\<a href='help/canceling.html' title='Shortcut for multiplying fractions'  target='_blank'>canceling\</a>.";

	document.getElementById("cancelfractionnumber").style.display="";
	document.getElementById("cancelfractioninput").focus();
	document.getElementById("userInstructions").style.display="";
	
	if (document.getElementById("hiddendivfrac").innerHTML=="playme"){
		findAudio("divfrac");
	} else {
		findAudio("cancelling");
	}
	return;
}

function skipCancelFractionNum() 
{
	var doNotCancel = true;
	document.getElementById("cancelfractionnumber").style.display="none";
	var errMsg=document.getElementById("cancelfractionmessage");
	errMsg.innerHTML = "";
	
	var errorToDisplay=document.getElementById("warningMessage");
	errorToDisplay.innerHTML="";	
	checkCancelFractionNum(doNotCancel);
	return;
}

function showCancelFractionNum() 
{
	/*
	 * displays the common factor for cancelling
	 */
	var doNotCancel=false; // don't branch to multiply
	var showFactor=true; // display common factor and let them continue
	
	var errorToDisplay=document.getElementById("warningMessage");
	errorToDisplay.innerHTML="";
	// display common factor
	var helpMsg=document.getElementById("cancelfractionmessage");
	helpMsg.innerHTML = "";
	
	checkCancelFractionNum(doNotCancel,showFactor);
	showFactor=false;
	return;
}
function checkCancelFractionNum(doNotCancel,showFactor) 
{	
	var cancelElement;
	var cancelNumber;
	var beginObj, endObj;
	var beginObjStr, endObjStr;
	var matchNumberArray = [];
	var matchNumbers;
	var hiddenBeginObj, hiddenEndObj, hiddenMatchNumbers;
	var x, i;
	var matchFound = false;
	var showMessage;
	var termFound;
	var numbersToFactor = [];
	var cancelFractions = [];

	document.getElementById("stepExplanation").style.display="none";
	document.getElementById("stepExplanationText").style.display="none";
	document.getElementById("specificCancelNumbers").style.display="";
	
	hiddenBeginObj = document.getElementById("hiddenbeginobj");
	beginObjStr = hiddenBeginObj.innerHTML;
	beginObj = Number(beginObjStr);
	hiddenEndObj = document.getElementById("hiddenendobj");
	endObjStr=hiddenEndObj.innerHTML;
	endObj = Number(endObjStr);
	hiddenMatchNumbers = document.getElementById("hiddenmatchnumbers");
	matchNumbers = hiddenMatchNumbers.innerHTML;
	
	matchNumberArray = matchNumbers.split(",");
	
	if (doNotCancel == null || doNotCancel == "" || !doNotCancel) {
		/*
		 * get the number entered, make sure it is on the matchNumbers list
		 * If it is, then find the numerator/denominator pair that it applies to
		 * do the simplification, update the blackboard display w/strikethru,
		 * update the structure with new numerator/denom values
		 * Check if more simplification is possible
		 */ 
		cancelElement = document.getElementById("cancelfractioninput");
		showMessage = document.getElementById("cancelfractionmessage");
		showMessage.innerHTML="";		
		var errorToDisplay=document.getElementById("warningMessage");
		
		cancelNumber = Number(cancelElement.value);
		cancelNumber = Math.abs(cancelNumber);
		if (showFactor) {
			var optCommonFactor = Math.max.apply(Math,matchNumberArray);
			showMessage.innerHTML="Common factor to use is: "+
					String(optCommonFactor);
			return;			
		} else { //showFactor is false
			for (i=0;i<matchNumberArray.length;i++) {
				if (cancelNumber == Number(matchNumberArray[i])) {
					// bts 1012: erase the warning message innerhtml
					errorToDisplay.innerHTML="";
					matchFound = true;
				}
			}
			if (!matchFound) {
				writeWrongAns(document.getElementById("cancelfractionnumber").innerHTML,
						cancelNumber,"cancelfraction");
				errorToDisplay.innerHTML="Common factor "+
					String(cancelNumber)+" is incorrect. Try again.";;
				document.getElementById("cancelfractionnumber").reset();
				document.getElementById("cancelfractionnumber").style.display="";
				return false;
			}
		}
		// see which numerator/denominator pair this cancelNumber applies to
		cancelNumber = Number(cancelNumber);
		beginObj = Number(beginObj);
		endObj = Number(endObj);
		numbersToFactor[0] = Number(elementArray[beginObj].numerator);
		numbersToFactor[1] = Number(elementArray[endObj].numerator);
		numbersToFactor[2] = Number(elementArray[beginObj].denominator);
		numbersToFactor[3] = Number(elementArray[endObj].denominator);	
		termFound=false;
		i=0;
		var objectPos;
		
		var numeratorIndicator;
		var strikeLen = 1;
		var elemArrayLen = elementArray.length;
		
		while (!termFound) {
			termFound = testIfFactor(cancelNumber, numbersToFactor[i]);
			if (termFound) {
				// update structure; change expression on blackboard
				if (i==0 || i==2) { // update the numerator value of beginObj
					objectPos = beginObj;
				} else if (i==1||i==3) {
					objectPos = endObj;
				}
				if (i<2) { // update numerator
					elementArray[objectPos].numerator = Number
						(elementArray[objectPos].numerator/cancelNumber);
					elementArray[objectPos].string = elementArray[objectPos].numerator+"/"+
						elementArray[objectPos].denominator;
					numeratorIndicator = true;
					writeCancelMark(objectPos, elementArray[objectPos].numerator, 
							numeratorIndicator,elemArrayLen);
					i=2;
					termFound=false;
				} else { // update denominator
					elementArray[objectPos].denominator = Number
						(elementArray[objectPos].denominator/cancelNumber);
					elementArray[objectPos].string = elementArray[objectPos].numerator+"/"+
						elementArray[objectPos].denominator;
					numeratorIndicator = false;
					writeCancelMark(objectPos, elementArray[objectPos].denominator,
							numeratorIndicator,elemArrayLen);
				}
			} else {
				i++;
			}			
		}
		document.getElementById("cancelfractionnumber").reset();
		writeToTable(" -- After dividing by the common factor "+cancelNumber); // write out the new line after cancel oper
		cancelFractions = checkForFractionCancel(beginObj,endObj);
		if (cancelFractions[0] != 0) {// ask if fraction(s) should be canceled again
			setCancelPrompt(beginObj,endObj,cancelFractions);
			return;
		} else {
			document.getElementById("cancelfractionnumber").style.display="none";
		}
	} else {
		document.getElementById("cancelfractionnumber").style.display="none";
	}
	
	// calcAnswerArray[0] is calculated numerator; [1] is denominator
	
	var expnToSolveArray=buildArray(beginObj,endObj);
	var expnToSolve = "";
	expnToSolve=buildStrPart(beginObj,endObj);
	
	var calcAnswerArray; // holds calculated answer for fractions
	var userFractionPrompt = [];
	
	var expnToSolveArray=buildArray(beginObj,endObj);
	calcAnswerArray = calculateFractionAnswer(expnToSolveArray,beginObj, endObj);
	var fractString;
	var specialText;
	fractString=String(elementArray[beginObj].numerator)+"/"+
					String(elementArray[beginObj].denominator);
	specialText=setMixNumFractTextEffects(fractString);
	userFractionPrompt[0]= specialText+elementArray[beginObj+1].string;
	fractString=String(elementArray[endObj].numerator)+"/"+
					String(elementArray[endObj].denominator);
	specialText=setMixNumFractTextEffects(fractString);
	userFractionPrompt[0]= userFractionPrompt[0]+specialText;	
	
	var num = calcAnswerArray[0];
	var denom = calcAnswerArray[1];
	var calcAnswer = String(calcAnswerArray[0])+"/"+String(calcAnswerArray[1]);
	var expnHasFractions=true;
	var expnOperation="multiplication";
	performSimpleMathPartTwo(beginObj,endObj,num,denom,calcAnswer,
			expnOperation, expnHasFractions,expnToSolve,
			userFractionPrompt,	calcAnswerArray);
	
	return true;
}

function testIfFactor(divideNumber, numToFactor)
{
	/*
	 * returns true if divideNumber is a factor of numToFactor
	 */
	var remainder;
	var factorFound=false;
	
	remainder = numToFactor%divideNumber;
	if (remainder == 0) factorFound = true;
	return(factorFound);
}

function helpSimplifyLastFraction() 
{
	/*
	 * Provides the answer for cancelling fractions
	 * or simplifying last fraction when Give Up pressed
	 */
	var enterAnsForMe = true;
	if (equationFlag) {
		simplifyLastEqFraction(enterAnsForMe);
	} else 
		simplifyLastFraction(enterAnsForMe);
	return;
}

function simplifyLastFraction(enterAnsForMe)
{
	var simplifyFractionInput;
	var errorMessage;
	var simplifyFractionNumber;	
	var cancelNumber = [];
	var i;
	var matchFound;
	var termNumber;
	var solved;
	var convertToMixed;
	var objectLoc, objectLocElement;
	
	if (equationFlag) {
		simplifyLastEqFraction(enterAnsForMe);
		return;
	}
		
	var errorToDisplay=document.getElementById("warningMessage");
	errorToDisplay.innerHTML = ""; 
		
	document.getElementById("simplifylastfractiongotit").style.display="none";
	
	simplifyFractionInput = document.getElementById("simplifylastfractioninput");
	errorMessage = document.getElementById("simplifylastfractionmessage");
	simplifyFractionNumber = simplifyFractionInput.value;
	document.getElementById("simplifylastfractionform").reset();
	
	// check if we're solving the last fraction term
	// or last fraction when there are still whole numbers to add
	// bts 090414: if coming from alg expns, fraction term ptr
	//	MUST be set in hiddenendobj.
	
	objectLocElement = document.getElementById("hiddenendobj");
	objectLoc = objectLocElement.innerHTML;
	if (objectLoc == "undefined" || objectLoc == null || objectLoc=="") {
		objectLoc = 0;
	}
	
	cancelNumber = checkForFractionCancel(objectLoc,objectLoc);
	for (i=0;i<cancelNumber.length;i++) {
		if (simplifyFractionNumber == cancelNumber[i]) {
			errorMessage.innerHTML=" ";
			matchFound = true;
			i=cancelNumber.length;
		}
	}

	var errorToDisplay=document.getElementById("warningMessage");
	
	if (enterAnsForMe) {
		writeGaveUpMsg(" computing factor for cancelling last fraction");
		simplifyFractionNumber = Math.max.apply(Math,cancelNumber);
		simplifyFractionInput.value = simplifyFractionNumber;
		
		errorMessage.innerHTML="The correct common factor is: " 
			+ simplifyFractionNumber+".";	
		enterAnsForMe=false;
		document.getElementById("simplifylastfraction").style.display="none";
		document.getElementById("simplifylastfractionhelpbutton").style.display="none";
		document.getElementById("simplifylastfractiongotit").style.display="";
		errorToDisplay.innerHTML="";
		return false;
	}
	
	if (!matchFound) {
		writeWrongAns(" ",simplifyFractionNumber,"simplifylastfraction");
		errorToDisplay.innerHTML = "Common factor "+simplifyFractionNumber+
			" is incorrect. Try again.";
		document.getElementById("simplifylastfractionhelpbutton").disabled=false;
		document.getElementById("simplifylastfractionform").reset();
		return false;
	}
	document.getElementById("simplifylastfractionhelpbutton").disabled=true;
	errorMessage.innerHTML="";
	errorToDisplay.innerHTML="";
	
	simplifyFractionNumber = Number(simplifyFractionNumber);
	elementArray[objectLoc].numerator = Number
		(elementArray[objectLoc].numerator/simplifyFractionNumber);
	elementArray[objectLoc].denominator = Number
		(elementArray[objectLoc].denominator/simplifyFractionNumber);
	elementArray[objectLoc].string = elementArray[objectLoc].numerator+"/"+
		elementArray[objectLoc].denominator;
	
	if (selExpType==20) {
		if (elementArray[objectLoc].variable !==null) { 
			elementArray[objectLoc].string=elementArray[objectLoc].string+
				elementArray[objectLoc].variable;
			if (elementArray[objectLoc].exponent !=1) {
				elementArray[objectLoc].string=elementArray[objectLoc].string+
					"^"+String(elementArray[objectLoc].exponent);
			}
		}
		if (elementArray[objectLoc].variable2 !==null) { 
			elementArray[objectLoc].string=elementArray[objectLoc].string+
				elementArray[objectLoc].variable2;	
			if (elementArray[objectLoc].exponent2 !=1) {
				elementArray[objectLoc].string=elementArray[objectLoc].string+
					"^"+String(elementArray[objectLoc].exponent2);
			}
		}
		if (elementArray[objectLoc].variable3 !==null) {
			elementArray[objectLoc].string=elementArray[objectLoc].string+
				elementArray[objectLoc].variable3;
			if (elementArray[objectLoc].exponent3 !=1) {
				elementArray[objectLoc].string=elementArray[objectLoc].string+
					"^"+String(elementArray[objectLoc].exponent3);
			}
		}
		if (elementArray[objectLoc].variable4 !==null) {
			elementArray[objectLoc].string=elementArray[objectLoc].string+
				elementArray[objectLoc].variable4;
			if (elementArray[objectLoc].exponent4 !=1) {
				elementArray[objectLoc].string=elementArray[objectLoc].string+
					"^"+String(elementArray[objectLoc].exponent4);
			}
		}
	}
	// cancel numerator
	var elemArrayLen = elementArray.length;
	numeratorIndicator = true;
	writeCancelMark(objectLoc, elementArray[objectLoc].numerator, 
			numeratorIndicator,elemArrayLen);
	// cancel denominator
	numeratorIndicator = false;
	writeCancelMark(objectLoc, elementArray[objectLoc].denominator,
			numeratorIndicator,elemArrayLen);
	writeToTable(" -- After dividing by the common factor "+simplifyFractionNumber); 
	if (selExpType==20) {
		var fractArray=[];
		simplifyAlgFraction(fractArray);
		document.getElementById("operationMenuArea").style.display="none";
		return;
	}
	
	if (objectLoc > 0) {
		// working on an expression that adds whole numbers/fractions
		document.getElementById("simplifylastfractionform").style.display="none";
		var fractBeginEndObj = [];
		fractBeginEndObj[0] = 0;
		fractBeginEndObj[1] = objectLoc;
		var callerId = "addNumbers";
		addWholeNumbers(fractBeginEndObj, callerId);
	} else {
		solved = computeSimpleFraction(0);
		if (solved) {
			document.getElementById("simplifylastfractionform").style.display="none";
			convertToMixed=checkImproperToMixedNumber(0);
			if (!convertToMixed) { // write out solved expression and exit
				if (elementArray[0].denominator==1) {
					elementArray[0].string=String(elementArray[0].numerator);
				}
				var evalAnswer = elementArray[0].string;
				writeToTable(" -- Exercise completed successfully!");
				displayPage();				
				
				resetAfterSolved();
	        	if ((selExpType == 22) || (selExpType == 23)) {  //jcs209
	        		doAnotherEvalExpn(evalAnswer);
	        	}
			}
		}
	} 
	return true;
}

function checkImproperToMixedNumber(objectLoc)
{
	/*
	 * Checks if last term is an improper fraction to be converted
	 * to a mixed number. Returns false if no conversion necessary
	 * 
	 */
	
	var convertToMixedBoolean = false;
	var mixedNumPrompt;
	if ((Math.abs(elementArray[objectLoc].numerator) > (elementArray[objectLoc].denominator)) && (elementArray[objectLoc].denominator  !== 1)) {
		convertToMixedBoolean = true;
		document.getElementById("converttomixednumberform").reset();
		mixedNumPrompt=document.getElementById("converttomixedprompt");
		var mixedPromptNumElem=document.getElementById("convertmixednumber");
		mixedPromptNumElem.innerHTML = elementArray[objectLoc].string;
		mixedNumPrompt.innerHTML = "You need to express the improper fraction " + 
			elementArray[objectLoc].string + " as a <span class='helpbutton' " +
			"title='A number expressed as a whole number with a fraction, such as 1 2/3'>mixed number</span>. " +
			"Remember to leave a space between the whole number and fraction portion.";
		document.getElementById("converttomixednumberhelp").style.display="";
		
		document.getElementById("converttomixednumberform").style.display="";
		document.getElementById("converttomixednumberinput").focus();
	}
	return(convertToMixedBoolean);
}

function convertAlgToMixedNumber(objectLoc,calcMixedNumber,
		calcMixedRemainder,holdWholeNumber,calcDenom) {
	/*
	 * bts 090814:called from convertToMixedNumber only if we're
	 * 	converting imperfect fractions for constant term in algebraic
	 *  expression.
	 */
	
	if (calcMixedRemainder == 0) { // mixed number is whole number only
		elementArray[objectLoc].string = calcMixedNumber;
	} else if (calcMixedRemainder != 0) {// mixed number includes fraction
		if (objectLoc == elementArray.length-1) { // constant is last term
			elementArray[objectLoc].string = String(holdWholeNumber);
			var ctr=Number(objectLoc)+1;
			var stringVal = String(calcMixedRemainder) + "/"+String(calcDenom);
			var newElement=addElementToArray(ctr, stringVal,"term",calcMixedRemainder,calcDenom);
		} else {
			elementArray[objectLoc].string = calcMixedRemainder + 
					"/"+String(calcDenom);
			elementArray[objectLoc].numerator = Number(calcMixedRemainder);
			elementArray[objectLoc].denominator= calcDenom;
			// temporary struct to hold 2 new elements
			var copyObj;
			var copyArray = [];
			
			stringval = String(holdWholeNumber);
			var elemtype = "term";
			var num = holdWholeNumber;
			var denom = 1;
			var objIndx = 0;
			for (objIndx = 0;objIndx<2;objIndx++) {
				copyObj = new pe(" ");
				if (objIndx==0) copyObj.addElement(stringval,elemtype,num,denom);
				if (objIndx==1) copyObj.addElement(" ","oper"); // make it a blank operator
				copyArray[objIndx]=copyObj;	
			}
			var i=objectLoc;
			// insert copyArray elements in front of fraction element
			elementArray.splice(i,0,copyArray[0],copyArray[1]);
		}
	}
	// write new expression
	var expnOperation = "converting to mixed number";
	var expnSolved = " ** Exercise completed successfully! **";
	writeToTable(" -- After "+expnOperation+expnSolved);	
	resetAfterSolved();	
	return;
}

function convertToMixedNumber(endObj)
{
	/*
	 *	Modified routine to handle
	 *	converting alg constant fract to mixed #
	 *	if algebraic expn and mixed number entered matches
	 *	calculated mixed number, then branch to separate routine
	 *	so that structure is correctly updated.
	*/
	var mixedNumberInput;
	var mixedNumber;
	var calcMixedNumber, calcNum,calcDenom;
	var calcMixedRemainder, calcMixedResult;
	var errorMessage;
	var completed;
	var objectLoc, objectLocElement;
	var i;
	var callerId;
	var copyObj;
	var copyArray = [];
	
	var errToDisplay = document.getElementById("warningMessage");
	errToDisplay.innerHTML = " ";

	objectLocElement = document.getElementById("hiddenendobj");
	objectLoc = objectLocElement.innerHTML;
	if (objectLoc == "undefined" || objectLoc == null || objectLoc == "") {
		objectLoc = 0;
	}
	if (endObj != "undefined" && endObj != null) {
		objectLoc = endObj;
	}
	
	mixedNumberInput = document.getElementById("converttomixednumberinput");
	var messageElement = document.getElementById("converttomixednumbermessage");
	mixedNumber = mixedNumberInput.value;
	errorMessage=" ";
	messageElement.innerHTML=" ";
	
	calcNum = Number(elementArray[objectLoc].numerator);
	calcDenom = Number(elementArray[objectLoc].denominator);
	
	calcMixedRemainder = Math.abs(calcNum%calcDenom);
	calcMixedResult = calcNum/calcDenom;
	// remainder is 0 - mixed number is integer
	calcMixedNumber = parseInt(calcMixedResult);
	
	var holdWholeNumber = Number(calcMixedNumber); 

	if (calcMixedRemainder != 0) {
		calcMixedNumber = calcMixedNumber+" "+
			calcMixedRemainder + "/"+String(calcDenom);
	}	
		
	if (calcMixedNumber == mixedNumber) {
		messageElement.innerHTML=" ";
		document.getElementById("converttomixednumberform").style.display="none";
		if (selExpType==20) {
			convertAlgToMixedNumber(objectLoc,calcMixedNumber,
					calcMixedRemainder,holdWholeNumber,calcDenom);
			completed=true;
			return(completed);
		}
		if (objectLoc == 0) {
			if (calcMixedRemainder == 0) { // mixed number is whole number only
				elementArray[objectLoc].string = calcMixedNumber;
			} else if (calcMixedRemainder != 0) {// mixed number includes fraction
				elementArray[objectLoc].string = String(holdWholeNumber);
				var ctr=1;
				var stringVal = String(calcMixedRemainder) + "/"+String(calcDenom);
				var newElement=addElementToArray(ctr, stringVal,"term",calcMixedRemainder,calcDenom);
			}
			if (holdWholeNumber<0) {// special write for neg mixed number
				writeToTableSpecial(String(holdWholeNumber)+" "+stringVal,
					" -- After converting to mixed number");
			} else {// positive mixed number
				writeToTable(" -- After converting to mixed number");
			}
			completed=true;
			if (selExpType == 22 || selExpType == 23) {	//jcs126 added 23 for other evals
				var evalAnswer = elementArray[0].string+" "+elementArray[1].string;
			}
			elementArray.splice(0);
			writeToTable(" ** Exercise completed successfully! **");
        	resetAfterSolved();
        	if (selExpType == 22 || selExpType == 23) {	
        		doAnotherEvalExpn(evalAnswer);
        	}
   		} else if (objectLoc >0) { // keep fraction remainder as term and create new
								   // element for the whole number portion
			elementArray[objectLoc].string = calcMixedRemainder + 
				"/"+String(calcDenom);
			elementArray[objectLoc].numerator = Number(calcMixedRemainder);
			elementArray[objectLoc].denominator= calcDenom;
			
			var stringval = String(holdWholeNumber);
			var elemtype = "term";
			var num = holdWholeNumber;
			var denom = 1;
			var objIndx = 0;
			for (objIndx = 0;objIndx<2;objIndx++) {
				copyObj = new pe(" ");
				if (objIndx==0) copyObj.addElement(stringval,elemtype,num,denom);
				if (objIndx==1) copyObj.addElement("+","oper");
				copyArray[objIndx]=copyObj;	
			}
			i=objectLoc;
			elementArray.splice(i,0,copyArray[0],copyArray[1]);
			var expnOperation = "converting to mixed number";
			var expnSolved = "";
			writeToTable(" -- After "+expnOperation+expnSolved);

			var fractBeginEndObj = [];
			fractBeginEndObj[0] = 0;
			fractBeginEndObj[1] = elementArray.length-3;
			callerId = "addAllNumbers";
			addWholeNumbers(fractBeginEndObj, callerId);
		}
	} else {
		completed=false;
		errorMessage="You entered the mixed number incorrectly.";
		displayErrMsg(errorMessage,"mixednum");
		writeWrongAns(document.getElementById("convertmixednumber").innerHTML,
				mixedNumber,"tomixednum");
		document.getElementById("converttomixednumberform").reset();
		document.getElementById("converttomixednumberhelp").style.display="";
	}	
	return(completed);
}

function convertToMixedNumberHelp()
{
	var calcMixedNumber, calcNum,calcDenom;
	var calcMixedRemainder, calcMixedResult;
	var errorMessage;
	var objectLoc, objectLocElement;
	var mixedNumberInput;
	var messageElement;

	errorMessage = document.getElementById("converttomixednumbermessage");
	errorMessage.innerHTML=" ";

	objectLocElement = document.getElementById("hiddenendobj");
	objectLoc = objectLocElement.innerHTML;
	if (objectLoc == "undefined" || objectLoc == null || objectLoc == "") {
		objectLoc = 0;
	}
	
	calcNum = Number(elementArray[objectLoc].numerator);
	calcDenom = Number(elementArray[objectLoc].denominator);
	
	calcMixedRemainder = Math.abs(calcNum%calcDenom);
	calcMixedResult = calcNum/calcDenom;
	// If remainder is 0 then mixed number is an integer only
	calcMixedNumber = parseInt(calcMixedResult);
	
	var holdWholeNumber = Number(calcMixedNumber); 

	if (calcMixedRemainder != 0) {
		calcMixedNumber = calcMixedNumber+" "+
			calcMixedRemainder + "/"+String(calcDenom);
	}	

	errorMessage.innerHTML=
			calcNum+" \u00F7 "+calcDenom + " = "+ holdWholeNumber+
			" Remainder "+ calcMixedRemainder+" = "+ calcMixedNumber;
	document.getElementById("converttomixednumberhelp").style.display="none";
	
	mixedNumberInput = document.getElementById("converttomixednumberinput");
	var errToDisplay = document.getElementById("warningMessage");
	errToDisplay.innerHTML = " ";
	mixedNumberInput.value=calcMixedNumber;
	
	return;
}

function computeSimpleFraction(fractionPtr)
{
	/*
	 * When a single term that is a fraction remains in a simple 
	 * numeric expression, check 1st if it can be simplified and
	 * prompt to simplify it. Then, check if it can be converted
	 * to a mixed number
	 * 
	 * Changed to handle improper fractions in expressions
	 * that add fractions only, when there is only 1 fraction
	 * left and there are also whole numbers remaining in expression.
	 * 
	 * fractionPtr: indicates position in the structure for 
	 * 				the single fraction term
	 * 
	 * Returns false if fraction can be further simplified
	 *  
	 */
	
	var cancelNumber = [];
	var expnSolved;
	
	cancelNumber = checkForFractionCancel(fractionPtr,fractionPtr);
	if (cancelNumber[0] != 0) {// ask if fraction(s) should be canceled again
		//prompt for common factor
		document.getElementById("simplifylastfractionform").style.display="";
		document.getElementById("simplifylastfractioninput").focus();		
		expnSolved=false;
	} else {
		expnSolved=true;
		document.getElementById("simplifylastfractionform").style.display="none";
	}
	return(expnSolved);
}

function enterAnsForMe() {
	/*
	 * called when user gives up on solving a problem
	 * or verifies that they've seen the correct answers
	 */
	var enterAnsFlag = true;
	var answerVerifiedByUser = false;
	var giveUpButton=document.getElementById("helpwithanswerbutton");
	if (giveUpButton.value == "Got It") {
		answerVerifiedByUser=true;
		document.getElementById("helpwithanswerbutton").value="I Give Up";
		document.getElementById("helpwithanswerbutton").innerHTML="I Give Up";
		document.getElementById("helpwithanswerbutton").disabled=true;
		document.getElementById("answerbutton").style.visibility="visible";
	}
	
	getUserAnswer(enterAnsFlag,answerVerifiedByUser);
	
	if (giveUpButton.value == "I Give Up" && !answerVerifiedByUser) {
		document.getElementById("helpwithanswerbutton").value="Got It";
		document.getElementById("helpwithanswerbutton").innerHTML="Got It";
		document.getElementById("helpwithanswerbutton").disabled=false;
		document.getElementById("answerbutton").style.visibility="hidden";
	}
	return true;
}

function promptImproperNum(expnString, mixNumString)
{
	var expnString, mixNumString, improperFraction;
	var location;
	var mixNumCtr;
	var i;
	var improperNum = [];
	var tempString = [];
	var newOperString = [];
	var newString="";
	
	var j=0;
	var cellnode, cellnode2, cellnode3, cellnode4; 
	var inputElement;
	var buttonElement;
	var trElement;
	var tableElement, tableElementStart;
	var promptLine;
	
	document.getElementById("workarea").style.display="";
	document.getElementById("whatToDoNextArea").style.display="";
	
	document.getElementById("evaluateexpressionform").style.display="none";
	document.getElementById("impropernumberform").style.display="";
	displayTip("erase");

	i=0;
	j=0;
	tableElementStart=document.getElementById("impropernumbertable");	
	mixNumCtr = mixNumString.length;
		
	while (i < mixNumCtr) {
		promptLine = mixNumString[i];
		var rownode=document.createElement("tr");
		rownode.id="mixnumrow"+i;
		tableElementStart.appendChild(rownode);
		cellnode=document.createElement("td");
		cellnode.id = rownode.id+"mixnumprompt"+i;
		cellnode.innerHTML = "Convert "+promptLine+" ";
		rownode.appendChild(cellnode);
		cellnode2=document.createElement("td");
		cellnode2.id="mixnuminput"+i;
		inputElement = document.createElement("input");
		inputElement.id="mixnuminputvalue"+i;
		inputElement.style.maxWidth="40px";
		
		inputElement.setAttribute("required","required");	
		cellnode2.appendChild(inputElement);
		rownode.appendChild(cellnode2);	
		cellnode3=document.createElement("td");
		cellnode3.innerHTML=" ";
		cellnode3.id="mixnumcheckBox"+i;
		textElement = document.createElement("text");
		cellnode3.appendChild(textElement);
		rownode.appendChild(cellnode3);			
		cellnode4=document.createElement("td");
		cellnode4.innerHTML=" ";
		cellnode4.id="mixnumshowme"+i;
		buttonElement = document.createElement("input");
		buttonElement.id="showmebutton"+i;
		buttonElement.type = "button";
		buttonElement.value = "Show Me";
		if (i==0) buttonElement.onclick=function(){showMeHow("0");};
		if (i==1) buttonElement.onclick=function(){showMeHow("1");};
		if (i==2) buttonElement.onclick=function(){showMeHow("2");};
		if (i==3) buttonElement.onclick=function(){showMeHow("3");};
		if (i==4) buttonElement.onclick=function(){showMeHow("4");};
		if (i==5) buttonElement.onclick=function(){showMeHow("5");};
		if (i==6) buttonElement.onclick=function(){showMeHow("6");};
		if (i==7) buttonElement.onclick=function(){showMeHow("7");};
		if (i==8) buttonElement.onclick=function(){showMeHow("8");};
		if (i==9) buttonElement.onclick=function(){showMeHow("9");};
		
		cellnode4.appendChild(buttonElement);
		rownode.appendChild(cellnode4);			
		setMixNumAttributes(i);
		i++;
	}
	
	document.getElementById("mixnuminputvalue0").focus();
		
	// convert mixed numbers to improper fractions
	improperNum = convertMixedToImproper(mixNumString);
	
	var hiddenMixNumList = document.getElementById("hiddenmixnumlist");
	hiddenMixNumList.innerHTML = mixNumString;
	hiddenMixNumList.style.display="none";
	var hiddenImproperValues = document.getElementById("hiddenimpropervalues");
	hiddenImproperValues.innerHTML = improperNum;
	hiddenImproperValues.style.display="none";
	var hiddenOrigExpression = document.getElementById("hiddenmixnumorigexpression");
	hiddenOrigExpression.innerHTML = expnString;
	hiddenOrigExpression.style.display="none";
	
	// display the check improper fractions button
	document.getElementById("entermixnumbutton").disabled=false;		
	return;
}

function processImproperNum()
{
	var mixNumString;
	var improperValues;
	var improperValArray = [];
	var mixNumArray = [];
	var hiddenMixNumList, hiddenImproperValues,hiddenOrigExpression;
	var x, i, j;
	var improperFractionVals;
	var fractionElement, fractionValue;
	var valId = "";
	var correctAns=false;
	var checkBoxElement, checkBoxId;
	var improperNumber;
	var badInput;
	var showMeButtonId;
	var newExpressionString;
		
	hiddenMixNumList = document.getElementById("hiddenmixnumlist");
	hiddenImproperValues = document.getElementById("hiddenimpropervalues");
	
	mixNumString = hiddenMixNumList.innerHTML;
	mixNumArray = mixNumString.split(",");
	improperValues = hiddenImproperValues.innerHTML;
	improperValArray = improperValues.split(",");
	
	x = document.getElementById("impropernumberform");
	
	for (i=0;i<mixNumArray.length;i++) {
		valId = "mixnuminputvalue"+i;
		j=0;
		badInput = false;
		while (x.elements[j].id != valId || badInput) {
			j++;
			if (j==x.elements.length) badInput = true; 
		}
		fractionValue = x.elements[j].value;

		checkBoxId = "mixnumcheckBox"+i;
		checkBoxElement = document.getElementById(checkBoxId);
			
		if (improperValArray[i] != fractionValue) {
			checkBoxElement.innerHTML = "X" + "  Try again";
			checkBoxElement.style.color="red";
			checkBoxElement.style.fontWeight="bold";
			correctAns = false;
			writeWrongAns(i,fractionValue,"mixedtoimproper");
					
		} else {
			checkBoxElement.innerHTML = "&#x2714;";
			checkBoxElement.style.color="green";
			checkBoxElement.style.fontWeight="bold";
			correctAns = true;
			showMeButtonId = "showmebutton"+i;
			document.getElementById(showMeButtonId).style.display="none";
		}
	}

	if (!correctAns) return false;
	// build new expression string with improper fractions 
	// call second part of confirmPoly to complete building the structure
	newExpressionString=replaceMixedNum();
	
	clearMixedNumHiddenVals();
	var errMsgText=confirmPoly(newExpressionString);
	return true;
}

function clearMixedNumHiddenVals()
{
	/*
	 * clears hidden values and answer table rows for mixed number
	 * conversion to improper fractions
	 */
	var hiddenMixNumList, hiddenImproperValues,hiddenOrigExpression;
	
	var x = document.getElementById("impropernumberform");
	// clear out the form/table for improper numbers
	x.reset();
	x.style.display="none";

	hiddenMixNumList = document.getElementById("hiddenmixnumlist");
	hiddenImproperValues = document.getElementById("hiddenimpropervalues");
	hiddenMixNumList.innerHTML = "";
	hiddenImproperValues.innerHTML="";	
	hiddenOrigExpression = document.getElementById("hiddenmixnumorigexpression");
	hiddenOrigExpression.innerHTML="";
	
	// clear out the improper number table cells/rows
	var rowName="mixnumrow";
	clearAnswerFormTable("impropernumbertable", rowName);
	return;
}

function convertMixedToImproper(mixNumString)
{
	var mixNumString;
	var improperFraction;
	var mixNumPtr;
	var i,j;
	var improperNum = [];;
	var wholeNum, numerator, denominator;
	var spacePtr, slashPtr;

	// find location of the space
	// portion of string preceding space is the whole number
	// find location of slash /
	// portion from space to slash is numerator; after slash is denominator
	// multiply whole # by denominator and add to numerator. 
	// Improper fraction is new numerator over same denominator
	
	for (i=0;i<mixNumString.length;i++) {
		spacePtr = mixNumString[i].indexOf(" ");
		slashPtr = mixNumString[i].indexOf("/");
	
		wholeNum = mixNumString[i].slice(0,spacePtr);
		numerator = mixNumString[i].slice(spacePtr+1, slashPtr);
		denominator = mixNumString[i].slice(slashPtr+1,mixNumString[i].length);
		wholeNum = wholeNum*denominator;
		wholeNum = Number(wholeNum)+Number(numerator);
		improperNum[i] = wholeNum+"/"+denominator;
	}		
	return(improperNum);
}
function showMeHow(rowPointer)
{
	var mixNumString;
	var mixNumArray;
	var improperNum;
	var convertedFraction;
	var hiddenMixNumList;
	var showMeButtonId;
	var checkBoxId, checkBoxElement,inputElement,inputElementId;
	var improperNumConversion="";
	var spacePtr, slashPtr,wholeNum, numerator, denominator;
	var textElement, textElementId, cellnode2, cellnode2Id;
	
	hiddenMixNumList = document.getElementById("hiddenmixnumlist");
	mixNumString = hiddenMixNumList.innerHTML;
	mixNumArray = mixNumString.split(",");
	
	showMeButtonId = "showmebutton"+rowPointer;
	document.getElementById(showMeButtonId).style.display="none";
	
	improperNum = convertMixedToImproper(mixNumArray);
	convertedFraction = improperNum[rowPointer];

	// write improper fraction to the input field and 
	// the explanation to the checkbox field/cell	
	inputElementId = "mixnuminputvalue"+rowPointer;
	inputElement = document.getElementById(inputElementId);
	inputElement.value = convertedFraction;
	checkBoxId = "mixnumcheckBox"+rowPointer;
	checkBoxElement = document.getElementById(checkBoxId);
	
	spacePtr = mixNumArray[rowPointer].indexOf(" ");
	slashPtr = mixNumArray[rowPointer].indexOf("/");
	
	wholeNum = mixNumArray[rowPointer].slice(0,spacePtr);
	numerator = mixNumArray[rowPointer].slice(spacePtr+1, slashPtr);
	denominator = mixNumArray[rowPointer].slice(slashPtr+1,
			mixNumArray[rowPointer].length);
	
	improperNumConversion = "("+wholeNum+"*"+denominator+"+"+numerator+")/"+
					denominator;
	checkBoxElement.innerHTML = improperNumConversion;
	checkBoxElement.style.fontWeight="bold";
	checkBoxElement.style.color="black";
	
	// check if all fields answered (more show me buttons?)
	var i = 0;
	var moreToDo = false;
	var moreButtons = false;
	var nextButtonElement;
	while (!moreButtons) {
		showMeButtonId = "showmebutton"+i;
		nextButtonElement = document.getElementById(showMeButtonId);
		if (nextButtonElement == null) {
			moreButtons = true;
		} else if (nextButtonElement.style.display=="") {
			moreToDo = true;
			moreButtons = true;
		}
		i++;
	}
	if (!moreToDo) {
		document.getElementById("entermixnumbutton").innerHTML="Continue";
	}	
	return true;
}

function replaceMixedNum()
{
	var expnString, mixNumString;
	var location;
	var mixNumCtr;
	var i;
	//var improperNum = [];
	var tempString = [];
	var newString="";
	var hiddenMixNumList, hiddenImproperValues,hiddenOrigExpression;
	var mixNumArray, improperValues,improperNum;
	
	hiddenOrigExpression = document.getElementById("hiddenmixnumorigexpression");
	expnString = hiddenOrigExpression.innerHTML;
	hiddenMixNumList = document.getElementById("hiddenmixnumlist");
	hiddenImproperValues = document.getElementById("hiddenimpropervalues");
	mixNumString = hiddenMixNumList.innerHTML;
	mixNumArray = mixNumString.split(",");
	improperValues = hiddenImproperValues.innerHTML;
	improperNum = improperValues.split(",");
	
	mixNumCtr=mixNumArray.length;
	for (i=0;i<mixNumCtr;i++) {
		if (i==0) {
			tempString[i] = expnString.replace(mixNumArray[i],improperNum[i]);			
		} else if (i >0) {
			tempString[i] = tempString[i-1].replace(mixNumArray[i],improperNum[i]);
		}
		if (i == mixNumCtr-1) { // last one	
			newString=tempString[i];
		}
	}
	
	newString=newString.replace(/\s/g,"");	
	return(newString);
}

function changeMixedExpnOpers(expnString, mixNumString) 
{
	/*
	 * when operators are only add and subtract, do not prompt for
	 * improper fractions.Instead, insert +/- between whole# and fraction
	 * 
	 * This function should not be called if expression includes subtraction
	 */
	
	var expnString, mixNumString;
	var location;
	var mixNumCtr;
	var i;
	var tempString = [];
	var newOperString = [];
	var newString="";
	var locOperPlus, locOperMinus;
	var locMixedNum = [];
	
	mixNumCtr = mixNumString.length;

	for (i=0;i<mixNumCtr;i++) {	
		locMixedNum[i]=expnString.indexOf(mixNumString[i]);
		locOperPlus = expnString.indexOf("+",locMixedNum[i]);	
		locOperMinus = expnString.indexOf("-",locMixedNum[i]);	
		if (locOperPlus > -1) {
			if (locMixedNum[i] <= locOperPlus || locMixedNum[i]<= locOperMinus) {
				newOperString[i]=mixNumString[i].replace(" ","+");
			} 
		}
		if (locMixedNum[i]>locOperPlus) {
			newOperString[i]=mixNumString[i].replace(" ","+");
		} else if (locMixedNum[i]>locOperMinus && locOperMinus != -1)	{
			newOperString[i]=mixNumString[i].replace(" ","-");
		}
	}
	for (i=0;i<mixNumCtr;i++) {
		if (i==0) {
			tempString[i] = expnString.replace(mixNumString[i],newOperString[i]);			
		} else if (i >0) {
			tempString[i] = tempString[i-1].replace(mixNumString[i],newOperString[i]);
		}
		if (i == mixNumCtr-1) { // last one	
			newString=tempString[i];
		}
	}		
	return(newString);
}

function writeToTableSpecial(expnString,textToDisplay)
{
	/*
	 * Writes Original expression line to blackboard for
	 * expressions containing mixed numbers
	 */
	var i,j,x,y;
	var cellnode; 
	var textincell;
	var tableElement, tableElementStart;
	var specialText;
	var expnSubString, tempString;
	var holdOneChar;
	var writeCounter;
	var subStringFound;
	var writeAnnot, writeCell;
	var negNum;
	
	// write text to a table. Create new table for each row of data
	i=0;
	var rownode=document.createElement("tr");
	tableElementStart=document.getElementById("expnTable");
	tableElement=document.createElement("table");
	tableElementStart.appendChild(tableElement);
	tableElement.appendChild(rownode);
	
	expnSubString = "";
	
	i=0;
	j=0;
	writeAnnot = false;	
	writeCell=false;
	negNum = false;
	
	while (!writeAnnot) {
		subStringFound=false;
		j=i;

		while (!subStringFound) {
			x=expnString.charAt(j);
			if (x==" " || (isNaN(x) && x!="/") || j==expnString.length) { 
				subStringFound = true;
				if (i==j) {// should be operator or grouper symbol
					expnSubString = x;
					holdOneChar="";
					writeCounter = 1;
					if (x=="-") negNum = true;// if first char, this is a neg sign
				} else {
					expnSubString = expnString.substring(i,j);
					holdOneChar = expnString[j];
					writeCounter = 2;
					if (!holdOneChar || holdOneChar == " ") {
						writeCounter=1;
					}
				}
				writeCell=true;
				j++;
			} else { //character is number or slash
				j++;
			}
			
			if (j>expnString.length) {//last part of expression
				writeAnnot = true;
				subStringFound=true;
				writeCell=true;
				if (holdOneChar==")") {
					writeCounter = 1;
					expnSubString = holdOneChar;
				}
			}

			if (writeCell) {
				for (var k=0;k<writeCounter;k++) {
					if (k==1) {
						expnSubString=holdOneChar;
						negNum = false;
					}
					cellnode=document.createElement("td");
					specialText = setMixNumFractTextEffects(expnSubString);
					if (negNum) specialText=specialText.fontcolor("red").bold();
					if (expnSubString == "\u00F7") 
						specialText=specialText.fontcolor("red").bold();
					textincell=document.createTextNode(expnSubString);
					cellnode.appendChild(textincell);
					cellnode.innerHTML=specialText;
					rownode.appendChild(cellnode);
				}
				writeCell=false;
			}
		}
		i=j;					
	}

	// write annotation
	var mdashPtr = textToDisplay.indexOf("--");
	if (mdashPtr > -1) { 
		textToDisplay="	&mdash; "+ textToDisplay.substring(mdashPtr+2);
	} else {
		textToDisplay="	&mdash; "+ textToDisplay;
	}
	
	cellnode=document.createElement("td");
	cellnode.style.whiteSpace="nowrap";
	textincell=document.createTextNode(textToDisplay);
	specialText = textToDisplay;
	//jcs011817 need to get rid of Bradley font
	//cellnode.style.cssText="font-weight: bold;font-family: Bradley Hand ITC";			
	cellnode.style.cssText="font-weight: bold;font-family: arial";			
	cellnode.appendChild(textincell);
	cellnode.innerHTML=specialText;
	rownode.appendChild(cellnode);

	writeToStorage(expnString+
			" "+textToDisplay.bold());
	return;
}

function setMixNumFractTextEffects(textparameter)
{
	/*
	 * formats fractions with sup/subscripts for mixed numbers only
	 * Uses the expression string as input rather than elementArray
	 * 
	 */
	var text, formatText;
	var slashPtr;
	var numStr, denomStr;
	var j;
	
	text=String(textparameter);
	
	slashPtr = text.indexOf("/");	
	formatText="";
	
	if (slashPtr > -1) { // text contains fractions
		numStr = text.slice(0,slashPtr);		
		formatText = formatText.concat(numStr.sup(),"/");
		denomStr = text.slice(slashPtr+1);
		formatText=formatText.concat(denomStr.sub());
	}
	if (formatText=="") formatText = text;
	return (formatText);
}

function regroupExpn() 
{
	/*
	 * Groups whole numbers and fraction terms in the structure
	 * Only applies to add operations for simple numeric expressions
	 */
	var i,j,x;

	var tempWholeArray=[];
	var tempFractArray=[];
	var wholeNumber, fractNumber;
	var lastElement=false;
	var slashPtr;
	var prevDenom=1;
	var lcdNeeded = false;
	var fractBeginObj=-1;
	
	for (i=0;i<elementArray.length;i++) {
		if (elementArray[i].elemtype == "term") { 
			if (elementArray[i].denominator == 1) { // whole number
				tempWholeArray.push(elementArray[i]);
				wholeNumber = true;
			} else {
				if (prevDenom != 1) {
					if (prevDenom != elementArray[i].denominator) 
						lcdNeeded = true;
				}
				prevDenom=elementArray[i].denominator;
				tempFractArray.push(elementArray[i]);
				wholeNumber = false;
			}
		} else {
			if (wholeNumber) {
				tempWholeArray.push(elementArray[i]);
			} else {
				tempFractArray.push(elementArray[i]);
			}
		}
	}
	
	// last element of fraction array must be a term (fraction)
	// if operator, move it to end of whole number array
	// before appending fraction array to whole number array
	
	if (tempFractArray.length>0 &&
			tempFractArray[tempFractArray.length-1].elemtype != "term") {
		tempWholeArray.push(tempFractArray[tempFractArray.length-1]);
		tempFractArray.pop();
	}
	
	x = elementArray.length;
	elementArray.splice(0); 
	for (j=0;j<tempWholeArray.length;j++) {
		elementArray.push(tempWholeArray[j]);
	}
	fractBeginObj = tempWholeArray.length;
	if (tempFractArray.length < 3) fractBeginObj = -1;
	for (j=0;j<tempFractArray.length;j++) {
		elementArray.push(tempFractArray[j]);
	}	
	return(fractBeginObj);
}

function checkLCDenom(beginObj,endObj)
{
	var lcdNeeded = false;
	var prevDenom;
	var i;
	
	if (beginObj > -1) {
		prevDenom = elementArray[beginObj].denominator;
		i=beginObj+2;
		
		while (i<endObj+1) {
			if (prevDenom != elementArray[i].denominator) {
				lcdNeeded = true;
			} else {
				prevDenom = elementArray[i].denominator;
			}
			i = i+2;
		}
	}	
	return(lcdNeeded);
}

function addWholeNumbers(fractBeginEndObj, callerId)
{
	/*
	 * prompts user to add whole numbers in simple numeric expn
	 * whole numbers located at beginObj thru endObj in structure.
	 *
	 * fractBeginEndObj[0]: beginObj
	 * fractBeginEndObj[1] : endObj.
	 * fractBeginEndObj[0]=0: no whole numbers in expn to add; only fractions
	 * fractBeginEndObj[0] = -1: no lcd needed for fraction portion of expn
	 * fractBeginEndObj[0]>-1: location of first fraction term element in struct
	 */
	var lcdNeeded; 
	var callerId;
	var addFractionsNeeded;
	var addWholeNumbersNeeded;
	var j;
	var color;
	var beginObj,endObj;
	var simplificationNeeded;
	var hiddenBeginObjElement,hiddenEndObjElement;
	var checkMixedNumbers, addFinalNumbers;
	var noFractionsRemain =false;
	
	document.getElementById("getanswerform").reset();
	document.getElementById("getanswerform").style.display="none";
	document.getElementById("helpwithanswerbutton").value="I Give Up";
	document.getElementById("helpwithanswerbutton").innerHTML="I Give Up";
	
	beginObj = Number(fractBeginEndObj[0]);
	endObj = Number(fractBeginEndObj[1]);

	if (callerId == " " && fractBeginEndObj[0] != -1) {
		lcdNeeded = checkLCDenom(fractBeginEndObj[0],fractBeginEndObj[1]);
	}
	addFractionsNeeded = false;
	// callerId = addAllNumbers after fractions are added
	if (callerId != "addFractions" && callerId != "addAllNumbers" &&
			callerId != "addNumbers") {
		if (fractBeginEndObj[0] != fractBeginEndObj[1]) {
			if (fractBeginEndObj[0] != -1) {
				addFractionsNeeded = true;
			} else if (fractBeginEndObj[0] == -1) {
				addWholeNumbersNeeded=true;
			}
		} 
	} else if (callerId == "addFractions" || callerId== "addAllNumbers") {
		addWholeNumbersNeeded=true;
		addFractionsNeeded = false;
	} else if (callerId == "addNumbers") {
		addFinalNumbers = true;	
		addWholeNumbersNeeded=true;
		addFractionsNeeded = false;
	}
	
	if (callerId == " " && lcdNeeded) {			
		color = "yellow";
		for (j=beginObj;j<elementArray.length;j++) {
			writeMultHighlight(j,1,elementArray.length,color);
		}
		callerId = "applyLCD";
		promptLCD(beginObj, endObj, callerId);
		return;
	}	
	
	// After common denominator change or no lcd needed, add fractions
	// getUserAnswer sets this flag to -99 after 
	if (addFractionsNeeded) {
		document.getElementById("commondenominatorform").style.display="none";
		document.getElementById("converttolcdform").style.display="none";
		color = "yellow";
		for (j=beginObj;j<elementArray.length;j++) {
			writeMultHighlight(j,1,elementArray.length,color);
		}
		addFractionsSetup(fractBeginEndObj,callerId);
		return;
	}
	
	if (addWholeNumbersNeeded) {
		// done adding fractions
		// check for simplifying last fraction/converting to
		// mixed number, then add the whole number terms
		document.getElementById("commondenominatorform").style.display="none";
		document.getElementById("getanswerform").style.display="none";
		
		beginObj = 0;
		endObj = elementArray.length-1;
		fractBeginEndObj[0]=beginObj;
		fractBeginEndObj[1]=endObj;
		
		// write current object positions to html variables
		hiddenBeginObjElement=document.getElementById("hiddenbeginobj");
		hiddenBeginObjElement.innerHTML = beginObj;
		hiddenEndObjElement=document.getElementById("hiddenendobj");
		hiddenEndObjElement.innerHTML= endObj;
		
		var cancelArray = checkForFractionCancel(endObj,endObj);
		if (cancelArray[0] != 0) {// ask if fraction(s) should be canceled
			color = "yellow";
			for (j=endObj;j<elementArray.length;j++) {
				writeMultHighlight(j,1,elementArray.length,color);
			}
			document.getElementById("simplifylastfractionform").style.display="";
			return;
		} else {
			// check for mixed number conversion needed?
			if (callerId == "addAllNumbers" || callerId =="addNumbers"
				|| callerId == " ") {
				checkMixedNumbers=true;
			} else {
				addFinalNumbers = true;
			}
			if (elementArray.length == 1 && 
					elementArray[0].denominator != 1) {
				checkMixedNumbers = true;
			}
			// if denom=1 and only 1 fraction (beginObj=endObj)
			// set fraction term to whole number, write
			// new expn to blackboard and indicate change w/msg
			if (endObj == elementArray.length-1 && 
					elementArray[endObj].denominator == 1) {
				elementArray[endObj].string = 
					String(elementArray[endObj].numerator);
				writeToTable(" -- After changing fraction to whole number ");
				checkMixedNumbers=false;
				addFinalNumbers = true;
				noFractionsRemain = true;
			}	
		}		
	}
	
	if (checkMixedNumbers) {
		endObj = elementArray.length-1;
		var mixedNumberFound = checkImproperToMixedNumber(endObj);
		if (mixedNumberFound) {
			color = "yellow";
			for (j=endObj;j<elementArray.length;j++) {
				writeMultHighlight(j,1,elementArray.length,color);
			}			
			return;
		} else {
			addFinalNumbers = true;
		}
	}
	if (addFinalNumbers) {
		// do last addition if 2 or more whole numbers in structure
		if (noFractionsRemain || elementArray.length > 3) {
			var wholeNumEndObj;
			if (noFractionsRemain) {
				fractBeginEndObj[1]= elementArray.length-1;// last term
				wholeNumEndObj = elementArray.length;
			} else {
				fractBeginEndObj[1]=elementArray.length-3;	
				wholeNumEndObj = elementArray.length-2;
			}
			color = "yellow";
			for (j=beginObj;j<wholeNumEndObj;j++) {
				writeMultHighlight(j,1,elementArray.length,color);
			}
			callerId = "addNumbers";
			addWholeNumberSetup(fractBeginEndObj,callerId);
			return;
		} else if (elementArray.length == 3 && !noFractionsRemain) { // last term is fraction
			var evalAnswer = elementArray[0].string+" "+elementArray[2].string;
			elementArray[1].string=" ";
			writeToTable(" -- Combined whole number and fraction");
			elementArray.splice(0);
			writeToTable(" ** Exercise completed successfully! **");
        	resetAfterSolved();
        	if (selExpType == 22  || selExpType == 23) {
        		doAnotherEvalExpn(evalAnswer);
        	}
		} else if (elementArray.length==1) {
			var evalAnswer = elementArray[0].string;
			elementArray.splice(0);
			writeToTable(" ** Exercise completed successfully! **");
        	resetAfterSolved();
        	if (selExpType == 22 || selExpType == 23) {
        		doAnotherEvalExpn(evalAnswer);
        	}
		}
	}	
	return;
}

function addFractionsSetup(fractBeginEndObj,callerId)
{
	/*
	 * sets up prompts for adding fractions
	 * only called when fractions all have the same denominator
	 * 
	 */
	var i;
	var userPrompt;
	var userPromptArray;
	var calcAnswer;
	var calcAnswerArray = [];
	var beginObj, endObj;
	
	beginObj = Number(fractBeginEndObj[0]);
	endObj = Number(fractBeginEndObj[1]);
	userPrompt = "";
	userPromptArray = "";
	calcAnswer = 0;
	var fractString;
	var specialText;
	
	for (i=beginObj;i<endObj+1;i=i+2){
		if (i < endObj) {
			fractString=String(elementArray[i].numerator)+
					"/" +String(elementArray[i].denominator);
			specialText=setMixNumFractTextEffects(fractString);
			userPromptArray = userPromptArray+specialText+" + ";
		} else {// last item
			fractString=String(elementArray[i].numerator)+
					"/" +String(elementArray[i].denominator);
			specialText=setMixNumFractTextEffects(fractString);
			userPromptArray=userPromptArray+specialText;
		}
		calcAnswer=calcAnswer+Number(elementArray[i].numerator);
	}

	calcAnswerArray = String(calcAnswer)+"/"+String(elementArray[beginObj].denominator);
	
	elementArray[beginObj].numerator = calcAnswer;
	elementArray[beginObj].string = 
		elementArray[beginObj].numerator+"/"+
		elementArray[beginObj].denominator;
	
	elementArray.splice(beginObj+1);

	var preprompttext = "How much is: ";
	callerId = "addAllNumbers"; // next step after adding numerators
	var onePrompt = true;
	var multiplier = "";
	var matchPositions=[];
	matchPositions[0] = beginObj;
	matchPositions[1] = endObj;	
	var expnOperation = "adding fractions";
	var introType = 5;
	setAnswerPrompt(preprompttext,userPromptArray,multiplier, 
			calcAnswerArray,matchPositions,1,onePrompt,callerId,expnOperation,
			introType);	
	return;
}

function addWholeNumberSetup(fractBeginEndObj,callerId)
{
	/*
	 * sets up prompts for adding all whole numbers in expression
	 * endObj should point to last whole number in expression
	 */
	var i;
	var userPrompt;
	var calcAnswer;
	var beginObj, endObj;
	
	beginObj = Number(fractBeginEndObj[0]);
	endObj = Number(fractBeginEndObj[1]);
	userPrompt = "";
	calcAnswer = 0;
	for (i=beginObj;i<endObj+1;i=i+2){
		if (i < endObj) {
			userPrompt= userPrompt+elementArray[i].numerator+" + ";
		} else {// last item
			userPrompt= userPrompt+elementArray[i].numerator;
		}
		calcAnswer=calcAnswer+Number(elementArray[i].numerator);
	}
	// update the structure
	
	elementArray[beginObj].numerator = calcAnswer;
	elementArray[beginObj].string = elementArray[beginObj].numerator;
	
	var lastElement = endObj-beginObj;
	elementArray.splice(beginObj+1,lastElement);

	var preprompttext = "How much is: ";
	callerId = "addNumbers"; 
	var onePrompt = true;
	var multiplier = "";
	var matchPositions=[];
	matchPositions[0] = beginObj;
	matchPositions[1] = elementArray.length-1;// endObj
	var expnOperation = "adding whole numbers";
	var introType=1;
	setAnswerPrompt(preprompttext,userPrompt,multiplier, 
		calcAnswer,matchPositions,1,onePrompt,callerId,expnOperation,
		introType);		
	return;
}

function promptLCD(beginObj, endObj, callerId)
{
	/*
	 * Asks for the lowest common denominator for
	 * either 2 fractions (beginObj,endObj) or for
	 * all fractions in the expression (if only add operations)
	 * 
	 * calls function to calculate the lcd
	 */
	
	var beginObj, endObj;
	var calcLCD;
	var hiddenCommonDenom; 
	var hiddenBeginObj, hiddenEndObj;
	var commonDenomHint;
	var hiddenCaller; 
	
	document.getElementById("commondenominatorform").reset();
	var comDenomInputField = document.getElementById("commondenominatorinput");
	document.getElementById("commondenominatorinput").focus();
	var button=document.getElementById("getcommondenominatorbutton");
	button.setAttribute("onclick", "lowestCommonDenominator();");

	clearDisplayData("cdhelptable");
	
	var fractArray = [];
	var denomArray=[];
	var denomString;
	var arrayCtr, ptr;
	
	endObj=Number(endObj);
	beginObj=Number(beginObj);
	arrayCtr=0;
	
	ptr = endObj-beginObj;
	// set up denomArray for denoms only
	if (ptr == 2) { //only 2 fractions
		fractArray[0]=elementArray[beginObj].string;
		fractArray[1]=elementArray[endObj].string;
		denomArray[0]=String(elementArray[beginObj].denominator);
		denomArray[1]=String(elementArray[endObj].denominator);
	} else {// more than 2 fractions
		for (ptr=beginObj;ptr<endObj+1;ptr++) {
			if (elementArray[ptr].elemtype == "term") {
				if (elementArray[ptr].string.indexOf("/") >-1){//fraction
					fractArray[arrayCtr]=elementArray[ptr].string;
					denomArray[arrayCtr]=String(elementArray[ptr].denominator);
					arrayCtr++;
				}
			}
		}
	}
	denomString=denomArray.join(" and ");
	
	var fractionString;
	fractionString=fractArray.join(" and ");
	
	var commonDenomCaption = document.getElementById("commondenominatorcaption");
	var commonDenomFraction=document.getElementById("commondenominatorfraction");
	commonDenomFraction.innerHTML=fractionString;
	
	document.getElementById("userInstructions").style.display="";

	var tipText= document.getElementById("commondenominatorhint");
	tipText.innerHTML="To add or subtract fractions, you need to convert " +
			"the fractions to the same number, what we call a" +
			"<input class='helpbutton' type='button' value='common denominator.' " +
			"title='A denominator that the denominators you are adding or subtracting can be converted to.' " +
			"onclick='open_helpwin('convertingtolcd')'></input>"+	
			"<strong>Hint:</strong> in your exercise, the common denominator is a number that can be " +
			"divided by "+denomString+".";
	
	displayTip("lcd");
	findAudio("addfrac");
	
   	document.getElementById("generalHighlight").style.display="none";
	document.getElementById("helpcommondenominatorbutton").disabled=false;	
	
	var commonDenomCaption = document.getElementById("commondenominatorcaption");
	var commonDenomFraction=document.getElementById("commondenominatorfraction");
	commonDenomFraction.innerHTML=fractionString;
	
	document.getElementById("commondenominatorform").style.display="";
	document.getElementById("commondenominatorinput").focus();
	document.getElementById("helpcommondenominatorbutton").disabled=false;

	hiddenCommonDenom = document.getElementById("hiddencommondenominator");
	hiddenCommonDenom.style.display="none";
	hiddenCommonDenom.innerHTML = calcLCD;
	
	hiddenBeginObj = document.getElementById("hiddenbeginobj");
	hiddenBeginObj.style.display="none";
	hiddenBeginObj.innerHTML = beginObj;

	hiddenEndObj = document.getElementById("hiddenendobj");
	hiddenEndObj.style.display="none";
	hiddenEndObj.innerHTML = endObj;
	// save the callerId
	hiddenCaller = document.getElementById("hiddencaller");
	hiddenCaller.innerHTML = callerId;
	hiddenCaller.style.display="none";	
	return;
}

function lowestCommonDenominator()
{
	/*
	 * Sets flag indicating if this is lowest common denom or not
	 * 
	 */
	var checkLCDEntry=true;
	getCommonDenominator(checkLCDEntry);
	var button=document.getElementById("getcommondenominatorbutton");
	button.setAttribute("onclick", "getCommonDenominator();");
	return;
}

function enableDenomButtons()
{
	/*
	 * Turn on 2 lcd buttons
	 */
	document.getElementById("getcommondenominatorbutton").disabled=false;
	document.getElementById("helpcommondenominatorbutton").disabled=false;
	return;
}

function getCommonDenominator(checkLCDEntry) 
{
	var commonDenomInput, commonDenomVal;
	var errorMessage;
	var calcLCD, remainderVal;
	var hiddenCommonDenom; 
	var hiddenBeginObj, hiddenEndObj;
	var beginObj, endObj;
	var denomArray;
	var validCommonDenom;
	var commonDenomHint;
	var numDenomArray = [];
	var j,i;
	var userPromptArray= [];
	var calcAnswerArray= [];
	var callerId;
	var introType;
	var helpString=[];
	var calcNextAnswerArray=[];
	
	commonDenomInput=document.getElementById("commondenominatorinput");
	errorMessage = document.getElementById("commondenominatormessage");

	commonDenomVal = Number(commonDenomInput.value);
	if (commonDenomVal==0) return (false);
	var tipText= document.getElementById("UserInstructionPrompt");

	tipText.innerHTML="Convert the fractions to the common denominator. \<strong>Hint: \</strong>" +
	"You have to use an identity fraction such as 2/2 or 3/3. "+
	"\<a href='javascript\:open_helpwin(6);' title='To convert 2/3 to 1/12s, multiply 2/3*4/4' >" +
	"How do I convert a fraction?\</a><br /><br />"; 

	findAudio("convertfrac");	
	errorMessage.innerHTML=" ";
	
	commonDenomHint = document.getElementById("commondenominatorhint");
	commonDenomHint.innerHTML=" "; 
	commonDenomHint.style.display="";

	displayTip("erase");
	var hiddenCaller = document.getElementById("hiddencaller");
	callerId=hiddenCaller.innerHTML;
	hiddenBeginObj = document.getElementById("hiddenbeginobj");
	beginObj = hiddenBeginObj.innerHTML;

	hiddenEndObj = document.getElementById("hiddenendobj");
	endObj=hiddenEndObj.innerHTML;

	// calculate the lcd using saved begin,end objects
	denomArray = getDenomsForLCD(beginObj,endObj);
	calcLCD = calculateLCD(denomArray);
	validCommonDenom=false;
	
	if (commonDenomVal == calcLCD) {
		validCommonDenom = true;
	} else if (commonDenomVal < calcLCD) {	
		commonDenomHint.innerHTML = "ERROR: ".fontcolor("red").bold();
		commonDenomHint.innerHTML = commonDenomHint.innerHTML +
			String(commonDenomVal)+" is not a common denominator. ";
	} else {
		// see if number entered is common denominator
		remainderVal = commonDenomVal%calcLCD;
		validCommonDenom = true;
		if (remainderVal != 0) {
			validCommonDenom = false;
			commonDenomHint.innerHTML = "ERROR: ".fontcolor("red").bold()+
				String(commonDenomVal)+
				" is not a common denominator."+
				" Try multiplying the denominators.";
		} else {
			if (checkLCDEntry) {
				commonDenomHint.innerHTML = "NOTE: ".fontcolor("red").bold()+
					String(calcLCD)+" is the lowest common denominator, but "+
					String(commonDenomVal)+
					" also works."+
					" Click \<strong>Go \</strong> to use "+
					String(commonDenomVal)+" or try another value.";
				validCommonDenom=false;
			}
		}
	}
	
	if (calcLCD > 100) {
		commonDenomHint.innerHTML=
			"For this case, you must multiply the denominators.";
	}
	
	if (!validCommonDenom && calcLCD <101) {
		writeWrongAns(
				document.getElementById("commondenominatorfraction").innerHTML,
				commonDenomVal,"commondenom");
	} else if (calcLCD>100 && !validCommonDenom) {
		writeToStorage("For "+dispFracts+" "+" you must multiply the denominators."+
				commonDenomVal);
	}
	
	hiddenCommonDenom=document.getElementById("hiddencommondenominator");
	hiddenCommonDenom.innerHTML = commonDenomVal;
	hiddenCommonDenom.style.display="none";
	
	if (validCommonDenom) {
		clearAnswerFormTable("converttolcdtable","converttolcdrow");
		// add array to hold original fractions for later processing
		var origFraction = [];
		numDenomArray=updateDenomsWithLCD(commonDenomVal,beginObj,endObj);

		if (numDenomArray[0] != null || numDenomArray[0] != undefined) {
			document.getElementById("commondenominatorform").style.display="none";
			i=0;
			for (j=0;j<numDenomArray[0].length;j++) {
				// skip prompts/answers when multiplying by 1/1
				if (numDenomArray[2][j]!=1) {
					fractString=String(numDenomArray[0][j]+"/"+numDenomArray[1][j]);
					origFraction[i]= fractString;
					specialText=setMixNumFractTextEffects(fractString);
					userPromptArray[i]=specialText;
					//bts 2nd fract is answer we expect user to enter
					fractString=String(numDenomArray[2][j]+"/"+ numDenomArray[2][j]);
					calcAnswerArray[i]=fractString;
					calcNextAnswerArray[i]=numDenomArray[0][j]*numDenomArray[2][j]+
						"/"+numDenomArray[1][j]*numDenomArray[2][j];
					i++;
				}
			}
			var preprompttext = "What do you multiply ";
			var midprompttext = " by to convert it to \<sup>1\</sup>/\<sub>" + String(commonDenomVal)+"\</sub>'s?";		
			
			if (callerId == null || callerId == "") 
				callerId = "applyLCD"; 
			hiddenCaller.innerHTML=callerId;
			hiddenCaller.style.display="none";
			
			document.getElementById("converttolcdanswerbutton").style.display="";
			document.getElementById("converttolcdhelpbutton").style.display="";
			document.getElementById("converttolcdgotitbutton").style.display="none";			
			document.getElementById("converttolcdform").style.display="";

			var promptText;
			var rowIdVal;
			var cellnode, cellnode2, cellnode3; 
			var inputElement;
			var textElement;
			var textincell;
			var trElement;
			var tableElement, tableElementStart;
			i=0;
			j=0;
			tableElementStart=document.getElementById("converttolcdtable");	
			
			var userPromptLength = userPromptArray.length;
			var numCalcAns;
			
			while (i < userPromptLength) {
				promptText = userPromptArray[i];

				var rownode=document.createElement("tr");
				rownode.id="converttolcdrow"+i;
				tableElementStart.appendChild(rownode);

				cellnode=document.createElement("td");
				cellnode.id=rownode.id+"prompt"+i;

				cellnode.innerHTML = preprompttext+" "+promptText 
						+ midprompttext;
				rownode.appendChild(cellnode);
				cellnode2=document.createElement("td");
				inputElement = document.createElement("input");
				inputElement.id="converttolcdinput"+i;
				inputElement.innerHTML="";
				inputElement.size = 15;
				cellnode2.appendChild(inputElement);
				rownode.appendChild(cellnode2);				

				setLCDAttributes(i);			
				
				cellnode3=document.createElement("td");
				cellnode3.innerHTML=" ";
				cellnode3.id="converttolcdcheckBox"+i;
				rownode.appendChild(cellnode3);			
				setDenominatorAttributes(i)
				i++;
			}	
			document.getElementById("converttolcdinput0").focus();
			// holds the subsequent converted fraction answer for part2
			var hiddenText = document.getElementById("hiddenanswertext");
			hiddenText.innerHTML = calcNextAnswerArray;
			hiddenText.style.display="none";
			var hiddenOrigFractions=document.getElementById("hiddenorigfractions");
			hiddenOrigFractions.innerHTML = origFraction;
			hiddenOrigFractions.style.display="none";
			// holds the multiply by fraction answer
			var hiddenNextAnswer = document.getElementById("hiddenmultfraction");
			hiddenNextAnswer.innerHTML = calcAnswerArray;
			hiddenNextAnswer.style.display="none";
		}
	}
	return(validCommonDenom);
	//after entering lcd conversion fraction, processing
	//  continues with getCommonDenomPart2
}

function getCommonDenomConversion(enterAnsForMeFlag)
{
	/*
	 * Gets the lcd conversion fraction(s)
	 */
	var userAns=[];
	var i,j;
	var answerString;
	var answer;
	var wrongAnswer;
	var hiddenAnswer;
	var checkBoxElement;
	var correctAnswer;
	var holdStr;
	var enterAnsForMeFlag;
	
	// get the multiply by fraction answer
	var hiddenNextAnswer = document.getElementById("hiddenmultfraction");
	answerString = hiddenNextAnswer.innerHTML;
	answer = answerString.split(",");

	document.getElementById("converttolcdanswerbutton").style.display="";
	document.getElementById("converttolcdhelpbutton").style.display="";
	document.getElementById("converttolcdform").style.display="";

	var x = document.getElementById("converttolcdform");
	if (!enterAnsForMeFlag) { //user enters answers
		for (i=0;i<x.elements.length-1;i++) {
			if (x.elements[i].tagName == "INPUT") { 
				userAns[i] = x.elements[i].value.trim();
				userAns[i] = userAns[i].toLowerCase();
			}
		}
		
		j=0;
		wrongAnswer = false;
	
		while (j < answer.length) {
			correctAnswer=false;	
			var checkBoxId = "converttolcdcheckBox"+j;
			checkBoxElement = document.getElementById(checkBoxId);
			
			if (correctAnswer || userAns[j]== answer[j]) {
				checkBoxElement.innerHTML = "&#x2714;";
				checkBoxElement.style.color="green";
				checkBoxElement.style.fontWeight="bold";
			} else {
				checkBoxElement.innerHTML = "X" + "  Try again";
				checkBoxElement.style.color="red";
				checkBoxElement.style.fontWeight="bold";
				wrongAnswer = true;
				writeWrongAns(j,userAns[j],"lcd");
			}
			j++;			
		} // end while loop checking answers
	
		if (wrongAnswer) {
			document.getElementById("converttolcdhelpbutton").disabled=false;			
			return false;
		}

		document.getElementById("converttolcdanswerbutton").style.display="none";
		document.getElementById("converttolcdhelpbutton").style.display="none";
		document.getElementById("converttolcdform").style.display="";		
	} else if (enterAnsForMeFlag) { //enter the answer for the user here
		for (i=0;i<x.elements.length-1;i++) {
			if (x.elements[i].tagName == "INPUT") {
				var checkBoxId = "converttolcdcheckBox"+i;
				checkBoxElement = document.getElementById(checkBoxId);
				x.elements[i].value = answer[i];
				checkBoxElement = document.getElementById(checkBoxId);
				checkBoxElement.innerHTML = "&#x2714;";
				checkBoxElement.style.color="green";
				checkBoxElement.style.fontWeight="bold";
			}
		}
		writeGaveUpMsg("on converting to LCD");
		
		document.getElementById("converttolcdanswerbutton").style.display="none";
		document.getElementById("converttolcdhelpbutton").disabled=true;	

		document.getElementById("converttolcdhelpbutton").style.display="none";
		document.getElementById("converttolcdgotitbutton").style.display="";			
		document.getElementById("converttolcdform").style.display="";
		return;
	}
	
	document.getElementById("converttolcdform").style.display="none";	
	getCommonDenomPart2();	
	return;
}

function helpCommonDenomConversion()
{	
	var enterAnsForMeFlag = true;
	getCommonDenomConversion(enterAnsForMeFlag);
	document.getElementById("converttolcdgotitbutton").style.display="";			
	return;
}

function getCommonDenomPart2()
{
	/*
	 * Continuation of getCommonDenom function
	 * 	Have valid common denominator and values to multiply against
	 *  the fractions, so now prompt for common denom calculation
	 */
	
	var commonDenomInput, commonDenomVal;
	var errorMessage;
	var calcLCD, remainderVal;
	var hiddenCommonDenom; 
	var hiddenBeginObj, hiddenEndObj;
	var beginObj, endObj;
	var denomArray;
	var validCommonDenom;
	var commonDenomHint;
	var numDenomArray = [];
	var j,i;
	var helpString = [];
	var userPromptArray= [];
	var calcAnswerArray= [];
	var callerId;
	var introType;
	
	errorMessage = document.getElementById("commondenominatormessage");
	// get common denom from hidden vals
	hiddenCommonDenom = document.getElementById("hiddencommondenominator");
	commonDenomVal = Number(hiddenCommonDenom.innerHTML);
	
	errorMessage.innerHTML=" ";
	
	commonDenomHint = document.getElementById("commondenominatorhint");
	commonDenomHint.innerHTML=" "; 
	commonDenomHint.style.display="";

	displayTip("erase");
	var hiddenCaller = document.getElementById("hiddencaller");
	callerId=hiddenCaller.innerHTML;

	//  get the converted fraction answer field
	var hiddenText = document.getElementById("hiddenanswertext");
	var calcAnswerString;	
	calcAnswerString = hiddenText.innerHTML;
	calcAnswerArray = calcAnswerString.split(",");		
	hiddenText.style.display="none";
	
	// get the multiply by fractions
	var hiddenNextAnswer = document.getElementById("hiddenmultfraction");
	var multByString = hiddenNextAnswer.innerHTML;
	var multByArray=[];
	multByArray=multByString.split(",");
	hiddenNextAnswer.style.display="none";
	
	var hiddenOrigFractions=document.getElementById("hiddenorigfractions");
	var origFractionString;
	var origFractionArray=[];
	origFractionString=hiddenOrigFractions.innerHTML;
	origFractionArray = origFractionString.split(",");
	hiddenOrigFractions.innerHTML = "";
	hiddenOrigFractions.style.display="none";
	
	hiddenBeginObj = document.getElementById("hiddenbeginobj");
	beginObj = hiddenBeginObj.innerHTML;
	hiddenEndObj = document.getElementById("hiddenendobj");
	endObj=hiddenEndObj.innerHTML;

	document.getElementById("commondenominatorform").style.display="none";
	document.getElementById("converttolcdform").style.display="none";
	// build prompts for new fractions
			
	i=0;
	var ptr;
	var tempFract;
	for (i=0;i<origFractionArray.length;i++){

		ptr = multByArray[i].indexOf("/");
		tempFract = multByArray[i].substring(ptr+1,multByArray[i].length);
		if (Number(tempFract) != 1) {
			fractString = origFractionArray[i];
			specialText=setMixNumFractTextEffects(fractString);
			userPromptArray[i]=specialText+" * ";
			fractString = multByArray[i];
			specialText=setMixNumFractTextEffects(fractString);
			userPromptArray[i]=userPromptArray[i]+specialText;
			helpString[i]=origFractionArray[i];
		}
	}
	
	var preprompttext = "How much is: ";
	if (callerId == null || callerId == "") 
			callerId = "applyLCD"; 
	var onePrompt = false;
	var multiplier = "";
	var matchPositions=[];
	matchPositions[0] = beginObj;
	matchPositions[1] = endObj;	
	introType = 2;
	var expnOperation = "common denominator conversion";
	var answerFormIntroElement;
	answerFormIntroElement=document.getElementById("getanswerintro");
	answerFormIntroElement.innerHTML = "Convert the fraction(s) ";
	for (j=0;j<helpString.length;j++) {
		if (j==helpString.length-1) { // last one
			answerFormIntroElement.innerHTML=
					answerFormIntroElement.innerHTML+" "+helpString[j];
		} else {
			answerFormIntroElement.innerHTML=
					answerFormIntroElement.innerHTML+" "+helpString[j]+", ";
		}
	}
	answerFormIntroElement.innerHTML = answerFormIntroElement.innerHTML+
			" to the common denominator: "+ commonDenomVal;
			
	setAnswerPrompt(preprompttext,userPromptArray,multiplier, 
			calcAnswerArray,matchPositions,1,onePrompt,callerId,
			expnOperation,introType);	
	
	document.getElementById("userAns0").focus();
	return(validCommonDenom);
}

function updateDenomsWithLCD(lcdVal,beginObj,endObj)
{
	var i,j;
	var oldDenom, oldNumerator;
	var oldNumArray = [];
	var oldDenomArray = [];
	var multiplierArray = [];
	var returnArray = [];
	
	lcdVal = Number(lcdVal);
	beginObj = Number(beginObj);
	endObj=Number(endObj);

	j=0; // counter into fraction arrays
	for (i=beginObj;i<=endObj;i++) {
		if (elementArray[i].elemtype == "term") {
				oldNumArray[j] = elementArray[i].numerator;
				oldDenomArray[j] = elementArray[i].denominator;
				multiplierArray[j] = lcdVal/oldDenomArray[j];
				elementArray[i].denominator=lcdVal;
				elementArray[i].numerator = 
					elementArray[i].numerator*multiplierArray[j];
				elementArray[i].string = elementArray[i].numerator+
					"/"+elementArray[i].denominator;
				j++;
		}		
	}	
	returnArray[0]=oldNumArray;
	returnArray[1]=oldDenomArray;
	returnArray[2]=multiplierArray;
	return(returnArray);
}

function getDenomsForLCD(beginObj, endObj)
{
	var denomArray = [];
	var i,j;

	j=0;
	for (i=beginObj;i<=endObj;i++) {
		if (elementArray[i].elemtype == "term") {
			if (elementArray[i].denominator != 1) {
				denomArray[j]=elementArray[i].denominator;
				j++;
			}
		}		
	}	
	return (denomArray);
}

function calculateLCD(denomArray) 
{
	/*
	 * calculates the lowest common denominator for all fractions
	 * from beginObj through endObj locations
	 */
	var calcLCD=0;
	var denomArray;
	var i,j;
	var divideAmt;
	var srchRemainder;
	var remainderVal;
	var remainderFound;
		
	// divide denominators into sequence of increasing numbers 
	// starting with 2 until there are no remainders
	divideAmt = 2;
	srchRemainder = true;
	remainderFound = false;
	i=0;	
	while (srchRemainder) {
		for (i=0;i<denomArray.length;i++) {
			remainderVal = divideAmt%denomArray[i];
			if (remainderVal != 0) {
				remainderFound = true;
			}
		}
		if (!remainderFound) {
			srchRemainder = false;
			calcLCD = divideAmt;
		} else {
			divideAmt++;
			remainderFound = false;
			if (divideAmt>100) {
				srchRemainder=false;
				calcLCD = Number(denomArray[0]*denomArray[1]);
				if (denomArray.length>2) {
					j=2;
					while (j<denomArray.length) {
						calcLCD = calcLCD*Number(denomArray[j]);
						j++;
					}
				}
			}
		}
	}	
	return(calcLCD);
}

function checkFractionAddOnly()
{
	/*
	 * checks a simplenumeric expression for 2 conditons:
	 * 	- all operators are additions (+)
	 *  - has at least 1 fraction term
	 * Returns an array where 
	 *  - element 0 is -1 if both conditions are not true
	 *  - otherwise, returns start/end locations of fraction terms
	 */
	var fractBeginEndObj = [];
	var fractTempString;
	var fractRegrpString;
	var fractBeginObj;
	var operString;
	var fractionLoc;
	var regroupFractionLoc;
	var regroupMsg;

	fractBeginEndObj[0]=-1; // set default to no fractions
	fractBeginEndObj[1]=-1; // set default to no fractions	
	
	fractTempString = buildStrPart(0, elementArray.length-1);
	fractionLoc = fractTempString.indexOf("/");
	if (fractionLoc > -1) { // fractions exist; check for + only
		operString = parseString(fractTempString,10);
		if (operString == null) {
			operString = parseString(fractTempString,12);
			if (fractTempString.indexOf("|")>-1) operString="|";
		}
		if (operString == null) { // only "add" opers present
			fractBeginObj=regroupExpn();
			fractBeginEndObj[0]=fractBeginObj;
			fractBeginEndObj[1]=elementArray.length-1;
			// did regrouping change expression?
			fractRegrpString = buildStrPart(0, elementArray.length-1);
			regroupFractionLoc= fractRegrpString.indexOf("/");
			if (fractionLoc != regroupFractionLoc) {
				regroupMsg = 
					"-- Grouped whole numbers & fractions using commutation";
				writeToTable(regroupMsg);
			}			
		}
	}	
	return(fractBeginEndObj);
}

function helpCommonDenominator()
{
	var hiddenBeginObj, hiddenEndObj;
	var beginObj, endObj;
	var denomArray;
	var calcLCD;
	var cdHelpTableElement;
	var cdRowNode, cdCellNode;
	var j,k, a,b;
	var minDenom,colNum,colHead;
	var messageLine;
	
	hiddenBeginObj = document.getElementById("hiddenbeginobj");
	beginObj = hiddenBeginObj.innerHTML;

	hiddenEndObj = document.getElementById("hiddenendobj");
	endObj=hiddenEndObj.innerHTML;
	
	displayTip("erase");

	// calculate the lcd using saved begin,end objects
	denomArray = getDenomsForLCD(beginObj,endObj);
	calcLCD = calculateLCD(denomArray);

	var hiddenCommonDenom = document.getElementById("hiddencommondenominator");
	hiddenCommonDenom.style.display="none";
	hiddenCommonDenom.innerHTML=calcLCD;

	writeGaveUpMsg("on common denominator");
	// calculate number of columns we need
	minDenom=denomArray[0];
	for (j=0;j<denomArray.length-1;j++) {
		a=minDenom;
		b=denomArray[j+1];
		minDenom=Math.min(a,b);
	}
	colNum = calcLCD/minDenom;
	
	document.getElementById("helpcommondenominatorbutton").disabled=true;
	
	var comDenomInputField = document.getElementById("commondenominatorinput");
	comDenomInputField.setAttribute("onmouseout", null);
	
	messageLine = document.getElementById("commondenominatormessage");
	messageLine.innerHTML = "To get a common denominator, you need to recall " +
			"the multiplication table for each denominator. Any number that appears in each " +
			"row can be used as a common denominator. " +
			"The least common denominator for this problem is highlighted in yellow in the following table.";
	document.getElementById("commondenominatorinput").value=calcLCD;
	cdHelpTableElement=document.getElementById("cdhelptable");
	for(j=0;j<denomArray.length+1;j++) {
		colHead=1;
		if (j>0) {
			cdRowNode=document.createElement("tr");
			cdHelpTableElement.appendChild(cdRowNode);
			// bts 0710: add row "heading" for first cell in each row
			cdCellNode=document.createElement("td");
			cdCellNode.innerHTML=denomArray[j-1];
		}
		for (k=0;k<colNum+1;k++){
			cdCellNode=document.createElement("td");
			if (j==0) { // create heading row columns
				cdRowNode=document.createElement("th");
				cdHelpTableElement.appendChild(cdRowNode);
				if (k==0){
					cdCellNode.innerHTML=" ";
				} else {
					cdCellNode.innerHTML=colHead;
					colHead++;
				}
			} else if (j>0){
				cdCellNode.innerHTML = denomArray[j-1]*colHead;
				if (cdCellNode.innerHTML==calcLCD) 
					cdCellNode.style.backgroundColor="yellow";				
				colHead++;
				if (k==0) {
					colHead--;
					cdCellNode.innerHTML= cdCellNode.innerHTML+" | ";
					cdCellNode.style.fontWeight="bold";
				}
			}
			cdRowNode.appendChild(cdCellNode);
		}
	}
	document.getElementById("getcommondenominatorbutton").disabled=false;
	return;
}

function removeBlanks()
{
	var i=0;
	var j=0;
	var newString="";
	var windowContent;
	
	//Prevent selection after problem is done
	if (elementArray.length < 1) return;
		
	var errorToDisplay=document.getElementById("warningMessage");
	errorToDisplay.innerHTML = ""; 
	
	if (typeof window.getSelection != "undefined") {
	      windowContent = window.getSelection();
	}
			
	newString = String(windowContent);
	var mobileEntry;
	if (newString == "") {
		if (equationFlag) {
			mobileEntry=document.getElementById("mobileEntryField2").value;
		} else {
			mobileEntry=document.getElementById("mobileEntryField").value;
		}
		
		//call getExpressionToSolve if no selection
		//	to allow blank entry to signal return to previous menu
		if (mobileEntry == "" || mobileEntry=="undefined") {
			getExpressionToSolve(newString);
			return;
		}
		newString = mobileEntry;
		document.getElementById("mobileEntryField").value = "";
		document.getElementById("mobileEntryField2").value = "";
	}	
	try {
		displayTip("erase");

		var tipText= document.getElementById("UserInstructionPrompt");
		tipText.innerHTML="";
				
		if (newString != null && newString != "") {
			// check for mdash; if found, remove subsequent text
			var mdashPtr = newString.indexOf("\u2014");
			if (mdashPtr != -1) {
				newString=newString.substring(0,mdashPtr);
			}
			newString=newString.replace(/\s/g,"");
			var operChar = newString.charAt(newString.length-1);
			if (parseString(operChar,3)!= null) 
				newString=newString.substring(0,newString.length-1);
			if (newString.length == 0) {
				var errorCode=13;  // invalid selection
				var errMsgText = "";
				errMsgText = errorMsg(errorCode,errMsgText,operChar);
				displayErrMsg(errMsgText);
				errMsgText = "";
				return;
			}

			//  remove first char if operator
			operChar=newString.charAt(0);
			if (operChar !="-" && parseString(operChar,3)!= null) 
				newString=newString.substring(1);						
		}
	    window.getSelection().removeAllRanges();
		getExpressionToSolve(newString);
		
		errorToDisplay=document.getElementById("warningMessage");
		if (!errorToDisplay.innerHTML) {
			document.getElementById("UserInstructionPrompt").innerHTML=""; //jcs1027
			document.getElementById("UserInstructionPrompt").style.display="none";
		}
	}
	catch(err) {
		alert("Unexpected error occurred. Please start a new problem.");
	}	
	return;
}

function getExpressionToSolve(newString)
{
	var validPart;
	var expnToSolve;
	var selEq = [];
	var selEqIndex = [];
	var j, i;
	var expnOperation;
	var x;
	var removeSelParen = false;
	var errMsgText = "";
	var errorCode;
	var endObj=elementArray.length-1;
	var beginObj=0;
	var removeParen = false;
	var x;
	var partString;
	j=0;
	var opType=0; 
	var simplifyOpList=document.getElementById("simplifyMenu");

	var equationOpList=document.getElementById("equationMenu"); 
	
	validPart = false;	
	i=0;
	partString = newString;
	
	if (partString!="") {
		var testString=partString;
		partString=checkForSpecialChars(testString);
	}
	
	document.getElementById("userInstructions").style.display="";
	document.getElementById("workarea").style.display="";
	document.getElementById("whatToDoNextArea").style.display="";

	switch (selExpType) 
	{
	case 10: //simplify numeric expression
		document.getElementById("stepExplanation").style.display="none";
		
		selEq = parseString(partString,0);
		errMsgText = doSimpleNumericExp(selEq);
		if (errMsgText) {
			displayErrMsg(errMsgText);
			errMsgText = "";
			validPart = false;
			document.getElementById("generalHighlight").style.display="";
		    document.getElementById("mobileEntryField").focus();
		}
		break;
	
	case 20: //Simplify an algebraic expression
	case 30: //simplify equation alg expression
	case 32: //32 is for eq evals
        if (equationFlag) {
        	opType=equationOpList.options[equationOpList.selectedIndex].value;
        } else {
        	opType=simplifyOpList.options[simplifyOpList.selectedIndex].value;
        }
	
		switch (opType)
		{
		case "100":
		case "300": //display error here
			errMsgText="You need to select an operation from the menu first. Then you can highlight.";
			var errorToDisplay=document.getElementById("warningMessage");
			errorToDisplay.innerHTML = errMsgText;
			document.getElementById("operationMenuArea").style.display="";
			if (equationFlag) {
				document.getElementById("equationMenu").style.display="";
			} else {
				document.getElementById("simplifyMenu").style.display="";
			}
			break;
			
		case "101": //Multiply
		case "301": //multiply part of an equation
			if (newString=="") {
				document.getElementById("operationMenuArea").style.display="";	
				document.getElementById("equationMenu").style.display="";
				document.getElementById("equationMenu").selectedIndex=0;
				document.getElementById("multiplyPart").style.display="none";							
				return;
			}
			errMsgText=simplifyAlgExpPart(newString);
			
			if (errMsgText) {
				displayErrMsg(errMsgText);
				errMsgText="";
				document.getElementById("operationMenuArea").style.display="";
				document.getElementById("generalHighlight").style.display="none";
				if (equationFlag) {
					document.getElementById("equationMenu").style.display="none";
				}
				else {
					document.getElementById("simplifyMenu").selectedIndex=0;
					document.getElementById("simplifyMenu").style.display="";
				}
			} else {
				document.getElementById("operationMenuArea").style.display="none";	
				document.getElementById("equationMenu").selectedIndex=0;
				document.getElementById("multiplyPart").style.display="none";							
			}
			break;
			
		case "102": //Combine like terms
			document.getElementById("liketermbutton").style.display="none";
			errMsgText = getTermToCombine(newString);
			
			if (errMsgText == "combineconstants") {
				errMsgText="";
				errMsgText=combineConstants(newString);
			}
			if (errMsgText) {
				displayErrMsg(errMsgText);
				errMsgText="";
			} else {
				document.getElementById("combineliketermsform").reset();				
			}
			document.getElementById("simplifyMenu").selectedIndex=0;
			return;
		
		case "103": //Combine constants
			errMsgText=combineConstants(newString);
			break;		
		}
       	return;

	case 23: //23 for other evals
	case 22: //Evaluate an algebraic expression
		document.getElementById("sidenotes").style.display="";

		selEq = parseString(partString,0);
		errMsgText = doSimpleNumericExp(selEq);
		if (errMsgText) {
			displayErrMsg(errMsgText);
			validPart = false;
		}
		break;
				
	default:
		break;
	}
	
	var warningMsgFieldContent = document.getElementById("warningMessage").innerHTML;
	if (warningMsgFieldContent=="") {
		   	document.getElementById("generalHighlight").style.display="none";
			document.getElementById("UserInstructionPrompt").innerHTML="";			   	
			document.getElementById("UserInstructionPrompt").style.display="none";				
		}
	
	errMsgText="";
	return;
}

function checkForNoValVar(varString)
{
	/*
	 * checks hidden eq variables/values elements
	 * for match on variable string with no value set; used for
	 * equation evaluates where 1 variable value can be left blank by 
	 * setting its val field to ?
	 */
	var match,i;
	var eqVarArray=[];
	var eqValArray=[];
	
	var eqVariables=document.getElementById("hiddeneqvariables").innerHTML;
	var eqValues=document.getElementById("hiddeneqvalues").innerHTML;

	eqVarArray=eqVariables.split(",");
	eqValArray=eqValues.split(",");
	
	match=false;
	for (i=0;i<eqVarArray.length;i++) {
		if (varString==eqVarArray[i] && 
				eqValArray[i]=="?") {
			match=true;
		}
		if (match) i=eqVarArray.length;
	}
	if (!match) {
		eqVariables=eqVariables+","+varString;
		document.getElementById("hiddeneqvariables").innerHTML=eqVariables;
	}
	return (match);
}

function doAlgExpn(expnString)
/*
 * handle selection type=22: evaluate an expression
 * 	first do a parse to get the variable names
 *  for each variable, display a label (variable name) and
 *  		an entry field for the value
 *  submit button
 *  After submit, display new expression with values inserted
 *  Solve expression using simplify numeric routines
 *  
 *  clear out variable box names and/or value ids from 
 *	innerhtml fields. Variables may stay the same for a
 *  subsequent problem
 */
{
	var i, j, k;
	var expnVars=[];
	var varString;
	var strToMatch;
	var a;
	var addToArray = false;
	var hiddenVarVals, hiddenOrigExpression,hiddenVarList;
	var firstPass;
	var newLine;
	var solvedExpns;
	
	var varValsArray = [];
	var varListArray = [];

	// check if this is the first pass		
	hiddenVarVals = document.getElementById("hiddenvarvalues");
	if(hiddenVarVals.innerHTML != "") {
		hiddenVarList = document.getElementById("hiddenvarlist");
		var varList = hiddenVarList.innerHTML;
		varListArray = varList.split(",");
		//get variables from new expression
		strToMatch = expnString.join("");
		strToMatch = strToMatch.toLowerCase();
		varString = parseString(strToMatch, 4);
		// do all variables in varList match variables in new expression
		var foundNew=false;
		var matchedVar=false;
		k=0;
		for (i=0; i<varString.length; i++) {
			j=0;
			while (!matchedVar && j<varListArray.length) {
				if (varString[i]==varListArray[j]) {
					matchedVar=true;
					j=varListArray.length;
				} 
				j++;
			}
			if (!matchedVar && equationFlag) {
				matchedVar=checkForNoValVar(varString[i]);
			}
			
			if (!matchedVar) {
				foundNew = true;
				expnVars[k]=varString[i];
				k++;
			}
			matchedVar=false;
		}
		if (expnVars.length>0) {// new variable(s) added to expression, call setVarPrompt
			hiddenOrigExpression = document.getElementById("hiddenorigexpression");
			hiddenOrigExpression.innerHTML = expnString;
			hiddenOrigExpression.style.display="none";
			setVarPrompt(expnVars, expnString);
			return;
		}
				
		firstPass = false;
		hiddenOrigExpression = document.getElementById("hiddenorigexpression");
		hiddenOrigExpression.innerHTML = expnString;
		hiddenOrigExpression.style.display="none";
		getVarVals();
	} else {
		firstPass = true;
        hideDoAnotherButtons();
	}
	
	if (firstPass) {
		// find all variables in elementArray structure
		// parse the expression string for letters only: match option 4
		// then remove any duplicate variables
		j = 0; //counts number of variables in expression
		
		strToMatch = expnString.join("");
		strToMatch = strToMatch.toLowerCase();
		varString = parseString(strToMatch, 4);
		for (i=0;i<varString.length;i++) {
			a = varString[i];
			addToArray = true;
			if (i >0) {
				for (k=0;k<j;k++) {
					if (expnVars[k] == a) addToArray = false;
				}
			}
			if (addToArray) {
				expnVars[j] = a;
				j++;
			}
		}
		setVarPrompt(expnVars, expnString);
	}	
	return;
}

function doAnotherEvalExpn(finalAnswer)
{
	var hiddenVarList, hiddenVarVals, hiddenOrigExpression;
	var varList;
	var varVals;
	var varValsArray=[];
	var varListArray;
	var origExpression;
	var expnToDisplay;
	var solvedExpns;
	var solvedInfo=" ";
	var newLine;
	
	hiddenVarList = document.getElementById("hiddenvarlist");
	varList = hiddenVarList.innerHTML;
	hiddenVarVals = document.getElementById("hiddenvarvalues");
	varVals = hiddenVarVals.innerHTML;
	hiddenOrigExpression = document.getElementById("hiddenorigexpression");
	origExpression = hiddenOrigExpression.innerHTML;
	
	varValsArray = varVals.split(",");
	varListArray = varList.split(",");
	expnToDisplay = origExpression.split(",");
	
	/* 
	 * write the final answer to table display of solved expressions
	 * leave the variable values as is
	 * 
	 *  display last line for equations differently
	 *		than for expressions
	 */
	solvedExpns = document.getElementById("solvedexpressionslist");
	var lastLine = solvedExpns.lastChild;
	if (!equationFlag) {//display last line for expression
		lastLine.innerHTML = lastLine.innerHTML + " = " + finalAnswer + "<br />";
	} else {
		var formattedAnswer=formatAnswer(finalAnswer);
		lastLine.innerHTML = lastLine.innerHTML +formattedAnswer + "<br />";
	}
	
	resetAfterSolved();	
	document.getElementById("nextevalbutton").style.display=""; 
	return;
}

function formatAnswer(finalAnswer)
{
	/*
	 * Formats final answer string for equations
	 * Correct format is: var-equality sign-constant
	 * Reverses answers formatted as constant-eq sign-var
	 * 
	 * Uses element array to determine if var/constant in correct order
	 * Answers that are 2 constants, n=n, should not be affected
	 */
	var answer=finalAnswer;
	if (elementArray[0].variable) {//variable is set; correct format
	} else if (elementArray[2].variable) {//variable is on right side; switch
		answer=elementArray[2].string+elementArray[1].string+
						elementArray[0].string;
	}
	return(answer);
}

function doAnotherEval() 
{
	/*
	 * do additional eval problems
	 */
	resetExercise();
	startSolveTimer();
	
	document.getElementById("nextevalbutton").style.display=""; 
	//display last expression and current var values
	// user can edit expression and var values
	//	if new vars added to expression, app should prompt for
	//	values for these vars
	
    var newMsg = document.getElementById("statusmsg");
    newMsg.innerHTML="Evaluating an algebraic expression";
	document.getElementById("evaluateexpressionform").style.display="";
	document.getElementById("whatToDoNextArea").style.display="";
	document.getElementById("userInstructions").style.display="";
	document.getElementById("workarea").style.display="";	
	document.getElementById("operationMenuArea").style.display="none";        
	document.getElementById("problemEntryArea").style.display="none";        
	if (!equationFlag) {
		selExpType=22; 
	} else {
		selExpType=32;
	}
	changeVarVals();
	return;
}

function useChangedVarVals()
{
	/*
	 * called when user changes expression or var values for eval
	 * calls routines to build new structure and use current var
	 * values for solving
	 * 
	 */
	var varListArray=[];
	var varValsArray=[];
	var expnString,origExpn;
	var expnToChange=[];
	var noAnswer=false;
	
	document.getElementById("evaluateexpressiontablelabel").innerHTML="Enter variable values";

	origExpn = document.getElementById("hiddenorigexpression").innerHTML;
	expnToChange = origExpn.split(",");
	expnString = expnToChange.join("");
	var varList=document.getElementById("hiddenvarlist").innerHTML;
	var varVals=document.getElementById("hiddenvarvalues").innerHTML;
	
	if (equationFlag) {
		varList=document.getElementById("hiddeneqvariables").innerHTML;
		varVals=document.getElementById("hiddeneqvalues").innerHTML;
	}
	varValsArray = varVals.split(",");
	varListArray = varList.split(",");
	varValsArray[varValsArray.length]=expnString;

	var x = document.getElementById("evaluateexpressionform");
	var checkBoxId = "";
	var inputElemId;
	
	// hold eq string for display in sidenotes
	var newValueEntered=false;
	var blankVarCtr=0;
	var newEquationDisplay="";
	var changeEqHeader=false;
	var blankVarPos="";
		
	for (var i=0;i<varValsArray.length;i++) {
		inputElemId="variableinputelem"+i;
		y=document.getElementById(inputElemId).value;
		checkBoxId = "variablecheckBox"+i;
		msg = document.getElementById(checkBoxId);
		if (msg!=null) msg.innerHTML = " ";
		if (i<varValsArray.length-1) {//vars
			notNumber=false;
			slashPtr = y.indexOf("/");					
			if (slashPtr > -1) { // input contains fractions
				numStr = Number(y.slice(0,slashPtr));		
				denomStr = Number(y.slice(slashPtr+1));
				if (isNaN(numStr) || isNaN(denomStr)) {
					notNumber=true;
				} else {
					if (varValsArray[i]!=y) newValueEntered=true;
					varValsArray[i]=y;
				}
			} else if (y=="?" && equationFlag) {
				blankVarCtr++;
				if (blankVarCtr>1) {
					noAnswer=true;
					msg.innerHTML = " Only 1 variable can be left blank";
				} else {
					if (varValsArray[i]!=y) newValueEntered=true;
					varValsArray[i]=y;
					blankVarPos=i;
				}
			} else {
				aNum = "";
				aNum = Number(y);
				if (isNaN(aNum)) notNumber=true;
			}
			if (notNumber && blankVarCtr<2) {
				msg.innerHTML = " Value must be a number";
				noAnswer = true;
			} else {
				if (varValsArray[i]!=y) newValueEntered=true;
				varValsArray[i]=y;
			}
		} else {
			newEquationDisplay=expnString; //old equation
			if (expnString!=y) {
				expnString=y;
				expnToChange=parseString(expnString,1);
				if (expnToChange==null) {
					msg.innerHTML="Incorrect expression";
					noAnswer=true;
				} else if (!parseString(expnString,4)){//check for vars/alpha chars
					msg.innerHTML="Expression must include a variable";
					noAnswer=true;	
				} else {
					//check for equality opers: match pattern 14
					expnToChange=parseString(expnString,14);
					if (!equationFlag && expnToChange!=null) {
						//found equality oper
						msg.innerHTML="Cannot change expression to an equation at this time";
						noAnswer=true;
					}
					if (equationFlag) {
						if (expnToChange) {//valid equation
							newEquationDisplay=expnString;
							newValueEntered=true;
							changeEqHeader=true;
						}
					}
				}
			}
		}
	}
	
	if (noAnswer) return false;
	
	varValsArray.splice(-1,1);
	
	//if equation, remove any vars/vals with ? for val
	if (blankVarCtr>0) {
		document.getElementById("hiddeneqvariables").innerHTML=varListArray;
		document.getElementById("hiddeneqvalues").innerHTML=varValsArray;
		varListArray.splice(blankVarPos,1);
		varValsArray.splice(blankVarPos,1);
		document.getElementById("hiddenvarlist").innerHTML=varListArray;
	} else if (blankVarCtr==0) {
		document.getElementById("hiddenvarlist").innerHTML=varListArray;
		document.getElementById("hiddeneqvariables").innerHTML=varListArray;
		document.getElementById("hiddeneqvalues").innerHTML=varValsArray;		
	}
	
	if (newValueEntered) {
		var variableDisplayString="";
		for (i=0;i<varValsArray.length;i++) {
			variableDisplayString = variableDisplayString+varListArray[i]+" = "+
					varValsArray[i]+" ";
		}
		if (!equationFlag) {
			addHeaderLineForEval(variableDisplayString);
		} else {
			if (changeEqHeader) addHeaderLineForEvalEq(newEquationDisplay);
			addDetailForEvalEq(variableDisplayString);
		}
	}
	
	clearAnswerFormTable("evaluateexpressiontable","variablerow");
	document.getElementById("evaluateexpressionform").style.display="none";	
	document.getElementById("hiddenorigexpression").innerHTML=expnToChange;
	document.getElementById("hiddenvarvalues").innerHTML=varValsArray;	
	
	var saveEquationFlag=equationFlag;
	var errorMsg="";
	errorMsg=confirmPoly("",expnString);//pass empty string for 1st parameter
	equationFlag=saveEquationFlag;
	if (errorMsg) {// reset menu to evaluate problem and display change vals form
		document.getElementById("problemTypeMenu").selectedIndex=1;
		document.getElementById("problemEntryArea").style.display="none";
		document.getElementById("evaluateexpressionform").style.display="";
		document.getElementById("whatToDoNextArea").style.display="";
	}
	return;
}

function addHeaderLineForEval(variableDisplayString)
{
	/*
	 * writes new header line with vars/vals for evaluates
	 */
	if (document.getElementById("listheading")!==null)
		document.getElementById("listheading").id=" ";
	var newLineHdg = document.createElement("span");
	newLineHdg.setAttribute("id","listheading");
	newLineHdg.setAttribute("class","command");
	newLineHdg.innerHTML="<br />"+"For "+ variableDisplayString +", simplify:" + "<br />";
	var appendNode = document.getElementById("solvedexpressionslist");
	appendNode.appendChild(newLineHdg);	
	return;
}

function addHeaderLineForEvalEq(equation)
{
	/*
	 * writes evaluate display data for equationss
	 * 
	 */
	if (document.getElementById("listheading")!==null)
		document.getElementById("listheading").id=" ";
	var newLineHdg = document.createElement("span");
	newLineHdg.setAttribute("id","listheading");
	newLineHdg.setAttribute("class","command");
	newLineHdg.innerHTML="<br />"+"For "+ equation +", when:" + "<br />";
	var appendNode = document.getElementById("solvedexpressionslist");
	appendNode.appendChild(newLineHdg);		
	return;
}

function addDetailForEvalEq(varDisplayString)
{
	/*
	 * writes evaluate detail lines display 
	 * data for equations
	 * 
	 * use semicolon instead of comma to end variable display list
	 * 	semicolon signals if eq completed and line should be retained/removed 
	 */
	var appendNode = document.getElementById("solvedexpressionslist");
	var newLineHdg = document.createElement("span");
	newLineHdg.setAttribute("class","command");
	newLineHdg.innerHTML=varDisplayString +"; ";
	appendNode.appendChild(newLineHdg);		
	return;
}


function changeVarVals()
{
	/*
	 * Displays current expression and var values for an evaluate probl
	 * Allows user to change expression and variables or leave as is
	 * 
	 */
	var j,i;
	var cellnode, cellnode2, cellnode3; 
	var inputElement;
	var textElement;
	var textincell;
	var trElement;
	var tableElement, tableElementStart;
	var varArrayLength;
	var promptVar;
	
	var varVals,varList,origExpn,expnString;
	var varValsArray=[];
	var varListArray=[];
	var expnToChange=[];

	varList = document.getElementById("hiddenvarlist").innerHTML;
	varVals = document.getElementById("hiddenvarvalues").innerHTML;
	origExpn = document.getElementById("hiddenorigexpression").innerHTML;
	
	if (equationFlag) {
		varList=document.getElementById("hiddeneqvariables").innerHTML;
		varVals=document.getElementById("hiddeneqvalues").innerHTML;
	}

	varValsArray = varVals.split(",");
	varListArray = varList.split(",");
	expnToChange = origExpn.split(",");
	expnString = expnToChange.join("");	
	
	varValsArray[varValsArray.length]=expnString;
	varListArray[varListArray.length]="Expression: ";
	clearAnswerFormTable("evaluateexpressiontable","variablerow");
	
	i=0;
	j=0;
	tableElementStart=document.getElementById("evaluateexpressiontable");	
	document.getElementById("evaluateexpressionform").style.display="none";
	
	while (i < varListArray.length) {
		var rownode=document.createElement("tr");
		rownode.id="variablerow"+i;
		tableElementStart.appendChild(rownode);
		cellnode=document.createElement("td");
		cellnode.id="value"+rownode.id;
		cellnode.innerHTML = varListArray[i]+" ";
		cellnode.style.fontWeight="bold";
		cellnode.style.textAlign = "right";
		cellnode.style.paddingRight="10px";
		rownode.appendChild(cellnode);
		cellnode2=document.createElement("td");
		cellnode2.id="variableinput"+i;
		inputElement = document.createElement("input");
		inputElement.id="variableinputelem"+i;
		inputElement.style.maxWidth="40px";
		if (i==(varListArray.length-1)) {
			inputElement.style.maxWidth="100px";
			inputElement.style.width="100px";
		}
		inputElement.value=varValsArray[i];
		cellnode2.appendChild(inputElement);
		rownode.appendChild(cellnode2);
		// create checkBox for messages in last cell
		cellnode3=document.createElement("td");
		cellnode3.innerHTML=" ";
		cellnode3.id="variablecheckBox"+i;
		textElement = document.createElement("text");
		cellnode3.appendChild(textElement);
		rownode.appendChild(cellnode3);	
		i++;
	}	
	document.getElementById("variableinput0").focus();	
	if (equationFlag && varArrayLength>1) {
		document.getElementById("equationvarprompt").style.display="";
	}

	document.getElementById("entervarvaluesbutton").style.display="none";
	document.getElementById("changevarvaluesbutton").style.display="";
	
	document.getElementById("evaluateexpressiontablelabel").innerHTML=
		"Change variable values or expression. ";
	document.getElementById("evaluateexpressionform").style.display="";
	document.getElementById("evaluateexpressiontable").style.display="";		
	return;
}

function doAnotherSimplifyNum()
{  
    clearDisplayData("expnTable");
    document.getElementById("problemEntryArea").reset();
    document.getElementById("problemEntryArea").style.display="";
    document.getElementById("getanswerform").reset();
    //jcs012715 new field name
	document.getElementById("problementryfield").style.display="";
    hideDoAnotherButtons();

	document.getElementById("expType").selectedIndex=1;
	document.getElementById("operationMenuArea").style.display="none";
	resetAfterSolved();
    return;   
}

function enterVarVals()
{
	var y, aNum, msg;
	var checkBoxId;
	var noAnswer = false;
	var slashPtr, numStr, denomStr, notNumber;

	if (equationFlag) {
		enterEqVarVals();
		displayTip("equation");	//jcs102815 redisplay tip
		return true;
	}

	var x = document.getElementById("evaluateexpressionform");
		
	checkBoxId = "";
	for (var i=0;i<x.elements.length-1;i++) {
		if (x.elements[i].tagName == "INPUT") {
			y = x.elements[i].value;
			checkBoxId = "variablecheckBox"+i;
			msg = document.getElementById(checkBoxId);
			if (msg!=null) msg.innerHTML = " ";
			if (y=="" || y==" ") {
				msg.innerHTML = " Enter a value for the variable";
				noAnswer = true;
			} else {
				notNumber=false;
				slashPtr = y.indexOf("/");					
				if (slashPtr > -1) { // input contains fractions
					numStr = Number(y.slice(0,slashPtr));		
					denomStr = Number(y.slice(slashPtr+1));
					if (isNaN(numStr) || isNaN(denomStr)) notNumber=true;
				} else {
					aNum = "";
					aNum = Number(y);
					if (isNaN(aNum)) notNumber=true;
				}
				if (notNumber) {
					msg.innerHTML = " Value must be a number";
					noAnswer = true;
				}
			}
		}
	}
	
	if (noAnswer) return false;	
	getVarVals();
	
	//check for single terms within absol val bars
	//	 only needed for eval expns type 22 and for first pass;
	//	 subsequent iterations are caught in confirmPoly
    
    if (selExpType == 22 || selExpType == 23) {
    	var absolValSingleTerm = [];
    	absolValSingleTerm = checkAbsolValSingleTerm();
    	if (absolValSingleTerm[0]!=-1) {//found single term within abol val
    		promptSingleAbsVal(absolValSingleTerm);
    	}
    }	
	return true;
}

function getVarVals()
/*
 * function gets the values entered for alg expression variables
 * and builds the new structure. Original structure, in string format, 
 * should be saved to innerhtml within the form. Variables and values
 * should also be saved to innerhtml so that either can be reused for
 * additional problems
 */
{
	var userAns=[];
	var i,j, k;
	var varList;
	var varVals;
	var varValsArray=[];
	var varListArray;
	var origExpression;
	var expnToChange=[];
	var newExpn = [];
	var answer;
	var objPosArray;
	var objPosString;
	var hiddenVarList, hiddenVarVals, hiddenOrigExpression;
	var elementCopied = false;
	var newLine;
	var expnString="";
		
	hiddenVarList = document.getElementById("hiddenvarlist");
	varList = hiddenVarList.innerHTML;
	hiddenVarVals = document.getElementById("hiddenvarvalues");
	varVals = hiddenVarVals.innerHTML;
	hiddenOrigExpression = document.getElementById("hiddenorigexpression");
	origExpression = hiddenOrigExpression.innerHTML;

	var eqVariables=[];
	var eqValues=[];
	var solveEqOneStep;
	var parensFound;

	if (equationFlag) {
		eqVariables=document.getElementById("hiddeneqvariables").innerHTML;
	}

	if (varVals != "") {
		varValsArray = varVals.split(",");
	}
	varListArray = varList.split(",");
	expnToChange = origExpression.split(",");
	expnString = expnToChange.join("");
	
	expnToChange = buildStrPart(0,elementArray.length-1);
	
	//bts 010914: add check for additional variables: if there are additional ones,
	//  then varListArray should be > varValsArray;
	//	add addtl vars to end of varListArray
	var addedVars=false;
	if (varVals && (varListArray.length > varValsArray.length)) addedVars=true;
	if ((varVals == "" || varVals == null) ||
			(addedVars)) {
		var x = document.getElementById("evaluateexpressionform");
		for (i=0;i<x.elements.length-1;i++) {
			if (x.elements[i].tagName == "INPUT") {
				if (!addedVars) {//first time value inputs
					//save vals to 2nd hidden var for equations
					//		regardless if there's a value or if ? entered
					if (x.elements[i].value != "?") {
						if (i==0){//adjust for empty element if first element in array 
							varValsArray[i]=x.elements[i].value;
							if (equationFlag) 
								eqValues[i]=x.elements[i].value;
						} else {
							varValsArray[varValsArray.length] = x.elements[i].value;
							if (equationFlag) 
								eqValues[eqValues.length]=x.elements[i].value;
						}
					} else if (x.elements[i].value=="?" &&
							equationFlag) {
						if (i==0) {
							eqValues[i]="?";
						} else {
							eqValues[eqValues.length]="?";
						}
					}
				} else if (addedVars) {//extra var values
					varValsArray[varValsArray.length]= x.elements[i].value;
					if (equationFlag) {
						eqVariables[eqVariables.length]=x.elements[i].value;
						eqValues[eqValues.length]=x.elements[i].value;
					}
				}
			}
		}
		
		//add new vals to existing eqvalues
		if (equationFlag) {
			document.getElementById("hiddeneqvariables").innerHTML=eqVariables;
			var eqValsString=eqValues.join(",");
			//bts 02192016: replace hiddeneqvalues with new vals if blank or only ?
			if (document.getElementById("hiddeneqvalues").innerHTML=="" ||
					document.getElementById("hiddeneqvalues").innerHTML=="?"){
				document.getElementById("hiddeneqvalues").innerHTML=eqValsString;
			} else {
				document.getElementById("hiddeneqvalues").innerHTML=
					document.getElementById("hiddeneqvalues").innerHTML
					+","+eqValsString;
			}
		}
		
		//remove any added vars where there are no vals entered
		var remVar,remVal;
		i=varValsArray.length-1;
		while (i>0) {
			if (varValsArray[i]=="") {
				remVal=varValsArray.splice(i,1);
				remVar=varListArray.splice(i,1);
			}
			i--;
		}
		//update the var list
		if (remVar) hiddenVarList.innerHTML=varListArray;
		// save variable values in html form
		hiddenVarVals.innerHTML = varValsArray;
			
		clearAnswerFormTable("evaluateexpressiontable","variablerow");
		document.getElementById("evaluateexpressionform").style.display="none";
		var variableDisplayString="";
		for (i=0;i<varValsArray.length;i++) {
			variableDisplayString = variableDisplayString+varListArray[i]+" = "+
				varValsArray[i]+" ";
		}
		if (equationFlag) {
			addHeaderLineForEvalEq(expnToChange);
			addDetailForEvalEq(variableDisplayString);
		}
		
		// write variables/values above expression list
		var changedType=false;
		var saveSelExpType=selExpType;
		//if (!addedVars && !equationFlag) {
		if (!addedVars) {
			 selExpType=23;
			 changedType=true;
		}
		if (selExpType == 22 && !equationFlag) {
			newLine=document.getElementById("listheading");
			newLine.innerHTML = "For "+ variableDisplayString +", simplify:" + "<br />";
		}
		if (changedType) {//set type back to 22 or 30
			if (!equationFlag) {
				addHeaderLineForEval(variableDisplayString);
			} else {
				//addHeaderLineForEvalEq(expnToChange,variableDisplayString);
			}
			changedType=false;
			selExpType=saveSelExpType;
		}
	}
	var solvedExpns;
	solvedExpns = document.getElementById("solvedexpressionslist");
	var newExpnLine;
	
	if (!equationFlag) {
		newExpnLine =document.createElement("span");
		newExpnLine.innerHTML = expnString;
		newExpnLine.style.fontWeight="bold";
		solvedExpns.appendChild(newExpnLine);
	}
		
	// substitute entered values for variables in expression
	// replace variables in string with entered values and surround
	// with parens. Then call addAsterisk and removeParens functions;
	// rebuild the structure. 
	var substituteVars = [];
	var substituteVals = [];
	var subCount = 0; 
	
	k=0; // counter for newExpn array

	for (i=0;i<expnToChange.length;i++) {
		elementCopied = false;
		for (j=0;j<varListArray.length;j++) {
			if (expnToChange[i] == varListArray[j]) {
				substituteVars[subCount] = varListArray[j];
				substituteVals[subCount] = varValsArray[j];
				subCount++;
				newExpn[k] = "(";
				k++;
				newExpn[k] = varValsArray[j];
				k++;
				newExpn[k] = ")";
				k++;
				elementCopied = true;
			} 
		}
		if (!elementCopied) {
			newExpn[k] = expnToChange[i];
			k++;
			if (i==0 && expnToChange[i]=="-") {
				newExpn[k]="1";
				k++;
				newExpn[k]="*";
				k++;
			}
		}		
	}
	
	var testExpn = newExpn.join("");
	newExpn = parseString(testExpn,1);
		
	var errMsgText="";
	errMsgText = buildStructure(newExpn, elementArray);
	if (errMsgText) return;
	
	writeToTable(" -- Substituted " + substituteVals +" for "+ substituteVars);	
	
	elementArray.splice(1);	
	newExpn = addAsterisk(newExpn);
	
	errMsgText = buildStructure(newExpn, elementArray);
	removeParensInStructure();
	
	// display new structure with modified expression
	writeToTable(" -- Removed parentheses");
		
	changeMinusToAdd();
	
	if (!equationFlag) {		
		var addOpersOnly;
		var tempExpnString = buildStrPart(0,elementArray.length-1); 
		var hasFractions = tempExpnString.indexOf("/");
		if (hasFractions >-1) { // check for plus/minus opers only
			var operString = parseString(tempExpnString,10);
			if (operString == null) { // only "add" opers present
				var absValBars=tempExpnString.indexOf("|");
				if (absValBars==-1) addOpersOnly = true;
			}
		}
		
		// regroup integer and fraction terms together
		// and write regrouped expression to the blackboard
		
		if (addOpersOnly) {
			var fractBeginObj;
			var fractBeginEndObj = [];
			fractBeginObj=regroupExpn();
			fractBeginEndObj[0]=fractBeginObj;
			fractBeginEndObj[1]=elementArray.length-1;		
			// check if necessary to write the grouped message	
			var fractTempString = buildStrPart(0, elementArray.length-1);
			fractBeginObj = fractTempString.indexOf("/");
			hasFractions = tempExpnString.indexOf("/");
			if (fractBeginObj != hasFractions) { //expression reordered	
				writeToTable(" -- Grouped whole numbers & fractions using commutation " +
				"\<a href='javascript\:open_helpwin(7);'> Explain \</a>");			
			} 
			addWholeNumbers(fractBeginEndObj," ");
		}
		
		if (addOpersOnly) {
			document.getElementById("userInstructions").style.display="none";
		} else {
			document.getElementById("userInstructions").style.display="";
			document.getElementById("whatToDoNextArea").style.display="";
		}
	} // end of code skipped if equation

    document.getElementById("operationMenuArea").style.display="none";
    document.getElementById("evaluateexpressionform").style.display="none"; 
    document.getElementById("stepExplanation").style.display="none"; 
    if (!equationFlag) {
    	displayTip("eval2");
    } else {
    	//check for solving eq 1 step
    	//	solveEqOneStep=0: cannot solve in 1 step
    	//				 = -1: var on left side of eq
    	//				 = 1: var on right side of eq
     	var noTerms=false;
    	var operSide=0;
    	solveEqOneStep=solveEqOneStepTest(); 
    	if (solveEqOneStep==2) {
    		solveEqOneStep=0;
     		operSide=solveOneStepMostOpers();
    	}
    	if (solveEqOneStep && operSide==0) {
    		noTerms=solveOneStepCheckOpers(solveEqOneStep);
    	} else if (!solveEqOneStep && operSide!=0) {
    		solveEqOneStep=operSide;
    	}
    	parensFound=solveEqOneStepParensCheck(1);//check left side first
    	if (!parensFound) parensFound=solveEqOneStepParensCheck(-1);//right side
		if (parensFound||noTerms) solveEqOneStep=0;

    	if (!solveEqOneStep) {
    		document.getElementById("operationMenuArea").style.display="";
    	} else {
    		noTerms=buildEvalEqSpecialPrompt(solveEqOneStep);
    		//bts 02222016: fix bug with displaying getanswerform for 1 step answer
    		//if (noTerms) document.getElementById("operationMenuArea").style.display="";
    		if (noTerms) {
    			document.getElementById("operationMenuArea").style.display="";
    		} else {
        		document.getElementById("getanswerform").style.display="";
        		document.getElementById("userInstructions").style.display="";
    		}
    	}
    }
	return;
}

//TODO start here for comment removal
function buildEvalEqSpecialPrompt(sideToSolve)
{
	/*
	 * Builds special prompt for eval eqs where only numbers on 1 side
	 * sideToSolve indicates which side of eq oper for the how much prompt
	 * Calls setAnswerPrompt after the build
	 * 
	 *01052016: if sideToSolve=2, do calcs for both left/right sides of eq
	 *	and set up 2 prompts for user answer
	 */
	var i,j;
	var preprompttext="How much is: ";
	var expnOperation="";
	var introType;
	var onePrompt = true;
	var multiplier = "";
	var callerId = "onestep";
	
	var positions=[];
	var terms=[];
	var nums=[];
	var startLoc,endLoc;
	var noTerms=false;
	
	//bts 01052016: use arrays for userPrompt, calcAns if requiring
	//		answers for both left/right sides of equation
	var bothSides=false;
	var userPrompt="";
	var calcAns;

	var userPromptBoth=[];
	var calcAnsBoth=[];
	var eqSide=0;
	if (sideToSolve==2) bothSides=true;
	
	var eqLoc=findEqualityLocInStruct();

	if (sideToSolve==1){
		//build prompts from left side of eqLoc as var is on right side
		startLoc=0;
		endLoc=eqLoc;
	} else if (sideToSolve==-1){
		//build prompts from right side of eqLoc as var is on left side
		startLoc=eqLoc+1;
		endLoc=elementArray.length;		
	} else if (sideToSolve==2) {
		// solving both sides
		startLoc=0;
		endLoc=elementArray.length;
		for (i=0;i<2;i++) {
			userPromptBoth[i]="";
			calcAnsBoth[i]=0;
		}
	}
	
	for (i=startLoc;i<endLoc;i++) {
		 if (elementArray[i].elemtype=="term") {
			 positions[positions.length]=i;
			 terms[terms.length]=elementArray[i].string;
			 //nums[nums.length]=elementArray[i].numerator;
			 if (!bothSides) {
				 userPrompt=userPrompt+elementArray[i].string;
			 } else {
				 //if (i>eqLoc) eqSide=1;
				 userPromptBoth[eqSide]=userPromptBoth[eqSide]+elementArray[i].string;
			 }
		 } 
		 if (elementArray[i].elemtype=="oper") {
			 if (!bothSides) {
				 userPrompt=userPrompt+elementArray[i].string;
			 } else {
				 userPromptBoth[eqSide]=userPromptBoth[eqSide]+elementArray[i].string;
			 }
		 }
		 if (i==eqLoc) eqSide=1;
	}	
	if (terms.length<1) {
		document.getElementById("hiddeneqevalonestep").innerHTML="false";
		noTerms=true;
		return(noTerms);
	}
	
	// highlight the terms to combine before prompting for answer
	var highlightColor = "orange";
	for (i=0;i<positions.length;i++){
		writeMultHighlight(positions[i],1,elementArray.length,highlightColor);
	}
	var denomArray=[]; //holds 2 denominators
	var fractionPresent=false;
	var lcd=1; //calculated lcd for 2 terms
	var lcdMultiplier;
	var operPointer; //location of next operator to work on
	var expnToSolveArray;
	var calcAnswerArray=[];
	
	var continueLoop=true;
	eqSide=0; //for both sides, set side indicator to start w/left side
	while (continueLoop) {
		//reset end locations because of changes to structure array
		//add test for both sides here; if both sides, calc left side first
		if (sideToSolve==1 || sideToSolve==2) {
			endLoc=findEqualityLocInStruct()-1;
			startLoc=0;
			if (sideToSolve==2 && endLoc==0) {//2 sides: set limits for right side
				endLoc=elementArray.length-1;
				startLoc=findEqualityLocInStruct()+1;
				eqSide=1;
			} 
		}
		if (sideToSolve==-1) {//right side
			endLoc=elementArray.length-1;	//set to new length	
			startLoc=findEqualityLocInStruct()+1;
		}
		//if (sideToSolve==2 && eqSide>1) continueLoop=false;
		if (endLoc-startLoc <2) {
			continueLoop=false;
		} else {
			operPointer = checkOperators(startLoc,endLoc);
			if (operPointer == -1) continueLoop=false;
		} 
		if (continueLoop) {
			expnToSolveArray=buildArray(operPointer-1,operPointer+1);
			//check for zero in both numerators; if found, set denom to 1 
			if (elementArray[operPointer-1].numerator==0) 
				elementArray[operPointer-1].denominator=1;
			if (elementArray[operPointer+1].numerator==0) 
				elementArray[operPointer+1].denominator=1;				
			//check for fractions; if fraction found, +/- opers need lcd conversion		
			if (elementArray[operPointer-1].denominator>1 ||
					elementArray[operPointer+1].denominator>1) {//fraction
				denomArray[0]=elementArray[operPointer-1].denominator;
				denomArray[1]=elementArray[operPointer+1].denominator;
				fractionPresent=true;
				if (elementArray[operPointer].string == "+" || 
					elementArray[operPointer].string == "-") {
					lcd = calculateLCD(denomArray);
					if (lcd>1){
						var lcdConvPtr;
						for (i=0;i<2;i++) {
							if (i==0) lcdConvPtr=operPointer-1;
							if (i==1) lcdConvPtr=operPointer+1;
							lcdMultiplier = lcd/elementArray[lcdConvPtr].denominator;
							elementArray[lcdConvPtr].numerator=
									elementArray[lcdConvPtr].numerator*lcdMultiplier;
							if (i==0) elementArray[lcdConvPtr].denominator=lcd;
						}
					}
					calcAnswerArray = 
						calculateFractionAnswer(expnToSolveArray,operPointer-1,operPointer+1);
					elementArray[operPointer-1].numerator = calcAnswerArray[0];
				} else {//multiply or divide with fractions
					calcAnswerArray = 
						calculateFractionAnswer(expnToSolveArray,operPointer-1,operPointer+1);
					elementArray[operPointer-1].numerator = calcAnswerArray[0];	
					elementArray[operPointer-1].denominator = calcAnswerArray[1];					
				}
				//bts 12292015: if numerator is 0, eliminate fraction; set val to 0
				if (elementArray[operPointer-1].numerator==0) {
					elementArray[operPointer-1].denominator=1;
					calcAns=0;
					elementArray[operPointer-1].string="0";					
				} else {
					//format string for fraction; save to structure
					calcAns = String(elementArray[operPointer-1].numerator+"/"+
							String(elementArray[operPointer-1].denominator));
					elementArray[operPointer-1].string=calcAns;
				}
			} else {//not fraction
				fractionPresent=false;
				calcAns=Number(calculateAnswer(expnToSolveArray));
				elementArray[operPointer-1].numerator = calcAns;
				elementArray[operPointer-1].string = calcAns.toString();	
			}
			elementArray.splice(operPointer,2);//remove oper+term
		}
		if (bothSides) {
			//save answer in calcAnsBoth array
			if (fractionPresent){
				calcAnsBoth[eqSide]=elementArray[operPointer-1].string;
			} else {
				calcAnsBoth[eqSide]=elementArray[operPointer-1].numerator;
			}
		}
	}
	//if fraction in last term, then simplify it
	// use sideToSolve for correct element in struct
	var cancelNumber=[];
	var checkLoc=0;//default if checking term on left side of eq
	if (sideToSolve==-1) checkLoc=2;//term is on right side
	if (elementArray[checkLoc].string.indexOf("/")) {//fraction found
		cancelNumber = checkForFractionCancel(checkLoc,checkLoc);
		if (cancelNumber[0]>0) {//do calc if fraction can be cancelled
			var simplifyNumber = Math.max.apply(Math,cancelNumber);
			elementArray[checkLoc].numerator = Number
				(elementArray[checkLoc].numerator/simplifyNumber);
			elementArray[checkLoc].denominator = Number
				(elementArray[checkLoc].denominator/simplifyNumber);
			if (elementArray[checkLoc].denominator>1) { 
				elementArray[checkLoc].string = 
					String(elementArray[checkLoc].numerator)+"/"+
					String(elementArray[checkLoc].denominator);
			} else {
				elementArray[checkLoc].string=String(elementArray[checkLoc].numerator);
			}
		}
	}

	//set hidden var indicating 1 step solution to problem
	document.getElementById("hiddeneqevalonestep").innerHTML="true";
	if (bothSides) {
		onePrompt = false;
		setAnswerPrompt(preprompttext,userPromptBoth,multiplier, 
				calcAnsBoth,positions,1,onePrompt,callerId,
				expnOperation,introType);		
	} else {
		setAnswerPrompt(preprompttext,userPrompt,multiplier, 
				calcAns,positions,1,onePrompt,callerId,
				expnOperation,introType);
	}
	return(noTerms);
}

function solveEqOneStepTest()
{
	/*
	 * Tests if an equation with evaluate can be solved with single prompt
	 * Equation must have 1 variable on 1 side of eq & only 
	 * constants on other side
	 * 
	 * Checks for parentheses on side without variable. One step solving
	 * not allowed if parens exist
	 * 
	 * Returns oneStep variable: 
	 * 	if set to 0, cannot solve equation in 1 step
	 * 	otherwise, indicates side of the equation with no variables:
	 * 		oneStep= -1 - left side of equality sign
	 * 		oneStep= 1  - right side of equality sign
	 */
	//  array pos 0=leftvarfound
	//	array pos 2=rightvarfound
	var varsCoeffsArray=[false,false,false,false,false,-1];
	var oneStep=0;
	var testString;
	
	//bts 01052016: allow 1 step solution when no vars present
	varsCoeffsArray=checkEqVarsCoeffs();	
	//test for vars on left/right sides of eq
	if (varsCoeffsArray[0] && varsCoeffsArray[2]) {
		oneStep=0;
	} else if (!varsCoeffsArray[0] && !varsCoeffsArray[2]) {
		//no vars present
		oneStep=2;
	} else {//possible to solve in single step
		if (varsCoeffsArray[0]) oneStep=-1; 		
		if (varsCoeffsArray[2]) oneStep=1; 		
	}
	return(oneStep);
}

function solveOneStepMostOpers()
{
	/*
	 * For an eq eval with all constants after value substitution,
	 * this routine returns the side with the most operations to perform
	 * or indicates that only 1 side has multiple elements
	 */
	/*
	var sideToSolve=1; // apply single step solution to left side of equation
	var eqLoc=findEqualityLocInStruct();
	if (elementArray.length-eqLoc > eqLoc+1) sideToSolve=-1; 	
	return(sideToSolve);
	*/
	var sideToSolve;//1-solve left side only
					//-1=solve right side only
					//2- solve both sides
	var eqLoc=findEqualityLocInStruct();
	if (eqLoc>2 && (elementArray.length-eqLoc >2)) {
		sideToSolve=2;
	} else if (eqLoc==1 && elementArray.length>3) {
		sideToSolve=-1;
	} else {
		sideToSolve=1;
	}
	
	return(sideToSolve);
}

function solveOneStepCheckOpers(sideToCheck)
{
	/*
	 * checks for more than 1 element or opers on eq side with variable
	 * Also checks for single element on side opposite variable
	 * 
	 * Returns true indicating more than one element/oper on var side or
	 * single element on side opposite variable, indicating no prompt is 
	 * necessary to solve that side
	 */
	var multipleEls=false;
	var eqLoc=findEqualityLocInStruct();
	if (sideToCheck==-1) {
		//var on left side
		if (eqLoc>1) multipleEls=true;
	} else if (sideToCheck==1) {
		//var on right side
		//bts 02242016: var on right side must be single element on right
		//	side of equation; diff between array len and equal oper location
		//	in array should be >2 not >1
		//if (elementArray.length-eqLoc > 1) multipleEls=true;
		if (elementArray.length-eqLoc > 2) multipleEls=true;
	}
	
	if (!multipleEls) {
		//check for single element on side opposite variable
		if (sideToCheck==-1) {
			//var on left side. check for single element on right side
			if (elementArray.length-eqLoc == 1) multipleEls=true;
		} else if (sideToCheck==1) {
			//var on right side
			//bts 02242016: var on right side must be single element on right
			//	side of equation; diff between array len and equal oper location
			//	in array should be >2 not >1
			//if (elementArray.length-eqLoc > 1) multipleEls=true;
			if (elementArray.length-eqLoc > 2) multipleEls=true;
		}
	}	
	return(multipleEls);
}

function solveEqOneStepParensCheck(stepSide)
{
	/*
	 * Called for eval eqs that meet initial criteria for
	 * solving in 1 step. 
	 * Checks the side of the equation that is all constants for parens;
	 * If parens found, eq cannot be solved in 1 step 
	 * 
	 * Returns true if parens found and eq cannot be solved in 1 step
	 */
	var foundParens=false;
	var testString;
	var eqLoc=findEqualityLocInStruct();
	if (stepSide==-1) {//check left side
		testString=buildStrPart(0,eqLoc-1);
	} else {
		testString=buildStrPart(eqLoc+1,elementArray.length-1);
	}
	if (testString.indexOf("(") >-1) foundParens=true;			
	return(foundParens);
}

function setVarPrompt(expnVars, expnString) {
	
	var j=0;
	var i;
	var cellnode, cellnode2, cellnode3; 
	var inputElement;
	var textElement;
	var textincell;
	var trElement;
	var tableElement, tableElementStart;
	var varArrayLength;
	var promptVar;
	// write variables to a table. Create new table for each row of data
	// add a new row
	i=0;
	j=0;
	tableElementStart=document.getElementById("evaluateexpressiontable");	
	document.getElementById("evaluateexpressionform").style.display="none";
	varArrayLength = expnVars.length;
	
	// set loop counter limit to number of variables in expnVar array
	while (i < varArrayLength) {
		promptVar = expnVars[i];
		var rownode=document.createElement("tr");
		rownode.id="variablerow"+i;
		tableElementStart.appendChild(rownode);
		// display variable in cellnode
		cellnode=document.createElement("td");
		//bts 01222016: added id for variable 
		cellnode.id="value"+rownode.id;
		cellnode.innerHTML = promptVar+" ";
		cellnode.style.fontWeight="bold";
		rownode.appendChild(cellnode);
		// cellnode2 gets the input value from user
		cellnode2=document.createElement("td");
		cellnode2.id="variableinput"+i;
		inputElement = document.createElement("input");
		inputElement.style.maxWidth="40px";
		cellnode2.appendChild(inputElement);
		rownode.appendChild(cellnode2);
		// create checkBox for messages in last cell
		cellnode3=document.createElement("td");
		cellnode3.innerHTML=" ";
		cellnode3.id="variablecheckBox"+i;
		textElement = document.createElement("text");
		cellnode3.appendChild(textElement);
		rownode.appendChild(cellnode3);	
		i++;
	}	
	// bts 04152014: 
	// set focus to first prompt field
	document.getElementById("variableinput0").focus();	
	
	// bts 112014: display equation instructions
	if (equationFlag && varArrayLength>1) {
		//jcs102715 test document.getElementById("equationvarprompt").innerHTML="(You may have 1 variable with no value by entering ? for that variable.)";
		document.getElementById("equationvarprompt").style.display="";
	}
	
	document.getElementById("evaluateexpressionform").style.display="";

	// bts 010914: may be adding new variables for subsequent expressions
	// if var list contains data, then append new vars to list
	// don't overwrite the original expression
	var hiddenVarList = document.getElementById("hiddenvarlist");
	var hiddenOrigExpression = document.getElementById("hiddenorigexpression");
	
	if (hiddenVarList.innerHTML != "") {
		hiddenVarList.innerHTML = hiddenVarList.innerHTML+","+expnVars;
	} else {
		hiddenVarList.innerHTML = expnVars;
		hiddenOrigExpression.innerHTML = expnString;
	}
	hiddenVarList.style.display="none";
	var hiddenValues = document.getElementById("hiddenvarvalues");
	//hiddenValues.innerHTML = "";
	hiddenValues.style.display="none";
	hiddenOrigExpression.style.display="none";
	
	// bts 10052015:
	// display the get variable values button, not change button
	document.getElementById("entervarvaluesbutton").style.display="";
	document.getElementById("changevarvaluesbutton").style.display="none";
	document.getElementById("evaluateexpressionform").style.display="";
	
	return;
}

function simplifySingleFraction()
{	
	/*
	 * Handles case of an expression consisting of single 
	 * fraction term where fraction needs to be simplified
	 * and/or converted to mixed number
	 */
	var errMsgText = "";
	var convertToMixed=false;
	var simplificationDone;
	var solved;
	var simplifyLastTerm;
	
	// clear out any hidden values for mixed numbers, just in case
	var hiddenEndObjElem;
	hiddenEndObjElem = document.getElementById("hiddenendobj");
	hiddenEndObjElem.innerHTML = "";

	simplificationDone = computeSimpleFraction(0);
	if (simplificationDone) {
		simplifyLastTerm=false;
		// no factoring needed, now check if convert to mixed number
		convertToMixed = checkImproperToMixedNumber(0);
		if (!convertToMixed && elementArray[0].denominator !=1) {
			writeToTable(" ** No changes needed. Exercise completed successfully! **");
			resetAfterSolved();
		}
	}

	return;
}
	
function doSimpleNumericExp(selEq)
{
	var errMsgText = "";
	var errorCode;
	var endObj;
	var beginObj=0;
	var removeParen = false;
	var removeSelParen = false;
	var exitLoop = false;
	var operPointer;
	var leftgrpPtr = 0;
	var rightgrpPtr = 0;	
	var exitLoop = false;
	var expnToSolve;
	var expnOperation;
	var parenRemoved=false;
	var	j=0;

	endObj=elementArray.length-1;
	
	//bts010414: take separate branch if orig expression
	//	has single fraction term
	if (elementArray.length == 1 && 
			elementArray[0].denominator != 1){ // single term is a fraction
		simplifySingleFraction();
		return;
	}
	// get the lower/upper bounds of the elementArray
	// if brackets are present, get pointers to left/right brackets objects
	// otherwise, set pointers to 0 and length of elementArray
	while (!exitLoop && j< elementArray.length) {
		if (elementArray[j].elemtype == "leftgrp") beginObj = j+1;
		if (elementArray[j].elemtype == "rightgrp") {
			endObj = j-1;
			exitLoop = true;
			if (endObj-beginObj<4) {
				removeParen = true;
				leftgrpPtr = beginObj-1;
				rightgrpPtr = j;
			} else if (endObj==beginObj){
				leftgrpPtr = beginObj-1;
				rightgrpPtr = endObj+1;
			}
		}
		j++;
	}
		
	//check operator precedence 
	// operPointer should be the elementArray object of the operator
	
	if (beginObj == endObj) { 
		if (removeParen) {
			removeSelParen = true;
			parenRemoved = true;
			elementArray.splice(endObj+1,1);
			elementArray.splice(beginObj-1,1);
			operPointer = beginObj-2;
			beginObj = operPointer-1;
			endObj--;
		}
		if (!removeParen) {
			operPointer = beginObj-1;
			beginObj = operPointer-1;
			endObj = operPointer+1;
		}
	} else {
		operPointer = checkOperators(beginObj,endObj);
		beginObj = operPointer-1;
		endObj = operPointer+1;
	}	
	
	//bts 021214: check if combine expon terms selected
	//  if so, reset begin/end pointers; set operation name also
	
	// bts 03232014: if only 1 number/exponent selected, then
	//	 call performSimpleMath, not combineExponents
	var checkForMultExpons = selEq.indexOf("^"); //find 1st exponent
	if (checkForMultExpons > -1) {
		// check for 2nd exponent
		checkForMultExpons = selEq.indexOf("^",checkForMultExpons+1);
	}
		
	var combineExponsPos=[];
	combineExponsPos=checkExponentOpers(selEq);
	//if (combineExponsPos[0]!=-1) {
	if (checkForMultExpons > -1 && combineExponsPos[0]!=-1) {
		// call function to combine exponents for multiple terms w/same base;
		// rather than performSimpleMath
		errMsgText=performCombineExponents(combineExponsPos,selEq);
	} else {
		// get the string equivalent for the operator if not combining expons
		expnOperation = extractOperation(operPointer);
		errMsgText=performSimpleMath(beginObj, endObj,selEq,expnOperation,parenRemoved);
	}
	// bts 02172014: move call to performSimpleMath to if block above
	//errMsgText=performSimpleMath(beginObj, endObj,selEq,expnOperation,parenRemoved);
	return(errMsgText);
}

function performCombineExponents(exponsPos,selEq) {
	/*
	 * Allows user to combine exponent values for terms with same base value
	 * May have more than 2 terms 
	 * exponsPos: holds positions of all terms with same base and exponent operations
	 */
	var errMsgText="";
	var errprCode;
	var expnToSolve = "";
	var beginObj, endObj;
	
	// variables for setAnswerPrompt call
	var expnOperation="combining exponents";
	var preprompttext="How much is: ";
	var multiplier = 1;
	// last parameter indicates combine like terms
	// is the calling function
	var onePrompt = true;
	var callerId="simplifynumeric";	
	var calcAns, userAns;	
	var promptString="";
	var i;
	var holdBase;
	
	beginObj = exponsPos[0];
	// end obj pos of base term. Add 2 to include expon val
	endObj = exponsPos[exponsPos.length-1]+2;
	
	// make sure selected expression is correct
	expnToSolve=buildStrPart(beginObj,endObj);
	var expnToSolveArray=buildArray(beginObj,endObj);
		
	if (expnToSolve !== selEq.join("")) {
		errorCode=13;//Invalid entry
		errMsgText=errorMsg(errorCode,errMsgText,selEq.join(""));
	} 
	if (errMsgText) {
		displayErrMsg(errMsgText);
		errMsgText="";
		return(errMsgText);
	}

	//build the prompt string, calculate answer
	var nextPos;
	calcAns = 0;
	var addExp = true;
	for (i=0;i<exponsPos.length;i++) {
		if (i==0) {
			holdBase=elementArray[exponsPos[i]].string;
			if (holdBase.indexOf("/") != -1) {//base value is fraction
				promptString=promptString+String(elementArray[exponsPos[i]].numerator).sup()+
					"/"+String(elementArray[exponsPos[i]].denominator).sub();
			} else { // whole number
				promptString = promptString+elementArray[exponsPos[i]].string;
				//promptString = promptString+elementArray[exponsPos[i]].string+"^(".sup()+
				//	elementArray[exponsPos[i]+2].string.sup();
			}
			// exponent portion of prompt
			promptString = promptString+"^(".sup()+elementArray[exponsPos[i]+2].string.sup();
		} else {
			promptString=promptString+elementArray[exponsPos[i]+2].string.sup();
			if (i==exponsPos.length-1) promptString=promptString+")".sup();
		}
		//promptString = promptString+elementArray[exponsPos[i]].string+"^".sup()+
		//				elementArray[exponsPos[i]+2].string.sup();

		if (addExp) {
			calcAns = calcAns+Number(elementArray[exponsPos[i]+2].string);
		} else {
			calcAns = calcAns-Number(elementArray[exponsPos[i]+2].string);
		}
		// add +/- operator based on operator preceding the next term
		if (i<exponsPos.length-1) {
			nextPos = exponsPos[i+1];
			if (elementArray[nextPos-1].string=="*") {
				promptString=promptString+"+".sup();
				addExp = true;
			} else {
				promptString=promptString+"-".sup();
				addExp = false;
			}
		}
	}
	
	// set final calcAns to be base+exponent values
	var calcAnsString = holdBase+"^"+String(calcAns);
	//if (calcAns == 1) calcAnsString = holdBase;
	//if (calcAns == 0) calcAnsString = 1;
	
	var highlightColor = "yellow";
	for (i=0;i<exponsPos.length;i++){
		writeMultHighlight(exponsPos[i],3,elementArray.length,highlightColor);
	}
	
	setAnswerPrompt(preprompttext,promptString,multiplier, 
			calcAnsString,exponsPos,1, onePrompt,callerId,expnOperation);
	
	/* 
	 * insert answer in 1st term position; clear unneeded elements
	 * 
	*/
	elementArray[exponsPos[0]+2].numerator = calcAns;
	elementArray[exponsPos[0]+2].string = calcAns.toString();
	for (i=exponsPos.length-1;i>0;i--) {
		elementArray.splice(exponsPos[i]-1,4);
	}	
	return(errMsgText);
}

function performSimpleMath(beginObj, endObj,selEq,expnOperation,parenRemoved) {
	// find part of orig expn to solve next
	var expnToSolve;
	var selEqIndex = [];
	var j, i, x;
	var expnOperation;
	var eqIndex = [];
	var zeroResult=false;
	var calcAnswer;
	var removeSelParen = false;
	var errMsgText = "";
	var errorCode;

	var endObj;
	var beginObj;
	var exitLoop = false;
	var operPointer;
	
	var slashFound;
	var expnHasFractions;
	var cancelFractions = [];
	var calcAnswerArray; // holds calculated answer when fractions are involved
	var userFractionPrompt = [];
	//bts1230 added new values for exponents
	var exponOper=false;
	var negExpon=false;
	
	if (beginObj == null) beginObj = 0;
	if (endObj == null) endObj = elementArray.length-1;

	// extract the portion of the expression to be solved; mark objects for deletion
	// and replace with new object representing the calculated answer
	// Set begin/end data object pointers referenced operator pointer position
	expnToSolve = "";
	expnToSolve=buildStrPart(beginObj,endObj);
	var expnToSolveArray=buildArray(beginObj,endObj);

	// now work on the portion of the expression that the user selected

	//bts 04032014: ensure that selEq matches expnToSolve, allowing
	//		for parens
	var tempSelExpStr = selEq.join("");
	if (expnToSolve.indexOf(tempSelExpStr)==-1){
		if (tempSelExpStr.charAt(0) == "(" 
			|| tempSelExpStr.charAt(0)== "[") {
			var newSelExpStr = 
				tempSelExpStr.substring(1,tempSelExpStr.length-1);
			if (expnToSolve.indexOf(newSelExpStr)==-1){
				errorCode=13;//Invalid entry
				errMsgText=errorMsg(errorCode,errMsgText,selEq.join(""));				
			}
		} else {		
			errorCode=13;//Invalid entry
			errMsgText=errorMsg(errorCode,errMsgText,selEq.join(""));
		}
	}  	
	// bts 04032014: do paren removal loop only if no prior error
	while (!errMsgText && selEqIndex[0]!=-1) {
//	while (selEqIndex[0]!=-1) {
		selEqIndex[0]=-1;
		selEqIndex = checkParens(selEq);
	// remove parens if necessary from selected expression portion
		if (selEqIndex[0] >=0 && !removeSelParen) {
			selEq = selEq.slice(selEqIndex[0],selEqIndex[1]);
		} else if (selEqIndex[0] >=0 && removeSelParen) {
			selEq.splice(selEqIndex[1],1);
			selEq.splice(selEqIndex[0]-1,1);
		}
	}
	
	// check for abs val markers
	selEqIndex[0] = selEq.indexOf("|");
	if (selEqIndex[0] != -1) { //abs val markers are present
		selEqIndex[1] = selEq.lastIndexOf("|");
		selEq.splice(selEqIndex[1],1); // remove last marker
		selEq.splice(selEqIndex[0],1);// remove first marker
	}

// compare elementArray objects to selEq
	// bts 04032014: make sure we don't set a second error msg
	
//	if (expnToSolve !== selEq.join("")) {
	if (expnToSolve !== selEq.join("") && !errMsgText) {
		errorCode=13;//Invalid entry
		errMsgText=errorMsg(errorCode,errMsgText,selEq.join(""));
	} 
	//jcs1201 changed condition
	if (errMsgText) {
		displayErrMsg(errMsgText);
		//errMsgText="";
		// turn on the prompt to enter part to solve
		//jcs130 document.getElementById("simplifypartform").reset();
		return(errMsgText);
	}
	
	//bts 1229 check for exponentiation operation before calculating answer
	//    if exponent operation, then save expon value for prompt string
	if (elementArray[beginObj+1].string=="^") {
		exponOper = true;
		exponVal = Number(elementArray[endObj].string);
		if (exponVal < 0) {
			exponVal = Math.abs(exponVal);
			// flip numerator/denominator in the prompt
			negExpon = true;
			var holdNum = elementArray[beginObj].numerator;
			elementArray[beginObj].numerator = elementArray[beginObj].denominator;
			elementArray[beginObj].denominator = holdNum;
			elementArray[beginObj].string = 
				String(elementArray[beginObj].numerator)+"/"+
				String(elementArray[beginObj].denominator);
			//set expon val to positive
			elementArray[endObj].numerator=exponVal;
			elementArray[endObj].string=String(exponVal);
		}
	}
	
	// no errors with data entry so continue processing
	// if whole numbers only,use calculateAnswer function to calculate the answer
	// if mixed numbers, use calculateFractionAnswer function
	// test the expression string (expnToSolve) for slashes, indicating fractions
	
	// bts 0626: added 2 vars for formatting fraction prompts
	var fractString;
	var specialText;
	
	slashFound = expnToSolve.indexOf("/");
	// bts1230 fraction test should include negExpon=false
	if (slashFound == -1 && !negExpon) { // expression selection contains only whole numbers	
		calcAnswer=Number(calculateAnswer(expnToSolveArray));
		expnHasFractions=false;
		if (calcAnswer == 0 && elementArray.length > 3) zeroResult = true;
	} else {
		expnHasFractions=true;
		// if this is subtraction operation, then 
		// need to convert fractions to lowest common denominator
		var lcdNeeded = false;
		var addSubOperation;
		// bts 112514: added variable for subtraction to correct
		//		calculations later
		var subtractOper=false;
		if (elementArray[beginObj+1].string=="-" || 
				elementArray[beginObj+1].string == "+") {
			addSubOperation=true;
			if (elementArray[beginObj+1].string=="-") subtractOper=true;
			lcdNeeded = checkLCDenom(beginObj,endObj);
			
			if (lcdNeeded) {
				var callerId="applyLCDSub";
				promptLCD(beginObj,endObj,callerId);
				return;
			}
		}
		
		// check if the fraction(s) can be cancelled/simplified before doing 
		// the multiplication or division operations
		
		// flip the divisor before cancelling if this is for division operations
		// flip the divisor numerator and denominator before doing factor test.
		// Change divide operator to multiply
		if (elementArray[beginObj+1].string=="\u00F7") {
			flipDivisor(beginObj,endObj);
			//jcs062514 TEST
			var tipText= document.getElementById("UserInstructionPrompt");
			tipText.innerHTML="When you divide with fractions, you flip the divisor "+
			"(put the denominator on top and the numerator on the bottom) and multiply. ";

			//jcs040615 play audio for adding fractions
			if (document.getElementById("hiddendivfrac").innerHTML!="alreadyPlayed") {
				document.getElementById("hiddendivfrac").innerHTML="playme";
			}
		}
		
		if (!addSubOperation) {// multiplication/division operations
			// bts1230 skip cancel prompt if exponentiation operation
			if (!exponOper) {
				cancelFractions = checkForFractionCancel(beginObj,endObj);
				if (cancelFractions[0] != 0) {// ask if fraction(s) should be canceled
											  // and exit here
					setCancelPrompt(beginObj,endObj,cancelFractions);
					return;
				}
			}
	
			// calcAnswerArray[0] is calculated numerator; [1] is denominator
			calcAnswerArray = calculateFractionAnswer(expnToSolveArray,beginObj, endObj);
			// set up the prompts for later: numerator1*numerator2; denom1*denom2
			if (exponOper) {
				userFractionPrompt[0]= String(elementArray[beginObj].numerator)+" ^ "+
						String(exponVal).sup();
				userFractionPrompt[1]= String(elementArray[beginObj].denominator)+" ^ "+
						String(exponVal).sup();	
			} else {
				userFractionPrompt[0]=buildFractionPrompts
						(beginObj,endObj);
			}
		} else if (addSubOperation) { //add/subtract operations
			// bts 0626: format user prompt for fractions	
			calcAnswerArray = calculateFractionAnswer(expnToSolveArray,beginObj, endObj);
			// bts 112514: zero in numerator so change blackboard to
			//		reflect that the fraction is 0 not 0/n
			userFractionPrompt[0]=buildFractionPrompts
						(beginObj,endObj);
		}
	}

	// bts1230 write out new expression if exponent is negative
	if (negExpon) {
		writeToTable(" -- Changed exponent to positive and " +
				"base to reciprocal.");
	}

	// bts 112514: prior to calling performSimpleMathPartTwo, 
	//		set calculated answer and calc answer string version
	//		to 0 if numerator=0
	if (expnHasFractions) {
		var num = calcAnswerArray[0];
		var denom;
		if (!addSubOperation) { //multiply/divide/subtract
			denom = calcAnswerArray[1];
			calcAnswer = String(calcAnswerArray[0])+"/"+String(calcAnswerArray[1]);
			// bts 112514: added code for 0 in numerator
			if (num==0){// numerator is 0
				denom=1;
				calcAnswer=String(num);	
			} 
		} else if (addSubOperation) { //add/subtract
			denom = elementArray[beginObj].denominator;
			calcAnswer = String(calcAnswerArray[0])+"/"+String(denom);
			// bts 112514: added code for subtraction and 0 in numerator
			if (!subtractOper && num==0) {
				denom=1;
				calcAnswer=String(num);	
			} else if (subtractOper && elementArray[beginObj].numerator == 0) {
				denom=elementArray[endObj].denominator;
				calcAnswer=String(calcAnswerArray[0])+"/"+String(denom);
			}
		}
		
		performSimpleMathPartTwo(beginObj,endObj,num,denom,calcAnswer,
					expnOperation, expnHasFractions,expnToSolve,
					userFractionPrompt,	calcAnswerArray);
	} else {			
		var num = calcAnswer;
		var denom = 1;
		performSimpleMathPartTwo(beginObj,endObj,num,denom,calcAnswer,
				expnOperation, expnHasFractions,expnToSolve);
	}

	return(errMsgText);
}
	
function performSimpleMathPartTwo(beginObj,endObj,num,denom,calcAnswer,
		expnOperation,expnHasFractions,expnToSolve,
		userFractionPrompt,calcAnswerArray) 
{
	/*
	 * Continuation of performSimpleMath
	 */
	
	var introType;
	// bts 0421: if add/subtract oper and neg number, set
	//	introType to 8 for special tip
	//	do this before updating the structure
	
	/*jcs011615 test to have specific tips on add/subtract neg numbers
	if (expnOperation == "addition" || expnOperation=="subtraction") {
		if (elementArray[beginObj].numerator < 0 || 
				elementArray[endObj].numerator < 0) {
			introType = 8; // show negative msg in setAnswerPrompt
		}			
	}	*/
	
	if (expnOperation == "addition"){
		if (elementArray[beginObj].numerator < 0 && elementArray[endObj].numerator < 0) {
			introType = 12; // adding two negative numbers		
		} else {
			if (elementArray[beginObj].numerator < 0 || elementArray[endObj].numerator < 0) {
				introType = 8; // adding positive and negative numbers
			}
		}
	}
	
	if ((expnOperation=="subtraction")&&(elementArray[beginObj].numerator < 0 && elementArray[endObj].numerator > 0)) {
		introType = 13 // subtracting positive from negative 
	}
	
	//jcs011715 start here need subtract negative from positive nad subtract postive from negative
		
	// highlight portion of expression about to be solved before it is changed
	// start with beginObj location thru endObj location
	var color = "yellow";
	for (j=beginObj;j<endObj+1;j++) {
		writeMultHighlight(j,1,elementArray.length,color);
	}
	
	// bts 1229: check for exponent operator for setting
	// 	prompt text properly
	var exponOper=false;
	if (elementArray[beginObj+1].string=="^") {
		exponOper=true;
		var exponVal=Math.abs(Number(elementArray[endObj].string));
		introType=7; // show exponentiation message in setAnswerPrompt
	}
	
	// replace beginObj values with new values
	elementArray[beginObj].numerator = num;
	elementArray[beginObj].denominator = denom;
	elementArray[beginObj].string = String(calcAnswer);
	//bts1211 if fraction and calc denom=1, set string to whole number
	if (expnHasFractions && denom==1){
		elementArray[beginObj].string = String(num);
	}
		
	// remove oper and endObj 
	var strikeLen=endObj-beginObj;
	elementArray.splice(beginObj+1,strikeLen);
	
	//remove parentheses surrounding a single term
	removeParensInStructure();
	
	/*
	 * call setAnswerPrompt function, followed by getUserAnswer
	 * function to retrieve user's answer and make necessary updates
	 */
	var matchPositions = [];
	var userPrompt;
	var preprompttext;
	var onePrompt;
	var callerId;
	var multiplier;
	
	matchPositions[0] = beginObj;
	matchPositions[1] = endObj;	
	preprompttext="How much is: ";
	callerId = "simplifynumeric";
		
	if (!expnHasFractions) { // expression is only whole numbers
		if (!exponOper) {//no exponent so leave prompt in normal font
			userPrompt=expnToSolve;
		} else { // make exponent value superscript
			var expPtr = expnToSolve.indexOf("^");
			userPrompt = expnToSolve.slice(0,expPtr+1)+
				expnToSolve.slice(expPtr+1).sup();
		}
			
		onePrompt = true;
		multiplier = 1;
		// bts1220 pass in exponVal as last parameter
		setAnswerPrompt(preprompttext,userPrompt,multiplier, 
				calcAnswer,matchPositions,1,onePrompt,callerId,expnOperation,
				introType,exponVal);
	} else if(expnHasFractions){
		// set up prompts for fraction multiplication/division
		onePrompt = false;
		multiplier = "";
		switch (expnOperation) {
		case "addition":
			introType=5;
			break;
		case "subtraction":
			introType=4;
			break;
		case "exponentiation":
			introType=7;
			break;
		default:
			introType=3;
			if (exponOper) introType=7;
			break;
		}
		//bts120214: if fractions and exponentiation, prompt for 
		//	numerator and denominator calcs on separate lines
		if (expnHasFractions && expnOperation=="exponentiation") {
			setAnswerPrompt(preprompttext,userFractionPrompt,multiplier, 
				calcAnswerArray,matchPositions,1,onePrompt,callerId,
				expnOperation,introType, exponVal);
		} else {
			setAnswerPrompt(preprompttext,userFractionPrompt,multiplier, 
				calcAnswer,matchPositions,1,onePrompt,callerId,
				expnOperation,introType, exponVal);
		}
	}	
	return;
}

function checkOperators(beginPoint, endPoint)
{
	var i=0;
	var j=0;
	var newExpnArray;
	var foundOperator = false;
	var operatorLevel=0;
	var operObjPtr=-1;
	
	var findOper = (function() { 
	return function(findOper){
		var k=beginPoint;
		while (k<endPoint){
			if (elementArray[k].elemtype == "oper") {
			switch (operatorLevel)
			{
			case operatorLevel=0:
				if (elementArray[k].string == "^") {
					foundOperator=true;
					operObjPtr = k;
				}
				break;
			case operatorLevel=1:
				// check if slash causes problems
				if (elementArray[k].string == "*" || elementArray[k].string == "\u00F7"
						|| elementArray[k].string == "/") {
					foundOperator=true;
					operObjPtr = k;
				}
				break;
			case operatorLevel=2:
				if (elementArray[k].string == "+" || elementArray[k].string == "-") {
					foundOperator=true;
					operObjPtr = k;
				}
				break;
			} //end of switch
			if (foundOperator) k=endPoint;
			} //end of element is an oper if block
			k++;
		} // end of while loop
		return;	
	};
}()); // end of findOper function  
	
	//check for operator precedence, from left to right
	while (!foundOperator && operatorLevel<3) {
		findOper();
		operatorLevel++;
	}
	return(operObjPtr);
}

function writeToTable(textToDisplay,structToDisplay)
{
	var i;
	var rowIdVal;
	var cellnode; 
	var textincell;
	var trElement;
	var tableElement, tableElementStart;
	var list;
	var signPtr;
	var tempString;
	var specialText;
	var usingDisplayStruct = false;
	var holdStructure;
	var exponOperFlag;
	
	// test if new structure passed in
	if (structToDisplay) {
		holdStructure = elementArray;
		elementArray = structToDisplay;
		usingDisplayStruct = true;
	}
	
	// write text to a table. Create new table for each row of data
	// add a new row
	i=0;
	var rownode=document.createElement("tr");
	tableElementStart=document.getElementById("expnTable");
	tableElement=document.createElement("table");
	tableElementStart.appendChild(tableElement);
	tableElement.appendChild(rownode);

	while (i < elementArray.length+1) {
		cellnode=document.createElement("td");
		
		// extract string from each element in array
		if (i == elementArray.length) {
			// bts 0417: change -- of annotation to mdash
			var mdashPtr = textToDisplay.indexOf("--");
			if (mdashPtr > -1) {
				textToDisplay="	&mdash; "+ textToDisplay.substring(mdashPtr+2);
			} else {
				textToDisplay="	&mdash; "+ textToDisplay;
			}
			cellnode.style.whiteSpace="nowrap";
			textincell=document.createTextNode(textToDisplay);
			specialText = textToDisplay;
			//jcs011817 need to get rid of bradley font
			//cellnode.style.cssText="font-weight: bold;font-family: Bradley Hand ITC";
			cellnode.style.cssText="font-weight: bold;font-family: arial";
		} else {
			//if fraction, make numerator superscript, denom a subscript
			//exponents superscripts, asterisks subscripts
			// skip if element is a grouper
			if (elementArray[i].elemtype == "oper" || 
					elementArray[i].elemtype == "term") {
				//bts 010514: added ptr into elementArray for 
				//	specialeffects function
				//bts 02142014: special condition for eval expressions
				//	when slash (/) is an operator do not format it
				if ((selExpType == 22 || selExpType == 23) && 
						(elementArray[i].elemtype == "oper") && 
						(elementArray[i].string == "/")) {
					specialText = elementArray[i].string;
				//bts 032115: if equation or alg expn and rational expn, 
				//	don't format the numerator/denom
				} else if ((equationFlag || selExpType==20) &&
		 	 			 document.getElementById
		 	 			 	("hiddeneqfractionexpn").innerHTML=="equation") {
					specialText = elementArray[i].string;
				} else {
					specialText = setSpecialTextEffects(elementArray[i].string,i);
				}
				// bts 1227; if exponent sign is oper then set flag to display
				// 	subsequent term as superscript
				if (exponOperFlag) {
					exponOperFlag=false;
					specialText = specialText.sup();
				}
				if (elementArray[i].elemtype == "oper" && 
						elementArray[i].string == "^") {
					exponOperFlag=true;
				}
				
			} else {
				specialText=elementArray[i].string;
			}
			textincell=document.createTextNode(elementArray[i].string);
			// for negative numbers (signPtr==0) make entire term red
			if (elementArray[i].elemtype == "term") {
				tempString = String(elementArray[i].string);
				signPtr = tempString.indexOf("-");
				if (signPtr == 0) {
					specialText=specialText.fontcolor("red").bold();
				}
			}
			/*
			 * bts 0417: added divide sign
			 *  make divide sign red, bold
			 */
			if (elementArray[i].elemtype == "oper" && 
					elementArray[i].string == "\u00F7") {
					specialText = specialText.fontcolor("red").bold();			
			}
		}
		//bts 021715: underline equation/inequality line when solved
		//bts 030415: underline other solutions: extraneous solution,
		//		equation is true, final result for inequalities
		//bts 08252015: pick up last answer that is possible solution
		if (equationFlag) {
			if (textToDisplay.indexOf("Solved")>-1 ||
					textToDisplay.indexOf("Extraneous")>-1 ||
					textToDisplay.indexOf("is true")>-1 ||
					textToDisplay.indexOf("Final result")>-1 ||
					textToDisplay.indexOf("Possible solution")>-1) {
				cellnode.style.borderBottom = "thick solid #FFB84D";
			}
		}
		cellnode.appendChild(textincell);
		cellnode.innerHTML=specialText;
		rownode.appendChild(cellnode);

		i++;
	}
	
	//bts 07292015: write expression line to sessionStorage
	// bts 08092015: make text bold
	writeToStorage(buildStrPart(0,elementArray.length-1)+
			" "+textToDisplay.bold());

	if (usingDisplayStruct) elementArray=holdStructure;
	
	//jcs011215 scroll automatically
	var blackboard = document.getElementById('mainblackboard');
	blackboard.scrollTop = blackboard.scrollHeight;

	//bts 022515: call function to determine next audio tip for simplenumeric
	//jcs033015 leave out for now --  
	//if (selExpType==10 && !equationFlag) findAudio("pemdas");
	return;
}

function setSpecialTextEffects (textparameter,ptr, callingFunc)
{
	/*
	 * bts 04132014: added additional parameter indicating
	 * 		calling function so that carat is set to green or orange
	 * 		color depending on whether it displays on board or prompt
	 * 
	 * bts010514: revised version
	 * 
	 * textparameter:  term/oper string
	 * ptr:	element pointer to term/oper in structure
	 * 
	 * function sets up special display effects for certain types of
	 * text:
	 * 	fraction numerators: superscript
	 *  fraction denominators: subscripts
	 *  exponents: superscript
	 *  asterisks (for multiply): subscript
	 *  
	 */
	
	var text, formatText;
	var slashPtr, exponPtr, astPtr, signPtr;
	var numStr, denomStr, exponStr;
	var j,x, exponEnd,denomEnd;
	
	text=String(textparameter);
	
	slashPtr = text.indexOf("/");
	exponPtr = text.indexOf("^");
	astPtr = text.indexOf("*");
	signPtr = text.indexOf("-");

	formatText="";
	
	if (slashPtr > -1) { // text contains fractions
		numStr = String(elementArray[ptr].numerator);		
		formatText = formatText.concat(numStr.sup(),"/");
		
		denomEnd=text.length;
		for (j=slashPtr+1;j<denomEnd;j++) {
			x=text.charAt(j);
			// test for exponent mark rather than NaN condition
			if (x=="^") denomEnd=j;
			if (isNaN(x)) denomEnd=j;
		}
		denomStr = String(elementArray[ptr].denominator);
		slashPtr = denomStr.indexOf("-");
		if (slashPtr==0) {
			denomStr=denomStr.fontcolor("red");
		}
		formatText=formatText.concat(denomStr.sub());
		
		// check for variables
		var varCtr=0;
		var exponVal;
		while (denomStr && varCtr<4) {
			switch (varCtr) {
			case 0:
				// bts 010814: add space before first variable in denom
				//	if variable is not null
				if (elementArray[ptr].variable) {
					denomStr=" "+elementArray[ptr].variable;
				} else {
					denomStr=elementArray[ptr].variable;
				}
				exponVal= elementArray[ptr].exponent;
				break;
			case 1:
				denomStr=elementArray[ptr].variable2;
				exponVal= elementArray[ptr].exponent2;
				break;
			case 2:
				denomStr=elementArray[ptr].variable3;
				exponVal= elementArray[ptr].exponent3;
				break;
			case 3:
				denomStr=elementArray[ptr].variable4;
				exponVal= elementArray[ptr].exponent4;
				break;
			default:
				break;
			}
			if (denomStr) {
				formatText=formatText.concat(denomStr);

				//if (elementArray[ptr].exponent!=1) {
				if (exponVal !=1) {
					//denomStr = "^"+String(elementArray[ptr].exponent);
					denomStr = "^"+String(exponVal);
					//if (elementArray[ptr].exponent<1){
					if (exponVal<1){
						denomStr=denomStr.fontcolor("red");
					}
					formatText=formatText.concat(denomStr.sup());
				}
			}
			varCtr++;
		}
	}

	//bts1222 neg exponents test
	//bts 010614: exponents in alg fractions handled above;
	//	test for formatText already containing text
	if (exponPtr > -1) {
		var negExpon=false;
		if (!formatText) {
			formatText = text.slice(0,exponPtr);
			exponEnd = text.length;

			while (exponPtr > -1) {
				//formatText = text.slice(0,exponPtr);
				//exponEnd = text.length;
				for (j=exponPtr+1;j<exponEnd;j++) {
					x=text.charAt(j);
					if (j==exponPtr+1 && x=="-") {//neg exponent value so allow it
						// keep looking for exponent end location
						negExpon=true;
					} else if (isNaN(x)) {
						exponEnd = j;
					}
				}
				//exponStr = text.slice(exponPtr,exponEnd);
				
				//bts 04132014: make expon carat green if writing to board
				//		or make it orange if for prompting
				//  set color for font based on callingFunc value
				var hideColor = "lightgreen";
				if (callingFunc) hideColor="#FFB84D";
				
				// added .fontcolor green/orange to lines below that extract carat				
				if (negExpon) {
					exponStr = text.slice(exponPtr,exponPtr+1).fontcolor(hideColor);
					exponStr=exponStr+text.slice(exponPtr+1,exponEnd).fontcolor("red");
					//exponStr=exponStr+text.slice(exponPtr+2,exponEnd);
					negExpon=false;
				} else {
					// bts 04132014: set carat color
					exponStr = text.slice(exponPtr,exponPtr+1).fontcolor(hideColor);					
					exponStr = exponStr+text.slice(exponPtr+1,exponEnd);
				}
				// bts 04132014: carat is not a superscript
				//	if it is an operator (exponEnd == 1)
				if (exponEnd > 1){
					formatText=formatText.concat(exponStr.sup());
				} else {
					formatText=formatText.concat(exponStr);
				}
				
				// test for additional exponents
				// format/add any additional exponents to string
				// make sure any last variables after exponents are added; these
				// are variables without exponents
				if (exponEnd >= text.length) { // add any last characters/variables
					formatText=formatText.concat(text.slice(exponEnd));
					exponPtr=-1;
				} else {
					exponPtr = text.indexOf("^",exponEnd);
					if (exponPtr == -1) {
						formatText=formatText.concat(text.slice(exponEnd));
					} else {
						formatText=formatText.concat(text.slice(exponEnd,exponPtr));
						exponEnd=text.length;
					}
				}		
			}
		} 
	}
	
	if (astPtr>-1) {
		formatText = text.slice(0,astPtr);
		formatText = formatText.concat("*".sub());
	}	
		
	if (formatText=="") formatText = text;
		
	return(formatText);
}

function setSpecialTextExponInFract(formatText)
{
	/*
	 * Sets special effects when there the exponent value is
	 * a fraction
	 * 
	 * Need to rewrite this to handle exponent values that are fractions
	 * Currently, written to handle exponents in terms that are themselves
	 * fractions
	 */
	
	var exponPtr, exponEnd,j,x;
	var negExpon;
	var formatText, negPos;
	
	exponPtr = formatText.indexOf("^");
	exponEnd = formatText.indexOf("<", exponPtr);
	while (exponPtr > -1) {
		for (j=exponPtr+1;j<exponEnd;j++) {
			x=formatText.charAt(j);
			if (j==exponPtr+1 && x=="-") {//neg exponent value so allow it
				// keep looking for exponent end location
				negExpon=true;
				negPos=j;
			} else if (isNaN(x)) {
				exponEnd = j;
			}
		}
		if (negExpon) {
			formatText[negPos,exponEnd].fontcolor("red");
			negExpon=false;
		}			

		formatText[exponPtr-1,exponEnd].sup();
		exponPtr = formatText.indexOf("^",exponEnd);
	}
	
	return(formatText);
}

function getSimplifyOp()
//jcs9+ Hide preliminary docs, display highlight command, and wait for highlighting
{
	//bts 10182015: save current structure to prevStepsArray
	setUpEquationStruct();

	var errMsgText=" ";
	
	var simplifyOpList=document.getElementById("simplifyMenu");
	opType=simplifyOpList.options[simplifyOpList.selectedIndex].value; 	
	var newString="";
	var windowContent;
	
	document.getElementById("combineliketermsform").style.display="none";
	clearAnswerFormTable();
	document.getElementById("getanswerform").style.display="none";

	var errorToDisplay=document.getElementById("warningMessage");
	errorToDisplay.innerHTML = ""; 
	displayTip("erase");
	document.getElementById("operationMenuArea").style.display="none";

	//bts 10282015: enable the Go Back button
	document.getElementById("gobackbutton").disabled=false;

	switch (opType)
	{
	case "100":
		//need an error message here
		break;
		
	case "101": //Multiply
		//jcs1120 if user has already highlighted expression then just multiply
      windowContent = window.getSelection();
	    newString = String(windowContent);
	    newString = newString.replace(/\s/g,"");
		// bts 0929: check for multiply symbol at start of processing
	    if (newString == "") {
	    	var entireString = buildStrPart(0,elementArray.length-1);
	    	var astPtr = entireString.indexOf("*");
	    	if (astPtr == -1) {
	    		var errCode = 41;
	    		errMsgText = errorMsg(errCode,errMsgText);
				displayErrMsg(errMsgText);
				errMsgText="";
				document.getElementById("operationMenuArea").style.display="";
				document.getElementById("simplifyMenu").selectedIndex=0;
				document.getElementById("simplifyMenu").style.display="";
	    	} else {
				 //jcs111314  test document.getElementById("operationMenuArea").style.display="none";			
				document.getElementById("generalHighlight").style.display=""; //jcs090914 test
				//jcs092015 test
				document.getElementById("mobileEntryField").focus();
	    	}
		}  
	    if (newString !== "") {
			errMsgText=simplifyAlgExpPart(newString);
			if (errMsgText) {
				displayErrMsg(errMsgText);
				errMsgText="";
				document.getElementById("operationMenuArea").style.display="";
				//bts 091514: reset simplifymenu option to the default
				document.getElementById("simplifyMenu").selectedIndex=0;
				document.getElementById("simplifyMenu").style.display="";			}
			else {
				//jcs111314  test document.getElementById("operationMenuArea").style.display="none";			
				document.getElementById("generalHighlight").style.display=""; //jcs090914 test
			}
	    }

		break;
		
	case "102": //Combine like terms
		var plusMinusCtr=0;
		for (var i=0;i<elementArray.length-1;i++) {
			if (elementArray[i].elemtype == "oper") {
				if (elementArray[i].string == "+" || 
						elementArray[i].string == "-") {
					plusMinusCtr++;
				} 
			}	
		}
		if (plusMinusCtr == 0) {
			// no combine operations
			var errorCode=42;
			var errMsgText = errorMsg(errorCode,errMsgText);
			displayErrMsg(errMsgText);
			errMsgText="";
			document.getElementById("operationMenuArea").style.display="";
			document.getElementById("simplifyMenu").selectedIndex=0;
			document.getElementById("simplifyMenu").style.display="";
		} else {// there are plus/minus sign(s) so continue
			displayTip("liketerms");
	
			//jcs1120 if user has already highlighted expression then just combine the like terms
	        windowContent = window.getSelection();
		    newString = String(windowContent);
		    newString = newString.replace(/\s/g,""); 
			document.getElementById("combineliketermsform").reset();
			document.getElementById("combineliketermsform").style.display="";
			//jcs021715 put focus on input field
			document.getElementById("liketerm").style.display="";
					
			// bts 090814: no need to highlight expression for like term
			//document.getElementById("likeTermHighlight").style.display="";
		
			// bts 090814: set newString to entire expression and continue
			//  remainder of combining terms should work with no other changes
			newString=buildStrPart(0,elementArray.length-1);
			if (newString ) {
				var holdExpression = document.getElementById("hiddenliketermexpn");
				holdExpression.innerHTML = newString;
				//jcs1208 hide hidden variable for expression selection
				holdExpression.style.display="none";
				//document.getElementById("likeTermHighlight").style.display="none";
				// bts 090814: put focus on liketerm input field
				//jcs013116 test
				//document.getElementById("liketerm").focus();
			}	else {
				//jcs1208 hide go button
				document.getElementById("liketermbutton").style.display="none";
				//jcs013116 test
				//document.getElementById("liketerm").focus();
			}	
		}
		break;
	
	case "103": //Combine constants
      windowContent = window.getSelection();
	    newString = String(windowContent);
	    newString = newString.replace(/\s/g,"");
	    // bts 090814: remove highlighting for combining constants
		// bts 090814: set newString to entire expression and continue
		//  remainder of combining constants should work with no other changes
		newString=buildStrPart(0,elementArray.length-1);	    	    
		if (newString == "") {
			document.getElementById("whatToDoNextArea").style.display="";
			document.getElementById("userInstructions").style.display="";   //jcs130 test
			//jcs119 test
			//jcs111314  test document.getElementById("operationMenuArea").style.display="none";	
		}
		else {
			errMsgText=combineConstants(newString);
			if (errMsgText) {
				document.getElementById("simplifyMenu").style.display="";
				if (window.getSelection) window.getSelection().removeAllRanges();
			}
		}
		break;	
		
	case "104": //jcs119 Simplify powers
		
		break;
	}
 	return;
}

function resetAfterSolved () {
	hideDoAnotherButtons();	
	//jcs116 test document.getElementById("problemEntryArea").reset();
  document.getElementById("workarea").style.display="none";
  var newMsg = document.getElementById("statusmsg");
  newMsg.innerHTML="Solved! Waiting for next exercise.";
  //jcs111 test
  document.getElementById("userio").style.display="none";
  document.getElementById("problemEntryArea").style.display="none"; 
  document.getElementById("problementryfield").value="";
	elementArray.splice(0);
	//jcs119
	//jcs012715 test document.getElementById("newproblembutton").style.display="";
	
	//bts 120514: disable Go Back button
	document.getElementById("gobackbutton").disabled=true;
	
	//bts 008092015: turn on submit hw button
	//	insert spacer
	//bts 09162015: stop timer and display elapsed "solve" time
	//bts 01202016: do not write elapsed time to hw log file if val=0
	//		(should fix problem with writing time twice to log file)
	var elapsedTime=document.getElementById("problemTimer").value;
	stopCount();
	document.getElementById("problemTimer").value=0;
	if (elapsedTime>0) {//save to log file if time has elapsed
		var mins=elapsedTime/60;
		var strMins=mins.toFixed(0);
		var secs=elapsedTime % 60;
		var formatElapsedTime=strMins+":"+String(secs);
		//document.getElementById("problemTime").innerHTML=formatElapsedTime;
		writeToStorage(" ------------ "+"Mins/secs to solve problem: "+
				formatElapsedTime+" -----------");
	}
	document.getElementById("displayhw").style.display="";
}

function holdLikeTerm() {
	
	var errMsgText;
	var holdExpression = document.getElementById("hiddenliketermexpn");
	var expn = holdExpression.innerHTML;
	// bts 01282016: added termVar, vars to hold radio button check status
	var termButton,numButton;
	var termVar; //set to null or blank if combining constants or to term to combine
	document.getElementById("liketermbutton").style.display="";	
	
	//jcs1208 blank out error message
	var errorToDisplay=document.getElementById("warningMessage");
	errorToDisplay.innerHTML = "";
	// bts 02012016: check radio button selected (constant,var term)
	//		Display err msg if no var, no button selected; use
	//		combineterm for locale indicator
	if (document.getElementById("numradio").checked==true) {
		termVar="";//combine constant selected
		numButton=true;
	} else if (document.getElementById("varradio").checked==true) {
		//term with var: check for variable 
		 termVar=document.getElementById("liketerm").value;
		 termButton=true;
		 if (!termVar || termVar==" ") {
			 errorToDisplay.innerHTML=errorMsg
			 	(15,errorToDisplay.innerHTML);//choose option msg
			 displayErrMsg(errorToDisplay.innerHTML,"combineterm");
			 return;
		 }
	} else {
		//no button selected; display warning and go back to form
		errorToDisplay.innerHTML=errorMsg(58,errorToDisplay.innerHTML);//enter a term msg
		displayErrMsg(errorToDisplay.innerHTML,"combineterm");
		return;
	}
	//clear checked fields for radio buttons
	document.getElementById("numradio").checked=false;
	document.getElementById("varradio").checked=false;
	// bts 01282016: added termVar to function call
	errMsgText = getTermToCombine(expn,termVar);
	// bts 091514: errMsgText=combineconstants not error
	if (errMsgText == "combineconstants") {
		errMsgText="";
		if (!equationFlag) {
			errMsgText=combineConstants(expn);
		} else {
			errMsgText=eqCombineConstants(expn);
		}
	}
	if (errMsgText) {
		//bts 02012016: add error locale; remove tip,menu displays
		displayErrMsg(errMsgText,"combineterm");
		errMsgText="";
		// bts 02032016: reset selected radio button
		if (termButton) 
			document.getElementById("varradio").checked=true;
 		if (numButton)
			document.getElementById("numradio").checked=true;
	} else {
		holdExpression.innerHTML="";
	}
	return;
}

function simplifyAlgExpPart(selExpn){
	var j=0;
	var endObj=elementArray.length-1;
	var beginObj=0;
	var removeParen = false;
	var exitLoop = false;
	var startPos, endPos;
	var leftgrpPtr = 0;
	var rightgrpPtr = 0;
	var multiplier, multiplierPosition;
	var multiplierAtStart, multiplierFound;
	var answer=[];
	var expnToSolve;
	var objPosArray;
	var userAns = [];
	var ansCtr;
	var userPrompt = [];
	var selExpnString;
	var bracketRemoved = false;
	var leftGrp = [];
	var rightGrp = [];
	var grpCtr = 0;
	var errorCode;
	var errMsgText="";
	
	// get the lower/upper bounds of the elementArray
	// brackets must be present; get pointers to left/right brackets objects
	// otherwise, if no brackets then return
	// allow for multiplier to be within brackets as well as multiplicand
	
	// bts 04142014: allow only 1 asterisk oper in selected expn
	
	//bts 1031: Modified to reset properly when
	//		multiplying equation terms
	// build string version of expression to compare with user-entered string
	expnToSolve=buildStrPart(0,elementArray.length-1);
	expnToSolve=expnToSolve.toLowerCase();
	//jcs9 removed join from following function
	selExpnString = selExpn;
	selExpnString=selExpnString.toLowerCase();
	
	// bts 04142014: allow only 1 asterisk oper in selected expn
	var astPtr = selExpnString.indexOf("*");
	if (astPtr == -1) { // no asterisk operation; error
		errorCode=39; // Incorrect selection selExpnString
		errMsgText=errorMsg(errorCode,errMsgText,selExpnString);
		return(errMsgText);	
	} else if (astPtr >-1) { // check for 2nd asterisk
		astPtr = selExpnString.indexOf("*",astPtr+1);
		if (astPtr != -1) {
			errorCode=40; // Incorrect selection selExpnString
			errMsgText=errorMsg(errorCode,errMsgText,selExpnString);
			return(errMsgText);	
		}
	}
	
	// find matching part of expression
	// idxStart is starting point in elementArray
	// idxEnd is ending point in elementArray
	// idxLength is length of portion of elementArray to use
	var idxStart=expnToSolve.indexOf(selExpnString);
	var arrayString = "";
	var newIdx;
	if (idxStart < 0) {
		//if (expnToSolve !== selExpnString) {
		errorCode=13; // Incorrect selection selExpnString
		errMsgText=errorMsg(errorCode,errMsgText,selExpnString);
		return(errMsgText);
	} else if (idxStart >-1) {
		// set default start/end index points into elementArray
		var idxArray = [];
		idxArray = findArrayIndex(idxStart,selExpnString);
		// bts 03192014: finArrayIndex returns -1 if no match
		if (idxArray[0]==-1) { // match not found
			errorCode=13; // Incorrect selection selExpnString
			errMsgText=errorMsg(errorCode,errMsgText,selExpnString);
			return(errMsgText);	
		}
	}
	idxStart = idxArray[0];
	idxEnd = idxArray[1];
	var idxLength = idxEnd-idxStart;
	
	// if called by function to combine constants, then pass back
	// the idxStart and idxEnd points, plus error message (if any)
	
	// check whether there are 2 sets of numbers within parens
	// there may be a single term surrounded by brackets; if so, remove brackets
	
	//for (j=0;j<elementArray.length;j++){
	for (j=idxStart;j<idxEnd+1;j++) {
		//remove brackets surrounding single term
		//otherwise, check that there are no more than 2 sets of brackets
		//store locations of start/end bracket positions
		if (elementArray[j].elemtype == "leftgrp") {
			leftGrp[grpCtr] = j;
		}
		if (elementArray[j].elemtype == "rightgrp") {
			rightGrp[grpCtr]=j;
			if (rightGrp[grpCtr]-leftGrp[grpCtr]==2){ 
				//parens surround a single term so remove these grouper objects
				elementArray.splice(rightGrp[grpCtr],1);
				elementArray.splice(leftGrp[grpCtr],1);
				bracketRemoved = true;
				j=j-2;
				//grpCtr--;
			} else grpCtr++;
		}	
	}
	if (grpCtr > 2) {
		errorCode = 16;//too many bracketed groupings
		errMsgText=errorMsg(errorCode,errMsgText,grpCtr);
		//alert ("Too many bracket groupings entered: "+grpCtr);
	}
	// if grpCtr=0 then multiplying expression contained within 1 set of brackets
	// if grpCtr=1 then expression is a binomial
	// if grpCtr=2 expression is a polynomial
	if (grpCtr==0) {
		if (idxLength > 2) {
			errorCode = 28;
			errMsgText=errorMsg(errorCode,errMsgText);
		} else if (idxLength < 2) {
			errorCode = 24;
			errMsgText=errorMsg(errorCode,errMsgText);
		} 
		//jcs1201 changed test
		if (!errMsgText) 
			errMsgText=solveSimpleMult(idxStart,idxEnd,errMsgText);
	} else if (grpCtr==2) {
		//solvePolynomial(selExpnString, leftGrp,rightGrp,idxStart,idxEnd);
		// bts 04142014: set idxEnd to rightmost right grouper
		idxEnd = rightGrp[1];
		solvePolynomial(leftGrp,rightGrp,idxStart,idxEnd);
	} else if (grpCtr==1) {
		//solve binomial expression
		errMsgText = solveBinomial(leftGrp, rightGrp,idxStart,idxEnd,grpCtr,errMsgText);
	}
	//jcs1208 remove highlight if no longer needed
	if (!errMsgText) window.getSelection().removeAllRanges();
	return(errMsgText);
}

function solveBinomial(leftGrp,rightGrp,idxStart,idxEnd, grpCtr,errMsgText)
{
	/* selExpn should include parens + multiplier
	 multiplier may be a constant, variable, or constant+variable combo
	 multiplier may be before or after the binomial portion, which is enclosed
	 in parens. 
	 Form of the binomial is: (bx+c) or (c+bx) or (x+y)--1 or 2 variables are
	 valid.
	 */
	var j=0;
	var endObj=elementArray.length-1;
	var beginObj=0;
	var startPos, endPos;
	var leftgrpPtr = 0;
	var rightgrpPtr = 0;
	var multiplier, multiplierPosition;
	var multiplierAtStart, multiplierFound;
	var bracketRemoved = false;
	var errMsgText="";
	var errorCode=0; // errorCode=17: only one operand
				   // errorCode=18: missing multiplier	

	// binomial expression
	beginObj = leftGrp[grpCtr-1]+1;
	endObj = rightGrp[grpCtr-1]-1;
	leftgrpPtr = leftGrp[grpCtr-1];
	rightgrpPtr = rightGrp[grpCtr-1];
	
	startPos = idxStart;
	endPos = idxEnd;

	if (beginObj == endObj) {
		//alert("Expression must have minimum of two operands.");
		errorCode = 17;
		errMsgText=errorMsg(errorCode,errorMsgText);
		return(errMsgText);
	}
		
	// find multiplier position in elementArray using left/right grp ptrs
	// as starting points. 
	// if beginObj >=3, search for multiplier at start.
	// if multiplier found, set location of multiplier flag (start or end) 
	// if not found, search from endObj thru end of elementArray selection

	var searchFromStart = true;
	// search beginning of array for multiplier
	j=leftgrpPtr;
	multiplierFound = false;
	multiplier="";
	while (!multiplierFound) {
		if (searchFromStart) {
			j--;
			if (j<0 || j<startPos) searchFromStart = false;
		} 
		if (!searchFromStart) {
			if (j<leftgrpPtr) {
				j = rightgrpPtr;	
			}
			j++;
			//bts 02252014: set condition to exit loop if selection is incorrect
			if (j>elementArray.length-1) multiplierFound=true;
		}
		
		if (!multiplierFound) {
			if (elementArray[j].elemtype == "oper" 
				&& elementArray[j].string == "*") {
				if (searchFromStart && elementArray[j-1].elemtype == "term") {
					multiplier = elementArray[j-1].string;
					multiplierPosition=j-1;
					multiplierFound=true;					
					multiplierAtStart=true;
				}
				if (!searchFromStart && elementArray[j+1].elemtype == "term") {
					multiplier = elementArray[j+1].string;
					multiplierPosition=j+1;
					multiplierFound=true;					
					multiplierAtStart=false;					
				}
			}
			if (multiplierAtStart) {
				startPos = multiplierPosition;
				endPos = rightgrpPtr;
			} else { // multiplier at end
				startPos = leftgrpPtr;
				endPos = multiplierPosition;
			}
		}
		// exit while loop regardless if multiplier found
		if (!multiplierFound) {
			if (j<0 || j > elementArray.length-1) multiplierFound=true;
		}
	}
	
	if (multiplier == null || multiplier=="") {
		//alert("Error: missing multiplier. Try again");
		errorCode = 18; // missing multiplier
		errMsgText=errorMsg(errorCode,errMsgText);
		return(errMsgText);
	}
	
	// highlight multiplier in original expression
	var color = "yellow";
	var multPosForHighLight=multiplierPosition;
	if (bracketRemoved) multPosForHighLight--;
	writeMultHighlight(multPosForHighLight,1,elementArray.length,color);
	
	// test for adding associative set of parens to expression
	// add parentheses if there are additional multiplications
	// processing resumes with solveBinomial2
	var addParensFlag = false;

	// in case first left grouper is position 0, leave it at 0 or
	// do the adjustment to leftGrpFirstPos; same for last rightGrp position
	// use start/end positions of selected portion of structure
	//var leftGrpFirstPos = leftgrpPtr-1;
	var leftGrpFirstPos = startPos-1;
	if (leftGrpFirstPos <0) leftGrpFirstPos = 0;
	//var rightGrpLastPos = rightgrpPtr+1;
	var rightGrpLastPos = endPos+1;
	if (rightGrpLastPos > elementArray.length-1) rightGrpLastPos--;
	if (elementArray[leftGrpFirstPos].string == "*" ||
			elementArray[rightGrpLastPos].string == "*") {
		addParensFlag = true;
		var parenArray = []; // holds new paren positions for highlighting
		var holdArray;
		// insert parens block
		holdArray = elementArray.slice(0,startPos);
		holdArray = holdArray.concat(elementArray.slice(leftgrpPtr,leftgrpPtr+1));
		parenArray[0] = holdArray.length-1;
		if (rightGrpLastPos == elementArray.length-1) {// last position is end of array
			holdArray = holdArray.concat(elementArray.slice(startPos));
		} else {
			holdArray = holdArray.concat(elementArray.slice(startPos,rightGrpLastPos));
		}
		holdArray=holdArray.concat(elementArray.slice(rightgrpPtr,rightgrpPtr+1));
		parenArray[1] = holdArray.length-1;
		if (rightGrpLastPos < elementArray.length-1) {
			holdArray=holdArray.concat(elementArray.slice(rightGrpLastPos));	
		}

		elementArray = holdArray;
		//display new array struct
		writeToTable(" -- Applied associative property of multiplication");	
		// highlight new parens
		var color="orange";
		for (j=0;j<2;j++) {
			writeMultHighlight(parenArray[j], 1, elementArray.length,color);
		}
		
		// adjust saved values for new right paren position/multiplier positions
		beginObj++;
		endObj++;
		multiplierPosition++;
	}
	
	if (addParensFlag) {
		// save values to html page for later use
		var saveArray = [];
		saveArray[0]=multiplier;
		saveArray[1]=multiplierPosition;
		saveArray[2]=beginObj;
		saveArray[3]=endObj;
		if (!multiplierAtStart) {
			saveArray[4]=0;
		} else {
			saveArray[4]=1; // multiplierAtStart is true
		}
		
		var hiddenObjPosArray = document.getElementById("hiddenobjpostext");
		hiddenObjPosArray.innerHTML= saveArray;
		// bts 04142014 change to associate1 from associate2; use displayTip
		//document.getElementById("associate1").style.display="";
		displayTip("associate1");
		// bts 0414: go automatically to binomial1 because got it button is gone
		solveBinomial1(multiplier,multiplierAtStart,multiplierPosition,beginObj,endObj);
	} else { // go to next part automatically			
		// branch to binomial1 for rest of processing
		solveBinomial1(multiplier,multiplierAtStart,multiplierPosition,beginObj,endObj);
	}
	return(errMsgText);
}
	
function solveBinomial1(multiplier,multiplierAtStart,multiplierPosition,beginObj,endObj)
{
	var j;
	var color;
	var multiplier, multiplierPosition;
	var multiplierAtStart;
	var answer=[];
	var objPosArray;
	var userAns = [];
	var ansCtr;
	var userPrompt = [];
	var errMsgText="";
	var errorCode=0; // errorCode=17: only one operand
				   // errorCode=18: missing multiplier	
	
	// if parameters are null, then main window called this function so 
	// retrieve values from html page
	if (!multiplier) {
		var hiddenObjPosArray = document.getElementById("hiddenobjpostext");
		var idxArray = [];
		var hiddenVals;
		// bts 0414: do we need this? hide button that got us here
		//document.getElementById("associate1").style.display="none";
		hiddenVals=hiddenObjPosArray.innerHTML;	
		idxArray = hiddenVals.split(",");

		multiplier=idxArray[0];
		multiplierPosition=Number(idxArray[1]);
		beginObj=Number(idxArray[2]);
		endObj=Number(idxArray[3]);
		multiplierAtStart=Number(idxArray[4]);// 1=true; 0=false
		
		// clear out hidden vals
		hiddenObjPosArray.innerHTML = "";
	}
		
	
	// display intermediate binomial expression: (a*b)+(a*c)
	// build expanded version of elementArray
	objPosArray=expandArray(multiplierAtStart,multiplierPosition,beginObj,endObj);
	
	writeToTable(" -- Distributed multipliers");
	
	/* highlight multiplier in expanded array
	 * multiplier is at (objPosArray[n]-2)
	 */
	color="yellow";
	for (j=0;j<objPosArray.length;j++) {
		writeMultHighlight(objPosArray[j]-2, 1, elementArray.length,color);
	}
	
	// set beginObj and endObj to their new positions in elementArray
	// take care of any additional objects between begin and end objects
	j=0;
	ansCtr = 0;
	// build all user prompt strings first
	while (j < objPosArray.length) {
		userPrompt[j] = elementArray[objPosArray[j]].string;
		j++;
	}
	j=0;
	// build all calculated answers
	//bts: 11/15: fix position of multiplier--new position within expanded array
	multiplierPosition=objPosArray[0]-2;

	while (j < objPosArray.length) {
		answer[j] = calcBinomialAns(multiplier,objPosArray[j],multiplierPosition);
		j++;
	}
	
	ansCtr=0;
	j=0;
	//set last parameter(operandTotal) to 1 since this is
	// the binomial routine making the call
	var preprompttext="How much is ";
	var onePrompt = false;
	var callerId = "binom";
	var introType = 11;
	setAnswerPrompt(preprompttext,userPrompt,multiplier, 
			answer,objPosArray,1,onePrompt,callerId,"",introType);

	// strikethru previous expression display
	// var strikeLen=objPosArray[objPosArray.length-1]-(objPosArray[0]-3)+2;
	// writeStrikethru(objPosArray[0]-3, strikeLen,elementArray.length);
	
	//errorCode=0;
	errMsgText="";
	return(errMsgText);
}

function writeMultHighlight(beginPt, strikelength,arrayLength, color)
{
	//arrayLength - length of elementArray before removing calc answer
	//beginPt- start point in prev expression for replacing calc answer
	//length- length of expression that was replaced
	
	// get expn table element, then get only its td elements
	//var list=document.getElementsByTagName("td");

	var expnTableEl;
	expnTableEl=document.getElementById("expnTable");
	var list=expnTableEl.getElementsByTagName("td");
	
	var j;
	var x = list.length-arrayLength;
	x = x+beginPt-1;
	var y = x+strikelength;
	for (j=x;j<y;j++){
		list[j].style.backgroundColor=color;
	} 
	return;
}

function expandArray(multiplierAtStart,multiplierPosition,beginObj, endObj)
{
	var holdArray;
	var i,j;
	var objNewPos = []; // [0]:new beginObj position;[1]:new endObj position;
								// positions 1...: middle objects, if any
								// [last position]: new endObj position
	
	// add: test for more than 2 operands
	// if >2, find mid operand positions and build new elementArray
	// pass back all operand positions, in addition to begin and end positions.
	
	objNewPos[0]=beginObj;

	i=beginObj+1;
	j=0;
	while (i<=endObj) {
		if (elementArray[i].elemtype == "term") {
			j++;
			objNewPos[j]=i;
		}
		i++;
	}
	objNewPos[j]=endObj;
	var operandTotal = j;

	if (multiplierAtStart) {
		//holdArray=elementArray.slice(multiplierPosition,4);
		// change second argument to be relative to first argument
		holdArray=elementArray.slice(multiplierPosition,multiplierPosition+4);
		holdArray.splice(3,1,elementArray[endObj+1]);
		elementArray.splice(multiplierPosition,2);
		elementArray.splice(endObj-2,0,holdArray[2],holdArray[0],holdArray[1]);
		//splice in multiplier val+sign for middle objects
		while (j>1) {
			j--;
			elementArray.splice(objNewPos[j]-2,0,holdArray[2],holdArray[0],holdArray[1]);
			elementArray.splice(objNewPos[j]+2,0,holdArray[3]);
		}
		elementArray.splice(beginObj-1,0,holdArray[3]);
		elementArray.splice(beginObj-2,0,holdArray[0],holdArray[1]);
	} else { //multiplier at end of expression
		holdArray = elementArray.slice(0,beginObj); //start of expression thru 1st left parens
		// insert multiplier term
		holdArray = holdArray.concat(elementArray.slice(multiplierPosition,multiplierPosition+1));
		// insert asterisk, which should come before multiplier in elementArray expression
		holdArray = holdArray.concat(elementArray.slice(multiplierPosition-1,multiplierPosition));
		//insert first multiplicand (beginObj)
		holdArray = holdArray.concat(elementArray.slice(beginObj,beginObj+1));
		//insert right parens
		holdArray = holdArray.concat(elementArray.slice(endObj+1,endObj+2));
		// insert plus sign
		holdArray = holdArray.concat(elementArray.slice(beginObj+1,beginObj+2));
		// bts1226 Insert any middle terms (if j>1)
		if (j>1) {
			j=1;
			while (j<operandTotal) {
				//insert left parens
				holdArray = holdArray.concat(elementArray.slice(beginObj-1,beginObj));
				// insert multiplier, asterisk
				holdArray = holdArray.concat(elementArray.slice(multiplierPosition,multiplierPosition+1));
				holdArray = holdArray.concat(elementArray.slice(multiplierPosition-1,multiplierPosition));
				// insert middle term value
				holdArray = holdArray.concat(elementArray.slice(objNewPos[j], objNewPos[j]+1));
				// insert right bracket
				holdArray = holdArray.concat(elementArray.slice(endObj+1,endObj+2));
				// insert plus sign
				holdArray = holdArray.concat(elementArray.slice(beginObj+1,beginObj+2));
				j++;
			}
		}
		
		// insert left parens
		holdArray = holdArray.concat(elementArray.slice(beginObj-1,beginObj));
		// insert multiplier, asterisk
		holdArray = holdArray.concat(elementArray.slice(multiplierPosition,multiplierPosition+1));
		holdArray = holdArray.concat(elementArray.slice(multiplierPosition-1,multiplierPosition));

		// insert last multiplicand, endObj, right parens
		holdArray = holdArray.concat(elementArray.slice(endObj,endObj+2));
		// insert second right parens
		if (multiplierPosition == elementArray.length-2) {
			holdArray = holdArray.concat(elementArray.slice(endObj+1,endObj+2));
		} else {
		// insert any remaining expression after multiplier
		//if (multiplierPosition < elementArray.length-1) {
			holdArray = holdArray.concat(elementArray.slice(multiplierPosition+1));
		}
		elementArray = holdArray;		
		/* old code
		holdArray=elementArray.slice(endObj);
		holdArray.splice(0,1,elementArray[beginObj-1]);//add in left bracket at pos 0
		elementArray.splice(multiplierPosition-1,2);
		elementArray.splice(endObj,0,holdArray[0],holdArray[3],holdArray[2]);
		//splice in multiplier val+sign for middle objects
		while (j>1) {
			j--;
			elementArray.splice(objNewPos[j]+1,0,holdArray[1]);
			elementArray.splice(objNewPos[j],0,holdArray[0],holdArray[3],holdArray[2]);
		}
		// set up first element (beginObj)
		elementArray.splice(objNewPos[0]+1,0,holdArray[1]);	
		elementArray.splice(beginObj,0,holdArray[3],holdArray[2]);
		*/
	}
	
	var offset = 0;
	objNewPos[0]= beginObj; // first obj position should stay the same
	if (!multiplierAtStart) {
		objNewPos[0] = beginObj+2;
		offset = 2;
	}
	j=1;

	while (j<operandTotal+1) {
		objNewPos[j]= objNewPos[j]+ (4 * j) + offset;
		j++;
	}
	return(objNewPos);
}

function handleAnsEvent() {
	
	var ansButton = document.getElementById("answerbutton");
	b.addEventListener("click", function(){validateAnsEntered;});
}

function validateAnsEntered(){
	var y, msg;
	var checkBoxId;
	var noAnswer = false;
	
	
	var x = document.getElementById("getanswerform");
	checkBoxId = "";
	for (var i=0;i<x.elements.length-1;i++) {
		if (x.elements[i].tagName == "INPUT") {
			y = x.elements[i].value;
			checkBoxId = "checkBox"+i;
			msg = document.getElementById(checkBoxId);
			if (y=="" || y==" ") {
				msg.innerHTML = " Enter an answer";
				noAnswer = true;
			} else if (msg.innerHTML != null) {
				msg.innerHTML = " ";
			}
		}
	}
	
	// check if user has tried to solve expression
	var answerCounter = document.getElementById("answercounter");
	var ctr = answerCounter.innerHTML;
	if (answerCounter.innerHTML > 1) {
		answerCounter.innerHTML = 0;
		document.getElementById("helpwithanswerbutton").disabled=false;	
	} else {
		// increment answerCounter
		ctr=Number(ctr)+1;
		answerCounter.innerHTML = ctr;
	}
	
	if (noAnswer) return false;	
	x.style.display="";
	customPause = setTimeout(getUserAnswer(),1000);
	stopPause();

	return true;
}

function checkRoundingDiff(userAns,calcAns)
{
	/*
	 * checks user entered answer against calculated answer
	 * Allows for rounding differences.
	 * Note: calculated answer is fixed to 3 decimal places
	 * returns ansMatch=true if within correct tolerance
	 */
	var ansMatch=false;
	var numUserAns, numCalcAns,intAns;
	
	numUserAns=Number(userAns);
	numCalcAns=Number(calcAns);
	
	if (numUserAns==numCalcAns){
		ansMatch=true;
	}
	// check if the answer is not an integer
	intAns=Math.round(numCalcAns);
	if (intAns != numCalcAns) {
		if (Math.abs(numUserAns-numCalcAns) < .01) {
			ansMatch=true;
		} 
	}
	return(ansMatch);
}

function continueApp() {
	/*
	 * bts 091214: called from Continue button in getanswerform
	 * 
	 * Sets a parameter indicating user correctly entered answer(s)
	 * and has seen the answer(s) and pressed continue button
	 * Also hides the continue button in getsnwerform
	 */
	
	var continueWithUpdate = true;
	document.getElementById("continuebutton").style.display="none";
	getUserAnswer(false,false,continueWithUpdate);
	
	//jcs112414 display equation tip
	//bts 09072015:display eq menu?
	if (equationFlag) {
		displayTip("equation");
	}
	return;
}

// bts 091214: added 3rd parameter to handle continue button
function getUserAnswer(enterAnsFlag,verifiedAnswer,continueWithUpdate) {
	var userAns=[];
	var i,j;
	var answerString;
	var answer;
	var objPosArray;
	var objPosString;
	// multiplier is single value for binomial; array for polynomial
	var multiplierString;
	var multiplier;
	var wrongAnswer;
	var hiddenAnswer, hiddenObjPosArray, hiddenMultiplier;
	var hiddenCaller, callerId;
	var checkBoxElement;
	var hiddenOperation, expnOperation;
	var correctAnswer;
	var holdStr;
	
	//bts 080092015:new var to identify specific ans table
	var answerTable;
	
	hiddenAnswer = document.getElementById("hiddenanswertext");
	answerString = hiddenAnswer.innerHTML;
	hiddenObjPosArray = document.getElementById("hiddenobjpostext");
	objPosString = hiddenObjPosArray.innerHTML;
	hiddenMultiplier = document.getElementById("hiddenmultipliervalue");
	multiplierString = hiddenMultiplier.innerHTML;
	hiddenCaller = document.getElementById("hiddencaller");
	callerId = hiddenCaller.innerHTML;	
	hiddenOperation = document.getElementById("expressionoperation");
	expnOperation=hiddenOperation.innerHTML;
	
	answer = answerString.split(",");
	objPosArray = objPosString.split(",");
	multiplier = multiplierString.split(",");
	//operandTotal = operandTotalString.split(",");

	var x = document.getElementById("getanswerform");
	// bts 091214: Add test for continueWithUpdate flag; if true,
	//	user has entered correct answer, pressed continue, and
	//	now updates need to happen
	if (continueWithUpdate) {// skip rest of if block processing
		continueWithUpdate=false;
	} else if (!enterAnsFlag && !verifiedAnswer) { //user enters answers
		
		for (i=0;i<x.elements.length-1;i++) {
			if (x.elements[i].tagName == "INPUT") { 
				// remove leading/trailing spaces from user input
				// and convert input to lowercase
				userAns[i] = x.elements[i].value.trim();
				userAns[i] = userAns[i].toLowerCase();
			}
		}
		
		j=0;
		wrongAnswer = false;
	
		//while (j < objPosArray.length) {
		while (j < answer.length) {
			correctAnswer=false;
	
			var checkBoxId = "checkBox"+j;
			checkBoxElement = document.getElementById(checkBoxId);

			// check for leading zero if real number; allow 
			// answer without leading zero
			// apply leading zero logic to negative numbers

			if (selExpType == 10 || selExpType == 22 || selExpType == 23) {	//jcs126 added 23 for other evals) 
				// check numeric expressions 
				//bts 0421: allow for rounding differences for numeric answers
				//   may not need to do comparison test in line below
				correctAnswer=checkRoundingDiff(userAns[j],answer[j]);
				//if (Number(userAns[j]==Number(answer[j]))) {
				//	correctAnswer = true;
				//}
			} else if (selExpType == 20 ||
					selExpType==30) {//bts 042915: include equations
				//check for leading 0's, minus signs, for alg expression
				if (answer[j].indexOf(".") > -1) {
					if ((answer[j].indexOf("0")==0) || 
							(answer[j].indexOf("-")==0 && answer[j].indexOf("0")==1)) {
						if (answer[j].indexOf("0")==0) holdStr ="0".concat(userAns[j]);
						if (answer[j].indexOf("-")==0) holdStr ="-0".concat(userAns[j]);
						userAns[j]=holdStr;
						correctAnswer=true;
					}
				}
				// bts 042915: eliminate leading 1 from 
				//	user answer if preceding var
				var textChar=answer[j].charAt(0);
				if (isNaN(textChar)) {//first char of calc answer is 
									// not number; replace with empty space
					//bts 07172015: fix bug where user enters 1 with no var
					//		check calc ans variable against userans var
					//if (userAns[j].charAt(0)=="1" ) 
					if (userAns[j].charAt(0)=="1") {
						userAns[j]=userAns[j].replace("1","");
						if (userAns[j]==answer[j]) correctAnswer=true;
					}
					//correctAnswer=true;
				}
			}
						
			//jcs040715 equiv test 
			var testEquiv=false;
			if (!correctAnswer) {
				//bts 012115: do testequiv function if answers not eq
				//jcs080715 Need to test for fractions. 
				var slashPtr1=userAns[j].indexOf("/");
				var slashPtr2=answer[j].indexOf("/");
				if ((userAns[j]!=answer[j])&&((slashPtr1>-1)||(slashPtr2>-1))) {
					testEquiv=calcEquiv(userAns[j],answer[j]);
				}
			}
		
			//bts 102115: add testEquiv to if statement, changed message
			if (correctAnswer || userAns[j]== answer[j] || testEquiv) {	
				checkBoxElement.innerHTML = "&#x2714;";
				checkBoxElement.style.color="green";
				checkBoxElement.style.fontWeight="bold";
				if (testEquiv && (userAns[j]!=answer[j])) {
					checkBoxElement.innerHTML="OK. "+userAns[j]+
						" is the same as expected answer: "+answer[j];
				}
			} else {
				checkBoxElement.innerHTML = "X" + "  Try again";
				checkBoxElement.style.color="red";
				checkBoxElement.style.fontWeight="bold";
				wrongAnswer = true;
				//bts 08092015: write wrong answer w/prompt
				//		to storage location; set 3rd field
				//		indicating the specific answer table
				answerTable="default";
				writeWrongAns(j,userAns[j],answerTable);
			}
			j++;			
		} // end while loop checking answers
	
		if (wrongAnswer) return false;

		// disable check answer button 
		document.getElementById("answerbutton").disabled=true;
		//bts 03112014: disable help button and redisplay answerform
		document.getElementById("helpwithanswerbutton").disabled=true;
		// bts 091214: show or hide continuebutton and return true
		document.getElementById("continuebutton").style.display="";
		document.getElementById("getanswerform").style.display="";
		return true;
		
	} else if (enterAnsFlag && !verifiedAnswer) { //enter the answer for the user here
		for (i=0;i<x.elements.length-1;i++) {
			if (x.elements[i].tagName == "INPUT") {
				x.elements[i].value = answer[i];
				var checkBoxId = "checkBox"+i;
				checkBoxElement = document.getElementById(checkBoxId);
				checkBoxElement.innerHTML = "&#x2714;";
				checkBoxElement.style.color="green";
				checkBoxElement.style.fontWeight="bold";
			}
		}
		//bts 08092015:user gave up
		writeGaveUpMsg();

		document.getElementById("answerbutton").disabled=true;
		document.getElementById("helpwithanswerbutton").disabled=true;
		// return to enterAnsForMe function to leave up correct answer display
		
		//bts010814: display fraction combine hint if filled in
		// blank out and hide tip field after Got It button clicked
		var tipEl=document.getElementById("fractioncombinetip");
		if (tipEl) {
			if (tipEl.innerHTML) {
				tipEl.style.display="";
			}
		}
		
		return;
	}
	
	// clear out window parts if answer is correct
	//document.getElementById("getanswerform").style.display="none";
	//make sure I give up button text is set to normal case
	document.getElementById("helpwithanswerbutton").value="I Give Up";
	document.getElementById("helpwithanswerbutton").innerHTML="I Give Up";

	//jcs209 test
	//document.getElementById("whatToDoNextArea").style.display="none";
	//document.getElementById("userInstructions").style.display="none";
	document.getElementById("whatToDoNextArea").style.display="";
	document.getElementById("userInstructions").style.display="";
	
	//jcs0422 blank out multiply fraction prompt
	var tipText=document.getElementById("UserInstructionPrompt");
	if (tipText) {
		tipText.innerHTML=""; 
	}
	
	//bts082114: blank out fraction combine hint and hide it
	//	after Got It button clicked
	var tipEl=document.getElementById("fractioncombinetip");
	if (tipEl) {
		if (tipEl.innerHTML) {
			tipEl.innerHTML="";
			tipEl.style.display="none";
		}
	}

	
	document.getElementById("combineliketermsform").style.display="none";
	displayTip("erase");
	
	//jcs9+ enable simplifyMenu for next step
	//document.getElementById("simplifyMenu").disabled=false;	
	
	// check if expression is completely solved
	// note: should call checkForMoreWork here only if id is combineliketerms,combineconstants,
	//       or simplifynumeric. The updateBlkBoard/Simple functions both
	//       include calls to checkForMoreWork.
	var solved; 
	var simplificationDone;
   	var convertToMixed;
	var simplifyLastTerm;
	var expnSolved="";
	var evalAnswer; // holds eval alg expression answer to display in solved list
	var absolValSingleTerm = [];
	//bts 120914: Initialize actionIndicator here
	var actionIndicator;

	//bts 1024: check for equation solved someplace else, not here
	//if (callerId != "poly"){
	if (!equationFlag && callerId != "poly"){
		solved = checkForMoreWork();
	}
	
	//bts 090214: Check for simplifying any last fraction terms for 
	//		combining like terms and combining constants
	// - set flag indicating fractions to simplify (expn NOT solved)
	// - do check only if solved; if fractions to simplify, set solved=false
	// - allow routine to display updated board (line 9343 code)
	
	var convertToMixed = false;	// track if constant val includes fraction
								// that can be converted to mixed number at end
	var fractionToSimplify=[];
	var simplifyFractInAlgExp=false;
	if (solved && selExpType==20) {
		// check if structure includes any terms w/fraction to simplify
		fractionToSimplify=checkForFractionToSimplify();
		if (fractionToSimplify.length>0) {
			solved=false; // fraction found
			simplifyFractInAlgExp=true;
		} else {
			// bts 090514: check for mixed number conversion if solved
			// and fraction cannot be simplified. Do the mixed number
			// conversion later, after displaying last operation on board
			var fractPos = checkAlgFractToMixed();
			if (fractPos>-1) convertToMixed=
				checkImproperToMixedNumber(fractPos);
			if (convertToMixed) solved=false;
		}
	}
	
	//bts 12282015: add eval eq type 32
	if (solved && (selExpType == 10 || selExpType == 22 || selExpType == 23
			|| selExpType==32)) {  //added 32 evaleqs
		// see if last fraction can be simplified
		// last fraction must be at position 0 if adding numbers/fractions
		// bts: additional callerId parameter: applyLCDSub
		simplifyLastTerm=false;
		if ((callerId=="addNumbers" || callerId == "addAllNumbers"
		   	|| callerId=="addFractions" || callerId=="applyLCD" ||
		   	callerId=="applyLCDSub") &&
		    (elementArray.length == 1 && elementArray[0].denominator == 1)){
			solved=true;
			callerId="simplifynumeric";
		}
		if (elementArray.length == 1 && elementArray[0].denominator != 1){ // last term is a fraction
			solved = false;
			convertToMixed=false;
			simplificationDone = computeSimpleFraction(0);
			if(simplificationDone) {
				simplifyLastTerm=false;
				// no factoring needed, now check if convert to mixed number
				convertToMixed = checkImproperToMixedNumber(0);
				if (!convertToMixed && elementArray[0].denominator ==1) {
					solved = true;
				} else {
					solved = false;
					simplifyLastTerm=true;
				}
			} else {
				simplifyLastTerm=true;
			}
			//bts 12282015: set solved to false if this is eq eval type 32
			if (selExpType==32) solved=false;
		}
    	// bts 0401: check for single term within absolute value markers
		// 	if found, then set solved to false
    	absolValSingleTerm = checkAbsolValSingleTerm();
    	if (absolValSingleTerm[0]!=-1) {//found single term within abol val
    		solved=false;
    	}
	} 
	
	if (solved) {
		expnSolved = "  ** Exercise completed successfully! **";
		// bts: save eval alg expression answer for display in list
		evalAnswer = elementArray[0].string;
		//jcs9+
		hideDoAnotherButtons();
		hideWorkArea ();		 
		//jcs111 
       clearAnswerFormTable();
        //jcs119 test
        //resetAfterSolved();  
	} 
	
	// update the expression on the board and in the structure
	if (callerId == "applyLCDSub") callerId="simplifynumeric";

	if (callerId == "combineliketerms") {
		writeToTable("  -- After combining like terms"+expnSolved);
		checkForSubtraction(); //jcs090215 switch to adding a negative
	} else if (callerId == "combineconstants") {
		writeToTable(" -- After combining constants"+expnSolved);
		checkForSubtraction(); //jcs090215 switch to adding a negative
	//bts 12242015: added new callerId for onestep solution
	} else if (callerId=="onestep") {
		writeToTable(" -- After calculating"+expnSolved);
		//turn off hidden var
		document.getElementById("hiddeneqevalonestep").innerHTML="false";
	} else if (callerId == "simplifynumeric") {
		writeToTable(" -- After "+expnOperation+expnSolved);
		
		// bts 04152014: if subtraction operation precedes negative number, change
		//		operation to addition and neg number to positive
		changeMinusToAdd();
		
		// bts092513: check if expression now includes fraction(s) and
		// all operations are additions. If so, regroup if
		// necessary and then branch to
		// addWholeNumbers routine to properly handle
		// fraction lcd, addition, etc.
		if (elementArray.length >1) { // 2 or more terms remain
			var expnFractionAdd=[];
			expnFractionAdd=checkFractionAddOnly();
			//bts 009012015: check for absol val bars
			var absValBars=[];
			absValBars=checkForAbsolValBars();
			if (expnFractionAdd[1]>-1 && elementArray.length>1
					&& absValBars.length==0) { // expn has fraction, only + opers;no absol val bars
				callerId=" ";
				if (expnFractionAdd[0]== -1) {
					// either combine 1 whole #,fraction or 
					// add whole numbers
					if (elementArray.length > 2) callerId="addAllNumbers";
				}
				addWholeNumbers(expnFractionAdd,callerId);
				return;
			}
		}
	} else if (callerId == "simplemultiply") {
		solved=updateBlkBoardSimple(objPosArray);
	} else if (callerId == "applyLCD" || callerId == "addFractions"
		|| callerId=="addAllNumbers" || callerId=="addNumbers") {
		if (solved && callerId=="addNumbers") {
			addWholeNumbers(objPosArray,callerId);
		} else {
			writeToTable(" -- After "+expnOperation+expnSolved);
			addWholeNumbers(objPosArray,callerId);
		}			
		return;
	// bts 120914: callerId is eqtruefalse:  write answer, solved=true
	} else if (callerId == "eqtruefalse") {
		solved=true;	
		actionIndicator=1;
		writeToTable(" -- After "+expnOperation+expnSolved);
	//bts 122214: add callerId absolutevalue option to handle
	//	alg expressions/equations with absolute vals
	} else if (callerId == "absolutevalue") {
		writeToTable(" -- After "+expnOperation+expnSolved);		
	} else {
		solved=updateBlkBoard(objPosArray);
	}
	
	// bts 090214: if algebraic expn and flag set for simplifying
	//		any remaining fractions, do that here:
	//	- for fraction coefficients: simplify if possible and leave as
	//		improper number
	//  - for fraction constants: simplify and convert to mixed number
	// Need to check for mixed number conversion of last constant when
	//  	fractions do NOT have to be simplified
	if (selExpType==20){
		if (simplifyFractInAlgExp) {
			simplifyAlgFraction(fractionToSimplify);
			document.getElementById("combineliketermsform").reset();
	        document.getElementById("getanswerform").style.display="none";
	        return;
		}
		if (convertToMixed) {
			simplifyAlgFraction(fractionToSimplify);
			document.getElementById("combineliketermsform").reset();
	        document.getElementById("getanswerform").style.display="none";
	        return;			
		}
		//bts 010915: handle special case of simplifying last alg fraction(s)
		if (!solved) {
	        if (document.getElementById("hiddencaller").innerHTML
	        		=="simplifylastalgfract") return;
		}

	}
	
	// clean up any hidden values in the html page
	var hiddenBegObjElem,hiddenEndObjElem;
	hiddenBegObjElem = document.getElementById("hiddenbeginobj");
	hiddenEndObjElem = document.getElementById("hiddenendobj");
	
	removeHiddenValues(hiddenAnswer,hiddenObjPosArray,hiddenMultiplier,
			hiddenBegObjElem,hiddenEndObjElem,hiddenCaller,hiddenOperation);

	document.getElementById("combineliketermsform").reset();
	
	// bts 03102014: Answer(s) are correct so set up a delay timer
	//		Wait 300 msecs
	customPause = setTimeout(pauseTimer(300),0);
	
	// simple numeric expressions
	// jcs8 display or hide appropriate workarea for simple numeric expressions
    if (selExpType == 10 || selExpType == 22 || selExpType == 23) {	//jcs126 added 23 for other evals) 
        if (!solved) {
            document.getElementById("getanswerform").style.display="none";
            // check if last term in expression needs to be simplified
            // last term must be at position 0
			convertToMixed=false;
            if (simplifyLastTerm) {
            	simplificationDone = computeSimpleFraction(0);
            	if (simplificationDone) convertToMixed = checkImproperToMixedNumber(0);
            	if (!convertToMixed) solved = true;
            	if (!simplificationDone) solved=false;
            	if (solved) {
            		evalAnswer = elementArray[0].string;
            		elementArray.splice(0);
            		writeToTable(" ** Exercise completed successfully! **");
            		//jcs119 test
                	resetAfterSolved();
            	}
            } else {
	            document.getElementById("userInstructions").style.display="";
	            document.getElementById("whatToDoNextArea").style.display="";
	            //if (selExpType==10) {
	            	var combineExponsPos=[];
	            	combineExponsPos=checkExponentOpers();
	            	if (combineExponsPos[0]==-1) {
	    	            document.getElementById("UserInstructionPrompt").style.display="none";
	    	            document.getElementById("generalHighlight").style.display="";
	    				
	    				//jcs012715 new keypad
	    				document.getElementById("mobileEntryField").focus();
	            	} else {
	            		document.getElementById("UserInstructionPrompt").style.display="";
	         	   }
	            //}
           }
        }
        // bts 03282014: moved this test from below to here
    	// check for single term within absolute value markers
        absolValSingleTerm = checkAbsolValSingleTerm();
        if (absolValSingleTerm[0]!=-1) {//found single term within abol val
        	// update structure; set up prompts
        	promptSingleAbsVal(absolValSingleTerm);
        	solved=false;
        	// bts 1013: fix absol val bug by returning here
        	return;      	
        }
        
        if (solved) {
        	resetAfterSolved();
        }
    }

    // bts 122214: if absol value for alg expns/equations, resume
    //	with algExpSteps function
    if (selExpType == 20) {
        if (solved) {
        	document.getElementById("getanswerform").reset();            
            document.getElementById("getanswerform").style.display="none";
        	document.getElementById("workarea").style.display="none";
        	//jcs111
            resetAfterSolved();   	
        } else if (!solved) {
            document.getElementById("getanswerform").style.display="none";
            document.getElementById("userInstructions").style.display="";
            document.getElementById("operationMenuArea").style.display="";
            document.getElementById("whatToDoNextArea").style.display=""; 
			//bts 10182015: enable the Go Back button
			document.getElementById("gobackbutton").disabled=false;
    		//bts 122214: resume algexpsteps
            if (callerId=="absolutevalue") {
            	doAlgExpSteps();
            	return;
            }
        }
    } 
    //bts 1028: resetting window for equations
    //bts 120514: added selExptype=32
    if (selExpType==30 || selExpType==32) {//equations
    	//bts 1029: check if equation is solved
    	// bts 120914: only do check if actionIndicator is not 1
    	if (actionIndicator !=1) {}
    		actionIndicator=checkForEqSolved();
    	//if (!solved) {
    	if (actionIndicator==0) { //not solved
    		document.getElementById("getanswerform").style.display="none";
            document.getElementById("userInstructions").style.display="";
            document.getElementById("whatToDoNextArea").style.display=""; 			
    		document.getElementById("operationMenuArea").style.display="";
    		//jcs112414 reset equation menu
			document.getElementById("equationMenu").selectedIndex=0;
			//bts 09092015:display equationMenu
    		document.getElementById("equationMenu").style.display="";
			//bts 120514: enable the Go Back button
			document.getElementById("gobackbutton").disabled=false;
    		solved=false;
    		//bts 011915: if checking eq phase, use std highlight menu
    		if (callerId=="checkeq") {
    			document.getElementById("operationMenuArea").style.display="none";
    			document.getElementById("generalHighlight").style.display="";
    			
    			//jcs012715 new keypad
    			document.getElementById("mobileEntryField").focus();
    		}
    		//bts 122214: resume algexpsteps
    		//bts 122514: set up second call for multiplying terms 
    		//		added to both sides of an equation
            if (callerId=="absolutevalue") {
            	doAlgExpSteps();
            	return;
            } else if (callerId=="simplemultiply" || 
            		callerId=="poly" || callerId=="binom") {
            	//get hidden variable to see if this is second pass
            	//if first pass for solving left and right side of equation
            	// call function to build prompt
            	// TODO create hidden var and write to it from eqMultLeftRightSides
            	if (document.getElementById("hiddenmultiplybothsides").innerHTML=="firstpass") {
            		var firstPass=false;
            		eqMultLeftRightSides(firstPass);
            	} else if (document.getElementById("hiddenmultiplybothsides").innerHTML=="secondpass") {
            		document.getElementById("hiddenmultiplybothsides").innerHTML="";
            	}
            	return;
            }
    	} else if (actionIndicator==1) {//solved
    	    document.getElementById("getanswerform").reset();            
    	    document.getElementById("getanswerform").style.display="none";
    	    document.getElementById("workarea").style.display="none";
    	    solved=true;
    	    //bts 10212015: if eval eq, do another
    	    //bts 11302015: TEMP change: do another eval for equations
    	   
    	    if (document.getElementById("hiddenvarlist").innerHTML != "") {
    	    	//bts 12152015: use evalAnswer--final solution--instead of blank
        		evalAnswer = buildStrPart(0,elementArray.length-1);
           		doAnotherEvalExpn(evalAnswer);
           		//doAnotherEvalExpn(" ");
    	    }
    	   
    	    resetAfterSolved(); 
    	} else if (actionIndicator==2) {//simplify last fraction
    		solved=false;
    		// bts 12282015: handle eval eq type problem differently 
    		//		hide simplifylastfractionform/getanswerform
    		if (selExpType==32) {//eval eq
           		evalAnswer = buildStrPart(0,elementArray.length-1);
	    		document.getElementById("getanswerform").style.display="none";
	    		//document.getElementById("simplifylastfractionform").style.display="none";
           		//doAnotherEvalExpn(evalAnswer);			
    		} else {//normal equation
	    		document.getElementById("getanswerform").style.display="none";
	            document.getElementById("userInstructions").style.display="";
	            document.getElementById("whatToDoNextArea").style.display=""; 			
	    		document.getElementById("operationMenuArea").style.display="none"; 
    		}
	    	// bts 120914: prompt for true/false
    	// bts 012715: changed test for indicator vals to =3,4 from >2
    	} else if (actionIndicator==3 || actionIndicator==4) {
    		//TODO what action?
    		//bts 121114
    	    document.getElementById("getanswerform").style.display="none";
    	   // document.getElementById("workarea").style.display="none";
    		document.getElementById("operationMenuArea").style.display="none";
    		document.getElementById("UserInstructionPrompt").style.display="";
    	// bts 012715: action indicator=5: single term absol value in process
    	} else if (actionIndicator==5) {
    		// do nothing; just return
    		return;
    	}
    }
	
	// eval algebraic expressions: if solved, keep same values; prompt for 
	// another expression;track completed expressions/solutions
	if (selExpType == 22 || selExpType == 23) {	//jcs126 added 23 for other evals) 
		if (!solved) {
            //jcs6 Hide answer form and display next instruction for evaluate problems
            document.getElementById("getanswerform").style.display="none";
        	
            // check for single term within absolute value markers
            var absolValSingleTerm = [];
            absolValSingleTerm = checkAbsolValSingleTerm();
            if (absolValSingleTerm[0]!=-1) {//found single term within abol val
            	// update structure; set up prompts
            	promptSingleAbsVal(absolValSingleTerm);
            } else {
            	//jcs209 test
        		document.getElementById("whatToDoNextArea").style.display="";
	
            	document.getElementById("userInstructions").style.display="";
            }
		} else if (solved) {
			// call function to add solved expression to side display
			// keep var values as is
			// prompt for new expression			
			if (!evalAnswer) {
				doAnotherEvalExpn(answer);
			} else {
        		doAnotherEvalExpn(evalAnswer);
			}
			/* jcs1111 test
	        resetAfterSolved();		*/	
		}
	}
	return;
}

function simplifyAlgFraction(fractionToSimplify) {	
	/*
	 * bts 090314: prompts for simplifying fractions
	 * remaining in algebraic expressions; called when
	 * expression is otherwise completely solved
	 * 	- Any fractions referenced by fractionToSimplify array
	 * 		are in a form that can be simplified.
	 *   - handle fractions with coefficients first
	 *   - sort the array fractionToSimplify
	 *   - prompt for all fraction simplifications at same time 
	 *     or 1 by 1?
	*/
	
	var i;
	
	// erase previous screen areas
	document.getElementById("getanswerform").reset();            
    document.getElementById("getanswerform").style.display="none";
	//document.getElementById("workarea").style.display="none";
    // check if there are more fractions to simplify
	if (fractionToSimplify.length == 0) {
		fractionToSimplify=checkForFractionToSimplify();
	}
    
	var b=0;
	if (fractionToSimplify.length > 1) {
		fractionToSimplify.sort(function(a,b){return a-b;});
	}
	var fractPos;
	var allDone=false;
	var fractPosElement = document.getElementById("hiddenendobj");
	// only work on first element in array
	if (fractionToSimplify.length == 0) {
		allDone=true;
	}

	if (!allDone) {
		i=0;
	// strip out the 100 vals that identify terms w/out coeffs.
		fractPos = fractionToSimplify[i];
		//bts 010915: change if test so that we catch pos=0
		if (fractPos >=100) fractPos=fractPos-100;
		fractPosElement.innerHTML=fractPos;
		
		var color = "yellow";
		for (var j=fractPos;j<fractPos+1;j++) {
			writeMultHighlight(j,1,elementArray.length,color);
		}
		document.getElementById("simplifylastfractionform").style.display="";
		//bts 09292015: hide operationmenu, explanation area
		//document.getElementById("simplifylastfractioninput").focus();
		document.getElementById("operationMenuArea").style.display="none";	
		//jcs111015 explanationArea test
		//document.getElementById("explanationArea").style.display="none";
		document.getElementById("stepExplanation").style.display="none";
		allDone=computeSimpleFraction(fractPos);
	}	
	
	//if allDone is false, then fraction can be cancelled

	if (allDone) {
		document.getElementById("simplifylastfractionform").style.display="none";
		// before completely solved, check if there is a constant that
		// needs to be converted to a mixed number.
		// find location of constant term
		fractPos = checkAlgFractToMixed();
		var convertToMixed = false;
		if (fractPos>-1) {
			convertToMixed=checkImproperToMixedNumber(fractPos);
			if (!convertToMixed){		
				var expnSolved = "  ** Exercise completed successfully! **";
				writeToTable(expnSolved);
		        resetAfterSolved();   
			} else {
				fractPosElement.innerHTML=fractPos;
			}
		// bts 09242015: fraction cancelled, no mixed # conversion, exit
		} else {
			var expnSolved = "  ** Exercise completed successfully! **";
			writeToTable(expnSolved);
	        resetAfterSolved();   			
		}
	} 		
	return;
}

function checkAlgFractToMixed() {
	/*
	 * Converts last algebraic fraction to mixed number if needed
	 */
	
	// check for mixed number presence
	// find location of constant term
	var fractPos=-1;
	for (i=0;i<elementArray.length;i++) {
		if (elementArray[i].elemtype == "term" && 
				elementArray[i].denominator != 1 && 
				elementArray[i].variable == null) {
			fractPos = i;
		}
	}


	return(fractPos);
}


function checkForFractionToSimplify() {
	/*
	 * bts 090214: function checks for any terms that are fractions
	 * 	in algebraic expressions. Returns positions of terms
	 *  that are fractions; adds "100" to terms without coeffs so
	 *  that they appear at end of array
	 */
	var fractionPresent=[];
	var cancelNumber=[];
	var j=0; 
	var fractInSimpleForm;
	for (var i=0;i<elementArray.length;i++) {
		if (elementArray[i].elemtype == "term" && 
				elementArray[i].denominator != 1) {
			fractInSimpleForm=true;
			//check if found fraction can be simplified
			cancelNumber = checkForFractionCancel(i,i);
			if (cancelNumber[0] != 0) fractInSimpleForm=false;
			if (!fractInSimpleForm) { //fraction is simplifiable
				fractionPresent[j]=i;
				if (elementArray[i].variable == null) 
					fractionPresent[j]=i+100;
				j++;
			}
		}
	}	
	return (fractionPresent);
}

function checkForMoreWork() {
	/*
	 * check if user has finished solving the expression
	 * Conditions indicating expression solved:
	 * 	elementArray structure contains 1 element
	 *  no brackets remain
	 *  no multiply/divide operators
	 *  no 2 or more matching terms
	 *  no 2 or more constants
	 *  
	 *  Additional "finished" constraint for simplenumerics:
	 *  When elementArray structure contains 1 element, if 
	 *  term is a fraction, simplify
	 *  the improper fraction (if possible), then convert to
	 *  mixed number if needed (numerator>denominator) 
	 */
	
	var i;
	var moreToSolve, solved;
	var term, exponent;
	var matchPositions = [];
	
	moreToSolve = false;
	solved = true;
	
	i=0;
	if (elementArray.length == 1) {
		if (elementArray[0].denominator==1) {
			// for simple numerics, if last term is a fraction
			// call computeSimpleFraction routine elsewhere
			solved = true;
			return(solved);
		}
		moreToSolve = true;
		solved = true;
	} 
	while (!moreToSolve) {
		term = "";
	
		if (elementArray[i].elemtype == "oper") {
			if (elementArray[i].string == "\u00F7" ||
					elementArray[i].string== "*") {
				moreToSolve = true;
				solved = false;
			}
		}

		if (!moreToSolve) { // check variable/exponents for match
			if (elementArray[i].elemtype=="term" &&
					elementArray[i].variable != null) {
				term = elementArray[i].variable;
				if (elementArray[i].exponent != 1) {
					term = term+"^"+elementArray[i].exponent;
				}
			}
			if (elementArray[i].variable2 !=null) {
				term = term+elementArray[i].variable2;
				if (elementArray[i].exponent2 != 1) {
					term = term+"^"+elementArray[i].exponent2;
				}
			}
			if (elementArray[i].variable3 !=null) {
				term = term+elementArray[i].variable3;
				if (elementArray[i].exponent3 != 1) {
					term = term+"^"+elementArray[i].exponent3;
				}
			}
			if (elementArray[i].variable4 !=null) {
				term = term+elementArray[i].variable4;
				if (elementArray[i].exponent4 != 1) {
					term = term+"^"+elementArray[i].exponent4;
				}
			}				
			if (term) {	
				matchPositions = variableMatch(term,0,elementArray.length-1);
				if (matchPositions.length >1) {
					moreToSolve = true;
					solved = false;
				}
			}
		}
		
		if (!moreToSolve) {				
			// check for more than 1 constant
			if (elementArray[i].elemtype == "term" && 
					elementArray[i].variable==null) {
				//bts 10232015: change loop end to elementArray.length
				for (var j=0;j<elementArray.length;j++) {
				//for (var j=0;j<elementArray.length-1;j++) {
					if (j != i) {
						//bts 07182015: fix bug where constant is 0
						//	and thus there may still be constants to combine
						//	even tho there aren't
						if (elementArray[j].elemtype == "term" &&
								elementArray[j].numerator != 0) {
							if (elementArray[j].variable == null) {
								moreToSolve = true;
								solved = false;
								j=elementArray.length;
							}
						//bts 10232014: additional test for when constant
						//	is a zero and no vars present
						} else if (elementArray[j].elemtype == "term" &&
								elementArray[j].numerator == 0) {
							moreToSolve=true;
							solved=false;
							j=elementArray.length;
						}
					}
				}
			}
		}
		
		// TODO: Add test for simplifying fraction for algebraic term/expn??
		
		i++;
		if (i == elementArray.length) moreToSolve = true;

	}// end while loop
	//jcs207 test
	document.getElementById("simplifyMenu").selectedIndex=0;
	
	//bts 040715: test removing zeros from struct
	//bts 11302015: added type=23 for removing zeros
	//if (selExpType ==20 || selExpType==30) removeZerosFromStruct();
	if (selExpType ==20 || selExpType ==22 || 
			selExpType==30) removeZerosFromStruct();

	return(solved);
}



function updateBlkBoard(objPosArray) {
	/* 
	 * updates the blackboard display with new expression and
	 * updates the elementArray structure for algebraic expressions
	 * routine does following:
	 * 	first convert objPosArray to numbers
	 * 	remove element array objects no longer needed
	 * 	remove objects in reverse order (from end of array)
	 */
	var j;
	var numObjPosArray = [];
	for (j=0;j<objPosArray.length;j++) {
		numObjPosArray[j] = Number(objPosArray[j]);
	}
	
	j=objPosArray.length-1;	
	while (j>-1) {
		elementArray.splice(numObjPosArray[j]+1,1); // remove right grouper
		elementArray.splice(numObjPosArray[j]-3,3); // objects to left of term
		j--;
	}

	//bts 11082015: remove any multiplications by 1 
	removeMultByOneFromStruct();

	//bts 121214: remove parens surrounding single term
	removeParensFromStruct();
	
	// check if expression is completely solved
	var solved; 
	var expnSolved="";
		
	// bts 111214: handle checking equations differently
	if (!equationFlag) solved = checkForMoreWork();
	//solved = checkForMoreWork();
	
	// write out answer and operation msg
	writeToTable(" -- After multiplication");
	
	//bts 010815: check alg expn for simplifying any last fractions
	// code copied from getuseranswer routine
	//Check for simplifying any last fraction terms for 
	// - set flag indicating fractions to simplify (expn NOT solved)
	// - do check only if solved; if fractions to simplify, set solved=false
	// - allow routine to display updated board (line 9343 code)
	if (solved && selExpType==20) {	
		var fractionToSimplify=[];
		// check if structure includes any terms w/fraction to simplify
		fractionToSimplify=checkForFractionToSimplify();
		if (fractionToSimplify.length>0) {
			solved=false; // fraction found
			simplifyAlgFraction(fractionToSimplify);
			document.getElementById("operationMenuArea").style.display="none";
	        document.getElementById("getanswerform").style.display="none";
	        //set callerId to simplifylastalgfract--this is special case
	        document.getElementById("hiddencaller").innerHTML="simplifylastalgfract";
	        return(solved);
		}
	}
	//bts 010815: end of copied code for checking for fraction simplification
	
	if (solved) {
		elementArray.splice(0);
		writeToTable(" ** Exercise completed successfully! **");
		//jcs119 iffy
        resetAfterSolved();		

	}
	return(solved);	
}

function removeHiddenValues(hiddenAnswer,hiddenObjPosArray,
		hiddenMultiplier, hiddenBegObjElem,hiddenEndObjElem,
		hiddenCaller,hiddenOperation) {
	// clean up hidden values before exiting
	hiddenAnswer.innerHTML = "";
	hiddenObjPosArray.innerHTML = "";
	hiddenMultiplier.innerHTML = "";
	if (hiddenBegObjElem != null) hiddenBegObjElem.innerHTML = "";
	if (hiddenEndObjElem != null) hiddenEndObjElem.innerHTML = "";
	if (hiddenCaller != null) hiddenCaller.innerHTML = "";
	if (hiddenOperation !=null) hiddenOperation.innerHTML="";
	return;
}

function setAnswerPrompt(preprompttext, userPrompt, 
		multiplier,answer,objPosArray,operandTotal,
		onePrompt,callerId,expnOperation,introType,exponVal) {
	
	document.getElementById("combineliketermsform").style.display="none";
	displayTip("erase");
	document.getElementById("generalHighlight").style.display="none";

	document.getElementById("getanswerform").reset();
	// set msg field in getanswerform
	var answerFormIntroElement;
	answerFormIntroElement=document.getElementById("getanswerintro");
	if (introType =="" || introType == null) introType = 0;
	answerFormIntroElement.innerHTML="";
	switch (introType) {
	case 0:
		answerFormIntroElement.innerHTML="";
		break;
	case 1:
		// bts 0428: change instruction to add the whole numbers, from
		//		add the whole number portions
		answerFormIntroElement.innerHTML="Add the whole numbers";
		break;
	//jcs011215 combined 2 and 3. And blanked out userinstructionprompt
	case 2:
	case 3:
		var convertFractionPrompt=document.getElementById("UserInstructionPrompt");
		convertFractionPrompt.innerHTML="";
		// bts 112514: changed tip message to handle multiplying when 0 in numerator
		answerFormIntroElement.innerHTML=
			"When you multiply fractions, you multiply the numerators by each other " +
			"and the denominators by each other. Whole numbers have a denominator of 1.<br /> <br /> " +
			"Enter your answer as a fraction. Zero (0) may be a correct answer.";
		
		//jcs030415 apply voice over
		findAudio("simplemultfrac");		
		break;
	case 4://subtracting numerators
		answerFormIntroElement.innerHTML=
			"When subtracting fractions that have the same denominator, you subtract the numerators and keep the "+
			"same denominator.";
		break;
	case 5: // adding numerators for fractions with same denominators
		//jcs071414 changed the message
		answerFormIntroElement.innerHTML=
			"When fractions have the same denominator you add or subtract the numerators and keep the "+
			"same denominator. <br /> <br /> " +
			"Enter your answer as a fraction.  Zero (0) may be a correct answer.";
		//jcs030415 apply voice over
		findAudio("addfracsnow");		
		break;
	case 6: // displays polynomial multiplication line from structure
		// expnOperation in this 1 case holds the expanded multiplication line
		 
		/*var k,h;
		var hintString="";
		h=objPosArray.length/2;
		for (k=h;k<objPosArray.length;k++) {
			if (k==h) {
				hintString = hintString+elementArray[objPosArray[k]].string;
			} else {
				hintString = hintString+", "+elementArray[objPosArray[k]].string;
			}
		}
		
		answerFormIntroElement.innerHTML="\n Solve: "+expnOperation+ 
			"Multiply each term in the first expression ("+multiplier[0]+", "+
			multiplier[1]+") by each term in the second expression ("+hintString;
		*/		
		expnOperation = "";
		break;
	case 7:	//exponentiation
		// bts 1229
		answerFormIntroElement.innerHTML=
			"Raise the term to the power of "+exponVal+" .";
		break;
	
	case 8: // jcs011615 add negative and positive
		displayTip("negativehint8");
		break;
		
	// bts 091214: add case 9 for combining terms with
	//		fractional coefficients and case 10
	//		for combining constants with fractions
	case 9: 
		answerFormIntroElement.innerHTML=
			"Express the coefficient as a fraction or whole number";
		break;
	case 10: 
		answerFormIntroElement.innerHTML=
			"Express the answer as a fraction or whole number";
		break;
	
	case 11:
		answerFormIntroElement.innerHTML=
			 "When you multiply a single term by an expression, you need to "+
             "distribute the single term to each term in the expression. Math Assister "+
             "did this for you. Now you have to do the multiplications.";
		break;
		
	case 12: // jcs011615 add negative and negative
		displayTip("negativehint12");
		break;

	case 13: // jcs011615 subtract negative and negative
		displayTip("negativehint13");
		break;

	default:
		break;
	}
	
	// make sure I Give Up button is set properly and Check Answer button is visible
	document.getElementById("helpwithanswerbutton").value="I Give Up";
	document.getElementById("helpwithanswerbutton").innerHTML="I Give Up";
	document.getElementById("answerbutton").style.visibility="visible";

	document.getElementById("getanswerform").style.display="";

	// bts 0414: display whatToDoNextArea and userinstructions
	document.getElementById("whatToDoNextArea").style.display="";
	document.getElementById("userInstructions").style.display="";
	
	clearAnswerFormTable();
	var userPromptString;
	var j=0;
	var i;
	var rowIdVal;
	var cellnode, cellnode2, cellnode3; 
	var inputElement;
	var textElement;
	var textincell;
	var trElement;
	var tableElement, tableElementStart;
	var multiplyBy;
	var userPromptLength;
	var promptText;
	
	//bts 08042015: add id var for identifying prompt cell
	var promptTD;
	
	// write text to a table. Create new table for each row of data
	// add a new row
	i=0;
	j=0;
	tableElementStart=document.getElementById("answerprompttable");	
	
	// set up variables used for building the correct user prompt
	// default operator is asterisk, and there may be more than
	// one prompt line. (true for binomials/polynomials
	multiplyBy = multiplier;
	userPromptLength = userPrompt.length;
	var asterisk = " * ";
	
	//bts 10132015: leave asterisk blank if divide operation;
	if (document.getElementById("hiddendivision").innerHTML==
		"divide") {
		asterisk="";
	}
	
	//bts 122214: if callerId is absolutevalue, set asterisk to blank
	if (callerId == "absolutevalue") {
		asterisk="";
		multiplyBy="";
	}

	//bts 1024:set combineconstants asterisk to "" regardless
	//		of onePrompt setting.
	if (callerId == "combineconstants" && !onePrompt) {
		asterisk="";
		multiplyBy="";
	}
	
	//bts 01072016: set asterisk to "" if caller is onestep 
	if (callerId == "onestep") asterisk="";

	// bts 110414: blank out asterisk, multiplyBy if
	//	combineliketerms and onePrompt is false (equations)
	if (callerId == "combineliketerms" && !onePrompt) {
		asterisk="";
		multiplyBy="";
	}	
	
	// set up variables for user prompts where there is only 1
	// expected prompt (true for combine terms, simply numeric exp)
	// operator will be passed in from caller
	if (onePrompt) {
		userPromptLength = 1;
		asterisk= "";
		multiplyBy = "";
	}
	
	if (callerId == "simplifynumeric" && !onePrompt) {
		multiplyBy = "";
		asterisk="";
	} else if (callerId=="applyLCD" || callerId == "addFractions" ||
			callerId=="addNumbers"  || callerId=="applyLCDSub") {
		asterisk="";
	}
	
	while (i < userPromptLength) {
		// condition below is a polynomial; 
		// need to set multiplier values
		if (operandTotal>1) {
			if (i<operandTotal) multiplyBy = multiplier[0];
			if (i>=operandTotal) multiplyBy= multiplier[1];	
		}
		// set prompt text to element from userPrompt array
		// or to the complete userprompt string from combine terms
		promptText = userPrompt[i];
		if (onePrompt) promptText = userPrompt;
		// bts 0421: if answer includes a decimal then add rnding
		//		message to prompt
		var rndMsg="";
		var numCalcAns;
		var intAns;
		if (onePrompt) {
			numCalcAns = Number(answer);
		} else {
			numCalcAns = Number(answer[i]);
		}
		// is answer value a decimal?
		// if calc ans is a fraction, then numCalcAns is NaN so leave
		//		rndMsg empty
		if (!isNaN(numCalcAns)){
			intAns=Math.round(numCalcAns);
			if (intAns != numCalcAns) rndMsg=" (Round to 3 places, if necessary)"; //jcs071414 changed text
		}
		
		var rownode=document.createElement("tr");
		rownode.id="row"+i;
		tableElementStart.appendChild(rownode);

		cellnode=document.createElement("td");
		//bts 08042015: create id for prompt cell: row id+prompt id
		promptTD="prompt"+i;
		cellnode.id=rownode.id+promptTD;
		// bts 0421: add rounding message if needed
		//	rndMsg will be empty if no decimals
		cellnode.innerHTML = preprompttext+" "+multiplyBy + asterisk
			+promptText+rndMsg+"? ";
		//jcs205 bold not needed
		//cellnode.style.fontWeight="bold";
		rownode.appendChild(cellnode);
		cellnode2=document.createElement("td");
		cellnode2.id="input"+i;
		inputElement = document.createElement("INPUT");
		inputElement.id="userAns"+i;
		inputElement.innerHTML="";
		inputElement.value="";
		inputElement.size = 25;			
		cellnode2.appendChild(inputElement);
		rownode.appendChild(cellnode2);	
		
		// create checkBox in last cell
		cellnode3=document.createElement("td");
		cellnode3.innerHTML=" ";
		cellnode3.id="checkBox"+i;
		//textElement = document.createElement("text");
		//cellnode3.appendChild(textElement);
		rownode.appendChild(cellnode3);	
		
		//jcs021015 test
		setInputAttributes(i);
		i++;
	}	
	//jcs021015 test	
	setEntryField("userAns0");
	//jcs091615 put focus on userAns0
	document.getElementById("userAns0").focus();
	
	var hiddenText = document.getElementById("hiddenanswertext");
	hiddenText.innerHTML = answer;
	hiddenText.style.display="none";
	var hiddenPosition = document.getElementById("hiddenobjpostext");
	hiddenPosition.innerHTML = objPosArray;
	hiddenPosition.style.display="none";
	var hiddenMultiplier = document.getElementById("hiddenmultipliervalue");
	hiddenMultiplier.innerHTML = multiplier;
	hiddenMultiplier.style.display="none";
	// operandTotal is valid only for polynomials
	//if (operandTotal == null) operandTotal = 1;
	var hiddenCaller = document.getElementById("hiddencaller");
	hiddenCaller.innerHTML = callerId;
	hiddenCaller.style.display="none";
	// counter to track how many times they try to answer
	// initialize answercounter to 0
	var answerCounter = document.getElementById("answercounter");
	answerCounter.innerHTML = 0;
	answerCounter.style.display="none";
	
	// for simplifying numeric expressions, expnOperation contains
	// text describing operation that was performed
	var expnOper = document.getElementById("expressionoperation");
	expnOper.innerHTML = expnOperation;
	//jcs020915 this shouldn't ever display
	//expnOper.style.display="none";
	
	//set the I Give Up button to disabled/grayed out
	document.getElementById("helpwithanswerbutton").disabled=true;
	
	// display the check answer button
	document.getElementById("answerbutton").disabled=false;
	// bts 091214: hide the continue button
	document.getElementById("continuebutton").style.display="none";
	return;
}

function removeParensInStructure() {
	/*
	 * routine removes parentheses/brackets that surround a single term
	 * that has already been added to the structure.
	 * 
	 * Does NOT remove absolute value groupers
	 */
	var i;
	var positions = [];
	// jcs021315 add vars to declarations		
	var pos1=0;
	var pos2=0;
	var counter = 0;
	
	for (i=0;i<elementArray.length;i++) {
		if (elementArray[i].elemtype == "leftgrp" && 
				elementArray[i].string !="|") pos1 = i;
		if (elementArray[i].elemtype == "rightgrp" &&
				elementArray[i].string !="|") {
			pos2 = i;
			if (pos2-pos1 == 2) {
				// save the 2 bracket positions to remove later
				positions[counter] = pos1;
				counter++;
				positions[counter] = pos2;
				counter++;
				// reset pos1 and pos2
				pos1=0;
				pos2=0;
			}
		}		
	}
	/*
	 * if positions array contains values, remove those elements from structure
	 */
	counter= counter-1;
	if (positions.length > 0) {
		for (i=counter;i>-1;i--) {
			elementArray.splice(positions[i],1);
		}
	}
	return;
}

function reposPolyExpn(leftGrp,rightGrp,idxStart,idxEnd)
{
	/*
	 * checks if poly multiplication includes trinomial that 
	 * precedes the multiplier binomial. If so, it positions the
	 * binomial to precede the trinomial in the structure.
	 */
	var positions = [];
	var changedPos = false;
	var triDiff;
	var holdArray;
	
	triDiff = rightGrp[0]-leftGrp[0];//left/right bracket positions
	if (triDiff >4) { // trinomial precedes binomial
		changedPos = true;
		holdArray = elementArray.slice(0,idxStart);
		// insert multiplier binomial
		positions[0] = holdArray.length;
		holdArray = holdArray.concat
					(elementArray.slice(leftGrp[1],rightGrp[1]+1));
		positions[1] = holdArray.length-1;
		// insert asterisk
		holdArray = holdArray.concat(elementArray.slice(leftGrp[1]-1,leftGrp[1]));
		positions[2] = holdArray.length;
		// insert trinomial
		holdArray = holdArray.concat
					(elementArray.slice(leftGrp[0],rightGrp[0]+1));
		positions[3] = holdArray.length-1;
		holdArray = holdArray.concat(elementArray.slice(rightGrp[1]+1));
		
		elementArray = holdArray;
	}
	
	if (!changedPos) positions[0]= -1; //no change in structure elements
	return positions;
}

function solvePolynomial (leftGrp,rightGrp,idxStart,idxEnd) 
{
	/*
	 * 	 expnToSolve: expression string built from elementArray term objects
	 *   leftGrp,rightGrp: arrays holding positions of brackets in elementArray structure
	 *
	 * bts 1227: Do not assume first brackets are multiplier operands, 
	 * check for trinomial and if found, reposition multiplier operands to
	 * precede the trinomial portion.
	 * 
	 */
	
	var i;
	var multiplier=[];
	var j, k;
	var secondColor;
	var newPositions = [];
	var changePos=false;
	
	//bts 1227: call function to check for trinomial and reposition
	//		multipliers if trinomial precedes the multiplier binomial
	newPositions=reposPolyExpn(leftGrp,rightGrp,idxStart,idxEnd);
	if (newPositions[0] != -1) {
		changePos = true;
		var origMultPos=[]; 
		// save orig multiplier positions for highlighting
		origMultPos[0]=leftGrp[1]+1;
		origMultPos[1]=rightGrp[1]-1;
		
		leftGrp[0]=newPositions[0];
		leftGrp[1]=newPositions[2];
		rightGrp[0]=newPositions[1];
		rightGrp[1]=newPositions[3];
	}
	
	// objPosArray holds positions in elementArray for both terms and multipliers
	// 		positions 0,1 in objPosArray are the 2 multipliers;
	//		remaining positions are the multiplicands
	i=0;
	multiplier[0] = leftGrp[i]+1; // first multiplier term location
	multiplier[1] = rightGrp[i]-1; // second multiplier term location
	
	// save the passed in data in main window so poly2 can retrieve it
	// save the 4 pieces of data in hiddenObjPosArray
	// clear hiddenObjPosArray at start of poly2, after reading in vals 
	var idxArray = [];
	var hiddenObjPosArray;
	
	// highlight multiplier positions in original expression 
	// secondColor should be set to some color other than yellow
	
	for (i=0;i<multiplier.length;i++) {
		secondColor = "yellow";
		k=i%2;
		k=k*2;
		if (k!=i) secondColor="deepskyblue";
		if (changePos) {
			writeMultHighlight(origMultPos[i], 1, elementArray.length,secondColor);
		} else {
			writeMultHighlight(multiplier[i], 1, elementArray.length,secondColor);
		}
	}
	
	// add parentheses if there are additional multiplications
	// processing resumes with solvePolynomial1
	var addParensFlag = false;

	// in case first left grouper is position 0, leave it at 0 or
	// do the adjustment to leftGrpFirstPos; same for last rightGrp position
	var leftGrpFirstPos = leftGrp[0]-1;
	if (leftGrpFirstPos <0) leftGrpFirstPos = 0;
	var rightGrpLastPos = rightGrp[1]+1;
	if (rightGrpLastPos > elementArray.length-1) rightGrpLastPos--;
	if (elementArray[leftGrpFirstPos].string == "*" ||
			elementArray[rightGrpLastPos].string == "*") {
		addParensFlag = true;
		var holdArray;
		// insert parens block
		holdArray = elementArray.slice(0,leftGrp[0]+1);
		holdArray = holdArray.concat(elementArray.slice(leftGrp[0],leftGrp[0]+1));
		holdArray=holdArray.concat(elementArray.slice(leftGrp[0]+1,rightGrp[1]+1));
		holdArray=holdArray.concat(elementArray.slice(rightGrp[1],rightGrp[1]+1));
		holdArray=holdArray.concat(elementArray.slice(rightGrp[1]+1));
		elementArray = holdArray;
		//display new array struct
		writeToTable(" -- Applied associative property of multiplication");	
		// highlight new parens
		var color="orange";
		var parenArray = []; // holds new paren positions for highlighting
		parenArray[0] = leftGrp[0];
		parenArray[1] = rightGrp[1]+2;
		for (j=0;j<2;j++) {
			writeMultHighlight(parenArray[j], 1, elementArray.length,color);
		}
		
		// adjust saved values for new right paren position/multiplier positions
		leftGrp[0]++;
		rightGrp[0]++;
		leftGrp[1]++;
		rightGrp[1]++;
		idxStart++;
		idxEnd++;
	}

	// save values to html page for later use
	idxArray[0]=leftGrp;
	idxArray[1]=rightGrp;
	idxArray[2]=idxStart;
	idxArray[3]=idxEnd;
	
	hiddenObjPosArray = document.getElementById("hiddenobjpostext");
	hiddenObjPosArray.innerHTML= idxArray;
	
	if (addParensFlag) {
		// bts 04142014: use associate2 for polynomials
		displayTip("associate2");

		//jcs111 these 2 are iffy
/*		document.getElementById("associateOK").style.display="";
		document.getElementById("associateOK2").style.display="none";
*/		
	} else {
		solvePolynomial1();
	}
		
	return;
} // end of polynomial
	
function solvePolynomial1()
{
	// display intermediate distribution line, wait for user "got it" button
	// before continuing from here. Will resume at function below
	//save intermediate multiplier positions for highlighting
	var multHighLitePos = [];
	var displayStruct;
	var i;
	var multiplier=[];
	var j, k;
	var secondColor;
	var idxArray = [];
	var hiddenObjPosArray;
	var hiddenVals;
	var idxStart, idxEnd;
	var leftGrp=[];
	var rightGrp=[];
	
	// hide button that got us here
	//jcs207 test
	//document.getElementById("associate1").style.display="none";
	displayTip("erase");
	
/*	jcs111 not sure if these are needed
	document.getElementById("associateOK").style.display="none";
	document.getElementById("associateOK2").style.display="none";
*/

	//document.getElementById("distribute1").style.display="";

	// get the saved element array data from hiddenObjPosArray
	hiddenObjPosArray = document.getElementById("hiddenobjpostext");
	hiddenVals = hiddenObjPosArray.innerHTML;	
	
	idxArray = hiddenVals.split(",");

	leftGrp[0]=Number(idxArray[0]);
	leftGrp[1]=Number(idxArray[1]);
	rightGrp[0]=Number(idxArray[2]);
	rightGrp[1]=Number(idxArray[3]);
	idxStart=Number(idxArray[4]);
	idxEnd=Number(idxArray[5]);	

		
	// objPosArray holds positions in elementArray for both terms and multipliers
	// 		positions 0,1 in objPosArray are the 2 multipliers;
	//		remaining positions are the multiplicands
	i=0;
	multiplier[0] = leftGrp[i]+1; // first multiplier term location
	multiplier[1] = rightGrp[i]-1; // second multiplier term location
	
	displayStruct = elementArray.slice(0,leftGrp[0]);
	multHighLitePos[0]=displayStruct.length;
	displayStruct = displayStruct.concat(elementArray.slice
			(multiplier[0],multiplier[0]+1));
	displayStruct = displayStruct.concat(elementArray.slice
			(leftGrp[1],rightGrp[1]+1));
	multHighLitePos[1]=displayStruct.length+1;
	displayStruct = displayStruct.concat(elementArray.slice
			(multiplier[0]+1,multiplier[1]));
	displayStruct = displayStruct.concat(elementArray.slice
			(multiplier[1],multiplier[1]+1));
	displayStruct = displayStruct.concat(elementArray.slice
			(leftGrp[1]));

	// write to table

	writeToTable(" -- 1st distribution",displayStruct);
	
	//jcs119
	displayTip("dist1");

	// highlight multiplier positions in second expression 
	// secondColor should be set to some color other than yellow
	
	for (i=0;i<multiplier.length;i++) {
		secondColor = "yellow";
		k=i%2;
		k=k*2;
		if (k!=i) secondColor="deepskyblue";
		writeMultHighlight(multHighLitePos[i], 1, displayStruct.length,secondColor);
	}
	
	var firstTerm;
	var secondTerm;
	var secondExpression;
	
	firstTerm = elementArray[multiplier[0]].string;
	secondTerm = elementArray[multiplier[1]].string;
	secondExpression = buildStrPart(leftGrp[1],rightGrp[1]);
	
	var term1 = document.getElementById("firstterm");
	var term2 = document.getElementById("secondterm");
	var term3 = document.getElementById("secondexpression");
	term1.innerHTML=firstTerm;
	term2.innerHTML=secondTerm;
	term3.innerHTML=secondExpression;
	
	document.getElementById("distribute1").style.display="";
	document.getElementById("secondexpression").style.display="";
	document.getElementById("firstterm").style.display="";
	document.getElementById("secondterm").style.display="";	
	
	// bts 0624: display distribution tip 2 and dist 2 in 
	//	blackboard at same time as dist 1 blackboard/tip.
	// 	solvePolynomial2 will only set up prompt for answers
	
	solvePoly2Dist2();
	return;
}

function solvePoly2Dist2()
{
	/* 
	 * continuation of solvePolynomial to display distribution
	 * 2 expression in blackboard and tip.
	 */

	// leftGrp,rightGrp: arrays holding positions of brackets in elementArray structure
	// assume first bracket are multiplier operands.
	
	var beginObj, endObj;
	var i;
	var objPosArray = [];
	var multiplier=[];
	var multiplierValue=[];
	var multiplyLeft = true;
	var j, k;
	var ansCtr;
	var userPrompt = [];
	var answer = [];
	var userAns = [];
	var operandTotal;
	var multiplyBy;
	var secondColor;
	var introType;
	var expressionString;
	var idxStart, idxEnd;
	var leftGrp=[];
	var rightGrp=[];
	
	var hiddenObjPosArray;
	var hiddenVals;
	var idxArray=[];
	var moreVals = [];
	var hiddenMoreValsArray;
	
	// hide button that got us here
	//document.getElementById("distribute1").style.display="none";

	// get the saved element array data from hiddenObjPosArray
	hiddenObjPosArray = document.getElementById("hiddenobjpostext");
	hiddenVals = hiddenObjPosArray.innerHTML;	
	
	idxArray = hiddenVals.split(",");

	leftGrp[0]=Number(idxArray[0]);
	leftGrp[1]=Number(idxArray[1]);
	rightGrp[0]=Number(idxArray[2]);
	rightGrp[1]=Number(idxArray[3]);
	idxStart=Number(idxArray[4]);
	idxEnd=Number(idxArray[5]);	

	// clear out hiddenobjpostest before continuing
	hiddenObjPosArray.innerHTML = "";

	//	set up the 2 multipliers
	i=0;
	multiplier[0] = leftGrp[i]+1; // first multiplier term location
	multiplier[1] = rightGrp[i]-1; // second multiplier term location
	
	// bts 0624: save additional values to idxArray for passing
	//	to poly2 routine
	moreVals[0]= multiplier[0];
	moreVals[1]= multiplier[1];
	
	// reverse signs if needed
	var remSubFunc = removeSubtraction(idxStart,idxEnd);
	
	for (i=0;i<2;i++) {
		multiplierValue[i]= elementArray[multiplier[i]].string;
	}
	
	// calculate # of operands outside of multiplier
	operandTotal=(rightGrp[1]-leftGrp[1])/2;
	operandTotal=Math.floor(operandTotal);

	// bts 0624: save additional values to idxArray for passing
	//	to poly2 routine
	moreVals[2]= multiplierValue[0];
	moreVals[3]= multiplierValue[1];
	moreVals[4]= operandTotal;
		
	// build hint string for solving expression
	var answerFormIntroElement;
	answerFormIntroElement=document.getElementById("getanswerintro");
	var hintString="";
	i=0;
	for (k=0;k<operandTotal;k++) {
		if (k==0) {//first operand
			hintString = hintString+elementArray[leftGrp[1]+1].string;
		} else {
			i=k*2+1;
			hintString = hintString+" and "+elementArray[leftGrp[1]+i].string;
		}
	}
	
	objPosArray=expandPolyArray(leftGrp,rightGrp, multiplier,idxStart,idxEnd);
	writeToTable(" -- 2nd distribution");
		
	// highlight multiplier positions in expanded array 
	// add code to change color
	k=objPosArray.length/2;
	for (j=0;j<objPosArray.length;j++) {
		if (j<k) {
			secondColor = "yellow";
		} else secondColor="deepskyblue";		
		writeMultHighlight(objPosArray[j]-2, 1, elementArray.length,secondColor);
	}

	// bts 0624: save new object array vals to hiddenObjPosArray.innerHTML
	// so that solvePolynomial2 can access them
	// save additional needed values in second array
	hiddenObjPosArray.innerHTML=objPosArray;
	
	hiddenMoreValsArray = document.getElementById("hiddenmorevalues");
	hiddenMoreValsArray.innerHTML = moreVals;
	
	return;
}

	
function solvePolynomial2()
{
	/* 
	 * continuation of solvePolynomial
	 * Code for displaying distribution 2 moved to solvePoly2Dist2
	 */

	// leftGrp,rightGrp: arrays holding positions of brackets in elementArray structure
	// assume first bracket are multiplier operands.
	
	var beginObj, endObj;
	var i;
	var objPosArray = [];
	var multiplier=[];
	var multiplierValue=[];
	var multiplyLeft = true;
	var j, k;
	var ansCtr;
	var userPrompt = [];
	var answer = [];
	var userAns = [];
	var operandTotal;
	var multiplyBy;
	var secondColor;
	var introType;
	var expressionString;
	var idxStart, idxEnd;
	var leftGrp=[];
	var rightGrp=[];
	
	var hiddenObjPosArray;
	var hiddenVals;
	var idxArray=[];
	
	// bts 0624: pull in extra hidden values
	var moreVals = [];
	var hiddenMoreVals;
	
	var hiddenMoreValsArray = document.getElementById("hiddenmorevalues");
	hiddenMoreVals=hiddenMoreValsArray.innerHTML;
	moreVals = hiddenMoreVals.split(",");
	
	// hide button that got us here
	document.getElementById("distribute1").style.display="none";

	// get the saved element array data from hiddenObjPosArray
	hiddenObjPosArray = document.getElementById("hiddenobjpostext");
	hiddenVals = hiddenObjPosArray.innerHTML;	
	
	idxArray = hiddenVals.split(",");
	// use objPosArray instead of left/right grp arrays for struct pointers
	for (i=0;i<idxArray.length;i++) {
		objPosArray[i]=Number(idxArray[i]);
	}
	
	// clear out hiddenobjpostest before continuing
	hiddenObjPosArray.innerHTML = "";

	//	set up the 2 multipliers
	// bts 0624: multipliers, multiplierValues
	//		and operandTotal have been saved in moreVals array
	i=0;
	//multiplier[0] = leftGrp[i]+1; // first multiplier term location
	//multiplier[1] = rightGrp[i]-1; // second multiplier term location
	multiplier[0]= Number(moreVals[0]);
	multiplier[1]= Number(moreVals[1]);
	multiplierValue[0]=moreVals[2];
	multiplierValue[1]=moreVals[3];
	operandTotal = Number(moreVals[4]);

	// clear out hiddenMoreValsArray before continuing
	hiddenMoreValsArray.innerHTML = "";
	
	//jcs204 new code
	displayTip("erase");
	//displayTip("dist2");
		
	// build the string representation of the structure to display in getanswerform
	expressionString=buildStrPart(0, elementArray.length-1);
	
	j=0;
	ansCtr = 0;
	k=0;
	// build all user prompt strings first
	while (j < objPosArray.length) {
		userPrompt[k] = elementArray[objPosArray[j]].string;
		j++;
		k++;
	}
		
	k=0;
	i=0;
	j=0; 
	// build all calculated answers
	var multiplierLoc;
	while (j < objPosArray.length) {
		if (j<operandTotal) {
			multiplyBy=multiplierValue[0];
			multiplierLoc = multiplier[0];
		}
		if (j>=operandTotal) {
			multiplyBy=multiplierValue[1];
			multiplierLoc = objPosArray[objPosArray.length/2]-2;
		}
		answer[k] = calcBinomialAns(multiplyBy,objPosArray[j],multiplierLoc);
		k++;
		j++;
	}
	
	j=0;
	var preprompttext="How much is ";
	var onePrompt = false;
	var callerId = "poly";
	introType = 6; //displays expression string at top of getanswer table

	setAnswerPrompt(preprompttext, userPrompt,multiplierValue, answer,
			objPosArray,operandTotal,onePrompt,callerId,expressionString,introType);
	
	return;
}

function expandPolyArray(beginArray, endArray, multiplier,idxStart,idxEnd)
{
	var holdArray; // holds the left/right brackets 
	var i,j;
	var objNewPos = []; // [0]:new beginObj position;[1]:new endObj position;
								// positions 1...: middle objects, if any
								// [last position]: new endObj position
	var multiplierObj=[];
	var objPtr;
	var multNum;
	var holdObjects = [];
	
	// beginArray: left grouper locations
	// endArray: right grouper locations
	i=0;

//	multiplier[0] = beginArray[i]+1; // first multiplier term location
//	multiplier[1] = endArray[i]-1; // second multiplier term location
	
	// use idxStart for new beginning left bracket location
	// use idxEnd for new ending right bracket location
	beginArray[0] = idxStart;
	endArray[1] = idxEnd;
	// second argument to slice must be relative to first arg value.
	holdArray=elementArray.slice(beginArray[0],beginArray[0]+1); // left bracket
	holdArray.splice(1,1,elementArray[endArray[0]+1]); // asterisk
	//holdArray.splice(2,1, elementArray[endArray[0]]); // right bracket
	// set right bracket to endArray[1] location
	holdArray.splice(2,1, elementArray[endArray[1]]); // right bracket
	
	multiplierObj = elementArray.slice(beginArray[0],beginArray[0]+4);
	
	// save objects from the 2nd set
	// create new elements for the term objects from second set, then
	// add these new elements into the element structure at the correct points.
	// new elements to create: beginArray[1]+1, , endArray[1] (or holdObjects 0,2
	
	var copyObj;
	var copyArray = [];
	var m;
	var objIndx=0;
	var termLoc = [];
	i=0;
	holdObjects = elementArray.slice(beginArray[1]+1,endArray[1]);

	i=0;
	j=0;
	termLoc[i]=beginArray[1]+1;
	if (endArray[1]-beginArray[1]>4) {
		var endLimit = (endArray[1] - beginArray[1])/2;

		while (j<=endLimit) {
			i++;
			j=j+2;
			termLoc[i]= beginArray[1]+j+1;
		}
	} else termLoc[1] = endArray[1]-1;
		
	//for (var indx = 0;indx<2;indx++) {
	for (m = 0; m<holdObjects.length;m++) {
		if (holdObjects[m].elemtype=="term") {
			copyObj = new pe(" ");
			copyObj.addElement(holdObjects[m].string,holdObjects[m].elemtype,
	 			holdObjects[m].numerator,holdObjects[m].denominator,holdObjects[m].variable,
	 			holdObjects[m].exponent,holdObjects[m].variable2,holdObjects[m].exponent2,
	 			holdObjects[m].variable3,holdObjects[m].exponent3,holdObjects[m].variable4,
	 			holdObjects[m].exponent4),holdObjects[m].strikenum,holdObjects[m].strikedenom;
			copyArray[objIndx]=copyObj;	
			objIndx++;
			//m=m+2;
		}
	}

	// build expanded expression array
	// use termLoc array to locate respective terms in elementArray
	i=1; // i determines the multiplier to use
	var adjAmt=beginArray[0]+1; // was termLoc[0]-1
	
	while (i>-1){
		j=termLoc.length-1; // j determines the term operand location to multiply
		//objPtr=endArray[i]-1;
		while (j >-1) {
			objPtr=termLoc[j];
			if (i==0) {
				j=-1; //force an exit from loop after processing first multiplier;
				//replace 0 in splice to beginArray[0] in 3 cases below 
				// since we're not always starting at the beginning of 
				// the structure
				switch (copyArray.length) 
				{ 
				case 2:
				elementArray.splice(beginArray[0], termLoc[0]-adjAmt,holdArray[0],multiplierObj[1],holdArray[1],
						copyArray[0],holdArray[2],holdObjects[1],holdArray[0],
						multiplierObj[1],holdArray[1],copyArray[1],holdArray[2]);
				break;
				case 3:
				elementArray.splice(beginArray[0], termLoc[0]-adjAmt,holdArray[0],multiplierObj[1],holdArray[1],
							copyArray[0],holdArray[2],holdObjects[1],holdArray[0],
							multiplierObj[1],holdArray[1],copyArray[1],holdArray[2],
							holdObjects[1],holdArray[0],
							multiplierObj[1],holdArray[1],copyArray[2],holdArray[2]);
				break;
				case 4:
					elementArray.splice(beginArray[0], termLoc[0]-adjAmt,holdArray[0],multiplierObj[1],holdArray[1],
							copyArray[0],holdArray[2],holdObjects[1],holdArray[0],
							multiplierObj[1],holdArray[1],copyArray[1],holdArray[2],holdObjects[1],
							holdArray[0], multiplierObj[1],holdArray[1],copyArray[2],holdArray[2],
							holdObjects[1],holdArray[0], multiplierObj[1],holdArray[1],copyArray[3],holdArray[2]);

					break;
				default:
					alert("More than 4 operands; Is this possible?");
				}
			} else if (i>0) {
				//objPtr=termLoc[j];
				if (j==termLoc.length-1)
					elementArray.splice(objPtr,0,holdArray[0],
							elementArray[multiplier[i]],holdArray[1]);
				if (j==0){
					elementArray.splice(objPtr+1,0,holdArray[2]); //insert right grouper
					elementArray.splice(objPtr,0,
								elementArray[multiplier[i]],holdArray[1]);
					elementArray.splice(objPtr-1,0,holdObjects[1]); //insert plus sign
				} else if (j<termLoc.length-1) {
					elementArray.splice(objPtr+1,0,holdArray[2]); //insert right grouper
					elementArray.splice(objPtr,0,holdArray[0],
							elementArray[multiplier[i]],holdArray[1]);
				}				
			}
			j--;
		} // end j (operand terms) while loop
		i--;
	} // end i (multiplier) loop
	
	//calculate positions of terms 
	j=0;
	// use idxStart position for index to start loop, not 1
	i=idxStart;
	//i=1;
	var bracketPairs = termLoc.length*2;
	var bracketCtr = 0;

	while (i<=elementArray.length-1) {
		if (elementArray[i].elemtype == "rightgrp") bracketCtr++;
		if (bracketCtr < bracketPairs) {
			if (elementArray[i].elemtype == "term" && elementArray[i-1].elemtype=="oper") {
				objNewPos[j]=i;
				j++;
			}
		}
		i++;
	}

	return(objNewPos);
}

//bts 08032015: added 2nd parameter indicating called from
//	addtermtoboth sides with newly added var term; user should not
//	have to do combineliketerms option after adding term w var
function getTermToCombine(newString,addedTermVar) {
	
	var termToCombine;
	var expnPart="";
	var errorCode=0;
	var errMsgText="";
	var idxStart; 
	var idxEnd;
	var idxLength;
	
	//bts 01312016: remove reference to input var from combineliketermsform
	//		- this value will be passed in from holdliketerms as blank if
	//		  constant or set to var user entered
	//var x=document.getElementById("combineliketermsform");	
	var i=0;
	
	// build string version of expression to compare with user-entered string
	var expnToSolve=buildStrPart(0,elementArray.length-1);
	expnToSolve=expnToSolve.toLowerCase();
	var selExpnString = newString;
	selExpnString=selExpnString.toLowerCase();

//jcsa test
	expnPart = newString;
	//bts 08032015: if addedTermVar not null, coming from
	//	addtermtoboth sides and they've added term w variable
	//	set termToCombine to addedTermVar
	// Changed order of code
	document.getElementById("combineliketermsform").style.display="none";	
	if (addedTermVar) {
		termToCombine=addedTermVar;
	} 
	//else {
		//termToCombine =  x.elements[i].value;
	//}
	//document.getElementById("combineliketermsform").style.display="none";	
	// bts 091514: If termToCombine is empty/blank, then 
	//		assume user wants to combine constants.
	if (!termToCombine || termToCombine==" ") {
		// return special msg
		return ("combineconstants");
	}	
	
	// find matching part of expression
	// idxStart is starting point in elementArray
	// idxEnd is ending point in elementArray
	// idxLength is length of portion of elementArray to use
	
	//bts 021715:set idxStart to 0 for entire elementarray struct
	idxStart=0;
	
	var arrayString = "";
	var newIdx;
	if (idxStart < 0) {
		errorCode=13; // Incorrect selection selExpnString
		errMsgText=errorMsg(errorCode,errMsgText,selExpnString);
		return(errMsgText);
	} else if (idxStart >-1) {
		// set default start/end index points into elementArray
		var idxArray = [];
		idxArray = findArrayIndex(idxStart,selExpnString);
		// bts 03192014: finArrayIndex returns -1 if no match
		if (idxArray[0]==-1) { // match not found
			errorCode=13; // Incorrect selection selExpnString
			errMsgText=errorMsg(errorCode,errMsgText,selExpnString);
			return(errMsgText);	
		}
	}
	idxStart = idxArray[0];
	idxEnd = idxArray[1];
	
	// bts 1101: check equations separately from expressions
	//	for equations: continue if either side meets combine
	//	parameters
	//bts 011315: declare errMsg1 outside of block
	//bts 08282015: change errMsg1 to errMsgLeft for clarity
	//	    errMsgLeft holds left side errors; added errMsgRight 
	//		for right side errors. change code to not erase left-side
	//		error tracking if right side has no errors.
	var errMsgLeft="";
	var errMsgRight="";
	if (!equationFlag) {//expression check
		errMsgText = combineTermCheck(idxStart,idxEnd,errMsgText);
	} else if (equationFlag) {//equation check
		//find equality oper
		var equalityOperLoc=findEqualityLocInStruct();
		errMsgLeft = combineTermCheck(idxStart,equalityOperLoc-1,
				errMsgLeft);
		if (errMsgLeft) { // check right side if left NOT ok
			errMsgRight=combineTermCheck(equalityOperLoc+1,
					idxEnd,errMsgRight);
		} else {//bts 011315:left side has no errors; check right 
				// in case of absol val bars
			errMsgRight=combineTermCheck(equalityOperLoc+1,
					idxEnd,errMsgRight);
		}
		//bts 10282015: combining err msgs or set errMsgText to blank
		//	if error on only 1 side of equation
		if (errMsgLeft && errMsgRight) {
			//both sides have an error
			errMsgText=errMsgLeft+errMsgRight;			
		} else if (!errMsgLeft || !errMsgRight) {
			errMsgText="";
		}
	}
	//bts 10282015: combine err msgs is just for equations, so move up		
	//errMsgText=errMsgLeft+errMsgRight;		
	// if selected expression is valid, verify terms can be combined
	// also pass in the begin/end points within the array structure
	
	// bts 0929: reset errMsgText after displaying the error
	if (errMsgText)  {
		displayErrMsg(errMsgText);
		errMsgText="";
	} else {
		// bts 1101: branch to different combine routine for equations
		if (!equationFlag) {
			errMsgText=combineLikeTerms(termToCombine,idxStart,idxEnd,errMsgText);
		} else {
			errMsgText=combineEqLikeTerms(termToCombine,equalityOperLoc,errMsgText);
		}
	}
	
	document.getElementById("combineliketermsform").style.display="none";
	document.getElementById("simplifyMenu").selectedIndex=0;
	document.getElementById("equationMenu").selectedIndex=0;

	return(errMsgText);
}

function combineConstantsCheckAddOpers(idxStart,idxEnd,errMsgText)
{
	/*
	 * checks for more than 1 add operator for combining constants
	 * 
	 */
	var addSignCt=0;
	var j;
	var errorCode;
	
	if (idxStart>0) idxStart--;
	var constantCount=0;

	// bts 08032015: count number of plus signs between terms
	//	that are constants
	for (j=idxStart;j<idxEnd+1;j++) {
		if (elementArray[j].elemtype=="term" &&
				elementArray[j].variable==null) { 
			constantCount++;
		}
		//jcs090215 subtraction test
		//if (elementArray[j].elemtype == "oper" && 
		//		elementArray[j].string=="+") {
			
		if (elementArray[j].elemtype == "oper" && 
			(elementArray[j].string=="+"||elementArray[j].string=="-")) {
						
			addSignCt++;
		}
	}
	//bts 08052015: change test for addSignCt, constantCount
	if (constantCount<2 || addSignCt<1) {
		errorCode=21;//only 1 term to combine
		errMsgText=errorMsg(errorCode,errMsgText);
	}
	return(errMsgText);
}

function combineTermCheck(idxStart,idxEnd,errMsgText) {
	var j;
	var errorCode;
	var errMsgText;
	
	if (idxStart>0) idxStart--;
	
	//bts 020815: line below may be wrong; comment out
	//if (idxEnd<elementArray.length-1) idxEnd++;
	
	//	keep count of terms that may be combined
	// if term preceded by * or divide, do not include
	//	if term not preceded by * or/, followed by + or -: include
	// if term count is less than 2: error
	var multErrFlag=[];
	var multiplyErrorChecked=false;
	
	//bts 021915: comment out unneeded code in loop below
		
	for (j=idxStart;j<idxEnd+1;j++) {
		if (elementArray[j].elemtype == "oper") {
			//if (elementArray[j].string == "*" || elementArray[j].string == "\u00F7")
			//{ 
				// check if there are additional terms that may be combinable
				// before automatically exiting
				if (!multiplyErrorChecked) {
					multErrFlag=checkForCombinableTerms(idxStart,idxEnd);
					multiplyErrorChecked=true;
					if (multErrFlag[0]==-1) {
						errorCode = 26; //can't combine terms if multiply/divide 
						errMsgText=errorMsg(errorCode,errMsgText);
					}
				}
			//}
		}
		// bts 021915: skip grouper tests below
		//bts 011415: allow exception for absol val bars for equations
		/*
		if (elementArray[j].elemtype == "leftgrp") { 
			if (equationFlag && elementArray[j].string=="|") {
				//allow
			} else if (j >idxStart) {
				errorCode = 27; //can't combine terms across brackets 
				errMsgText=errorMsg(errorCode,errMsgText);	
			}
		} else if (elementArray[j].elemtype == "rightgrp") {
			if (equationFlag && elementArray[j].string=="|") {
				//allow
			} else if (j <idxEnd) {
				errorCode = 27; //can't combine terms across brackets 
				errMsgText=errorMsg(errorCode,errMsgText);	
			}	
		}
		*/
		// bts 0930: exit the loop if there's an error
		if (errMsgText) j=idxEnd+1;
	}
	return(errMsgText);
}

function combineLikeTerms(termToMatch,idxStart,idxEnd,errMsgText){

	// check entered expression for matching variables/exponents
	// if there's a match, prompt for answer
	// expression should only be a term (such as: x, xy, x^2,x^2y...)
	// Combining constants will be a different function.
	
	var terms;
	var termOnly=false;
	var matchString;
	var matchPositions = [];
	var correctAns = false;
	var calcAns;
	var highlightColor;
	var errorCode;
	var errMsgText="";

	matchString = termToMatch;
	matchString=matchString.toLowerCase();	
	
	// get all terms entered
	terms = parseString(matchString,4);
	if (terms == null) {
		errorCode=15; // Enter a term to combine
		errMsgText=errorMsg(errorCode,errMsgText);
	} else {
		//if (terms.length == matchString.length) termOnly = true;
		// bts020614: remove terms, termOnly from variableMatch parameters
		matchPositions = variableMatch(matchString,idxStart,idxEnd);	

		//matchPositions = variableMatch(matchString,terms,termOnly,idxStart,idxEnd);	
							//terms has only variables
							// matchString has variables + exponents, if any
		if (matchPositions.length <= 1) {
			if (matchPositions.length == 0) {
				errorCode=19; // term doesn't match expression terms
				errMsgText=errorMsg(errorCode,errMsgText);
			}
			if (matchPositions.length == 1) {
				errorCode=20; // Expression has only 1 term that matches your term.
				errMsgText=errorMsg(errorCode,errMsgText);
			}
		} else if (matchPositions.length > 1) {
			// prompt for answer
			// highlight the terms to combine before prompting for answer
			highlightColor = "orange";
			for (j=0;j<matchPositions.length;j++){
				writeMultHighlight(matchPositions[j],1,elementArray.length,highlightColor);
			}
	
			combineTermsAnswer(matchPositions,matchString);	
			// write out answer from getUseranswer
		}
	}
	
	if (errMsgText) {
		displayErrMsg(errMsgText);
		//jcs119 bring back the menu
		document.getElementById("operationMenuArea").style.display="";
	}
	//errMsgText=""
;	return(errMsgText);
}

function combineTermsAnswer(positions,matchString){
	/*  
	 * prompt for combining terms answer
	 */
	var calcAns, userAns, holdAns;	
	var holdAnsNum, calcAnsNum;
	var promptString="";
	var i;
	var correctAnswer = false;
	var numTotal = 0;
	var calcAnsString;
	var signOper, subtractOper;
	var signPosition;
	
	var tipString=[];
	var tipCtr=0;

	holdAns=0;
	calcAns=0;
	holdAnsNum=0;
	calcAnsNum=0;
	subtractOper = false;

	// bts010714: 
	//	  - calculate answer for fraction coefficients
	//	  - distribute coefficients in prompt for user's answer
	var fractionPresent=false;
	var denomArray=[];
	var lcd, lcdMultiplier;
	var calcAnsHint;
	
	// check for fractions
	for (i=0;i<positions.length;i++) {
		denomArray[i]=elementArray[positions[i]].denominator;
		if (elementArray[positions[i]].denominator > 1) {
			fractionPresent=true;
		}
	}
	// if there are fractions, set denominators to common denom
	// build array of denoms and call calculateLCD
	if (fractionPresent) {
		lcd = calculateLCD(denomArray);
		tipString[tipCtr]="Convert fractions to common denominator: "+String(lcd);
	}
	
	//bts 09102015: remove prompting as (coeff+coeff)variable format
	//	and return to coeff-var format: 2x+3x
	for (i=0;i<positions.length;i++) {
		//bts 09102015: restore old prompt string using string field from
		//		element array
		promptString = promptString+elementArray[positions[i]].string;
		/* bts 09102015: comment out coeff formatting
		// build prompt as (coeff+coeff)variable format using
		// denoms (if fractions) before applying lcd
		// Build answer AFTER converting fractions to lcd
		
		if (i==0) promptString="(";
		if (fractionPresent && elementArray[positions[i]].denominator != 1) {
			promptString = promptString+String(elementArray[positions[i]].numerator)
				+"/"+String(elementArray[positions[i]].denominator);
		} else {
			promptString = promptString+String(elementArray[positions[i]].numerator);
		}
		
		if (i==positions.length-1) {//last portion of prompt
			promptString=promptString+")"+matchString;
		}
		*/
		// calculate answer
		if (fractionPresent) {// calculate answer for fraction
			lcdMultiplier = lcd/elementArray[positions[i]].denominator;
			holdAnsDenom=lcd;
			holdAns=elementArray[positions[i]].numerator*lcdMultiplier;
			
			//bts010814: Add to tipString array for fractions
			tipCtr++;
			tipString[tipCtr]=String(elementArray[positions[i]].numerator)+"/"
				+ String(elementArray[positions[i]].denominator)+" * "
				+String(lcdMultiplier)+"/"+String(lcdMultiplier)+
				" = "+ String(holdAns)+"/"+String(lcd);
		} else {
			holdAns = elementArray[positions[i]].numerator;
		}

		if (subtractOper) {
			calcAns = Number(calcAns)-Number(holdAns);
			numTotal = Number(numTotal)-Number(holdAns);
		} else {
			calcAns = Number(calcAns)+Number(holdAns);
			numTotal = Number(numTotal)+Number(holdAns);
		}

		if (i<positions.length-1) {
			signPosition = positions[i+1]-1;
			signOper = elementArray[signPosition].string;
			if (signOper == "-") {
				subtractOper=true; 
			} else {
				subtractOper=false;
			}
			
			promptString = promptString+" "+signOper+" ";
		}
	}

	// if calculated answer is -1 or 1, then do not display the 1 in the string
	// if calculated answer is 0, then what?
	if (!fractionPresent) {
		if (calcAns == 1) {
			calcAns = matchString;
		} else if (calcAns == -1) {
			calcAns = calcAns.toString()+matchString;
			calcAnsString = calcAns.replace("-1","-"); // remove 1 and leave - sign
			calcAns = calcAnsString;
		} else if (calcAns == 0) {
			matchString="";
		} else {
			calcAns= calcAns.toString()+matchString;
		}
	} else if (fractionPresent) {
		// bts011114: use calcAnsHint for displaying tip with space betwn coeff & var.
		if (calcAns == lcd) {
			calcAns = 1;
			lcd=1;
			calcAns = matchString;
			calcAnsHint = calcAns;
		} else if (calcAns == -1) {
			calcAnsHint = calcAns.toString()+"/"+String(lcd)+" "+matchString;
			calcAnsHint = calcAns.replace("-1","-");
			//set up calc answer for getuseranswer
			calcAns = calcAns.toString()+"/"+String(lcd)+matchString;
			calcAnsString = calcAns.replace("-1","-"); // remove 1 and leave - sign
			calcAns = calcAnsString;
		} else if (calcAns == 0) {
			matchString="";
			lcd = 1;
			calcAnsHint="0";
		} else {
			calcAnsHint= calcAns.toString()+"/"+String(lcd)+" "+matchString;
			calcAns= calcAns.toString()+"/"+String(lcd)+matchString;
		}
		tipCtr++;
		tipString[tipCtr] = "Then combine coefficients as indicated: "+calcAnsHint;
	}
	
	if (tipCtr>0) {//write tip string array to html but don't display it
		var tipElement=document.getElementById("fractioncombinetip");
		tipElement.style.display="none";
		tipElement.innerHTML="";
		for (i=0;i<tipCtr+1;i++) {
			tipElement.innerHTML=tipElement.innerHTML+"<ul>"+tipString[i]+"</ul>";
		}
	}
	//jcs119 changed the following prompt text
	//jcs081115 Let's shorten the prompt
	//var preprompttext="Combine the coefficients for the like term. How much is: ";
	var preprompttext="How much is: ";
	// bts 091214: set up tip in setAnswerPrompt for 
	//		combining coefficients where there are fractions;
	//		also set expnOperation to empty;
	//		Add expnOperation and introType to 
	//		setAnswerPrompt parameter list
	var expnOperation="";
	var introType;
	if (fractionPresent)introType=9;
	var multiplier = 1;
	// last parameter indicates combine like terms
	// is the calling function
	var onePrompt = true;
	var callerId = "combineliketerms";
	// bts 091214: add expnOperation, introType parameters
	//		only introType is set if term coeff is fraction
	setAnswerPrompt(preprompttext,promptString,multiplier, 
			calcAns,positions,1, onePrompt,callerId,
			expnOperation,introType);
	i=0;

	// write correct answer to blackboard (in calling routine)
	// and update elementArray structure
	// replace first element in structure with correct answer
	// remove second element and its preceding operator; repeat
	// if there are additional elements that were combined.
	// elements may not be sequential!

	if (fractionPresent) {
		elementArray[positions[0]].numerator=numTotal;
		elementArray[positions[0]].denominator=lcd;
		elementArray[positions[0]].string=calcAns;
	} else {
		elementArray[positions[0]].string = calcAns;
		elementArray[positions[0]].numerator = numTotal;
	}
	for (i=positions.length-1;i>0;i--) {
	//for (i=1;i<positions.length;i++) {
		elementArray.splice(positions[i]-1,2);
	}
	
	// remove brackets that surround a single term
	removeParensFromStruct();
	
	// bts 020714: remove term whose calculated result is 0
	// if only 1 remaining term, then set its vals to zero/null 
	//		instead of removing it
	if (numTotal==0) {
		elementArray[positions[0]].variable=null;
		elementArray[positions[0]].variable1=null;
		elementArray[positions[0]].variable2=null;
		elementArray[positions[0]].variable3=null;	
	}
	// if structure is 2 operands,oper + or -, and 1 operand=0, 
	//	remove operand that is 0 and operator
	if (elementArray.length==3) {
		testForZeroOperand();
	}
	
	return;
}

function testForZeroOperand()
{
	/*
	 * Called when structure has only 3 elements remaining.
	 * If one operand is 0 and opers are either + or -,
	 * removes the zero operand and operator
	 */
	
	if (elementArray[1].string=="+" || elementArray[1].string=="-") {
		if (elementArray[2].numerator == 0) {
			elementArray.splice(1);
		} else if (elementArray[0].numerator == 0) {
			elementArray.splice(0, 2);
		}
	}

	return;
}

function removeParensFromStruct() {
	/*
	 * function checks elementArray for single terms surrounded by brackets.
	 * If there are, it removes the brackets
	 */
	var i;
	var positions = [];
	var ctr=0;
	
	for (i=0;i<elementArray.length-2;i++) {
		//bts 012215: do not remove brackets if absol val bars
		if (elementArray[i].elemtype == "leftgrp" &&
				elementArray[i].string !="|") {
			if (elementArray[i+2].elemtype == "rightgrp") {
				positions[ctr] = i;
				ctr++;
				positions[ctr] = i+2;
				ctr++;
			}
		}
	}
	for (i=positions.length;i>0;i--) {
		elementArray.splice(positions[i-1],1);
	}
	
	return;
}

function variableMatch(matchTerm, idxStart,idxEnd) {
/*
 * matchTerm: contains terms + caret symbol + exponent values, if any
 * termsToMatch: just terms, no exponent vals
 * termOnly: if true, no exponents were entered
 */	
	
	var positions = [];
	var i, j, posCtr;
	var elemString;
	var termNoDigit;

	posCtr = 0;
	
	// idxStart, idxEnd - elementArray start, end points
	for (i=idxStart;i<idxEnd+1;i++) {
		if (elementArray[i].elemtype == "term" && 
				elementArray[i].variable != null) {//skip if term is number only
			elemString = String(elementArray[i].string);
			for (j=0;j<elemString.length;j++) {
				if (isNaN(elemString[j])) {
					if (j==0 && elemString[0]=="-") {
						// treat minus sign as digit				
					} else if (elemString[j]=="/"){
						// bts 0820: fix bug with fractions and variables
						// treat slash as digit
					// bts 102014: allow decimal point; treat as digit
					} else if (elemString[j]==".") {
						// treat decimal point as digit
					} else {//term string is now variables+exponents only
						termNoDigit=elemString.slice(j);
						j=elemString.length;
					}
				}
			}
			if (termNoDigit == matchTerm) {
				positions[posCtr] = i; //save elementArray location
				posCtr++;
			}
		} // check elementArray term element variables		
	} // loop thru all elementarray elements
	
	return(positions);
}

function combineConstants(newString)
{
	/*
	 * search elementArray structure for constants: terms that 
	 * do not have variables associated with them.
	 * if more than 1 constant, build prompt and calculate answer
	 * replace elements in array with correct answer, write out
	 * resulting structure/expression
	 */
	var matchPositions = [];
	var userPrompt = "";
	var correctAns = false;
	var calcAns = new Number(0); 
	var holdAns;
	var i, counter, plusPtr;
	var errorCode, errMsgText;
	
	errMsgText = "";
	
	var signOper,subtractOper;
	
	counter = 0;
	calcAns = 0;
	holdAns = 0;
	
	//var x=document.getElementById("simplifypartform");	
	var i=0;
	// get selected expression part		
	// build string version of expression to compare with user-entered string
	var expnToSolve=buildStrPart(0,elementArray.length-1);
	expnToSolve=expnToSolve.toLowerCase();
	//var selExpnString = expnPart.join("");
	var selExpnString = newString;
	selExpnString=selExpnString.toLowerCase();
	
	//bts 10162015: remove outdated code; 
	//	declare idxStart, idxEnd vars
	var idxStart, idxEnd;
	var idxArray=[];
		 
	// find matching part of expression
	// idxStart is starting point in elementArray
	// idxEnd is ending point in elementArray
	// idxLength is length of portion of elementArray to use
	idxStart=expnToSolve.indexOf(selExpnString);
	var arrayString = "";
	var newIdx;
	if (idxStart < 0) {
		errorCode=13; // Incorrect selection selExpnString
		errMsgText=errorMsg(errorCode,errMsgText,selExpnString);
		//return(errMsgText);
	} else if (idxStart >-1) {
		// set default start/end index points into elementArray
		var idxArray = [];
		idxArray = findArrayIndex(idxStart,selExpnString);
		// bts 03192014: finArrayIndex returns -1 if no match
		if (idxArray[0]==-1) { // match not found
			errorCode=13; // Incorrect selection selExpnString
			errMsgText=errorMsg(errorCode,errMsgText,selExpnString);
			return(errMsgText);	
		}
	}
	
	//jcs1201 changed test
	//if (errMsgText == "") {
	if (!errMsgText) {
		idxStart = idxArray[0];
		idxEnd = idxArray[1];
		
		// check if selected expression is valid--does not span brackets 
		//    and does not include multiply or divide operation
		
		errMsgText = combineTermCheck(idxStart,idxEnd,errMsgText);
		// bts 0929: return if error
		if (errMsgText) return(errMsgText);
	}
	
	// bts 082314: use these vars for Give Up tip for fraction conversion
	var tipString=[];
	var tipCtr=0;
	var fractionPresent=false;
	var denomArray=[];
	var lcd, lcdMultiplier;
	var calcAnsHint;
	var j; 
	var numTotal;
	var positions = [];
	var holdAnsDenom;
	
	// bts 040715: save lcd for whole numbers
	var saveLCD;
	
	// bts 082314: check for fractions outside of constant calc loop below; 
	// build tip if found; set up lcd number
	
	//bts 021915: check for combinable constants and save positions in array
	var constantPositions=[];
	//bts 10162015: set idxStart, End to default positions
	//idxStart=0; //start of expression
	//idxEnd=elementArray.length-1;
	constantPositions=
		checkForCombinableTerms(idxStart,idxEnd);
	j=0;
	if (constantPositions[0]!=-1) {
		for (var k=0;k<constantPositions.length;k++) {//constant positions
			i=constantPositions[k];
			// bts 021915: keep same code below
			//for (i=idxStart;i<idxEnd+1;i++) {
			if (elementArray[i].elemtype == "term" && 
					elementArray[i].variable == null) { //constant term
				// build array of denominators	
				denomArray[j]=elementArray[i].denominator;
				positions[j]=i;
				j++;
				if (elementArray[i].denominator > 1) 
					fractionPresent=true;
			}	
		}
	}
	
	//call calculateLCD if there are fractions
	if (fractionPresent) {
		lcd = calculateLCD(denomArray);
		// bts 040715: save lcd for whole numbers
		saveLCD=lcd;
		tipString[tipCtr]="Convert fractions to common denominator: "+String(lcd);
	}
	
	if (!errMsgText) {
		//for (i=0;i<elementArray.length;i++) {
		subtractOper = false;

		// bts 082314:use constant positions within structure 
		for (i=0;i<positions.length;i++) {
			// bts 082314: build prompts differently for fractions
			// build prompt using
			// denoms (if fractions) before applying lcd
			// Build answer AFTER converting fractions to lcd
		
			if (i==0) { // first constant
				if (fractionPresent && elementArray[positions[i]].denominator != 1) {
					userPrompt = userPrompt+String(elementArray[positions[i]].numerator)
								+"/"+String(elementArray[positions[i]].denominator);
				} else {
					userPrompt = userPrompt+elementArray[positions[i]].string;
				}					
			} else { // subsequent constants
				if (elementArray[positions[i]-1].string == "-") {
						signOper = " - ";
						subtractOper = true;
				} else if (elementArray[positions[i]-1].string == "+") {
						signOper = " + ";
						subtractOper = false;
				}
						
				userPrompt = userPrompt+signOper+elementArray[positions[i]].string;
			}
			if (fractionPresent) {// calculate answer for fraction
				//bts 040715: use saveLCD instead of lcd; then reset lcd to saveLCD
				//lcdMultiplier = lcd/elementArray[positions[i]].denominator;
				//holdAnsDenom=lcd;
				lcdMultiplier = saveLCD/elementArray[positions[i]].denominator;
				holdAnsDenom=saveLCD;
				lcd=saveLCD;
				holdAns=elementArray[positions[i]].numerator*lcdMultiplier;
					
				//bts010814: Add to tipString array for fractions
				tipCtr++;
				tipString[tipCtr]=String(elementArray[positions[i]].numerator)+"/"
						+ String(elementArray[positions[i]].denominator)+" * "
						+String(lcdMultiplier)+"/"+String(lcdMultiplier)+
						" = "+ String(holdAns)+"/"+String(lcd);
			} else {
				holdAns = elementArray[positions[i]].numerator;
			}
			if (subtractOper) {
				calcAns = Number(calcAns)-Number(holdAns);
			} else {
				calcAns = Number(calcAns)+Number(holdAns);
			}
			
			if (fractionPresent) {
				// bts011114: use calcAnsHint for displaying tip
				if (calcAns == lcd) {
					calcAns = 1;
					lcd=1;
					calcAnsHint = calcAns;
				} else if (calcAns == 0) {
					lcd = 1;
					calcAnsHint="0";
				} else {
					calcAnsHint= calcAns.toString()+"/"+String(lcd);
					//calcAns= calcAns.toString()+"/"+String(lcd);
				}
			}
		}
		tipCtr++;
		tipString[tipCtr] = 
			"Then add the fraction numerators and change the denominator. Answer is: "
			+calcAnsHint;
		// bts 091514: fix error for positions.length.
		//		should be length <=1, not <=0
		//if (positions.length <=0) {
		if (positions.length <=1) {
			if (positions.length == 0) {
				errorCode=21; // expression has no constants to combine
				errMsgText=errorMsg(errorCode,errMsgText);
			}
			if (positions.length == 1) {
				errorCode=22; // Expression has only 1 constant
				errMsgText=errorMsg(errorCode,errMsgText);
			}
		} else if (positions.length > 1) {
			// highlight the terms to combine before prompting for answer
			var highlightColor = "orange";
			for (i=0;i<positions.length;i++){
				writeMultHighlight(positions[i],1,elementArray.length,highlightColor);
			}
			
			// insert answer in last position; remove other constant terms
			var lastConstantLoc = positions.length-1;
			elementArray[positions[lastConstantLoc]].numerator = calcAns;
			if (fractionPresent) elementArray[positions[lastConstantLoc]].denominator=lcd;
			if (!fractionPresent) {
				elementArray[positions[lastConstantLoc]].string = calcAns.toString();
			} else { //fraction so set string properly; set calcAns to string version
				elementArray[positions[lastConstantLoc]].string =calcAnsHint;
				calcAns=calcAnsHint;
			}
			for (i=positions.length-2;i>-1;i--) {
				if (positions[i]==0) {
					if (elementArray[positions[i]+1].string=='-') {
						elementArray[positions[i]+2].string = '-'+	
							elementArray[positions[i]+2].string;
						elementArray[positions[i]+2].numerator=
							Number(elementArray[positions[i]+2].numerator)*-1;
					}
					elementArray.splice(positions[i],2);
				} else {
					elementArray.splice(positions[i]-1,2);
				}
			}			
			// remove parens surrounding single term, if any
			removeParensFromStruct();
				
			if (tipCtr>0) {//write tip string array to html but don't display it
				var tipElement=document.getElementById("fractioncombinetip");
				tipElement.style.display="none";
				tipElement.innerHTML="";
				for (i=0;i<tipCtr+1;i++) {
					tipElement.innerHTML=tipElement.innerHTML+"<ul>"+tipString[i]+"</ul>";
				}
			}

			//jcs081115 Let's shorten the prompt
			//var preprompttext="Combine these constants: ";
			var preprompttext="How much is: ";
			// bts 091214: set up tip in setAnswerPrompt for 
			//		combining fraction constants;
			//		also set expnOperation to empty;
			//		Add expnOperation and introType to 
			//		setAnswerPrompt parameter list
			var expnOperation="";
			var introType;
			if (fractionPresent)introType=10;

			var onePrompt = true;
			var callerId = "combineconstants";
			var multiplier = 1;
			
			// bts 082314: use positions instead of matchPositions
			// bts 091214: add expnOperation, introType to 
			//		setAnswerPrompt parameter list
			setAnswerPrompt(preprompttext,userPrompt,multiplier, 
					calcAns,positions,1,onePrompt,callerId,
					expnOperation,introType);			
		}
	}
	
	// bts 112514: change to display instructions; commented out errMsg block 
	document.getElementById("userInstructions").style.display="";

	return(errMsgText);
}

function solveSimpleMult(beginObj,endObj,errMsgText) {
	/* 
	 * performs simple multiplication for algebraic expressions
	 * expects 2 operands and one operator, no brackets.
	 * Expected format: operand * operand
	 */	
		var i,j;
		var userAns;	
		var promptString="";
		var positions = [];
		
		//bts 10142015: divide hidden vars
		var divideOper;
		var divideSide;

		// check for any errors in selected portion of expression
		
		// verify that middle element is multiply operation
		if (elementArray[beginObj+1].elemtype != "oper" ||
				elementArray[beginObj+1].string != "*") {
			errorCode = 30;
			errMsgText=errorMsg(errorCode,errMsgText);
		}	
		// check that first/last elements are terms
		if (elementArray[beginObj].elemtype != "term" || 
				elementArray[endObj].elemtype != "term") {
			errorCode = 29;
			errMsgText=errorMsg(errorCode,errMsgText);
		} 
		
		// extract the 2 terms to use for multiplication
		if (!errMsgText) {
			//bts 10132015: set prompt to divide sign if we're
			//		doing division; divideOper=divide if true
			//	flip second term back to its orig orientation
			//	(in structure, term is flipped as if for multiply)
			//	added div side var: first is left side; second=right side
			divideOper=document.getElementById("hiddendivision").innerHTML;
			divideSide=document.getElementById("hiddendivisionside").innerHTML;

			// build user prompt string first
			positions[0] = beginObj;
			positions[1] = endObj;
			var formattedPrompt;
			for (i=0;i<positions.length;i++) {
				//bts 11052015: if divide operation and 2nd term
				//	flip numerator/denominator for prompt display only
				//	Before call to setSpecialTextEffects, reset struct element
				//	to flipped state (switch num and denom temporarily, then 
				//	switch back after special effects applied
				var termString;
				if (divideOper=="divide" && i==1) {//2nd term
					//bts 11052015: switch numerator and denominator, then restore	
					var currentNum,currentDenom;
					var negNum=1;//indicates positive number
					currentNum=elementArray[positions[1]].numerator;
					currentDenom=elementArray[positions[1]].denominator;
					if (currentNum<0) {//negative number
						negNum=-1;
					}
					elementArray[positions[1]].numerator=currentDenom*negNum;
					elementArray[positions[1]].denominator=currentNum*negNum;
					termString=flipDivisorStringOnly(positions[1]);
					//call specialtext effects before restoring num, denom vals
					formattedPrompt = setSpecialTextEffects(termString,positions[i],"solveSimpleMult");
					//restore numerator and denominator vals
					elementArray[positions[1]].numerator=currentNum;
					elementArray[positions[1]].denominator=currentDenom;
				} else {
					termString = elementArray[positions[i]].string;
					//bts 11052015: call special effects for non-divide prompts
					formattedPrompt = setSpecialTextEffects(termString,positions[i],"solveSimpleMult");
				}
				//formattedPrompt = setSpecialTextEffects(termString,positions[i],"solveSimpleMult");
				promptString = promptString+formattedPrompt;
				//promptString = promptString+elementArray[positions[i]].string;
				if (i<positions.length-1) {
					//bts 10132015: if divide oper, set oper to divide sign
					if (divideOper=="divide") {
						promptString = promptString+" \u00F7 ";						
					} else {
						promptString = promptString+" * ";
					}
				}
			}

			// now figure out the variable/exponent portion of the answer
			var multiplier =elementArray[positions[0]].string;
			var multiplicandPos = positions[1];
			var answer = [];

			answer = calcBinomialAns(multiplier,multiplicandPos,positions[0]);

			// highlight the part we're operating on
			//bts 10142015: skip highlighting if doing second/right division
			var color = "yellow";
			if (divideOper=="divide" && divideSide == "second") {
				//skip highlighting
			} else {
				for (j=positions[0];j<positions[1]+1;j++) {
					writeMultHighlight(j, 1, elementArray.length,color);
				}
			}
						
			var preprompttext="How much is: ";
			var onePrompt = true;
			var callerId = "simplemultiply";
			setAnswerPrompt(preprompttext,promptString,multiplier, 
					answer,positions,1, onePrompt,callerId);
		}
		
	return(errMsgText);
}

function flipDivisorStringOnly(termPos)
{
	/*
	 * bts 10132015: new function
	 * flips the divisor for building divide by prompt correctly
	 * Passes back the new numerator/denom string but does not
	 * touch the structure
	 * 
	 * termPos is the element in the structure
	 * 
	 */
	
	var newString="0";
	var numerator,denominator;
	
	numerator=elementArray[termPos].numerator;
	denominator=elementArray[termPos].denominator;
	
	//bts 11032015: build whole number or fraction
	/* old code
	if (numerator<0) {
		newString="-"+String(denominator)+"/"+String(numerator);
	} else if (numerator==1) {
		newString=String(denominator);
	} else if (numerator>1) {
		newString=String(denominator)+"/"+String(numerator);
	} 
	*/
	if (numerator<0) {//negative number
		if (denominator==1) {
			newString=String(numerator);
		} else {
			newString=String(numerator)+"/"+String(Math.abs(denominator));
		}
	} else if (denominator==1) {//whole number
		newString=String(numerator);
	} else if (denominator>1) {
		newString=String(numerator)+"/"+String(denominator);		
	}
	
	return(newString);
}

function updateBlkBoardSimple(objPosArray) {
	/* 
	 * updates the blackboard display with new expression and
	 * updates the elementArray structure for algebraic expressions
	 * for simple multiplication (no brackets or expanded arrays as with
	 * 	binomials/polynomials)
	 * routine does following:
	 * 	first convert objPosArray to numbers
	 * 	remove element array objects no longer needed
	 * 	remove objects in reverse order (from end of array)
	 */
	var j;
	var numObjPosArray = [];
	for (j=0;j<objPosArray.length;j++) {
		numObjPosArray[j] = Number(objPosArray[j]);
	}
		
	j=objPosArray.length-1;	
	//answer should be in the 2nd term position and there should only be 
	// 3 elements affected by the multiplication operation
	// remove the previous 2 elements from the array (1stterm and oper)
	while (j>0) {
		elementArray.splice(numObjPosArray[j]-2,2); // objects to left of term
		j--;
	}
	
	//bts 11082015: remove any multiplications by 1 
	removeMultByOneFromStruct();
	
	//bts 121214: remove parens around single term, just in case
	removeParensFromStruct();
		
	// check if expression is completely solved
	var solved; 
	var expnSolved="";
	
	// bts 111214: handle checking equations differently
	if (!equationFlag) solved = checkForMoreWork();
		
	//bts 10142015: if this is special divide and doing left side
	//	where div side=first, skip writing out to table
	if (document.getElementById("hiddendivision")
			.innerHTML==""){
		// write out answer and operaton msg
		writeToTable(" -- After multiplication");
	} else if (document.getElementById("hiddendivisionside")
			.innerHTML=="second") {//write divide message
		writeToTable(" -- After division");
		document.getElementById("hiddendivisionside").innerHTML="";
		document.getElementById("hiddendivision").innerHTML="";
	}	
	// bts 09292015: if solved, check for last fraction to simplify
	//	and/or mixed number to convert. Copied code from updateBlackBoard
	if (solved && selExpType==20) {	
		var fractionToSimplify=[];
		// check if structure includes any terms w/fraction to simplify
		fractionToSimplify=checkForFractionToSimplify();
		if (fractionToSimplify.length>0) {
			solved=false; // fraction found
			simplifyAlgFraction(fractionToSimplify);
			document.getElementById("operationMenuArea").style.display="none";
	        document.getElementById("getanswerform").style.display="none";
	        //set callerId to simplifylastalgfract--this is special case
	        document.getElementById("hiddencaller").innerHTML="simplifylastalgfract";
	        return(solved);
		}
	}
	
	if (solved) {
		elementArray.splice(0);
		writeToTable(" ** Exercise completed successfully! **");
	       //jcs107
	       resetAfterSolved();
	}

	return(solved);	
}
	
function findArrayIndex(idxStart,selExpnString) {
	
	var arrayString = "";
	var newIdx;
	var j;
	var idxEnd;
	var idxArray = [];
	var startPt, diff;
	
	var foundMatch = false;
	var possibleMatch = false;
	
	// bts 111414: start scanning equation either up to equality operator
	//		or after equality operator. 
	//		Adjust for loop variable to equality operator location
	//		if left side of equation, start loc is 0
	//		if right side of equation, start loc is eq oper loc+1.
	//		end pt can be elementArray length in either case
	//		Use eqOpLoc as startPt of 0 for expressions or actual
	//			equality oper loc for equations
	var eqStartLoc=0; // loop starting pt for equations(eq oper loc)
					// or 0 for expressions
	//bts 10162015: set end location for equations: end pt is equality sign
	//				set to length of elementArray if expression
	var eqEndLoc=elementArray.length;//not used
	
	
	if (equationFlag) {
		eqStartLoc=findEqualityLocInStruct();
		//bts 021015: set start loc to 0 if idxstart is less than or = to equality sign
		// Build string from structure; mark equality location; determine if
		//	selected string matches left or right side of equation
		var equalitySign=elementArray[eqStartLoc].string;//eq oper
		var fullEqString=buildStrPart(0,elementArray.length-1);
		var eqOperLocInString=fullEqString.indexOf(equalitySign);
		//bts 021715: reformat selExpnString in case of inequality opers
		selExpnString=fixCompareOper(selExpnString);
		var eqSelectionLoc=fullEqString.indexOf(selExpnString);
		if (eqSelectionLoc==-1 || eqOperLocInString==-1) {
			idxArray[0]=-1;//error condition
			return(idxArray);
		//bts 10162015: set start/end loc relative to eq oper location
		//  	in structure: doesn't work
		} else if (eqSelectionLoc<eqOperLocInString) {
			//eqEndLoc=eqStartLoc+1;//set end to 1 more than eq oper loc
			eqStartLoc=0;//equation left side
		} else {//selection on right side of eq oper, so leave end loc
				//as the end of the structure length		
			eqStartLoc++; //first element of eq right side
		}
	}
	//bts 10162015: use eqEndLoc as the idxEnd mark: will be elementArray
	//	length if expression or right side eq; else will be eq oper loc
	//idxEnd = eqEndLoc-1;
	idxEnd = elementArray.length-1;

	//bts 111414: set startPt to eqStartLoc for both expressions/equations
	//startPt = 0;
	startPt=eqStartLoc;
	idxStart=startPt;

	//bts 111414: reset loop start to eqStartLoc
	for (j=eqStartLoc;j<elementArray.length;j++) {
		arrayString = arrayString+elementArray[j].string;
		if (arrayString == selExpnString && !foundMatch) {
			idxEnd = j;
			foundMatch = true;
			//bts1216 set startPt if there's a match on substring
			// and no previous possible matches
			if (!possibleMatch) {
				idxStart=startPt-1;
				//bts 111414 use eqStartLoc instead of 0
				//if (idxStart<0) idxStart=0;
				if (idxStart<eqStartLoc) idxStart=eqStartLoc;
			}		
		}
		if (!foundMatch) {
			newIdx = selExpnString.indexOf(arrayString);
			//bts1216 starting point match should be 0; if not 0, then
			// this is a false match; this may not work
			//if (newIdx == 0){
			if (newIdx > -1 && newIdx <= j) {
				if (!possibleMatch) {
					//bts 111414: use eqStartLoc instead of 0
					//if (startPt == 0) startPt = 1;
					if (startPt == eqStartLoc) startPt = eqStartLoc+1;

					//idxStart = Math.max(0,startPt-1);
					idxStart = Math.max(eqStartLoc,startPt-1);
					startPt = j;
					possibleMatch = true;
				}
			} else {
				possibleMatch = false;
				arrayString = "";
				// bts1216 add chars referenced by pointer j if j >startPt
				// increment startPt within loop adding these chars to 
				// arrayString
				arrayString = arrayString+elementArray[startPt].string;
				if (j>startPt) {
					while (startPt<j) {
						startPt++;
						arrayString=arrayString+elementArray[startPt].string;
					}
					//bts 02212014: fix error in starting point for struct match
					startPt--;
				} else {
					startPt++;
				}
				// current element is now first element to test for a match
			}
		}
	}
	// bts 03192014: return -1 if no match found
	if (foundMatch) {
		idxArray[0]=idxStart;
		idxArray[1]=idxEnd;
	} else {// no suitable match found
		idxArray[0]=-1;
	}
	//bts 10162015: if not found,
	//	check for suitable match by looking for * opers
	if (!foundMatch) {
		idxArray=findArrayIndexByMultiplier(eqStartLoc,selExpnString);
	}

	return (idxArray);
}

function findArrayIndexByMultiplier(startLoc,selExpnString)
{
	/*
	 * bts 10172015: new function: finds start/end points
	 * for selected expn string in the structure using * oper as
	 * guide
	 * 
	 * startLoc is starting element in the elementArray
	 * 	if 0: left side of equation or expression
	 *  if >0: right side of equation
	 */	
	
	var i;
	var endLoc;
	var astLoc;
	var testString="";
	var idxPts=[];
	
	endLoc = elementArray.length;
	idxPts[0]=-1;

	for (i=startLoc;i<endLoc-1;i++) {
		if (elementArray[i].string=="*") {
			//build string from struct to test against selection
			astLoc=i;
			testString=buildStrPart(astLoc-1,astLoc+1);
			if (testString==selExpnString) {
				idxPts[0]=astLoc-1;
				idxPts[1]=astLoc+1;
				i=endLoc+1;
			}
		}
	}	
	return (idxPts);
}

function errorMsg(errorCode,errMsgText,moreText) {
	/*
	 * function converts error code to an error message
	 */
	var moreText;
		
	switch (errorCode) 
	{
	case 1:
		errMsgText = errMsgText+"You entered too many variables.";
		break;
	case 2:
		errMsgText = errMsgText+"You cannot have one operator after another.";
		break;
	case 3:
		errMsgText = errMsgText+"You need to insert a term between the absolute value signs.";
		break;
	case 4:
		errMsgText = errMsgText+
			"Each left parenthesis must be paired with a right parenthesis.";
		break;
	case 5:
		errMsgText = errMsgText+
		 	"You cannot enter an operator in front of a right parenthesis.";
		break;
	case 6:
		errMsgText = errMsgText+"Each left square bracket must be paired with a right square bracket.";
		break;
	case 7:
		errMsgText=errMsgText+"You cannot enter two minus signs at the start of an expression.";
		break;
	case 8:
		errMsgText=errMsgText+"You cannot have an operator at end of expression.";
		break;
	case 9:
		errMsgText=errMsgText+"You cannot have an operator before a right bracket. Did you leave out a term?";
		break;
	case 10:
		errMsgText=errMsgText+"Each left square bracket must be paired with a right square bracket.";
		break;		
	case 11:
		errMsgText=errMsgText+"Each left parenthesis must be paired with a right parenthesis.";
		break;	
	case 12:
		errMsgText=errMsgText+"Each absolute value sign is paired with the next absolute value sign. You have an odd number of absolute value signs.";
		break;		
	case 13:
		errMsgText=errMsgText+"Your selection "+moreText + " is incorrect.  The selection should be the " +
				"two terms and operator that come next in the recommended order.";
		//bts 08142015:save error msg to hw storage
		writeToStorage(errMsgText.fontcolor("red").bold());
		break;	
	case 14:
		errMsgText=errMsgText+"You must enter an expression.";
		break;	
	case 15:
		//bts 02012016 changed error message
		errMsgText=errMsgText+"You have to enter the like variable(s) in the term to be combined.";
		break;	
	case 16:
		errMsgText=errMsgText+
			"You have gone over the limit for bracketed groups in an algebraic expression.";
		break;	
	//jcs1023 This may change
	case 17:
		errMsgText=errMsgText+"You need to select two terms to be operated on.";
		break;	
	case 18:
		errMsgText=errMsgText+"You need to enter a second multiplier.";
		break;	
	//jcs0414
	case 19:
		// bts 02012016: changed error msg
		errMsgText=errMsgText+
			"You did not enter a like term in the expression.";
			//"The variable combination you entered is not in a like term in the expression.";
		break;
	case 20:
		// bts 091514: changed selection to expression for error msg
		errMsgText=errMsgText+
		"The variable you entered has no like terms in the expression.";
		//"The variable you entered has no like terms in the selection.";
//jcs1023			"\n-Expression has only 1 term that matches your term.";
		break;	
	case 21:
		// bts 07272015 changed error message from constants to like terms
		errMsgText=errMsgText+
			"The like term you entered doesn't work.";
		break;	
	case 22:
		// bts 07272015 changed error message from constants to like terms
		errMsgText=errMsgText+
			//"The expression you highlighted has only one constant.";
			"The like term you entered doesn't work.";

		break;	
	case 23:
		errMsgText=errMsgText+
			"You entered a letter or special character. Numeric expressions may only contain numbers and operators.";
		break;	
	case 24:
		errMsgText=errMsgText+
			"An expression must contain at least two operands and one operator.";
		break;	
	case 25:
		errMsgText=errMsgText+
			"An expression cannot include invalid characters or blank spaces.";
		break;	
	case 26:
		errMsgText=
			"You cannot combine terms or constants until multiply/divide operations are completed.";
		//bts 08142015: save error msg to hw storage
		writeToStorage(errMsgText.fontcolor("red").bold());
		break;	
	case 27:
		errMsgText=errMsgText+
			"You cannot combine terms or constants across brackets.";
		//bts 08142015: save error msg to hw storage
		writeToStorage(errMsgText.fontcolor("red").bold());
		break;
	case 28:
		//jcs111914 changed message
		errMsgText=errMsgText+
			"You did not select two terms that can be multiplied.";
		break;
	case 29:
		errMsgText=errMsgText+
			"The selected expression must start or end with a term.";
		break;
	case 30:
		errMsgText=errMsgText+
			" The selected expression must have an asterisk between the two terms to be multiplied.";
		break;
	case 31:
		errMsgText=errMsgText+
			"There was an added expression that you didn't find!";
		break;
	case 32:
		errMsgText=errMsgText+
			"There were no added expressions!";
		break;
	case 33:
		errMsgText=errMsgText+
			"There was a subtracted expression that you didn't find!";
		break;
	case 34:
		errMsgText=errMsgText+
			"There were no subtracted expressions!";
		break;
	case 35:
		errMsgText=errMsgText+
			"There were subtractions that you didn't find!";
		break;
	case 36:
		errMsgText=errMsgText+
			"There were no subtractions!";
		break;
	case 37:
		errMsgText=errMsgText+
			"There are no variables in your expression. Either add a variable" +
			" or click Start another exercise.";
		break;
	case 38:
		errMsgText=errMsgText+
			"You entered an equals or inequality symbol. Change the exercise type or the expression. ";
		break;
	// bts 04142014: added 2 new error msgs for multiplying
	//		algebraic expressions
	case 39:
		errMsgText=errMsgText+
			"Your selection does not include a multiplication operator.";
		break;
	case 40:
		errMsgText=errMsgText+
			"You selected too many operators.";
		break;
	
	case 41:
		errMsgText=	"The expression does not include multiplication.";
		break;
	case 42:
		errMsgText=	"There are no like terms that can be combined.";
		break;

	case 43:
		errMsgText=	
			"Currently you cannot use divide in algebraic expressions.";
		break;
		
	case 44:
		errMsgText = 
			"Reenter expression using correct operators:  *, +, -, ^, \u00F7. ";
		break;
		
	case 45: //bts 120114: change to equation must have variables
		//errMsgText = "Equations must have an equality sign.";
		errMsgText = "Equations must contain at least 1 variable.";
		break;
		
	case 46:
		errMsgText = "Equations can have only 1 equality sign.";
		break;

	case 47:
		errMsgText = "You cannot divide by 0.";
		break;

	case 48://bts 121514: alg expns cannot include abol vals
		errMsgText = "The app cannot currently simplify algebraic expressions that "+
					"include variables within absolute value markers.";
		break;

	case 49://bts 121714: absol vals in equations, alg expns cannot have
			// more than 2 terms
		errMsgText = "The app does not handle equations or algebraic expressions "+
					"with more than 2 terms within absolute value markers.";
		break;
		
	case 50://bts 031315: cannot handle alg expns with complex numerators in fractions
		errMsgText = "Math Assister cannot yet handle complex numerators in algebraic expressions.";
		break;

	case 51://bts 41315: complex denominator and cannot cross multiply with this expression
		errMsgText = "To enter a proportion problem you must select Fraction Expression.";
		break;

	case 52://bts 41315: cannot cross multiply alg expressions
		errMsgText = "Math Assister cannot yet handle these types of algebraic expressions.";
		break;

	case 53://bts050115: proportions cannot have more than 1 var or be quadratic expn
		errMsgText = "Proportions are limited to 1 variable, cannot include negative numbers," +
				" and cannot be raised to a second power.";
		break;
		
	//bts 08212015: added more than 1 term expression for add to both sides
	case 54:
		errMsgText="You can only add a single term at one time.";
		break;

	case 55:
		errMsgText="An added term for an equation can only contain 1 variable.";
		break;

	//bts 09172015: added msg for having term in multiply/divide options
	//	this is not yet supported
	case 56:
		errMsgText="You cannot multiply or divide both sides by a variable at this time.";
		break;
		
	//bts 11232015: new msg for plotting points problems
	case 57:
		errMsgText="An equation for this type of problem must have an " +
				"x and y variable and an equals sign.";
		break;

	//bts 02012016: new msg for plotting points problems
	case 58:
		errMsgText="Choose an option.";
		break;

	default:
		errMsgText = "\n-Bad input";
	}
	return(errMsgText);
}

function displayErrMsg(errMsgText, errorLocale) {
	/*
	 * displays any error messages that occurred
	 */
	errMsgText=errMsgText+"\n\nTry again.";
	//jcs1023 test
	//alert(errMsgText);
	var errorToDisplay=document.getElementById("warningMessage");
	errorToDisplay.innerHTML = errMsgText;
	
	//jcs119 test
	if (errorLocale=="entry") {
		document.getElementById("problemEntryArea").style.display="";
		//bts 031315: fix display if re-entering initial problem
		document.getElementById("workarea").style.display="";
		document.getElementById("whatToDoNextArea").style.display="none";
		//jcs111015 explanationArea test
		//document.getElementById("explanationArea").style.display="none";
		document.getElementById("stepExplanation").style.display="none";
	} else if (errorLocale=="combineterm") {
		//bts 02012016: display combineliketerms form properly
		document.getElementById("operationMenuArea").style.display="none";		
		document.getElementById("combineliketermsform").style.display="";		
	} else {
		//jcs209 test
		document.getElementById("whatToDoNextArea").style.display="";
		document.getElementById("userInstructions").style.display="";
		//jcs103014: handle equation errors
		//bts120514: added selexptype=32
		if (selExpType == 20 || selExpType == 30 || selExpType==32) {
			document.getElementById("operationMenuArea").style.display="";
		} else {
			if (errorLocale != "mixednum") 
				document.getElementById("generalHighlight").style.display="";	
			
				//jcs012715 new keypad
				document.getElementById("mobileEntryField").focus();
		}
	}
	return;
}

//jcs10052014 hide help area and main window
function closegetstart() {
	document.getElementById("getstarted").style.display="none";
	document.getElementById("helparea").style.display="";
	document.getElementById("mainblackboard").style.display="";
	//jcs012715 put focus on entryfield
	document.getElementById("problementryfield").focus();
	return;
}

//jcs10132014 Stubbed out function for handling equation selections from the menu
function getEquationOp()
{
	//bts 10142015: save current structure to prevStepsArray
	setUpEquationStruct();
	
	var errMsgText=" ";
	
	var equationOpList=document.getElementById("equationMenu");
	var opType=equationOpList.options[equationOpList.selectedIndex].value; 
	//jcs111314  test document.getElementById("operationMenuArea").style.display="none";
	document.getElementById("operationMenuArea").style.display="";
	
	// bts 1021: reset option menu to default
	//jcs111314 test   document.getElementById("equationMenu").selectedIndex=0;

	var newString="";
	var windowContent;
		
	//jcs10132014 Do we need this? Probably
	document.getElementById("combineliketermsform").style.display="none";
	clearAnswerFormTable();
	document.getElementById("getanswerform").style.display="none";

	// blank out error message
	var errorToDisplay=document.getElementById("warningMessage");
	errorToDisplay.innerHTML = ""; 
		
	// hide tip
	displayTip("erase");
	
	// hide menu. Bring it back if there's an error
    document.getElementById("operationMenuArea").style.display="none";
 
	//bts 10282015: enable the Go Back button
	document.getElementById("gobackbutton").disabled=false;

    //bts 121114: check if equation is already solved and needs only
    //		fraction simplified or true/false prompt
    if (elementArray.length==2) {
    	var processFlag=checkForEqSolved();
    	if (processFlag !=0) return;
    }    
	switch (opType)
	{	
	case "301": //Multiply part of an expression
		//jcs10132014 The following content is from getSimplyOp and may need to be changed
		windowContent = window.getSelection();
	    newString = String(windowContent);
	    newString = newString.replace(/\s/g,"");
		document.getElementById("generalHighlight").style.display="none";
	    
	    if (newString == "") {
	    	var entireString = buildStrPart(0,elementArray.length-1);
	    	var astPtr = entireString.indexOf("*");
	    	if (astPtr == -1) {
	    		var errCode = 41;
	    		errMsgText = errorMsg(errCode,errMsgText);
				displayErrMsg(errMsgText);
				errMsgText="";
				document.getElementById("operationMenuArea").style.display="";
				//jcs111314 test   document.getElementById("equationMenu").selectedIndex=0;
				document.getElementById("equationMenu").style.display="";
	    	} else {
	    		//jcs111314  test document.getElementById("operationMenuArea").style.display="none";			
				//jcs111814 test document.getElementById("generalHighlight").style.display=""; 
				document.getElementById("multiplyPart").style.display="";
	    	}
		}  
	    if (newString !== "") {
			errMsgText=simplifyAlgExpPart(newString);
			if (errMsgText) {
				displayErrMsg(errMsgText);
				errMsgText="";
				document.getElementById("operationMenuArea").style.display="";
				//bts 091514: reset simplifymenu option to the default
				//jcs111314 test   document.getElementById("equationMenu").selectedIndex=0;
				document.getElementById("equationMenu").style.display="";
			} else {
				//jcs111314  test document.getElementById("operationMenuArea").style.display="none";			
				//jcs111814 test document.getElementById("generalHighlight").style.display=""; //jcs090914 test
				displayTip("multiplyOneSide");  //jcs092815 is this used?

				//jcs111814 test document.getElementById("generalHighlight").style.display=""; 
				document.getElementById("multiplyPart").style.display="none";			
			}
	    }
		break;
		
	case "302": //Combine like terms for equations
		
		//jcs10132014 The following content is from getSimplyOp and may need to be changed		
		//bts 091514: Combine 2 options (combineliketerms and 
		//		combineconstants) into 1 "combine terms" function
		//		First branch to combineLikeTerms; if user does not
		//		enter a like term variable, then assume they're
		//		doing combine constants.
		
		// bts 0929: check for plus/minus signs; if none found, 
		// display error msg and prompt for different option
		
		// bts 1022: if equation, get equality sign location
		//		then check both sides separately for plus/minus opers
		//		Continue processing if either side has +- opers
		var eqLoc;
		if (equationFlag){
			eqLoc=findEqualityLocInStruct();
		}
		var plusMinusCtr=0;
		// bts 1022: change loop delimiters below for possible equations
		// do oper check twice: first left side, then right side
		var loopStart=0; // default vals for expressions
		var loopEnd=elementArray.length-1; //default for expression
		var operCheckEq=1; // default loop of once for expressions
		
		if (equationFlag) {
			loopEnd=eqLoc-1;
			operCheckEq=2;
		}
		
		for (var j=0;j<operCheckEq;j++) {// loop once for expressions;
										 // twice for equations
			//for (var i=0;i<elementArray.length-1;i++) {
			for (var i=loopStart;i<loopEnd;i++) {
				if (elementArray[i].elemtype == "oper") {
					if (elementArray[i].string == "+" || 
							elementArray[i].string == "-") {
						plusMinusCtr++;
					} 
				}	
			}
			if (operCheckEq==2) {//now check right side of equation
				loopStart=eqLoc+1;
				loopEnd=elementArray.length-1;
			}
		}
		if (plusMinusCtr == 0) {
			// no combine operations
			var errorCode=42;
			var errMsgText = errorMsg(errorCode,errMsgText);
			displayErrMsg(errMsgText);
			errMsgText="";
			document.getElementById("operationMenuArea").style.display="";
			document.getElementById("equationMenu").selectedIndex=0;
			//jcs111314 test   document.getElementById("equationMenu").selectedIndex=0;
			document.getElementById("equationMenu").style.display="";
		} else {// there are plus/minus sign(s) so continue
			displayTip("liketerms");
	
			//jcs1120 if user has already highlighted expression then just combine the like terms
	        windowContent = window.getSelection();
		    newString = String(windowContent);
		    newString = newString.replace(/\s/g,""); 
			document.getElementById("combineliketermsform").reset();
			document.getElementById("combineliketermsform").style.display="";
			// bts 090814: no need to highlight expression for like term
			//document.getElementById("likeTermHighlight").style.display="";
		
			// bts 090814: set newString to entire expression and continue
			//  remainder of combining terms should work with no other changes
			newString=buildStrPart(0,elementArray.length-1);
			if (newString ) {
				var holdExpression = document.getElementById("hiddenliketermexpn");
				holdExpression.innerHTML = newString;
				//jcs1208 hide hidden variable for expression selection
				holdExpression.style.display="none";
				//document.getElementById("likeTermHighlight").style.display="none";
				// bts 090814: put focus on liketerm input field
				//jcs013116 test
				//document.getElementById("liketerm").focus();
			}	else {
				//jcs1208 hide go button
				document.getElementById("liketermbutton").style.display="none";
				//jcs013116 test
				//document.getElementById("liketerm").focus();
			}	
		}
		//jcs121014 remove document.getElementById("bothSidesMenu").selectedIndex=0;
		break;
	
	case "303": //Change a fraction The user highlights a fraction to be simplified
		//Just get the numerator and the denominator and ignore variables
		{
		
		}
		break;	
		
	//jcs031815 Solve using cross products		
	case "306": //Write to table annotation: "Write equation for cross products"
		//If you have (a+1)/(b+2)=(c+3)(d+4) change it to:
		//(a+1)*(d+4)=(c+3)(b+2)
		//Note that if any denominator or numerator is 1, show it in the next line and then drop it.
		{
		
		}
		break;	
		

	case "310": //jcs121014 Changed to add to both sides
	{
		document.getElementById("addToBothSidesArea").style.display="";
		//jcs021715 put focus on input field
		document.getElementById("addToBothSidesField").focus();
		displayTip("addtobothsides");
	}
	break;

	case "316": //jcs090215 Subtraction test
	{
		document.getElementById("subtractFromBothSidesArea").style.display="";
		document.getElementById("subtractFromBothSidesField").focus();
		displayTip("addtobothsides");
	}
	break;
	
	case "317": //jcs090215 Subtraction test
	{
		document.getElementById("divideBothSidesArea").style.display="";
		document.getElementById("divideBothSidesField").focus();
		displayTip("dividebothsides");
	}
	break;

	case "311": //Use cross products
		//The rules are that there can only be one term on each side of the equation and
		//there must be at least one slash operator
		//Display the next line on the board is as follows
		//On the left side, we have the left numerator * right denominator
		//On the right side, we have the left denominator * the right numerator
		//If a denominator is 1, then just display the numerator by itself
		//Display the getanswerform and ask the how much question. Skip it
		//for any cases where the denomiator is 1
		//Then display the results on the board
		{
		
		}
	break;

	case "312": //Replace a variable with a number
		//We need to display all the variables similar to the evaluate form 
		//and let the user replace one or more of the variables with numbers
		//bts 112014: branch to replace vars with vals function

    	document.getElementById("operationMenuArea").style.display="none";        
		document.getElementById("evaluateexpressionform").style.display="";
		document.getElementById("whatToDoNextArea").style.display="";
		document.getElementById("userInstructions").style.display="";
    	document.getElementById("workarea").style.display="";
			
    	var expnArray=[];
    	var expnString=buildStrPart(0,elementArray.length-1);
    	expnArray=parseString(expnString,1);
		doAlgExpn(expnArray);
		// clear out equationvarprompt innerhtml later
		break;
	
	case "313": //Test for True or False. I need to design this
		//The user enters an equation or inequality (also called a number sentence)
		//and we have to test if it is true or false 
		{
		
		}		
		break;

	
	case "314": //Check for an identity or unsolvable equation. I need to design this
		//basically we need to check that if the same variable appears on either side 
		//of the equation. If the constants are the same, then the equation is an identity
		//If the constants are different, then the equation is unsolvable		
		{
		
		}
		
		break;
		
	case "315": //jcs121014 Changed to Multiply both sides
	{
		document.getElementById("multiplyBothSidesArea").style.display="";
		//jcs021715 put focus on input field
		document.getElementById("multiplyBothSidesField").focus();
		displayTip("multiplybothsides");
	}
	break;
	
	case "320": //Split eqs w vars within abol val bars into 2 equations
		{
		//disable the split option
	    document.getElementById("splitoption").disabled=true;
	    //bts 011615: enable the 2 multiply options 
	    document.getElementById("multiplyboth").disabled=false;
	    document.getElementById("multiplypart").disabled=false;
	    /*
	     * split equation into 2 equations:
	     * - remove absol val bars
	     * * 1st equation: same as orig without absol val bars
	     * * 2nd equation: one side without bars but reverse all signs on 
	     * 		opposite side fronm abol val bars; hide 2nd equation 
	     * 		in "hiddensecondexpn" until
	     * 		first one solved (add check when checking for eq solved)
	     */
	    splitEquation();//removes absol val bars; does the split

	    //display the menu
	    //bts 020415: if solving single absol val, don't display normal menu
	    if (document.getElementById("hiddensingleabsolval").innerHTML
	    		!="absolutevalue") {
			document.getElementById("operationMenuArea").style.display="";
			document.getElementById("equationMenu").selectedIndex=0;
	    }
		} //end of split option case
		break;	
	}
	// bts 1021: reset sub menu options to default
	//jcs111314 test    document.getElementById("bothSidesMenu").selectedIndex=0;
	return;
}

//jcs042015 new fraction entry functions
function displayFracForm()
{
	document.getElementById("fracentry").style.display="";
    //jcs121415 test remove following statement
	 //   document.getElementById("fractionexpression").style.display="none";
	document.getElementById("stdentry").style.display="none";
	document.getElementById("numerator1field").focus();
	//jcs042815 display proportion tip
	//jcs111015 explanationArea test
	//document.getElementById("explanationArea").style.display="";
	document.getElementById("stepExplanation").style.display="";

	//jcs071415 hide evaluate button
	document.getElementById("enableevaluate").style.display="none";

	displayTip("proportion");
	findAudio("proportion");
	return;
}

//jcs070315 return to std entry
function displayStdForm()
{
	document.getElementById("fracentry").style.display="none";
    //jcs121415 test remove following statement
	 //   document.getElementById("fractionexpression").style.display="";
//jcs11222015 test
	document.getElementById("stdentry").style.display="";
	//bts 11302015: comment out xyentry for now
	//document.getElementById("xyentry").style.display="";
	document.getElementById("problementryfield").focus();
	//jcs042815 display proportion tip
	//jcs111015 explanationArea test
	//document.getElementById("explanationArea").style.display="none";
	document.getElementById("stepExplanation").style.display="none";
	
	//jcs071415 display evaluate button
	document.getElementById("enableevaluate").style.display="";
	document.getElementById("whatToDoNextArea").style.display="none";

	displayTip("erase");
	//findAudio("proportion");
	return;
}

function enterFraction()
{
/*	var num=document.getElementById("numeratorfield");
	var denom=document.getElementById("denominatorfield");
	num=num.value;
	denom=denom.value;
	var entry=document.getElementById("entryfield");
	entry=entry.value;
	document.getElementById("entryfield").value = entry+"("+num+")/("+denom+")";
	document.getElementById("entryfield").focus();
	document.getElementById("numeratorfield").value="";
	document.getElementById("denominatorfield").value="";
*/	
    //jcs121415 test remove following statement
	 //   document.getElementById("fractionexpression").style.display="";
	document.getElementById("fracentry").style.display="none";

	return;
}

//jcs012715 new function to set entryfield 
function setEntryField(fieldID){	
	var hiddenentryfield=document.getElementById("hiddenentryfield");
	var entryfield=document.getElementById("hiddenentryfield").innerHTML;	
	if (entryfield!=fieldID) {
		hiddenentryfield.innerHTML=fieldID;
	}
	return (fieldID);
}

//jcs013116 new function 
function typeInEntryField(fieldID){
	setEntryField(fieldID);
	document.getElementById(fieldID).focus();
//	alert("Keyboard entry test");
}

//jcs091115 test key depress
function getKeyDepress(event, fieldID){
	var key=event.which;
	if (key==13) {
/*		var fieldCtr=Number(fieldID.charAt(7));
		var newCtr=fieldCtr+1;
		newFieldID="userans"+String(newCtr);
		document.getElementById(fieldID).blur();
		document.getElementById(newFieldID).focus();
*/
		switch (fieldID) 	{	
		case "userAns0":
		case "userAns1":
		case "userAns2":
		case "userAns3":
		case "userAns4":
		case "userAns5":
		case "userAns6":
		case "userAns7":
		case "userAns8":
		case "userAns9":
			validateAnsEntered();
			break;
		case "problementryfield":
			getEntry('std');
			break;
		case "mobileEntryField":
			removeBlanks();
			break;
		case "converttolcdinput0":
		case "converttolcdinput1":
		case "converttolcdinput2":
		case "converttolcdinput3":
		case "converttolcdinput4":
		case "converttolcdinput5":
		case "converttolcdinput6":
		case "converttolcdinput7":
		case "converttolcdinput8":
		case "converttolcdinput9":
			getCommonDenomConversion();
			break;
		case "liketerm":		//jcs100215 added return function for combining like terms
			holdLikeTerm();
			break;					
		}

	} else {
		return;
	}
}


//jcs111014 new functions for  keypad
function getKey(keyselection)
{
//	alert("Key pad test2");
	
	var hiddenentryfield=document.getElementById("hiddenentryfield");
	var entryfield=document.getElementById("hiddenentryfield").innerHTML;
	var entryvalue=document.getElementById(entryfield).value;
	
	//entryvalue = entryvalue+keyselection;		
	//document.getElementById("entryfield").value = entryvalue+keyselection;		
	//document.getElementById("entryfield").innerHTML = entryvalue+keyselection;
	document.getElementById(entryfield).value = entryvalue+keyselection;
	document.getElementById(entryfield).innerHTML = entryvalue+keyselection;		

	//jcs020415 test
//	document.getElementById(entryfield).focus();

//	alert("Key pad test3");

	return;	
}

function clearKPEntry()
{
	//jcs012715 new keypad 
	var hiddenentryfield=document.getElementById("hiddenentryfield");
	var entryfield=document.getElementById("hiddenentryfield").innerHTML;
	var entry=document.getElementById(entryfield).value;
	entry = entry.slice(0, -1);
	document.getElementById(entryfield).value=entry;
	document.getElementById(entryfield).focus();
	return;	
}


function toggleShow(togglecmd) {

	if (togglecmd=="eq") {
		var toggleButton=document.getElementById("eqtoggle");
	} else {
		var toggleButton=document.getElementById("eqtoggle2");
	}
	
	var toggleValue=toggleButton.value;
	if (toggleValue=="Hide the steps for equations") { //jcs072315 change to hide advanced equation steps
		toggleButton.value="Show the steps for equations"; 
		document.getElementById("equationTipPart2").style.display="none";				
	}	else {
		toggleButton.value="Hide the steps for equations";  //jcs072315 change to hide advanced equation steps
		document.getElementById("equationTipPart2").style.display="";				
	}
}

//jcs091115 added this line to appropriate cases
//document.getElementById("userAns0").setAttribute("onkeypress", "getKeyDepress(event, 'userAns0')");			
function setInputAttributes(i){
	switch (i) 	{	
	case 0:
		document.getElementById("userAns0").setAttribute("onclick", "typeInEntryField('userAns0')");
		document.getElementById("userAns0").setAttribute("onfocus", "setEntryField('userAns0')");	
		document.getElementById("userAns0").setAttribute("onkeypress", "getKeyDepress(event, 'userAns0')");			
		break;
	
	case 1:
		document.getElementById("userAns1").setAttribute("onclick", "typeInEntryField('userAns1')");
		document.getElementById("userAns1").setAttribute("onfocus", "setEntryField('userAns1')");			
		document.getElementById("userAns1").setAttribute("onkeypress", "getKeyDepress(event, 'userAns0')");			
		break;
	
	case 2:
		document.getElementById("userAns2").setAttribute("onclick", "typeInEntryField('userAns2')");
		document.getElementById("userAns2").setAttribute("onfocus", "setEntryField('userAns2')");			
		document.getElementById("userAns2").setAttribute("onkeypress", "getKeyDepress(event, 'userAns0')");			
		break;
	
	case 3:
		document.getElementById("userAns3").setAttribute("onclick", "typeInEntryField('userAns3')");
		document.getElementById("userAns3").setAttribute("onfocus", "setEntryField('userAns3')");			
		document.getElementById("userAns3").setAttribute("onkeypress", "getKeyDepress(event, 'userAns0')");			
		break;
	
	case 4:
		document.getElementById("userAns4").setAttribute("onclick", "typeInEntryField('userAns4')");
		document.getElementById("userAns4").setAttribute("onfocus", "setEntryField('userAns4')");			
		document.getElementById("userAns4").setAttribute("onkeypress", "getKeyDepress(event, 'userAns0')");			
		break;
	
	case 5:
		document.getElementById("userAns5").setAttribute("onclick", "typeInEntryField('userAns5')");
		document.getElementById("userAns5").setAttribute("onfocus", "setEntryField('userAns5')");			
		document.getElementById("userAns5").setAttribute("onkeypress", "getKeyDepress(event, 'userAns0')");			
		break;
	
	case 6:
		document.getElementById("userAns6").setAttribute("onclick", "typeInEntryField('userAns6')");
		document.getElementById("userAns6").setAttribute("onfocus", "setEntryField('userAns6')");			
		document.getElementById("userAns6").setAttribute("onkeypress", "getKeyDepress(event, 'userAns0')");			
		break;
	
	case 7:
		document.getElementById("userAns7").setAttribute("onclick", "typeInEntryField('userAns7')");
		document.getElementById("userAns7").setAttribute("onfocus", "setEntryField('userAns7')");			
		document.getElementById("userAns7").setAttribute("onkeypress", "getKeyDepress(event, 'userAns0')");			
		break;
	
	case 8:
		document.getElementById("userAns8").setAttribute("onclick", "typeInEntryField('userAns8')");
		document.getElementById("userAns8").setAttribute("onfocus", "setEntryField('userAns8')");			
		document.getElementById("userAns8").setAttribute("onkeypress", "getKeyDepress(event, 'userAns0')");			
		break;
	
	case 9:
		document.getElementById("userAns9").setAttribute("onclick", "typeInEntryField('userAns9')");
		document.getElementById("userAns9").setAttribute("onfocus", "setEntryField('userAns9')");			
		document.getElementById("userAns9").setAttribute("onkeypress", "getKeyDepress(event, 'userAns0')");			
		break;
	}
}

function setDenominatorAttributes(i){
	switch (i) 	{	
	case 0:
		document.getElementById("converttolcdinput0").setAttribute("onclick", "typeInEntryField('converttolcdinput0')");
		document.getElementById("converttolcdinput0").setAttribute("onfocus", "setEntryField('converttolcdinput0')");			
		break;
	
	case 1:
		document.getElementById("converttolcdinput1").setAttribute("onclick", "typeInEntryField('converttolcdinput1')");
		document.getElementById("converttolcdinput1").setAttribute("onfocus", "setEntryField('converttolcdinput1')");			
		break;
	
	case 2:
		document.getElementById("converttolcdinput2").setAttribute("onclick", "typeInEntryField('converttolcdinput2')");
		document.getElementById("converttolcdinput2").setAttribute("onfocus", "setEntryField('converttolcdinput2')");			
		break;
	
	case 3:
		document.getElementById("converttolcdinput3").setAttribute("onclick", "typeInEntryField('converttolcdinput3')");
		document.getElementById("converttolcdinput3").setAttribute("onfocus", "setEntryField('converttolcdinput3')");			
		break;
	
	case 4:
		document.getElementById("converttolcdinput4").setAttribute("onclick", "typeInEntryField('converttolcdinput4')");
		document.getElementById("converttolcdinput4").setAttribute("onfocus", "setEntryField('converttolcdinput4')");			
		break;
	
	case 5:
		document.getElementById("converttolcdinput5").setAttribute("onclick", "typeInEntryField('converttolcdinput5')");
		document.getElementById("converttolcdinput5").setAttribute("onfocus", "setEntryField('converttolcdinput5')");			
		break;
	
	case 6:
		document.getElementById("converttolcdinput6").setAttribute("onclick", "typeInEntryField('converttolcdinput6')");
		document.getElementById("converttolcdinput6").setAttribute("onfocus", "setEntryField('converttolcdinput6')");			
		break;
	}
}

//jcs021515 new function
function setMixNumAttributes(i){
	switch (i) 	{	
	case 0:
		document.getElementById("mixnuminputvalue0").setAttribute("onclick", "typeInEntryField('mixnuminputvalue0')");
		document.getElementById("mixnuminputvalue0").setAttribute("onfocus", "setEntryField('mixnuminputvalue0')");			
		break;
	
	case 1:
		document.getElementById("mixnuminputvalue1").setAttribute("onclick", "typeInEntryField('mixnuminputvalue1')");
		document.getElementById("mixnuminputvalue1").setAttribute("onfocus", "setEntryField('mixnuminputvalue1')");			
		break;
	
	case 2:
		document.getElementById("mixnuminputvalue2").setAttribute("onclick", "typeInEntryField('mixnuminputvalue2')");
		document.getElementById("mixnuminputvalue2").setAttribute("onfocus", "setEntryField('mixnuminputvalue2')");			
		break;
	
	case 3:
		document.getElementById("mixnuminputvalue3").setAttribute("onclick", "typeInEntryField('mixnuminputvalue3')");
		document.getElementById("mixnuminputvalue3").setAttribute("onfocus", "setEntryField('mixnuminputvalue3')");			
		break;
	
	case 4:
		document.getElementById("mixnuminputvalue4").setAttribute("onclick", "typeInEntryField('mixnuminputvalue4')");
		document.getElementById("mixnuminputvalue4").setAttribute("onfocus", "setEntryField('mixnuminputvalue4')");			
		break;
	
	case 5:
		document.getElementById("mixnuminputvalue5").setAttribute("onclick", "typeInEntryField('mixnuminputvalue5')");
		document.getElementById("mixnuminputvalue5").setAttribute("onfocus", "setEntryField('mixnuminputvalue5')");			
		break;
	
	case 6:
		document.getElementById("mixnuminputvalue6").setAttribute("onclick", "typeInEntryField('mixnuminputvalue6')");
		document.getElementById("mixnuminputvalue6").setAttribute("onfocus", "setEntryField('mixnuminputvalue6')");			
		break;
	}
}

//jcs021915 new functions
function turnAudioOn() {
	document.getElementById("turnAudioOnButton").style.display="none";
	document.getElementById("turnAudioOffButton").style.display="";
	document.getElementById("audioarea").style.display="";
	var audio=document.getElementById("voiceOver");

	/*
	 var start=document.getElementById("getstarted");
	var firstTime=document.getElementById("hiddenen1");
	if ((firstTime.innerHTML=="")&&(start.style.display=="")) {
	    audio.src="sound/intro.mp3";
	    audio.volume=0.1;
		firstTime.innerHTML="notNeeded";
		audio.autoplay=true;				
	}	
	*/
	//jcs040615 test
    audio.volume=0.1;
	audio.autoplay=true;				

	return;
}

function turnAudioOff() {
	document.getElementById("turnAudioOnButton").style.display="";
	document.getElementById("turnAudioOffButton").style.display="none";
	document.getElementById("audioarea").style.display="none";
	//jcs040115 test turning off sound
	//var audioControl = document.getElementById("audioarea");
	var audioControl = document.getElementById("voiceOver");
	
	//jcs032615 stop playing if user turns off audio
	audioControl.pause();
	return;
}

//jcs091615 set attributes for LCD conversion fraction field
function setLCDAttributes(i){
	switch (i) 	{	
	case 0:
		document.getElementById("converttolcdinput0").setAttribute("onkeypress", "getKeyDepress(event, 'converttolcdinput0')");			
		break;
	case 1:
		document.getElementById("converttolcdinput1").setAttribute("onkeypress", "getKeyDepress(event, 'converttolcdinput1')");			
		break;
	case 2:
		document.getElementById("converttolcdinput2").setAttribute("onkeypress", "getKeyDepress(event, 'converttolcdinput2')");			
		break;
	case 3:
		document.getElementById("converttolcdinput3").setAttribute("onkeypress", "getKeyDepress(event, 'converttolcdinput3')");			
		break;
	case 4:
		document.getElementById("converttolcdinput4").setAttribute("onkeypress", "getKeyDepress(event, 'converttolcdinput4')");			
		break;
	case 5:
		document.getElementById("converttolcdinput5").setAttribute("onkeypress", "getKeyDepress(event, 'converttolcdinput5')");			
		break;
	case 6:
		document.getElementById("converttolcdinput6").setAttribute("onkeypress", "getKeyDepress(event, 'converttolcdinput6')");			
		break;
	case 7:
		document.getElementById("converttolcdinput7").setAttribute("onkeypress", "getKeyDepress(event, 'converttolcdinput7')");			
		break;
	case 8:
		document.getElementById("converttolcdinput8").setAttribute("onkeypress", "getKeyDepress(event, 'converttolcdinput8')");			
		break;
	case 9:
		document.getElementById("converttolcdinput9").setAttribute("onkeypress", "getKeyDepress(event, 'converttolcdinput9')");			
		break;

	}
}