/*
 * Functions for equations
 */

//bts 10142015: new function: clone of buildStrPart
function buildStrPartPrev(prevElementLoc)
{
	var txt="";
	var i;
	var prevStep=[];
	
	prevStep=prevStepsArray[prevElementLoc];
	
	for (i=0;i<prevStep.length;i++) {
		if (prevStep[i] !== null) txt = txt + prevStep[i].string;
	}	
	return(txt);
}

function setUpEquationStruct()
{
	/*
	 * Sets up structure arrays for equations
	 * 
	 * do not add current eq step/state if equal to previously
	 * stored step
	 *
	 */
	var saveStep=false;
	var elementArrayString;
	var prevStepsArrayString;
	
	if (prevStepsArray.length > 0) {//prev steps have been saved
		elementArrayString=buildStrPart(0,elementArray.length-1);
		prevStepsArrayString=buildStrPartPrev(prevStepsArray.length-1);
		if (elementArrayString!=prevStepsArrayString) {
			saveStep=true;
		}
	} else saveStep=true;
	
	if (saveStep) {
		var  newEl=[];
		var prevSteps=[];
		var ctr;
		var stringval,elemtype,num,denom,v1,v2,v3,v4,e1,e2,e3,e4;
		var strikenum, strikedenom;
		for (i=0;i<elementArray.length;i++) {
			stringval=elementArray[i].string;
			elemtype=elementArray[i].elemtype;
			num=elementArray[i].numerator;
			denom=elementArray[i].denominator;
			v1=elementArray[i].variable;
			e1=elementArray[i].exponent;
			v2=elementArray[i].variable2;
			e2=elementArray[i].exponent2;		
			v3=elementArray[i].variable3;
			e3=elementArray[i].exponent3;		
			v4=elementArray[i].variable4;
			e4=elementArray[i].exponent4;
			ctr=i;

			newEl=addElementToPrevStep
				(ctr, stringval, elemtype, num, 
				denom,v1,e1,v2,e2,v3,e3,v4,e4,strikenum, strikedenom);
			prevSteps[prevSteps.length]=newEl;

		}
		prevStepsArray[prevStepsArray.length]=prevSteps;
	}
	return;
}

function addElementToPrevStep(ctr, stringval, elemtype, num, 
		denom,v1,e1,v2,e2,v3,e3,v4,e4,strikenum, strikedenom)
{
	/*
	 * bts120414: new function to add elements to prev steps structure
	 */
	var elem;
	
	elem = "elem"+ctr;
	elem=new pe(" ");
 	elem.addElement(stringval,elemtype,num,denom,v1,e1,v2,e2,v3,e3,v4,e4,
 			strikenum, strikedenom);

	return(elem);
}


function goBack1Step()
{
	/*
	 * Allows the user to go back to the previous step
	 * Resets the elementArray struct to the previous expression state
	 * and directs the user to the operation screen
	 * 
	 * bts120414: changed go back messages from restored
	 * to went back
	 * bts 121414: fix pop logic
	 */
	var textline;
	if (prevStepsArray.length==0) {
		resetExercise(); //start over if they backed up too far
	} else {
		//bts 10142015: pop last element in prevStepsArray and
		//	save it in elementArray; 
		elementArray=prevStepsArray.pop();
		//bts 10142015: if len==0, display orig expn msg
		if (prevStepsArray.length==0) {
			textline="Went back to original expression";
		} else {
			textline="Went back to previous step";
		}

		writeToTable(textline);
		// bts 10182015: display equation menu or expression menu
		// bts 10282015: hide any forms/prompts, prob entry area,errors
		hideForms();
		document.getElementById("problemEntryArea").style.display="none";
		document.getElementById("warningMessage").innerHTML="";
		
		if (equationFlag) {
			document.getElementById("equationMenu").selectedIndex=0;
		} else {
			document.getElementById("simplifyMenu").selectedIndex=0;
		}
		document.getElementById("operationMenuArea").style.display="";
		//bts 120514: enable the GoBack button
		document.getElementById("gobackbutton").disabled=false;
		displayTip("erase");			
	}
	return;
}



function eqAddBothSides()
{
	/*
	 * Adds the entered term from both sides of the 
	 * equation. User then must simplify equation by selecting from
	 * simplification menu options
	 * 
	 *  - Find equality sign location
	 *  - add term to end of left and right sides
	 * 
	 * 	equationOper: indicates addition or subtraction
	 *  equationTerm: term/value to add or subtract
	 *  expnOperation: text indicating operation performed (for blackboard)
	 */
	
	var startLoc=0;
	var endLoc=elementArray.length-1;
	var equalitySignLoc=findEqualityLocInStruct();
	
	var newExpn=[];
	var arrayExpn=[];
	var expnString,expnStringRight;
	
	//jcs121014 
	operation="+";
	expnOperation="Added term to each side";
	var equationField=document.getElementById("addToBothSidesField");
	var equationTerm=equationField.value;
	
	//bts 11092015: change any terms to lower case
	equationTerm=equationTerm.toLowerCase();
	
	//bts 08212015: allow only 1 term
	//	handle fractions correctly for automatically combine terms option
	// check for operators and slash symbol in equationTerm;matchoption 3
	var operArray=[];
	var fractFound,fractLoc;
	var minusSignFound;
	var negNumber;
	var errorCode,errMsgText;
	//bts 082521015: use match option 17: operators without caret ^ symbol
	operArray=parseString(equationTerm,17);
	if (operArray!==null) {
		//oper or slash or both found in entered term
		//check for slash indicating fraction and leading minus sign
		fractLoc=equationTerm.indexOf("/");
		if (fractLoc>-1) fractFound=true;
		minusSignFound=equationTerm.indexOf("-");
		if (minusSignFound>0) {
			//sign is oper, not negative indicator
			errorCode=54;
			errMsgText=errorMsg(errorCode,errMsgText);
		} else if (minusSignFound==0) {
			//neg number
			negNumber=true;
		}
		if (!errMsgText) {
			if (operArray.length>2) {
				errorCode=54;
				errMsgText=errorMsg(errorCode,errMsgText);				
			} else if (operArray.length==2) {
				if (negNumber && fractFound) {
					//no error so continue
				} else {
					errorCode=54;
					errMsgText=errorMsg(errorCode,errMsgText);					
				}
			} else if (operArray.length==1) {
				if ((negNumber && fractFound) || 
						(!negNumber && !fractFound)) {
					errorCode=54;
					errMsgText=errorMsg(errorCode,errMsgText);										
				}
			}
		}
		if (errMsgText) {
			displayErrMsg(errMsgText);
			equationTerm="";//so we go back to menu
		}
	}
	
	//bts 08032015: pass var of added term to gettermtocombine to
	//	skip prompting for this term 
	var varInTerm="";
	// extract the string portion of equationTerm, if any
	var varStrLen=0;
	varStrLen=equationTerm.length;
	//bts 08212015:allow single constant that is fraction or negative
	//	use parseString instead of isNaN, matchoption 4: letters only
	newExpn=parseString(equationTerm,4);
	if (newExpn!==null) {
		if (newExpn.length==1) {
			varInTerm=newExpn[0];
		} else {
			errorCode=55;
			errMsgText=errorMsg(errorCode,errMsgText);					
			displayErrMsg(errMsgText);
			equationTerm="";//so we go back to menu
		}
	}
	
	if (equationTerm=="" || equationTerm==" " || equationTerm==null) {
		document.getElementById("equationMenu").selectedIndex=0;
		document.getElementById("addToBothSidesArea").style.display="none";
		document.getElementById("operationMenuArea").style.display="";
		document.getElementById("addToBothSidesField").value="";
		//jcs080615 test
		displayTip("equation");
		return;
	}
	
	//bts 08212015: only build structure if legal term entered
	// then fall into combining constants/terms 
	expnString=buildStrPart(startLoc,equalitySignLoc-1);
	expnStringRight=buildStrPart(equalitySignLoc,endLoc);
	//jcs121014 expnString=expnString.concat(equationOper);
	expnString=expnString.concat("+");
	expnString=expnString.concat(equationTerm)+expnStringRight+
			"+"+equationTerm;	
	arrayExpn=parseString(expnString,1); //convert new expn string to array
	//bts 08212015: removed var for errMsgText
	errMsgText=buildStructure(arrayExpn,elementArray);
	
	
	if (errMsgText) {
		alert("Error building structure.");
	} else {
		writeToTable(expnOperation);	//jcs111814 reset equation menu
		document.getElementById("equationMenu").selectedIndex=0;
		//jcs121014 new
		document.getElementById("addToBothSidesArea").style.display="none";
		displayTip("afteraddtobothsides");
		document.getElementById("operationMenuArea").style.display="";
		document.getElementById("addToBothSidesField").value="";
	}
	
	//pass expnString as 1st parameter
	// be sure menu area is not displayed
	document.getElementById("operationMenuArea").style.display="none";

	errMsgText=getTermToCombine(expnString,varInTerm);
	if (errMsgText=="combineconstants") {
		eqCombineConstants(expnString);
	} 

	return;
}
function checkForVarInMultDivTerm(term,matchOption)
{
	/*
	 * checks multiply,divide by term in equation for
	 * presence of a variable (alpha char). If found,
	 * displays error message and sets flag to exit
	 */
	var errorCode;
	var errMsgText;
	var parseResult=parseString(term,4);
	if (parseResult) {
		//var found
		errorCode=56;
		errMsgText=errorMsg(errorCode,errMsgText);
		displayErrMsg(errMsgText)
	}
	return(errMsgText);
}


//jcs091115 new function for dividing both sides by a term
function eqDivideBothSides()
{
	var newExpn=[];
	var expnString="";
	var startLoc=0;
	var endLoc=elementArray.length-1;
	var equalitySignLoc=findEqualityLocInStruct();
	
	var exitFunction=false;
	
	var operation="\u00F7";//divide sign 
	var expnOperation="Added divisor to each side";
	var equationField=document.getElementById("divideBothSidesField");
	var divTerm=equationField.value;
	//bts 11092015: set entered term to lower case
	divTerm=divTerm.toLowerCase();

	var signReversed=false;
	var negMultiplier = divTerm.indexOf("-"); 
	
	var arrayLength=elementArray.length;
	
	//bts 10142015: set div side var and divide var to blank
	document.getElementById("hiddendivisionside").innerHTML="";
	document.getElementById("hiddendivision").innerHTML="";

	//return if no value is entered
	if (divTerm=="" || divTerm==" " || divTerm==null) {
		exitFunction=true;
	} else {
		//bts 09172015: check for vars; put up error msg and exit if found
		var errMsgText=checkForVarInMultDivTerm(divTerm,4);
		if (errMsgText) {
			exitFunction=true;
			errMsgText="";
		}
	}
	//bts 09172015: exit if div term is blank or includes a variable
	if (exitFunction) {
		document.getElementById("divideBothSidesArea").style.display="none";
		document.getElementById("operationMenuArea").style.display="";
		document.getElementById("equationMenu").selectedIndex=0;
		document.getElementById("divideBothSidesField").value="";
		displayTip("equation");
		return;
	}
	
	//check for fraction and negative number
	var slashPtr=divTerm.indexOf("/");
	var minusSign=divTerm.indexOf("-");
	
	if (!exitFunction && arrayLength==3) {
		// bts120814: reverse sign if multiplying by negative number
		//	check for minus sign in equationTerm string	
		//bts 010515: call switchOperSign function instead of reverseMultByNeg 
		if (minusSign!=-1) {
			// call switchOperSign function: pass in sign to switch 
			//	and get back changed sign. Update structure here and 
			//	set boolean to true if changed
			var currentSign=elementArray[equalitySignLoc].string;
			var newSign=switchOperSign(currentSign);
			if (newSign!=currentSign){
				elementArray[equalitySignLoc].string=newSign;
				signReversed=true;
			}
		}	

		//insert divide sign plus term into positions 1-2 and positions 5-6
		// Change expnOperation to "Added divisor to each side";
		//Write to table and call flipdivisor
		expnString=elementArray[0].string+operation+String(divTerm)+
			elementArray[1].string+elementArray[2].string+operation+
			String(divTerm);
		newExpn=parseString(expnString,1); //convert new expn string to array
		// build structure from expn array
		var errMsgText=buildStructure(newExpn,elementArray);

		if (errMsgText) {
			alert("Error building structure.");
		} else {
			if (signReversed) expnOperation = expnOperation+
				" and reversed equality sign";		

			writeToTable(expnOperation);
			displayTip("dividebothsides");
			//bts 09172015: change flipDivisor to handle 2 sets of divisors
			//bts 10132015: added parameter to flipDivisor: if set, indicates
			//	coming from eqDivideBothSides where array has only 3 elements
			//	so we flip divisor but do not display the flipped divisor
			var doNotDisplayFlip=true;
			flipDivisor(0,2,4,6,doNotDisplayFlip);
			//bts 10132015: use hidden var so that subsequent functions
			//	use the divide oper and display correctly for 
			//	answer prompting and retrieving answer
			//	added 2nd hidden var (hiddendivisionside) indicating 
			//	solving left/first or right/second side of equation
			document.getElementById("hiddendivision").innerHTML="divide";
			//build prompts for solving multiplication
			//	on left/right sides of equation
			document.getElementById("divideBothSidesArea").style.display="none";
			document.getElementById("operationMenuArea").style.display="none";

			var firstPass=true;
			eqMultLeftRightSides(firstPass);
		}
		
	} else if (!exitFunction && arrayLength>3){
		// treat flipped divisor as standard multiplier added to both sides
		//Flip divisor for entered number and call eqMultiplyBothSides
		var holdNum;
		var divNum;
		var newNum="";
		if (slashPtr==-1) {//whole number
			divNum=Number(divTerm);
			var holdNum=Math.abs(divNum);
			if (holdNum==divNum) {
				newNum="1/"+String(divNum);
			} else {//negative whole number
				newNum="-1/"+String(divNum);
			}
		} else {//fraction entered
			if (minusSign == -1) {//positive fraction
				newNum=newNum+divTerm.slice(slashPtr+1)+"/"+
					divTerm.slice(0,slashPtr);
			} else {
				newNum=newNum+"-"+divTerm.slice(slashPtr+1)+"/"+
					divTerm.slice(1,slashPtr);				
			}
		}

		eqMultiplyBothSides(newNum);
	}
	
	
	//exit routine
	document.getElementById("divideBothSidesArea").style.display="none";
	document.getElementById("divideBothSidesField").value="";
	
	return;
}


function eqMultiplyBothSides(divTerm)
{
	//bts 09112015: added parameter divTerm if coming fromn divide both sides
	
	/*
	 * Adds the passed in operation and term to both sides of the
	 * equation. Then prompts user to solve new multiply operations
	 * on left/right sides of the equation.
	 * 
	 * 	-Find the equality operator
	 *  -Add term/operator to beginning left side
	 *  -Add term/operator to beginning of right side
	 *  
	 *  -Build prompts/calc answers for left and right side
	 *  -Display prompts, check for correct answers
	 *  
	 *  operation: indicates addition or subtraction
	 *  equationTerm: term/value to add or subtract
	 *  expnOperation: text indicating operation performed (for blackboard)

	 */
	 
	var newExpn=[];
	var expnString,expnStringRight;
	var startLoc=0;
	var endLoc=elementArray.length-1;
	var equalitySignLoc=findEqualityLocInStruct();
	
	//bts 09112015: add var to operation declaration
	var operation="*";
	var expnOperation="Added multiplier to each side";
	// bts 09112015 test divTerm to see if we need to pull in multiplier entry or
	//	use already flipped divisor; moved var declarations before block
	var equationField;
	var equationTerm;
	if (divTerm ==null || divTerm==undefined) {//get multiply by entered val
		equationField=document.getElementById("multiplyBothSidesField");
		equationTerm=equationField.value;
		//bts 11092015: set entered term to lower case
		equationTerm=equationTerm.toLowerCase();
		//bts 09172015: if multiplier entered, check that it does not include var
		var errMsgText=checkForVarInMultDivTerm(equationTerm,4);
		if (errMsgText) {
			//if multiplier includes var, set equationTerm to "" to exit
			// divTerm is checked for vars in eqDivideBothSides
			errMsgText="";
			equationTerm="";
		}
	} else {//use passed in divisor term
		equationTerm=divTerm;
		//bts 11092015: set entered term to lower case
		equationTerm=equationTerm.toLowerCase();
		expnOperation="Added reciprocal of divisor to each side";
	}
	//bts 022115: fix bug where no value is entered
	if (equationTerm=="" || equationTerm==" " || equationTerm==null) {
		document.getElementById("multiplyBothSidesArea").style.display="none";
		document.getElementById("operationMenuArea").style.display="";
		document.getElementById("equationMenu").selectedIndex=0;
		document.getElementById("multiplyBothSidesField").value="";
		//jcs080615 test
		displayTip("equation");
		return;
	}

	var termString = String(equationTerm)+operation;
	
	// bts120814: reverse sign if multiplying by negative number
	//	check for minus sign in equationTerm string	
	//bts 010515: call switchOperSign function instead of reverseMultByNeg 
	var signReversed=false;
	var negMultiplier = equationTerm.indexOf("-"); 
	if (negMultiplier!=-1) {
		// call switchOperSign function: pass in sign to switch 
		//	and get back changed sign. Update structure here and 
		//	set boolean to true if changed
		var currentSign=elementArray[equalitySignLoc].string;
		var newSign=switchOperSign(currentSign);
		if (newSign!=currentSign){
			elementArray[equalitySignLoc].string=newSign;
			signReversed=true;
		}
	}	
	
	// bts 022015: check for mult/divide opers to not put parens around 
	//	multiplied terms; add new multiplier term to added terms not within brackets
	
	var leftTermLoc=[];
	var rightTermLoc=[];
	var nextLoc;
	var expnStringTemp="";
	expnString="";
	var addMultipliers=true;
	leftTermLoc=checkForAddMultiplyTerms(0,equalitySignLoc-1);
	rightTermLoc=checkForAddMultiplyTerms(equalitySignLoc+1,endLoc);
	
	// remove first terms from term loc array if they are in left/right
	//	first positions
	var holdterm;
	if (leftTermLoc.length>0) {
		if (leftTermLoc[0]==startLoc) {
			holdterm=leftTermLoc.shift();
		}
	}
	if (rightTermLoc.length>0) {
		if (rightTermLoc[0]==equalitySignLoc+1) {
			holdterm=rightTermLoc.shift();
		}
	}

	// add parentheses around orig left/right expressions if 
	//	more than one term in those expressions
	var leftParens="(";
	var rightParens=")";
	
	// 022015: build eq string based on term locations
	//expnString=buildStrPart(startLoc,equalitySignLoc-1);
	//expnStringRight=buildStrPart(equalitySignLoc+1,endLoc);
	
	// build left side piece by piece
	// need to include terms that are added even if followed by a multiply
	//	clone checkForCombinableTerms
	nextLoc=0;
	if (leftTermLoc.length==0) {// all opers are multiply/divide
		expnString=buildStrPart(startLoc,equalitySignLoc-1);
		expnString=termString.concat(expnString);//add multiplier at start, no parens		
	} else if (leftTermLoc.length>0) {//plus signs found; add parens around those terms
		expnString="";
		for (var j=0;j<leftTermLoc.length;j++) {
			expnStringTemp=buildStrPart(nextLoc,leftTermLoc[j]-1);
			expnString=expnString+termString+expnStringTemp;

			nextLoc=leftTermLoc[j];
			if (j==leftTermLoc.length-1) {
				expnStringTemp=buildStrPart(leftTermLoc[j],equalitySignLoc-1);
				expnString=expnString+termString+expnStringTemp;
			}
		}		
	}
	// bts 022115: build right side same as for left side
	nextLoc=equalitySignLoc+1;
	expnStringRight="";
	expnStringTemp="";
	if (rightTermLoc.length==0) {// all opers are multiply/divide
		expnStringRight=buildStrPart(equalitySignLoc+1,endLoc);
		expnStringRight=termString.concat(expnStringRight);//add multiplier at start, no parens		
	} else if (rightTermLoc.length>0) {//plus signs found
		for (var j=0;j<rightTermLoc.length;j++) {
			expnStringTemp=buildStrPart(nextLoc,rightTermLoc[j]-1);
			expnStringRight=expnStringRight+termString+expnStringTemp;
			nextLoc=rightTermLoc[j];
			if (j==rightTermLoc.length-1) {
				expnStringTemp=buildStrPart(rightTermLoc[j],endLoc);
				expnStringRight=expnStringRight+termString+expnStringTemp;
			}
		}		
	}
		
	//combine left and right sides
	expnString=expnString+elementArray[equalitySignLoc].string
			+expnStringRight;
	newExpn=parseString(expnString,1); //convert new expn string to array

	// build structure from expn array rather than expn string
	var errMsgText=buildStructure(newExpn,elementArray);

	if (errMsgText) {
		alert("Error building structure.");
	} else {
		// remove parens surrounding single term, if any
		removeParensFromStruct();
		if (signReversed) expnOperation = expnOperation+
			" and reversed equality sign";		
		writeToTable(expnOperation);
		//jcs121014 new
		document.getElementById("multiplyBothSidesArea").style.display="none";
		displayTip("aftermultiplybothsides");
		document.getElementById("operationMenuArea").style.display="";
		document.getElementById("equationMenu").selectedIndex=0;
		document.getElementById("multiplyBothSidesField").value="";
	}
	
	//bts 122514: if no error, build prompts for solving multiplication
	//	on left/right sides of equation
	var firstPass=true;
	eqMultLeftRightSides(firstPass);
	
	return;
}
function eqMultLeftRightSides(firstPass) 
{
	/*
	 * Called after user adds term to multiply both sidees
	 * Prompts for "how much is..." for the multiplication on left/right
	 * sides of equation
	 * 
	 * New multiplier term is always added to leftmost position 
	 */
	var expnLeftString,expnRightString;
	var expnToSolve;
	var i, expnEnd;
	var nestedParens=0;
	var errMsgText;
	
	var equalitySignLoc=findEqualityLocInStruct();
	document.getElementById("operationMenuArea").style.display="none";
	
	// build left side first if firstPass is 0
	// multiplier starts with 1st term, pos 0, plus asterisk, pos 1 in struct
	// find last part of multiplier: either second term in struct or portion
	//	enclosed in parens
	// for first time thru, write indicator to hidden variable
	if (firstPass) {
		document.getElementById("hiddenmultiplybothsides").innerHTML="firstpass";
		expnEnd=2; // default end position, assuming no parens
		if (elementArray[expnEnd].elemtype=="leftgrp") {//need to look for rightgrp position
			for (i=3;i<equalitySignLoc;i++) {
				if (elementArray[i].elemtype=="rightgrp") {
					if (nestedParens>0) {
						nestedParens--;
					} else {
						expnEnd=i;
						i=equalitySignLoc;
					}
				} else if (elementArray[i].elemtype=="leftgrp") {
					nestedParens++;
				}
			}		
		} 
		expnLeftString=buildStrPart(0,expnEnd);
		//bts 10142015: set div side var to first/left side if division
		if (document.getElementById("hiddendivision").innerHTML == "divide") {
			document.getElementById("hiddendivisionside").innerHTML="first";
		}
		errMsgText=simplifyAlgExpPart(expnLeftString);
	} else {//not firstPass, this must be 2nd time and right side of equation
		//set hidden variable to second pass
		document.getElementById("hiddenmultiplybothsides").innerHTML="secondpass";

		expnEnd=equalitySignLoc+3; // default end position, assuming no parens
		if (elementArray[expnEnd].elemtype=="leftgrp") {//need to look for rightgrp position
			for (i=3;i<elementArray.length-1;i++) {
				if (elementArray[i].elemtype=="rightgrp") {
					if (nestedParens>0) {
						nestedParens--;
					} else {
						expnEnd=i;
						i=elementArray.length;
					}
				} else if (elementArray[i].elemtype=="leftgrp") {
					nestedParens++;
				}
			}		
		} 
		expnRightString=buildStrPart(equalitySignLoc+1,expnEnd);
		//bts 10142015: set div side to second/right side if division
		if (document.getElementById("hiddendivision").innerHTML == "divide") {
			document.getElementById("hiddendivisionside").innerHTML="second";
		}
		errMsgText=simplifyAlgExpPart(expnRightString);
	}
	//bts 021215: if error, display message, erase hiddenvar for 2nd pass
	if (errMsgText) {
		document.getElementById("hiddenmultiplybothsides").innerHTML="";
		//displayErrMsg(errMsgText);
		errMsgText="";
		document.getElementById("equationMenu").style.display="";
		document.getElementById("operationMenuArea").style.display="";	
		document.getElementById("equationMenu").selectedIndex=0;
		//jcs080615 test
		displayTip("equation");
	}

	return;
}


function findEqualityLocInStruct()
{
	/*
	 * finds and returns the location in elementArray of the equality sign
	 * 
	 */
	var location;
	for (var i=0;i<elementArray.length-1;i++) {
		if (elementArray[i].elemtype=="equality") {
			location=i;
			i=elementArray.length+1;
		}
	}
	return(location);
}

function checkEqMatchPositions(matchPositions,equalityOperLoc)
{
	/*
	 * checks an array of "matched" positions for those on the 
	 * left side of an equation and those on the right side
	 * Returns:
	 * 1 for left side only
	 * 2 for right side only
	 * 3 for both sides
	 * 0 if only 1 match position max per side

	 */
	var affectedSides=[];
	var i;
	var leftCtr=0;
	var rightCtr=0;
	var midPt=equalityOperLoc;
	
	for (i=0;i<matchPositions.length;i++) {
		if (matchPositions[i]<equalityOperLoc) {
			leftCtr++;
		} else if (matchPositions[i]>equalityOperLoc) {
			rightCtr++;
		}
	}
	if (leftCtr>1 && rightCtr>1) {
		affectedSides[0]=3;
	} else if (leftCtr>1 && rightCtr<=1) {
		affectedSides[0]=1;
	} else if (leftCtr<=1 && rightCtr >1) {
		affectedSides[0]=2;
	} else affectedSides[0]=0;
	affectedSides[1]=midPt;
	return(affectedSides);
}

function leftRightPos(matchPositions,equalityOperLoc,side)
{
	/*
	 * returns either left/right position arrays for 
	 * location of matched terms
	 * 
	 * side=1: left side 
	 * side=2: right side
	 */
	var newPosArray=[];
	
	var i;
	var j=0; //for right side array
	for (i=0;i<matchPositions.length;i++) {
		if (side==1) {
			if (matchPositions[i]<equalityOperLoc)
				newPosArray[i]=matchPositions[i];
		} else if (side==2) {
			if (matchPositions[i]>equalityOperLoc) {
				newPosArray[j]=matchPositions[i];
				j++;
			}			
		}
	}
	
	return(newPosArray);
}

function checkTermWithinGrouper(matchPositions,grpPos,eqOperLoc)
{
	/*
	 * new 08282015
	 * checks array of terms for those that fall within grouper brackets
	 * returns only those term positions that fall outside of grouper brackets
	 * grpPos array: positions of groupers
	 * matchPositions: positions of terms within array
	 * eqOperLoc: position of equality operator
	 */
	
	var tempMatchPos=[];
	var i, j;
	var inGroup;
	
	for (i=0;i<matchPositions.length;i++) {
		inGroup=false;
		for (j=0;j<grpPos.length;j=j+2){
			if (matchPositions[i]>grpPos[j] && 
					matchPositions[i]<grpPos[j+1]) {
				//skip position; term is between 2 groupers
				inGroup=true;
			}
		}
		if (!inGroup) {
			tempMatchPos[tempMatchPos.length]=matchPositions[i];//outside grper block
		}

	}

	return(tempMatchPos);
}

function combineEqLikeTerms(termToMatch,equalityOperLoc,errMsgText)
{
	/*
	 * Clone of combineLikeTerms for expressions
	 * Modified to handle left/right side of equations
	 * 
	 */	
	var terms;
	var termOnly=false;
	var matchString;
	var matchPositions = [];
	var correctAns = false;
	var calcAns;
	var highlightColor;
	var errorCode;
	var errMsgText="";
	var i;

	matchString = termToMatch;
	matchString=matchString.toLowerCase();	
	
	// get all terms entered
	terms = parseString(matchString,4);
	if (terms == null) {
		errorCode=15; // Enter a term to combine
		errMsgText=errorMsg(errorCode,errMsgText);
		//bts 08312015: display error message for user to enter a term
		displayErrMsg(errMsgText);
		return(errMsgText);
	}
	//bts 08312015: remove if block: exited if no term entered
	//} else {
	//bts 08302015:check for more than 1 term outside of multiply
	//	operations or brackets per equation side		
		
	// set begin/end pts to entire equation
	idxStart=0;
	idxEnd=elementArray.length-1;
	matchPositions = variableMatch(matchString,idxStart,idxEnd);
		
	//bts 011315: check if either matched side of equation 
	//	spans absol val bars; remove those positions if yes
	// compare bar positions to matchpositions for overlap
		
	//bts 08282015: check for grouper positions 
	//	comment out code for checking for absol val bars only
	var grpPos=[];
	grpPos=checkForGrp();
	
	//var barPos=[];//for absol val bars only
	var tempMatchPos=[];
	var j;
	var numBars=grpPos.length/2;
	if (grpPos.length>0 && matchPositions.length>1) {// check if term betw grpers
		tempMatchPos=checkTermWithinGrouper(matchPositions,grpPos,equalityOperLoc);
		matchPositions=tempMatchPos;	
	}

	/* commented out code
		barPos=checkForAbsolValBars();
		var numBars=barPos.length/2;
		if (barPos.length>0 && matchPositions.length>1) {// check if term betw absol bars
			for (i=0;i<matchPositions.length;i++) {
				for (j=0;j<barPos.length;j=j+2){
					if (matchPositions[i]<barPos[j]) {
						tempMatchPos[tempMatchPos.length]=matchPositions[i];//good match
						j=barPos.length;//force exit from loop
					} else if (matchPositions[i]>barPos[barPos.length-1]) {
						tempMatchPos[tempMatchPos.length]=matchPositions[i];//good match
						j=barPos.length;//force exit from loop
					//bts 011615: changed test for vars betw bars	
					} else if (matchPositions[i]>barPos[j]&& 
							matchPositions[i]<barPos[j+1]) {
						//skip this position; betw absol val bars
					}						
				}
			}
			matchPositions=tempMatchPos;	
		}
	*/
		
	// check which positions are left side vs right side
	// display terms to highlight accordingly
	// function returns 1 for left side only, 2 for right side only
	//		3 for both sides, or 0 if only 1 match position max per 
	//		side. Counters are set in position[0]. 
	//		Position 1 of affectedSides array holds pt where
	//		right side of equation starts in matchPositions
	var affectedSides=checkEqMatchPositions(matchPositions,equalityOperLoc);

	//bts 011715: check affectedSides for terms to combine
	//	if set to 0, set error msg and exit
	if (affectedSides[0]==0) {
		errorCode=42; // Expression has only 1 term that matches your term.
		errMsgText=errorMsg(errorCode,errMsgText);
		return(errMsgText);			
	}
	if (matchPositions.length <= 1) {
		if (matchPositions.length == 0) {
			errorCode=19; // term doesn't match expression terms
			errMsgText=errorMsg(errorCode,errMsgText);
		}
		if (matchPositions.length == 1) {
			errorCode=20; // Expression has only 1 term that matches your term.
			errMsgText=errorMsg(errorCode,errMsgText);
		}
		// bts 011715: if error, exit routine
		return(errMsgText);
	} else if (matchPositions.length > 1) {
		var eqStart,eqEnd;
		var leftPosArray=[]; // array for determining
							   //prompts,calc answers
		var rightPosArray=[];
		var calcAnsArray=[];
		var userPromptArray=[];
		var promptLoop=1;
		var side; // indicates left or right side for positions
		var holdPositions=matchPositions;//save orig match positions
		if (affectedSides[0]==3){ // highlight both sides
			eqStart=0;
			eqEnd=matchPositions.length;
			promptLoop=2;
			side=1;//left side
			leftPosArray=leftRightPos(matchPositions,equalityOperLoc,side);
			side=2;//right side
			rightPosArray=leftRightPos(matchPositions,equalityOperLoc,side);
		} else if (affectedSides[0]==2) {//right side only
			side=2;//right side
			rightPosArray=leftRightPos(matchPositions,equalityOperLoc,side);
			eqStart=equalityOperLoc+1;
			eqEnd=rightPosArray.length;
		} else if (affectedSides[0]==1) {//left side only
			eqStart=0;
			side=1;//left side
			leftPosArray=leftRightPos
					(matchPositions,equalityOperLoc,side);
			eqEnd=leftPosArray.length;
		}
		// prompt for answer
		// highlight the terms to combine before prompting for answer
		highlightColor = "orange";
		//for (j=0;j<matchPositions.length;j++){
		// use new loop delimiters based on sides to highlight
		for (j=eqStart;j<eqEnd;j++){
			writeMultHighlight(matchPositions[j],1,elementArray.length,highlightColor);
		}

		// call once if either left/right side
		//	call twice if both sides
		var holdPromptAnsObj={prompt:"",calcAns:0,numTotal:0,
				fractionPresent:false,lcd:0};
		var promptCalcAns=[];
		var holdPromptAnsArray=[];
		
		for (i=0;i<promptLoop;i++) {
			if (i==0) {
				if (affectedSides[0]==2) 
					matchPositions=rightPosArray;
				if (affectedSides[0]==1||affectedSides[0]==3)
					matchPositions=leftPosArray;
			} else if (i==1) {
				matchPositions=rightPosArray;
			}
			promptCalcAns=
				combineEqTermsAnswer(matchPositions,matchString);
			var objName=addToPosObj(i,promptCalcAns);

			holdPromptAnsArray[i]=objName;
		}
	}
	// set up prompts using arrays for prompt,calc answer
	// restore full matchPositions array if both sides
	if (affectedSides[0]==3) matchPositions=holdPositions;
	//jcs081115 Let's shorten the prompt
	//var preprompttext="Combine the coefficients for the like term. How much is: ";
	var preprompttext="How much is: ";
	// bts 091214: set up tip in setAnswerPrompt for 
	//		combining coefficients where there are fractions;
	//		also set expnOperation to empty;
	var expnOperation="";
	var introType;
	var promptString=[];
	var calcAns=[];
	// variables for updating structure
	var numTotal=[];
	var fractionPresent=[];
	var lcd=[];
	
	for (i=0;i<holdPromptAnsArray.length;i++) {
		promptString[i]=holdPromptAnsArray[i].prompt;
		calcAns[i]=holdPromptAnsArray[i].calcAns;
		numTotal[i]=holdPromptAnsArray[i].numTotal;
		fractionPresent[i]=holdPromptAnsArray[i].fractionPresent;
		if (fractionPresent[i]) {
			lcd[i]=holdPromptAnsArray[i].lcd;
			introType=9;
		} else introType=0;
		// set tip when fraction present
		//if (promptString[i].indexOf("/")) introType=9;
	}
	var multiplier = 1;
	// last parameter indicates combine like terms
	// is the calling function
	//var onePrompt = true;
	var onePrompt=false;//may be 2 prompts for equations
	var callerId = "combineliketerms";
	setAnswerPrompt(preprompttext,promptString,multiplier, 
				calcAns,matchPositions,1, onePrompt,callerId,
				expnOperation,introType);	
		
	// update structure here
	//	left/right arrays and use those positions for the update
	//bts 120414: set rightside only matchpositions correctly
	for (i=calcAns.length-1;i>-1;i--) {
		//if (calcAns.length==2 && i==1) {
		if (affectedSides[0]==2 || (calcAns.length==2 && i==1)) {
			matchPositions=rightPosArray;
		} else 
			matchPositions=leftPosArray;
				
		if (fractionPresent[i]) {
			elementArray[matchPositions[0]].numerator=numTotal[i];
			elementArray[matchPositions[0]].denominator=lcd[i];
			elementArray[matchPositions[0]].string=calcAns[i];
		} else {
			elementArray[matchPositions[0]].string = calcAns[i];
			elementArray[matchPositions[0]].numerator = numTotal[i];
		}
		// bts 020714: remove term whose calculated result is 0
		// if only 1 remaining term, then set its vals to zero/null 
		//		instead of removing it
		if (numTotal[i]==0) {
			elementArray[matchPositions[0]].variable=null;
			elementArray[matchPositions[0]].variable1=null;
			elementArray[matchPositions[0]].variable2=null;
			elementArray[matchPositions[0]].variable3=null;	
		}
		for (var j=matchPositions.length-1;j>0;j--) {
			if (elementArray[matchPositions[j]-1].elemtype=="equality") {
				elementArray.splice(matchPositions[j]+1,2);
			} else 
				elementArray.splice(matchPositions[j]-1,2);
		}
	}
	
	// remove brackets that surround a single term
	removeParensFromStruct();
	
	// remove any zero terms unless only term on 1 side of equation
	//bts 011315: change to use removeZerosFromEqStruct() function
	removeZerosFromEqStruct();
//bts 08312015: end of removed if block
//	}//end of processing if no error
	
	if (errMsgText) {
		displayErrMsg(errMsgText);
		//bts 121414: don't display menus here; user still
		//		has to enter the answer
		//jcs119 bring back the menu
		//document.getElementById("operationMenuArea").style.display="";
	} else {	//jcs111814 reset equation menu
		document.getElementById("equationMenu").selectedIndex=0;
		//document.getElementById("operationMenuArea").style.display="";	//jcs112414 fixed
	}
	return(errMsgText);
}

function combineEqTermsAnswer(positions,matchString){
	/*  
	 * prompt for combining terms answer for equations
	 */
	var calcAns, userAns, holdAns;	
	var holdAnsNum, calcAnsNum;
	var promptString="";
	var i;
	var correctAnswer = false;
	var numTotal = 0;
	var calcAnsString;
	var signOper, subtractOper;
	var signPosition;
	
	var tipString=[];
	var tipCtr=0;
	// holds prompt+calc answer
	var promptAnsArray=[];

	holdAns=0;
	calcAns=0;
	holdAnsNum=0;
	calcAnsNum=0;
	subtractOper = false;

	// bts010714: 
	//	  - calculate answer for fraction coefficients
	//	  - distribute coefficients in prompt for user's answer
	var fractionPresent=false;
	var denomArray=[];
	var lcd, lcdMultiplier;
	var calcAnsHint;
	
	// check for fractions
	for (i=0;i<positions.length;i++) {
		denomArray[i]=elementArray[positions[i]].denominator;
		if (elementArray[positions[i]].denominator > 1) {
			fractionPresent=true;
		}
	}
	// if there are fractions, set denominators to common denom
	// build array of denoms and call calculateLCD
	if (fractionPresent) {
		lcd = calculateLCD(denomArray);
		tipString[tipCtr]="Convert fractions to common denominator: "+String(lcd);
	}
	
	//bts 09102015: remove prompting as (coeff+coeff)variable format
	//	and return to coeff-var format: 2x+3x	
	for (i=0;i<positions.length;i++) {
		//bts 09102015: restore old prompt string using string field from
		//		element array
		promptString = promptString+elementArray[positions[i]].string;
		/* bts 09102015: comment out coeff formatting
		if (i==0) promptString="(";		
		if (fractionPresent && elementArray[positions[i]].denominator != 1) {
			promptString = promptString+String(elementArray[positions[i]].numerator)
				+"/"+String(elementArray[positions[i]].denominator);
		} else {
			promptString = promptString+String(elementArray[positions[i]].numerator);
		}
		
		if (i==positions.length-1) {//last portion of prompt
			promptString=promptString+")"+matchString;
		}
		*/
		// calculate answer
		if (fractionPresent) {// calculate answer for fraction
			lcdMultiplier = lcd/elementArray[positions[i]].denominator;
			holdAnsDenom=lcd;
			holdAns=elementArray[positions[i]].numerator*lcdMultiplier;
			
			//bts010814: Add to tipString array for fractions
			tipCtr++;
			tipString[tipCtr]=String(elementArray[positions[i]].numerator)+"/"
				+ String(elementArray[positions[i]].denominator)+" * "
				+String(lcdMultiplier)+"/"+String(lcdMultiplier)+
				" = "+ String(holdAns)+"/"+String(lcd);
		} else {
			holdAns = elementArray[positions[i]].numerator;
		}

		if (subtractOper) {
			calcAns = Number(calcAns)-Number(holdAns);
			numTotal = Number(numTotal)-Number(holdAns);
		} else {
			calcAns = Number(calcAns)+Number(holdAns);
			numTotal = Number(numTotal)+Number(holdAns);
		}

		if (i<positions.length-1) {
			signPosition = positions[i+1]-1;
			signOper = elementArray[signPosition].string;
			if (signOper == "-") {
				subtractOper=true; 
			} else {
				subtractOper=false;
			}
			
			promptString = promptString+" "+signOper+" ";
		}
	}

	// if calculated answer is -1 or 1, then do not display the 1 in the string
	// if calculated answer is 0, then what?
	if (!fractionPresent) {
		if (calcAns == 1) {
			calcAns = matchString;
		} else if (calcAns == -1) {
			calcAns = calcAns.toString()+matchString;
			calcAnsString = calcAns.replace("-1","-"); // remove 1 and leave - sign
			calcAns = calcAnsString;
		} else if (calcAns == 0) {
			matchString="";
		} else {
			calcAns= calcAns.toString()+matchString;
		}
	} else if (fractionPresent) {
		// bts011114: use calcAnsHint for displaying tip with space betwn coeff & var.
		if (calcAns == lcd) {
			calcAns = 1;
			lcd=1;
			calcAns = matchString;
			calcAnsHint = calcAns;
		} else if (calcAns == -1) {
			calcAnsHint = calcAns.toString()+"/"+String(lcd)+" "+matchString;
			calcAnsHint = calcAns.replace("-1","-");
			//set up calc answer for getuseranswer
			calcAns = calcAns.toString()+"/"+String(lcd)+matchString;
			calcAnsString = calcAns.replace("-1","-"); // remove 1 and leave - sign
			calcAns = calcAnsString;
		} else if (calcAns == 0) {
			matchString="";
			lcd = 1;
			calcAnsHint="0";
		} else {
			calcAnsHint= calcAns.toString()+"/"+String(lcd)+" "+matchString;
			calcAns= calcAns.toString()+"/"+String(lcd)+matchString;
		}
		tipCtr++;
		tipString[tipCtr] = "Then combine coefficients as indicated: "+calcAnsHint;
	}
	
	if (tipCtr>0) {//write tip string array to html but don't display it
		var tipElement=document.getElementById("fractioncombinetip");
		tipElement.style.display="none";
		//tipElement.innerHTML="";
		for (i=0;i<tipCtr+1;i++) {
			tipElement.innerHTML=tipElement.innerHTML+"<ul>"+tipString[i]+"</ul>";
		}
	}
	
	// save user prompt and calcans 
	promptAnsArray[0]=promptString; // user prompt
	promptAnsArray[1]=calcAns;		// answer
	// add numerator new amt and lcd, for updating structure later
	promptAnsArray[2]= numTotal;
	promptAnsArray[3]= fractionPresent;
	if (fractionPresent) promptAnsArray[4]=lcd;
	i=0;
	return(promptAnsArray);
}

function checkEqVarsCoeffs()
{
	/*
	 * checks if an equation of length 3 is done
	 * based on vars/coeffs rules; Also returns indicator
	 * if fraction present
	 */
	var i,j;
	var leftvariableFound, leftcoeffFound;
	var rightvariableFound, rightcoeffFound;
	var eqSignLoc;
	var checkForDone = true;
	var fractionFound, simplified;
	var fractionPtr; //element loc for fraction
	var ansArray=[];
	var solved=false;
	
	//  ansArray: array pos 0 true if leftvarfound
	//	array pos 1 true if leftcoefffound
	//	array pos 2 true if rightvarfound
	//	array pos3=rightcoefffound
	//	array pos4= solved true/false
	//	array pos5, if exists = fraction loc pointer
	
	for (i=0;i<6;i++) {//initialize positions in array
		ansArray[i]=false;
	}
	
	eqSignLoc=findEqualityLocInStruct();
	while (checkForDone) {
		for (i=0;i<elementArray.length;i++) {
			if (i<eqSignLoc && elementArray[i].elemtype=="term") {
				if (elementArray[i].variable) {
					leftvariableFound=true;
					ansArray[0]=leftvariableFound;
					// bts 122614: check both numerator and denom vals
					//	to catch negative #s and fractions
					if (elementArray[i].numerator !=1 || 
						elementArray[i].denominator != 1) {
						leftcoeffFound=true;
					    ansArray[1]=leftcoeffFound;
					}
				} else if (!elementArray[i].variable) {
					//check if number is fraction
					if (elementArray[i].denominator !=1){
						fractionFound=true;
						fractionPtr=i;
					}
				}

			} else if (i>eqSignLoc && elementArray[i].elemtype=="term") { 
				if (elementArray[i].variable) {
					rightvariableFound=true;
					ansArray[2]=rightvariableFound;
					// bts 032115: change test for coefficient to include fraction
					if (elementArray[i].numerator !=1 || 
							elementArray[i].denominator != 1) {
						rightcoeffFound=true;
						ansArray[3]=rightcoeffFound;
					}
				} else if (!elementArray[i].variable) {
					if (elementArray[i].denominator!=1){
						fractionFound=true;
						fractionPtr=i;
					}
				}
			}
		}
		checkForDone=false;
	}	
	
	if (leftcoeffFound && rightcoeffFound) {
		solved=false;
	} else if ((leftcoeffFound && leftvariableFound) ||
			(rightcoeffFound && rightvariableFound)){
		solved=false;
	} else if (leftvariableFound && rightvariableFound) {
		solved=false;
	} else {
		solved=true;
	}
	ansArray[4]=solved;
	//bts 012115: set fraction pointer field to -1 if no fractions
	if (fractionFound) {
		ansArray[5]=fractionPtr;	
	} else {
		ansArray[5]=-1;
	}
	return(ansArray);
}

function checkForEqSolved()
{
	/*
	 * checks if an equation is solved
	 * returns true if solved
	 * writes "equation solved" to blackboard
	 * 
	 * bts 120814: check inequalities
	 */
	var solved=false;
	var i;
	var leftvariableFound, leftcoeffFound;
	var rightvariableFound, rightcoeffFound;
	var eqSignLoc;
	var checkForDone = true;
	// bts 120914: initialize actionIndicator here
	var actionIndicator=0; // 0: not solved
						 // 1: solved
						 //  2: simplify last fraction
						 //  3: equation is false
						 //  4: equation is true
						 // 5: solving absol value single term (special case)
	
	var fractionFound, simplified;
	var fractionPtr; //element loc for fraction
	
	//bts 010315: add errMsgText var
	var errMsgText;
	
	// bts 121014: separate functionality into different functions
	// Not solved if struct length > 3
	//  array pos 0=leftvarfound
	//	array pos 1=leftcoefffound
	//	array pos 2=rightvarfound
	//	array pos3=rightcoefffound
	//	array pos4= solved true/false
	//	array pos5, if exists = fraction loc pointer
	//bts 012715:initialize array
	var checkVarsCoeffsArray=[false,false,false,false,false,-1];
	
	// check for single term within absolute value markers
    var absolValSingleTerm=[];
    absolValSingleTerm=checkAbsolValSingleTerm();
    if (absolValSingleTerm[0]!=-1) {//found single term within abol val
    	// update structure; set up prompts
    	promptSingleAbsVal(absolValSingleTerm);
    	solved=false;
    	actionIndicator=5;
    	// bts 1013: fix absol val bug by returning here
    	return(actionIndicator);      	
    }

	if (elementArray.length<=3) {
		//check vars and coefficients
		checkVarsCoeffsArray=checkEqVarsCoeffs();
	}
	
	eqSignLoc=findEqualityLocInStruct();	
	
	// bts 120914: changed logic order
	solved=checkVarsCoeffsArray[4];
	//bts 012115: -1 indicates no fractions found
	//bts 012715: check for undefined or false field
	if (checkVarsCoeffsArray[5] != -1 || checkVarsCoeffsArray[5]==false) {
		fractionFound=true;
		fractionPtr=checkVarsCoeffsArray[5];
	}
	
	if (solved) {
		if (fractionFound) {//check if it can be simplified
			//bts 121114: hide the operation menu
			document.getElementById("operationMenuArea").style.display="none";
			//bts 012115: replace computeSimpleFraction with its code
			//	to control displaying form for simplifying last fraction
			//var simplified=computeSimpleFraction(fractionPtr);
			var simplified;
			var cancelNumber = [];
			
			cancelNumber = checkForFractionCancel(fractionPtr,fractionPtr);
			if (cancelNumber[0] != 0) {// ask if fraction(s) should be canceled again
				//prompt for common factor
				document.getElementById("simplifylastfractionform").style.display="";
				simplified=false;
			} else {
				simplified=true;
				document.getElementById("simplifylastfractionform").style.display="none";
			}

			if (simplified)	{
				solved=true;
				actionIndicator=1;
			} else {
				//bts 012115: set action indicator to 2, not 0, for menu display
				actionIndicator=2;
				solved=false;
		    	//save fraction pointer
				document.getElementById("operationMenuArea").style.display="none";
				//bts 12282015: hide getuseranswer form
	    		document.getElementById("getanswerform").style.display="none";

				simplified=true;
		    	var objectLocElement = document.getElementById("hiddenendobj");
		    	objectLocElement.innerHTML=fractionPtr;
		    	var color = "yellow";
		    	writeMultHighlight(fractionPtr,1,elementArray.length,color);
				//bts 121014: moved return to here for fract simplify
		    	return(actionIndicator);			
			} 
		} else {
			actionIndicator=1;
		}
		
		//bts 120814: solved is true, check inequality opers. 
		//bts 09032015: move finalAnswer declaration to here
		var finalAnswer="";
		var trueFinalAnswer="";
		var solutionCnt;
		
		var equationFalse=false;
		var inequalitySign, trueFalse, trueFalseAns;
		var lastTerms=[];
		trueFalse=false;
		leftvariableFound=checkVarsCoeffsArray[0];
		rightvariableFound=checkVarsCoeffsArray[2];

		inequalitySign=elementArray[eqSignLoc].string;
		if (!leftvariableFound && !rightvariableFound)			
				trueFalse=true; //true/false condition exists
		lastTerms=getLastTerms();
		//bts 09102015: test for true/false if NOT in abs val checking phase
		//	test both for incheckphase flag and checkingprocess 1st/2nd check flag
		var inEqChecking=false;
		if (document.getElementById("hiddennocheck").innerHTML=="incheckphase" ||
				document.getElementById("hiddencheckingprocess").innerHTML!="") {
			inEqChecking=true;
		}
		
		if (trueFalse) {
			//bts 022615: if eq sign is u225f ?= change to =
			if (inequalitySign == "\u225f") inequalitySign="=";
			//bts 09102015: added inEqChecking boolean to not include 
			//		abs val checking problems
			if (inequalitySign !="=" && !inEqChecking) {
				// test equation for true or false condition
				var trueFalseAns=testTrueFalseAns(inequalitySign,lastTerms);
				//prompt for true or false
				promptForTrueFalse(trueFalseAns);
				actionIndicator=3;
			} else {//equal sign, test if 2 constants (no var) remain
				//bts 110820156: moved get solutionCnt val to here
				solutionCnt=document.getElementById("hiddensolutions").innerHTML;
				if (lastTerms[0]==lastTerms[1]) {//restore default equationFalse
					//bts 022615: set u225F to =
					elementArray[eqSignLoc].string="=";
					writeToTable("** Equation is true **");
					//solutionCnt=document.getElementById("hiddensolutions").innerHTML;
					if (solutionCnt==undefined || solutionCnt=="") {
						solutionCnt="1";
					} else {
						solutionCnt="2";
					}
					document.getElementById("hiddensolutions").innerHTML=solutionCnt;
					/* bts 11082015 moved block of code down
					if (document.getElementById
							("hiddencheckingprocess").innerHTML=="first" &&
							solutionCnt=="1")  {
						...	
					}
					*/
					equationFalse=false;
				} else {//set equationFalse variable
					elementArray[eqSignLoc].string="\u2260";
					//bts 11022015: check if testing equations
					if (document.getElementById
							("testevalequation").innerHTML=="testequation"){
						writeToTable("** Equation is false **");
					} else {
						writeToTable("** Extraneous solution **");
					}
					equationFalse=true;
				}
				//bts 11082015: moved block of code below to here from above
				if (document.getElementById
						("hiddencheckingprocess").innerHTML=="first" &&
						solutionCnt=="1")  {
					trueFinalAnswer=document.getElementById
						("hiddenfirsteqans").innerHTML;
				} else if (document.getElementById
						("hiddencheckingprocess").innerHTML=="second" &&
						solutionCnt=="1") {
					trueFinalAnswer=document.getElementById("hiddensecondanswer").innerHTML;						
				} else {//both answers are good
					//format trueFinalAnswer for display
					trueFinalAnswer=formatAbsFinalAnswer
							(document.getElementById("hiddenfirsteqans").innerHTML,
							document.getElementById("hiddensecondanswer").innerHTML);
				}

				actionIndicator=1;
				if (document.getElementById
						("hiddencheckingprocess").innerHTML=="second") {
					//bts 09042015: write final answer here: either both
					//	solutions; one solution; or no solution
					elementArray.splice(1);//reset elementarray struct except 
					//for 1st element
					elementArray[0].elemtype="special";
					trueFinalAnswer=formatCompareOper(trueFinalAnswer);
					if (solutionCnt=="1" || solutionCnt=="2") {
						//at least 1 valid solution
						elementArray[0].string=trueFinalAnswer;
						//bts 09092015: changed final result text
						trueFinalAnswer=" ** Final result after checking both solutions **";
					} else {
						elementArray[0].string=" ";
						trueFinalAnswer=" ** No Solution **";
					}
					writeToTable(trueFinalAnswer);
					//reset process indicator
					document.getElementById("hiddencheckingprocess").innerHTML="";
				} else if (document.getElementById
						("hiddencheckingprocess").innerHTML=="first" ||
						document.getElementById
						("hiddencheckingprocess").innerHTML=="") {
					document.getElementById("hiddencheckingprocess").innerHTML="second";
				}
			}
		}

		//bts 120914: display solved in blackboard if true/false answer not expected
		if (solved && !trueFalse) {
			//bts 08242015: check for absol val bars in orig expn.
			//	if found, change solved msg to Possible solution. Needs to be checked.
			var origExpStr=origExp.join("");
			if (origExpStr.indexOf("|")>-1) {
				writeToTable("** Possible solution. Answer needs to be checked.");
			} else {
				if (inequalitySign =="=") {
					writeToTable("** Equation Solved! **");
				} else {
					writeToTable("** Inequality Solved! **");
				}
			}
		}
	}

	//bts 010315: check if solving 1st absol val equation
	//	if so, reset elementArray to 2nd equation; blank out hidden 2nd
	//	expn later
	
	//TODO: create hidden variable for equationFalse=true so that
	//		we only ask them to solve the equation that is true, not false one
	if (actionIndicator==1) {//equation solved; check for 2nd equation
		var hiddenSecondExpn=document.getElementById("hiddensecondexpn");
		var hiddenFirstEqAns=document.getElementById("hiddenfirsteqans");
		var hiddenAbsValSide=document.getElementById("hiddenabsvalorigside");
		var hiddenDoNotCheck=document.getElementById("hiddennocheck");
		var arrayExpn=[];
		var lastConstant;
		var secondAns=0;
		if (hiddenSecondExpn.innerHTML!="") {
			if (hiddenFirstEqAns.innerHTML !="") {// solved 2nd eq
				//bts 012815: skip if in middle of checking phase
				if (hiddenDoNotCheck.innerHTML!="incheckphase") {
					//handle display of both eqs if inequality
					var equalOper=findEqualityLocInStruct();
					//bts 011715:move some code from below to here so that
					//	we have these values when eq uses = sign (for checking)
					var absValFlags=[];
					var hiddenValList=fixCompareOper(hiddenAbsValSide.innerHTML);
					absValFlags = hiddenValList.split(","); 
					//var finalAnswer=""; moved 
					var reverseSign;
					//find constant from second equation
					if (leftvariableFound){//constant is last term; else 1st term
						lastConstant=elementArray[2].string;
					} else lastConstant=elementArray[0].string;
					//bts 09032015: save complete second answer to hidden var
					// set counter for displaying final answer(s) or no solution
					var secondAnsString=buildStrPart(0,elementArray.length-1);
					secondAnsString=formatCompareOper(secondAnsString);

					document.getElementById("hiddensecondanswer").innerHTML=secondAnsString;
					document.getElementById("hiddencheckingprocess").innerHTML="first";

					//bts 011615: save second answer
					secondAns=lastConstant;
					
					//bts 012915: save second answer to hidden array
					//	for use in checking phase only
					hiddenAbsValSide.innerHTML=hiddenAbsValSide.innerHTML+","+
							lastConstant;					
				}
				
				//bts 011514: check hidden var for doing equation check.
				//	if found: restore original expression, substitute
				//	1st answer for var; solve as evaluate; then do same
				//	with second answer.
				//bts 012815: redo logic for checking 1st and 2nd eqs.
				var eqToCheck=0; //default is check first eq, then second
				//jcs042815 hide common factor
				document.getElementById("simplifylastfractionform").style.display="none";

				if (document.getElementById
						("hiddendoeqchecking").innerHTML=="checkequation") {
					if (hiddenDoNotCheck.innerHTML=="skipfirst" ||
							hiddenDoNotCheck.innerHTML=="incheckphase") {
						//skip first eq; go right to second eq or do 2nd eq
						eqToCheck=1;//check second eq
						//bts 012915: change parameters: secondAns is now last field in valflags
						checkEqResult(eqToCheck);
						//bts 012915: 2nd check is done set flag to exit
						document.getElementById("hiddendoeqchecking").innerHTML=
							"checkequationdone";
					} else {
						//do first equation
						checkEqResult(eqToCheck);
						hiddenDoNotCheck.innerHTML="incheckphase";
					}
					if (equationFalse) {
						hiddenDoNotCheck.innerHTML="skipsecond";
					}
					actionIndicator=0;//not yet solved, so continue
					document.getElementById("operationMenuArea").style.display="";
					document.getElementById("equationMenu").selectedIndex=0;
					//jcs080615 test
					displayTip("equation");					

					//bts 012615: checking phase for absol val eqs resumes w doAlgExpSteps
		           	doAlgExpSteps();
		           	//bts 020415: added test for singleabsolval condition; erase it further down
		           	if (document.getElementById("hiddencaller").innerHTML==
		           		"absolutevalue" || 
		           		document.getElementById("hiddensingleabsolval").innerHTML==
		           			"absolutevalue") {
		           		actionIndicator=5;
		           	}
		           	//bts 012815: reset flag to indicate in the
		           	//	middle of checking phase
					hiddenDoNotCheck.innerHTML="incheckphase";
	            	return(actionIndicator);
				} else {//finished with absol val eq; no need to check results
					// clear out both eq hidden vars
					// these are also cleared out in resetExercise called
					hiddenSecondExpn.innerHTML="";
					hiddenFirstEqAns.innerHTML="";
					hiddenAbsValSide.innerHTML="";
				}
				// bts 012915: reset hidden vars after completing
				//	checking phase
				if (hiddenDoNotCheck.innerHTML=="incheckphase") {
					hiddenDoNotCheck.innerHTML="";
					document.getElementById("hiddendoeqchecking").innerHTML="";					
					document.getElementById("hiddensingleabsolval").innerHTML="";
				}
				actionIndicator=1;		
			} else {//solved 1st equation so switch to second one
				// save 1st eq answer as string in hidden variable
				// save the constant to hidden variable hiddenabsvalside
				if (leftvariableFound){//constant is last term; else 1st term
					lastConstant=elementArray[2].string;
				} else lastConstant=elementArray[0].string;
				hiddenAbsValSide.innerHTML=hiddenAbsValSide.innerHTML+","+
							lastConstant;
				//bts 011915
				var holdString=buildStrPart(0,elementArray.length-1);
				holdString=formatCompareOper(holdString);
				hiddenFirstEqAns.innerHTML=holdString;
				if (equationFalse) {//eq has 1 solution to check
					hiddenDoNotCheck.innerHTML="skipfirst";
				}

				elementArray.splice(0);//reset elementarray struct
				//change any html code to utf code for <,>
				var secEqString=fixCompareOper(hiddenSecondExpn.innerHTML);
				arrayExpn=parseString(secEqString,1); //convert eq string to array
				errMsgText=buildStructure(arrayExpn,elementArray);
				if (!errMsgText) {
					actionIndicator=0;
				} else {
					alert("Error with second equation for absol vals.");
				}
				writeToTable(" ** Now solve the second equation");
				//jcs050815 add audio for abs value problem
				findAudio("1stproblemsolved");
			}
		} 
	}	
	return (actionIndicator);
}

function formatAbsFinalAnswer(firstAns,secondAns)
{
	/*
	 * Formats final answer when there are 2 correct answers
	 * after checking absol value equations
	 */
	var finalAnswer="";
	var signLoc;
	var absValFlags=[];
	var reverseSign;
	var lastConstant;
	
	var hiddenAbsValSide=document.getElementById("hiddenabsvalorigside");
	var hiddenValList=fixCompareOper(hiddenAbsValSide.innerHTML);

	absValFlags = hiddenValList.split(","); 
	lastConstant=absValFlags[absValFlags.length-1];
	
	//extract sign from each answer
	if (firstAns.indexOf("=")>-1 || secondAns.indexOf("=")>-1) {
		//eqs have = signs 
		finalAnswer=firstAns+" or "+secondAns;
	} else {
		//not eq sign
		// first check for lt or le signs
		//signLoc=firstAns.indexOf("\u003c");
		//if (signLoc==-1) signLoc=firstAns.indexOf("\u2264")
		//if (signLoc != -1) {
		//	finalAnswer=finalAnswer+firstAns.subString(0,signLoc);
		//}	
		if (absValFlags[0]=="left") {
			if (absValFlags[1]=="\u003c" || 
					absValFlags[1]=="\u2264") {
				//abs val on left side (1st eq) and less than
				//x<num: n2<x<n1
				finalAnswer=lastConstant+absValFlags[1]+
							absValFlags[2]+absValFlags[1]+absValFlags[3];
			} else {
				//abs val on left side and greater than
				// x>n1: x>n1 or x<n2
				reverseSign=switchOperSign(absValFlags[1]);
				finalAnswer=absValFlags[2]+
							reverseSign+lastConstant+" or "+
							absValFlags[2]+absValFlags[1]+
							absValFlags[3];
			}
		} else {
			if (absValFlags[1]=="\u003c" || 
					absValFlags[1]=="\u2264") {
				//abs val on right side (1st eq) and greater than
				//n<x: n1< x<n2
				reverseSign=switchOperSign(absValFlags[1]);
				finalAnswer=absValFlags[2]+reverseSign+
					absValFlags[3]+" or "+absValFlags[2]+
					absValFlags[1]+lastConstant;
			} else {
				//abs val on right side and less than
				//n>x: n2<x<n1
				reverseSign=switchOperSign(absValFlags[1]);
				finalAnswer=lastConstant+reverseSign+
						absValFlags[2]+reverseSign+absValFlags[3];
			}						
		}
	}
 
	//finalAnswer=formatCompareOper(finalAnswer);

	return(finalAnswer);
}


//bts 012915: change function parameters
//function checkEqResult(eqToCheck,secondAns,varToSub)
function checkEqResult(eqToCheck)
{
	/*
	 * Called to verify results of equations with abol vals and
	 * 2+ vars, one within the absol val bars
	 * if eqToCheck=0: check first equation
	 * if eqToCheck=1: check 2nd equation
	 */
	var hiddenSecondExpn=document.getElementById("hiddensecondexpn");
	var hiddenFirstEqAns=document.getElementById("hiddenfirsteqans");
	var hiddenAbsValSide=document.getElementById("hiddenabsvalorigside");

	var errMsgText=buildStructure(origExp,elementArray);
	if (errMsgText) {
		alert("Error restoring original equation.");
		return;
	}
		
	//bts 08252015: move code to after displaying original expression
	// bts 022615: find location of eq oper and change to ?= or u225f
	//var eqOperLoc=findEqualityLocInStruct();
	//elementArray[eqOperLoc].string="\u225f";
	
	//substute 1st answer for varToSub
	var absValFlags=[];
	var hiddenValList=fixCompareOper(hiddenAbsValSide.innerHTML);
	absValFlags = hiddenValList.split(","); 
	
	var secondAns=absValFlags[absValFlags.length-1];//second answer is last element in array
	var varToSub=absValFlags[2];

	var answerToCheck;
	//bts 012915: set up answers using list elements 3 and 4
	//bts 020815: display first ans for 1st check phase; second ans for 2nd phase
	//var displayAnswers=absValFlags[3]+", "+secondAns;
	var displayAnswers="";
	if (eqToCheck==0) {//1st eq
		answerToCheck=absValFlags[3];//first answer
		displayAnswers=absValFlags[3];
	} else if (eqToCheck==1) {//2nd eq
		answerToCheck=secondAns;
		displayAnswers=secondAns;
	}
	
	writeToTable(" -- Check "+displayAnswers+" against original expression");
	//bts 08242015: reverse any subtraction operations to additions,
	//		reverse sign of subtracted term; displays msg
	// bts 022615: find location of eq oper and change to ?= or u225f
	// bts 09092015: change only equal sign + to ?=; leave other signs as is
	var eqOperLoc=findEqualityLocInStruct();
	if (elementArray[eqOperLoc].string=="=") 
		elementArray[eqOperLoc].string="\u225f";

	checkForSubtraction();

	checkEqSubValsForVars(answerToCheck,varToSub);	
	return;
}

function checkEqSubValsForVars(answerToSub,varToSub)
{
	/*
	 * clone of getvarvals: substitutes answer into eq vars
	 * for eqs with absol vals and more than 1 variable; 
	 */
	var expnToChange = buildStrPart(0,elementArray.length-1);
	var subCount = 0; 
	var elementCopied;	
	var newExpn=[];
	k=0; // counter for newExpn array

	for (i=0;i<expnToChange.length;i++) {
		elementCopied = false;
		if (expnToChange[i] == varToSub) {
			subCount++;
			newExpn[k] = "(";
			k++;
			newExpn[k] = answerToSub;
			k++;
			newExpn[k] = ")";
			k++;
			elementCopied = true;
		} 

		if (!elementCopied) {
			newExpn[k] = expnToChange[i];
			k++;
			if (i==0 && expnToChange[i]=="-") {
				newExpn[k]="1";
				k++;
				newExpn[k]="*";
				k++;
			}
		}		
	}
	
	// bts 092614: Use parseString to change newExpn to proper format for
	//		building element array the second time
	var testExpn = newExpn.join("");
	newExpn = parseString(testExpn,1);
		
	// bts 012414: return errMsgText from buildStructure so that we
	//	catch error of too many variables. No need to return elementArray
	//	since global.
	var errMsgText="";
	errMsgText = buildStructure(newExpn, elementArray);
	if (errMsgText) return;
	
	writeToTable(" -- Substituted " + answerToSub +" for "+ varToSub);	
	elementArray.splice(1);
	
	newExpn = addAsterisk(newExpn);
	//bts 012115: use removeParensInStructure
	//newExpn = removeParens(newExpn);	
	// build a new structure
	errMsgText = buildStructure(newExpn, elementArray);
	removeParensInStructure();
	// display the new structure with modified expression
	writeToTable(" -- Removed parentheses");
	changeMinusToAdd();
	return;
}

function formatCompareOper(stringToCheck)
{
	/*
	 * checks for utf encoding for < and > signs
	 * and converts to html format
	 */
	var retString=stringToCheck;
	var fixString=stringToCheck.replace("\u003c","&lt;");
	retString=fixString.replace("\u003e","&gt;");
	return (retString);
}

function fixCompareOper(stringToCheck)
{
	/*
	 * checks for html encoding for < and > signs
	 * and converts to utf codes
	 */
	var retString=stringToCheck;
	var fixString=stringToCheck.replace("&lt;","\u003c");
	retString=fixString.replace("&gt;","\u003e");
	return(retString);
}

function promptForTrueFalse(expectedAns) 
{
	/*
	 * prompt for true/false answer
	 * display special true/false element in mainwindow
	 * After user selection, display right or wrong msg 
	 * and exit
	 */
	
	//store correct answer
	var hiddenAns=document.getElementById("hiddenanswertext");
	hiddenAns.innerHTML=expectedAns;
	document.getElementById("operationMenuArea").style.display="none";
	var trueFalseAns=document.getElementById("UserInstructionPrompt");
	trueFalseAns.innerHTML="Is the equation sentence true or false? "
		+"\<button type='button' id='truebutton' onclick='return trueFalse(true);' >True\</button>"+
		"\<button type='button' id='falsebutton' onclick='return trueFalse(false);' >False\</button>";
	document.getElementById("UserInstructionPrompt").style.display="";
	return;
}

function trueFalse(useranswer)
{
	/*
	 * gets user answer to true/false prompt and compares it with computed answer
	 *
	 */
	var response=document.getElementById("UserInstructionPrompt");
	var hiddenAns=document.getElementById("hiddenanswertext");
	var correctanswer=hiddenAns.innerHTML;
	
	if (String(useranswer) != correctanswer) {
		response.innerHTML="Wrong. Equation is "+correctanswer+
		"\<br />\<button type='button' onclick='correctTrueFalse();' >Continue\</button>";		
	} else {
		writeToTable("After verifying equation is "+correctanswer+"** Exercise completed. **");
		hiddenAns.innerHTML="";
		response.innerHTML="";
		document.getElementById("UserInstructionPrompt").style.display="none";
		resetAfterSolved();
	}
	return;
}

function correctTrueFalse()
{
	var hiddenAns=document.getElementById("hiddenanswertext");
	var response=document.getElementById("UserInstructionPrompt");
	var correctanswer=hiddenAns.innerHTML;
	writeToTable("After verifying equation is "+correctanswer+"** Exercise completed. **");
	hiddenAns.innerHTML="";
	response.innerHTML="";
	document.getElementById("UserInstructionPrompt").style.display="none";
    document.getElementById("workarea").style.display="none";
	resetAfterSolved();
	return;	
}


function testTrueFalseAns(inequalitySign,lastTerms)
{
	/*
	 * bts 120814: tests if equation with inequality oper is
	 * true or false and returns indicator. Should only be here if 
	 * oper is not = sign
	 * 
	 * bts 010515: add less than/greater than codes
	 */
	var trueFalseAns=false;
	switch(inequalitySign) 
	{
 	  case "\u003c": //utf code for <
 	 	if (lastTerms[0] < lastTerms[1]) trueFalseAns=true;
 	 	break;
 	  case "\u003e":  //utf code for >
 	 	if (lastTerms[0] > lastTerms[1]) trueFalseAns=true;
 	 	break;
 	  case "\u2264": // <=
 	 	if (lastTerms[0] < lastTerms[1] ||
 	 			lastTerms[0]==lastTerms[1]) trueFalseAns=true;
 	 	break;
 	  case "\u2265": // >=
 	 	 if (lastTerms[0] > lastTerms[1] ||
 	 	 		lastTerms[0]==lastTerms[1]) trueFalseAns=true;
 	 	 break;	
 	  default:
 	  	 break;
	}	
	return(trueFalseAns);
}

function getLastTerms() {
	/*
	 * Returns the 2 last values in the equation
	 */
	var numArray = [];
	numArray[0] = Number(elementArray[0].numerator);
	numArray[1] = Number(elementArray[2].numerator);
	var denom1 = Number(elementArray[0].denominator);
	var denom2 = Number(elementArray[2].denominator);
	
	if (denom1>1) {
		numArray[0] = numArray[0]/denom1;
	}
	if (denom2>1) {
		numArray[1] = numArray[1]/denom2;
	}	
	return(numArray);
}

function simplifyLastEqFraction(enterAnsForMe)
{
	var simplifyFractionInput;
	var errorMessage;
	var simplifyFractionNumber;	
	var cancelNumber = [];
	var i;
	//bts 123114: removed unused vars; initialized matchFound, solved
	var matchFound=false;
	var solved=false;
	var objectLoc, objectLocElement;
	
	var errorToDisplay=document.getElementById("warningMessage");
	errorToDisplay.innerHTML = ""; 

	//bts 123114: erase operation menu display
	document.getElementById("operationMenuArea").style.display="none";

	document.getElementById("simplifylastfractiongotit").style.display="none";
	
	simplifyFractionInput = document.getElementById("simplifylastfractioninput");
	errorMessage = document.getElementById("simplifylastfractionmessage");
	simplifyFractionNumber = simplifyFractionInput.value;
	document.getElementById("simplifylastfractionform").reset();
	
	// check if we're solving the last fraction term
	// or last fraction when there are still whole numbers to add
	// bts 090414: if coming from alg expns, fraction term ptr
	//	MUST be set in hiddenendobj.
	
	objectLocElement = document.getElementById("hiddenendobj");
	objectLoc = objectLocElement.innerHTML;

	if (objectLoc == "undefined" || objectLoc == null || objectLoc=="") {
		objectLoc = 0;
	}
	
	// check if value entered is in factor list
	// then cancel/simplify the fraction if it is found 
	
	cancelNumber = checkForFractionCancel(objectLoc,objectLoc);
	for (i=0;i<cancelNumber.length;i++) {
		if (simplifyFractionNumber == cancelNumber[i]) {
			errorMessage.innerHTML=" ";
			matchFound = true;
			i=cancelNumber.length;
		}
	}
	
	// bts 1012: get access to warning message element at bottom of screen
	var errorToDisplay=document.getElementById("warningMessage");
	
	if (enterAnsForMe) {
		//bts 08132015: write gave up msg for hw
		writeGaveUpMsg(" computing factor for cancelling last fraction");

		// bts 1010: set simplifyFractionNumber of best possible
		//		factor for cancelling (max # in cancelNumber array)
		simplifyFractionNumber = Math.max.apply(Math,cancelNumber);
		simplifyFractionInput.value = simplifyFractionNumber;
		
		errorMessage.innerHTML="The correct common factor is: " 
			+ simplifyFractionNumber+".";	
		enterAnsForMe=false;
		document.getElementById("simplifylastfraction").style.display="none";
		document.getElementById("simplifylastfractionhelpbutton").style.display="none";
		document.getElementById("simplifylastfractiongotit").style.display="";
		// bts 1012: clear out any previous error messages
		errorToDisplay.innerHTML="";
		//clear out hidden value
		objectLocElement.innerHTML="";
		return false;
	}
	
	// bts0717 show factor number they entered


	if (!matchFound) {
		//bts 08132015: write wrong common factor to hw storage
		writeWrongAns(" ",simplifyFractionNumber,"simplifylastfraction");

		errorToDisplay.innerHTML = "Common factor "+simplifyFractionNumber+
			" is incorrect. Try again.";
		// bts 0718: enable I Give Up button
		document.getElementById("simplifylastfractionhelpbutton").disabled=false;
		document.getElementById("simplifylastfractionform").reset();
		return false;
	}
	// bts 0718: correct answer, disable I Give Up button
	document.getElementById("simplifylastfractionhelpbutton").disabled=true;
	// bts 1012: Clear out any error messages
	errorMessage.innerHTML="";
	errorToDisplay.innerHTML="";
	//clear out hidden value
	objectLocElement.innerHTML="";
	
	simplifyFractionNumber = Number(simplifyFractionNumber);
	elementArray[objectLoc].numerator = Number
		(elementArray[objectLoc].numerator/simplifyFractionNumber);
	elementArray[objectLoc].denominator = Number
		(elementArray[objectLoc].denominator/simplifyFractionNumber);
	// rebuild elementArray.string;
	elementArray[objectLoc].string = elementArray[objectLoc].numerator+"/"+
		elementArray[objectLoc].denominator;
	
	// cancel out the numerator
	var elemArrayLen = elementArray.length;
	numeratorIndicator = true;
	writeCancelMark(objectLoc, elementArray[objectLoc].numerator, 
			numeratorIndicator,elemArrayLen);
	// cancel out the denominator
	numeratorIndicator = false;
	writeCancelMark(objectLoc, elementArray[objectLoc].denominator,
			numeratorIndicator,elemArrayLen);
	
	if (elementArray[objectLoc].denominator==1) {
		elementArray[objectLoc].string=String(elementArray[objectLoc].numerator);
	}
	writeToTable(" -- After dividing by the common factor "+simplifyFractionNumber); 

	// test again
	var actionIndicator=checkForEqSolved();
	if (actionIndicator==1) {
		writeToTable(" -- Equation solved successfully!");	
		solved=true;
		resetAfterSolved();
		return true;
	} else if (actionIndicator==0) {
		solved=false;
		//jcs112414 display equation tip here
		displayTip("equation");
		//jcs042815 test display equation menu
		document.getElementById("operationMenuArea").style.display="";
	} else if (actionIndicator==2) {
		document.getElementById("getanswerform").style.display="none";
        document.getElementById("userInstructions").style.display="";
        document.getElementById("whatToDoNextArea").style.display=""; 			
		document.getElementById("operationMenuArea").style.display="none";
		//jcs112414 display equation tip here
		displayTip("equation");
		solved=false;
	}
	return(solved);
}


function eqCombineConstants(newString)
{
	/*
	 * 1027: new eqCombineConstants function for 
	 * 		combining constants for equations only.
	 * 		Based on simplify exprn combineconstants function
	 * 
	 * search elementArray structure for constants: terms that 
	 * do not have variables associated with them.
	 * if more than 1 constant, build prompt and calculate answer
	 * replace elements in array with correct answer, write out
	 * resulting structure/expression
	 * 
	 * 1022: Modified to search left/right side for equations
	 * 	 find equality oper location
	 * 	and separately combine constants to left/right of equality oper 
	 * 	Requires making this a multi-prompt function rather than
	 * 	the single prompt function for expressions (oneprompt should
	 * 	be set to false and userprompt,calcans fields are arrays
	 */
	var matchPositions = [];
	// bts 1022: change variables to arrays for multiple prompts
	var userPrompt = [];
	var correctAns = false;
	//var calcAns = new Number(0);
	var calcAns=[];
	var holdAns=[];
	//var holdAns;
	var i, counter, plusPtr;
	var errorCode, errMsgText;
	
	// bts 1022: variables for handling equations
	var eqLoop, eqCtr;
	var equalityOpLoc;
	var leftEqEnd, rightEqStart;	
	var signOper,subtractOper;
	errMsgText = "";	
	counter = 0;
	
	var i=0;
	// build string version of equation left/right sides
	var expnToSolve=buildStrPart(0,elementArray.length-1);
	expnToSolve=expnToSolve.toLowerCase();
	
	// set selExpnString equal to expnToSolve since no more selecting
	//		part of expression to solve; should fix problem with
	//		inequality opers coming in with & marks
	var selExpnString =expnToSolve;
	
	// find matching part of equation, for left/right sides
	// idxStart is starting point in elementArray
	// idxEnd is ending point in elementArray
	// idxLength is length of portion of elementArray to use
	idxStart=expnToSolve.indexOf(selExpnString);
	var arrayString = "";
	var newIdx;
	if (idxStart < 0) {
		errorCode=13; // Incorrect selection selExpnString
		errMsgText=errorMsg(errorCode,errMsgText,selExpnString);
		return(errMsgText);
	} else if (idxStart >-1) {
		// set default start/end index points into elementArray
		var idxArray = [];
		idxArray = findArrayIndex(idxStart,selExpnString);
		// bts 03192014: findArrayIndex returns -1 if no match
		if (idxArray[0]==-1) { // match not found
			errorCode=13; // Incorrect selection selExpnString
			errMsgText=errorMsg(errorCode,errMsgText,selExpnString);
			return(errMsgText);	
		}
	}
	
	// bts 1022: no matching is necessary (code above is obsolete)
	//	so we should be here by default. 
	//	Check array first left side then
	//	right side of equality oper and build prompts/answers
	eqCtr=0;
	equalityOpLoc=findEqualityLocInStruct();
	// set equation variables 
	eqLoop=2;
	leftEqEnd=equalityOpLoc-1; 
	rightEqStart=equalityOpLoc+1;
	
	idxArray[0]=0;//start of left side equation
	idxArray[1]=leftEqEnd;//end of left side equation
	idxArray[2]=rightEqStart;//start of right side
	idxArray[3]=elementArray.length-1;
	var startPtr,endPtr;	
	//bts 010315: var for error on only 1 side of equation
	//	mark if error is on left or right side only
	var errorCtr=0;
	var errorLeftSide=false; 
	var errorRightSide=false;
	var combinedErrorMsg="";
	
	for (eqCtr=0;eqCtr<eqLoop;eqCtr++) {
		// check if selected expression is valid--does not span brackets 
		//    and does not include multiply or divide operation
		startPtr = Number(eqCtr)*2;
		endPtr=Number(eqCtr)*2+1;
		if (idxArray[endPtr]-idxArray[startPtr]<2) {
			errorCode=22;
			errMsgText=errorMsg(errorCode,errMsgText);
		} else {
			errMsgText = combineTermCheck(idxArray[startPtr],idxArray[endPtr],errMsgText);
			//bts 07272015: call new function to check if more than 1 add oper per side
			if (!errMsgText) {
				errMsgText=
					combineConstantsCheckAddOpers(idxArray[startPtr],idxArray[endPtr],errMsgText);
			}
		}
		//bts 010315: if error occurs on one side only, allow process to continue		
		if (errMsgText) {
			//bts 011415: new code for marking left/right side errors
			//bts 020915: save both errors, if there are 2; change logic for continuing
			if (eqCtr==0) {
				errorLeftSide=true;//left error if 1st loop interation
				combinedErrorMsg="On equation left side, "+errMsgText;
			}
			if (eqCtr==1) {
				errorRightSide=true;//right error if 2nd loop interation
				if (combinedErrorMsg) {
					combinedErrorMsg=combinedErrorMsg+"<br /> On equation right side, "
									+errMsgText;
				} else {
					combinedErrorMsg="On equation right side, "+errMsgText;
				}
			}
			//errorCtr++;
			//if (errorCtr==2) return(errMsgText);
			if (errorLeftSide && errorRightSide) return(combinedErrorMsg);
			errMsgText="";
		}
	}
	
	// bts 082314: use these vars for Give Up tip for fraction conversion
	var tipString=[];
	var tipCtr=0;
	var fractionPresent=false;
	var denomArray=[];
	var lcd, lcdMultiplier;
	var calcAnsHint=[];
	// bts 112714: add pointer into calcAnsHint array
	var calcAnsHintPtr;
	var j; 
	var numTotal;
	var positions = [];
	var holdAnsDenom;
	
	// bts 1023: loop twice for equations
	//  save right side fractions, if any, in separate denom array
	//	use denomArray for left side denominators
	// positions array holds constant positions for left side of equation
	var rightDenomArray=[];//holds right side denominators
	var rtPositions=[];//holds constant positions on right side
	var ltPositions=[];//hold left side positions temporarily
	//bts 030215: leftFractionPresent: indicates fraction on left side; initialize
	var rtFractionPresent=false;
	var leftFractionPresent=false;
	var rtLCD; //right side lcd
	//bts 112814: add explicit left side lcd
	var leftLCD;
	
	//bts 010315: set loop limit and start val for left only,
	//	right side only, or both sides using errorLeft/RightSide booleans
	var loopStart=0;//default val for both sides
	eqLoop=2;//default val for both sides
	if (errorLeftSide) {//do right side only
		loopStart=1;
		//bts 011415: change loop limit to 2 from 1
		eqLoop=2;
	} else if (errorRightSide) {//do left side only
		loopStart=0;
		eqLoop=1;		
	}
	//bts 010315:changed loop parameters to above vals
	//bts 020815: check again for valid constant terms
	var constantPositions=[];
	for (eqCtr=loopStart;eqCtr<eqLoop;eqCtr++) {
		j=0;
		startPtr = Number(eqCtr)*2;
		endPtr=Number(eqCtr)*2+1;
		constantPositions=
			checkForCombinableTerms(idxArray[startPtr],idxArray[endPtr]);
		if (constantPositions[0]!=-1) {
			for (var k=0;k<constantPositions.length;k++) {
				i=constantPositions[k];
				//for (i=idxArray[startPtr];i<idxArray[endPtr]+1;i++) {
				if (elementArray[i].elemtype == "term" && 
						elementArray[i].variable == null) { //constant term
					// build array of denominators
					// bts 1023: build left side of equation 
					//		in denomArray
					if (eqCtr==0) {
						denomArray[j]=elementArray[i].denominator;
						ltPositions[j]=i;
						j++;
						if (elementArray[i].denominator > 1) 
							//bts 030215: use leftFractionPresent
							//fractionPresent=true;
							leftFractionPresent=true;
					} else if (eqCtr==1) {
						rightDenomArray[j]=elementArray[i].denominator;
						rtPositions[j]=i;
						j++;
						if (elementArray[i].denominator > 1) 
							rtFractionPresent=true;
					}
				} 
			}
		}
	}
	
	//bts 011415: check if constant positions fall within absol val bars
	var barPos=[];
	var tempMatchPos=[];
	var matchPositions=[];
	var j,k;
	barPos=checkForAbsolValBars();
	var numBars=barPos.length/2;
	if (barPos.length>0 &&
			(ltPositions.length>1||rtPositions.length>1)) {// check if term betw absol bars
		for (eqCtr=loopStart;eqCtr<eqLoop;eqCtr++) {
			k=0;
			if (eqCtr==0) {
				matchPositions=ltPositions;
			} else if (eqCtr==1) {
				matchPositions=rtPositions;
			}
			for (i=0;i<matchPositions.length;i++) {
				for (j=0;j<barPos.length;j=j+2){
					if (matchPositions[i]<barPos[j]) {
						tempMatchPos[tempMatchPos.length]=matchPositions[i];//good match
						j=barPos.length;//force exit from loop
					} else if (matchPositions[i]>barPos[barPos.length-1]) {
						tempMatchPos[tempMatchPos.length]=matchPositions[i];//good match
						j=barPos.length;//force exit from loop						
					} else if (matchPositions[i]>barPos[j+1]) {
						if (numBars>1 && matchPositions[i]<barPos[j+(numBars*2)]) {						
							tempMatchPos[tempMatchPos.length]=matchPositions[i];//good match
							j=barPos.length;//force exit from loop							
						}
					}						
				}
			}
			if (eqCtr==0) {
				if (tempMatchPos.length>0) {
					ltPositions=[];
					while (k<tempMatchPos.length &&
							tempMatchPos[k]<equalityOpLoc) {
						ltPositions[ltPositions.length]=tempMatchPos[k];
						k++;
					}
				}
			} else if (eqCtr==1) {
				if (tempMatchPos.length>0) {
					rtPositions=[];
					while (k<tempMatchPos.length &&
							tempMatchPos[k]>equalityOpLoc) {
						rtPositions[rtPositions.length]=tempMatchPos[k];
						k++;
					}
				}
			}
			tempMatchPos=[];
		}//end of left/right loop
	}
	
	//call calculateLCD if there are fractions on left side
	//bts 030215: use leftFractionPresent instead of fractionPresent
	//if (fractionPresent) {
	if (leftFractionPresent) {
		//bts 112714: use tipString.length instead of tipCtr
		lcd = calculateLCD(denomArray);
		//bts 112814: hold the left lcd in leftLCD
		leftLCD=lcd;
		tipString[tipString.length]="Convert fractions on left side of equation "+
			" to common denominator: "+String(lcd);
	}
	//bts 1023: lcd tip for right side of equation
	if (rtFractionPresent) {
		rtLCD=calculateLCD(rightDenomArray);
	}
	
	subtractOper = false;
		
	//bts 1023: use positions array for left side
	//		of equation; rtPositions array for right side of equation

	// build left/right prompts only when needed 
	var leftOnly,rightOnly,bothSides;
	leftOnly=false;
	rightOnly=false;
	//bts 030215: added eqLoopStart to for loop; set to 0 for left only or left&right sides
	//		set to 1 if right side of eq only
	var eqLoopStart=0; //default for loop thru left/right sides of eq or left only
	//bts 021115: redo logic for selecting left and right sides
	eqLoop=2; //no need to change end loop since setting start of loop ctr to 0 or 1
	if (ltPositions.length>1 && rtPositions.length>1) {
		bothSides=true;
		eqLoopStart=0; // loop twice since both left/right have constants
	} else if (ltPositions.length<2 && rtPositions.length>1) {
		bothSides=false;
		//eqLoop=2;
		eqLoopStart=1;//start point for right side only
		rightOnly=true;
	} else if (ltPositions.length>1 && rtPositions.length<2) {
		bothSides=false;
		eqLoopStart=0;//start of loop for left side only
		//eqLoop=2;
		leftOnly=true;
	} else if (ltPositions.length<2 && rtPositions.length<2) { 
		errorCode=21; // No constants to combine
		errMsgText=errorMsg(errorCode,errMsgText);
		return(errMsgText);	
	}
	//bts 030215: added eqLoopStart var to for loop	
	//bts 030215: fix problem with userPrompt, calcAnsHint, calcAns arrays if
	//		solving only right side: nned to start arrays at 0, not 1
	for (eqCtr=eqLoopStart;eqCtr<eqLoop;eqCtr++) {
		userPrompt[eqCtr]="";
		calcAnsHint[eqCtr]="";
		holdAns[eqCtr]=0;
		calcAns[eqCtr]=0;
		if (eqCtr==1) {// switch to right side
			positions = rtPositions;
		} else if (eqCtr==0) {//left side
			if (ltPositions.length>1) {
				if (!bothSides) leftOnly=true;
				positions=ltPositions;
			} else if (rtPositions.length>1) {
				rightOnly=true;
				positions=rtPositions;
			}
		}
		for (i=0;i<positions.length;i++) {
			// bts 082314: build prompts differently for fractions
			// build prompt using
			// denoms (if fractions) before applying lcd
			// Build answer AFTER converting fractions to lcd
			// bts 1012: use prevSub to change leading constant to
			//		neg val if needed
			var prevSub=1;//default value if not preceded by subtraction
			signOper="";//set to blank before testing 1st constant
			subtractOper=false;//make sure this is false each iteration
			if (i==0) { // first constant
				//bts 1023: if 1st constant is not first term in struct then
				//		check if it is preceded by a subtraction
				//	if so, change value to negative
				//		leave as is if not preceded by subtraction
				//test if not 1st element in struct
				// or 1st element in right side for applying subtraction
				if ((eqCtr==0 && positions[i]!= 0) ||
						(eqCtr==1 && 
						 elementArray[positions[i]-1].elemtype!="equality")) {
					if (elementArray[positions[i]-1].string == "-") {
						signOper = "-";
						prevSub=-1;
					}
				}
				//bts 1023: add signOper symbol to prompt and use prevSub to 
				//	make leading constant negative for calculation
				//  Use array version of userPrompt and answer arrays
				// check right side of equation for fractions
				//bts 030215: use leftFractionPresent
				//if ((fractionPresent && eqCtr==0) || (eqCtr==1 && rtFractionPresent) && 
				if ((leftFractionPresent && eqCtr==0) || (eqCtr==1 && rtFractionPresent) && 
						elementArray[positions[i]].denominator != 1) {
					userPrompt[eqCtr] = userPrompt[eqCtr]+signOper+
								String(elementArray[positions[i]].numerator)
								+"/"+String(elementArray[positions[i]].denominator);
				} else {
					userPrompt[eqCtr] = userPrompt[eqCtr]+signOper+
									elementArray[positions[i]].string;
				}
			} else { // subsequent constants
					 // check previous operator for add or subtract
				if (elementArray[positions[i]-1].string == "-") {
						signOper = " - ";
						subtractOper = true;
				} else if (elementArray[positions[i]-1].string == "+") {
						signOper = " + ";
						subtractOper = false;
				}
							
				userPrompt[eqCtr] = userPrompt[eqCtr]+signOper+elementArray[positions[i]].string;
			}
			// bts 1023: separate tests for left/right fractions if equation
			// bts 030215: use leftFractionPresent
			if ((leftFractionPresent && eqCtr==0) || 
					(eqCtr==1 && rtFractionPresent)){//calculate fract answer
				var handleFraction=true;
				// bts 1023: use left/right lcd 
				if (eqCtr==1) {
					tempLCD=lcd;
					lcd=rtLCD;
				}
				if (handleFraction) {
					lcdMultiplier = lcd/elementArray[positions[i]].denominator;
					holdAnsDenom=lcd;
					holdAns[eqCtr]=elementArray[positions[i]].numerator*lcdMultiplier;
						
					//bts010814: Add to tipString array for fractions
					// bts 112714: use tipString.length instead of tipCtr
					// add intro line for right side
					if (rtFractionPresent && eqCtr==1 && i==0) {
						tipString[tipString.length]="Convert fractions on right side of equation "+"" +
							"to common denominator: "+String(rtLCD);
					}
					tipString[tipString.length]=String(elementArray[positions[i]].numerator)+"/"
							+ String(elementArray[positions[i]].denominator)+" * "
							+String(lcdMultiplier)+"/"+String(lcdMultiplier)+
							" = "+ String(holdAns[eqCtr])+"/"+String(lcd);	
				} 
			} else {
				holdAns[eqCtr] = elementArray[positions[i]].numerator;
			}
			if (subtractOper) {
				calcAns[eqCtr] = Number(calcAns[eqCtr])-Number(holdAns[eqCtr]);
			} else {
				calcAns[eqCtr] = Number(calcAns[eqCtr])+Number(holdAns[eqCtr]);
			}
				
			//bts 1023: make answer negative if preceded by subtraction
			if (prevSub==-1) calcAns[eqCtr]=prevSub*calcAns[eqCtr];
			//bts 112714: do hint for left side of equation if needed
			// bts 112814: use leftLCD for left side
			//bts 030215: use leftFractionPresent
			if (leftFractionPresent && eqCtr==0) {
				if (calcAns[0] == leftLCD) {
					//bts 021515: do not set ans to 1 and leftlcd to 1
					//		when numerator equals common denom
					//calcAns[0] = 1;
					//leftLCD=1;
					calcAnsHint[0] = calcAns[0];
				} else if (calcAns[0] == 0) {
					leftLCD=1;
					calcAnsHint[0]="0";
				} else {
					calcAnsHint[0]= calcAns[0].toString()+"/"+String(leftLCD);
				}
			}
			// bts 1023: set up hint for right side of equation
			// bts 112714: do right side hint if we're working on right side
			if (rtFractionPresent && eqCtr==1) {
				// bts011114: use calcAnsHint for displaying tip
				// bts 112714: use calcAnsHintPtr to find next element
				//		in calcAnsHint array
				//	change calcAnsHint[0] to calcAnsHint[calcAnsHintPtr]
				if (calcAnsHint==null || calcAnsHint==undefined) {
					calcAnsHintPtr=0;
				} else calcAnsHintPtr=1;
				
				//bts 021515: do not set ans to 1 and rightlcd to 1
				//		when numerator equals common denom
				if (calcAns[1] == rtLCD) {
					//calcAns[1] = 1;
					//rtLCD=1;
					calcAnsHint[calcAnsHintPtr] = calcAns[1];
				} else if (calcAns[1] == 0) {
					rtLCD = 1;
					calcAnsHint[calcAnsHintPtr]="0";
				} else if (calcAns[1]!=undefined){
					calcAnsHint[calcAnsHintPtr]= 
						calcAns[1].toString()+"/"+String(rtLCD);
				}
			}

		} // end of for loop to calculate answer, build prompt
		//bts 021715: check for rtFractionPresent for tip
		//bts 030215: move from below to here
		// use leftFractionPresent instead of fractionPresent
		if (leftFractionPresent && eqCtr==0 || rtFractionPresent&& eqCtr==1) {
			tipString[tipString.length] = 
				"Then add the fraction numerators and change the denominator to the "+
				"common denominator, or to a whole number.";
		}

	} // end of equation for loop
	// bts 1023: check both position arrays for error if equation	
	// restore left positions to positions array
	positions=ltPositions;
	if (positions.length <=1 || rtPositions.length <=1) {
		if (positions.length == 0 && rtPositions.length == 0) {
			errorCode=21; // equation has no constants to combine
			errMsgText=errorMsg(errorCode,errMsgText);
		}
		if (positions.length == 1 && rtPositions.length <=1) {
			errorCode=22; // Expression has only 1 constant
			errMsgText=errorMsg(errorCode,errMsgText);
		}
		// bts 112514: exit if there are no constants to combine
		if (errMsgText) return(errMsgText);
	}
	//bts 1023: end above if block
	if (positions.length > 1 || rtPositions.length>1) {
		//bts 030215: move highlight color to here; was missed on right side highlight
		var highlightColor = "orange";
		if (positions.length>1) {
			// highlight left side before prompting for answer
			for (i=0;i<positions.length;i++){
				writeMultHighlight(positions[i],1,elementArray.length,highlightColor);
			}
		}
		if (rtPositions.length>1) {
			// bts 1023: highlight right side for equations
			for (i=0;i<rtPositions.length;i++) {
				writeMultHighlight(rtPositions[i],1,elementArray.length,highlightColor);				
			}
		}
	}
			
	// insert answer in last position; remove other constant terms
	// bts 1023: if equations, set left/right side separately
	// start with right side and expressions:
	
	// combine left/right position arrays and work backwards
	//	do NOT remove the equality sign from the equation

	var doRight=false;
	// bts 030215: remove this line: save left fraction flag in case it's reset
	//var leftFractionPresent=fractionPresent;
	
	if (bothSides) {
		eqLoop=2;// update both right and left sides
		positions = rtPositions; // start with right side
		//bts 021715:use rtFractionPresent flag 
		fractionPresent=rtFractionPresent;
		//tmpLCD=lcd;
		lcd=rtLCD;
		doRight=true;
	} else {
		eqLoop=1;//update either left or right side
		if (rightOnly) {
			doRight=true;
			positions=rtPositions;
			//bts 021715:use rtFractionPresent flag 
			fractionPresent=rtFractionPresent;
			lcd=rtLCD;
		//} else if (ltPositions.length>0 && rtPositions.length<=1){
		} else if (leftOnly) {
			positions=ltPositions;
			//bts 030215: use leftFractionPresent
			fractionPresent=leftFractionPresent;
			//bts 112814: move left lcd into lcd var
			lcd=leftLCD;
		} 
	}
	for (eqCtr=eqLoop-1;eqCtr>-1;eqCtr--) {
		//bts 030215: Set pointer into calcAns, calcAnsHint based
		//	on whether doing both left/right sides, just left, or just right
		var ptrIntoCalcAns;
		//for second loop, if there is one, set positions to
		//left side vals
		// bts 112814: use leftLCD instead of tmpLCD for left side
		if (eqCtr==0 && !doRight) {
			lcd=leftLCD;
			positions=ltPositions;
			//bts 0217j15: restore left fraction flag for left side
			fractionPresent=leftFractionPresent;
			ptrIntoCalcAns=0;
		} else if (eqCtr==0 && doRight || eqCtr==1) {
			ptrIntoCalcAns=1;
		} 
		
		// bts 030215 use ptrIntoCalcAns instead of eqCtr
		//bts 09152015: build string for fractions from num/denom
		//	rather than using the hint string; 
		var lastConstantLoc = positions.length-1;
		elementArray[positions[lastConstantLoc]].numerator = calcAns[ptrIntoCalcAns];
		if (fractionPresent) elementArray[positions[lastConstantLoc]].denominator=lcd;
		if (!fractionPresent) {
			elementArray[positions[lastConstantLoc]].string = calcAns[ptrIntoCalcAns].toString();
		} else { //fraction--set string from num/denom; set calcAns to string version
			//elementArray[positions[lastConstantLoc]].string =calcAnsHint[ptrIntoCalcAns];
			//calcAns[ptrIntoCalcAns]=calcAnsHint[ptrIntoCalcAns];
			if (lcd != 1) {
				elementArray[positions[lastConstantLoc]].string=
					String(elementArray[positions[lastConstantLoc]].numerator)+"/"+
					String(elementArray[positions[lastConstantLoc]].denominator);
			} else {//denom==1 so answer is not a fraction
				elementArray[positions[lastConstantLoc]].string=
					String(elementArray[positions[lastConstantLoc]].numerator);				
			}
			calcAns[ptrIntoCalcAns]=elementArray[positions[lastConstantLoc]].string;
		}
		
		//set splice amount based on # of constant terms
		var spliceAmt=lastConstantLoc;
		for (i=positions.length-2;i>-1;i--) {
			// bts 012215: change to i==0
			if (i==0) {
			//if (positions[i]==0) {
				elementArray.splice(positions[i],2);
			} else {//not left most term; for right side, check
						// for equality oper and treat as 1st term
				if (!doRight) {//left side splice
					elementArray.splice(positions[i]-1,2);
				} else {
					elementArray.splice(positions[i],2);
					//if (i<=0) doRight=false;
				}
			}
			//bts 012215: moved flag for left side here
			if (i<=0) doRight=false;
		}
	} // end loop updating expressions, both sides of equation
		
	// remove any terms that are zeros
	removeZerosFromEqStruct();
	// remove parens surrounding single term, if any
	removeParensFromStruct();
	
	//bts 112714: use tipString.length instead of tipCtr
	if (tipString != undefined || tipString !=null) {//write tip string array to html but don't display it
		var tipElement=document.getElementById("fractioncombinetip");
		tipElement.style.display="none";
		tipElement.innerHTML="";
		for (i=0;i<tipString.length;i++) {
			tipElement.innerHTML=tipElement.innerHTML+"<ul>"+tipString[i]+"</ul>";
		}
	}
	
	//	bts 030315: if left or right side only--not both sides--
	//	make calcAns and prompt array into single value so only 1 prompt appears
	if (calcAns[0]==null || calcAns[0]==undefined) {
		calcAns.splice(0,1);
		userPrompt.splice(0,1);
	} else if (userPrompt[1]==undefined || userPrompt[1]=="") {
		calcAns.splice(1,1);
		userPrompt.splice(1,1);		
	}
	
	//jcs081115 Let's shorten the prompt
	//var preprompttext="Combine these constants: ";
	var preprompttext="How much is: ";
	// bts 091214: set up tip in setAnswerPrompt for 
	//		combining fraction constants;
	//		also set expnOperation to empty;
	//		Add expnOperation and introType to 
	//		setAnswerPrompt parameter list
	var expnOperation="";
	var introType;
	//bts 030215: use left/rt FractionPresent flag
	if (leftFractionPresent || rtFractionPresent)introType=10;
	//bts 1024: if equation, allow for multiple prompts
	//		change callerid?
	var onePrompt = true;//single prompt for expressions
	var multiplier = 1;
	var callerId = "combineconstants";
	if (equationFlag) {
		onePrompt=false;
		multiplier="";
	}
		
	// bts 082314: use positions instead of matchPositions
	// bts 091214: add expnOperation, introType to 
	//		setAnswerPrompt parameter list
	setAnswerPrompt(preprompttext,userPrompt,multiplier, 
			calcAns,positions,1,onePrompt,callerId,
			expnOperation,introType);
	
	document.getElementById("userInstructions").style.display="";

	return(errMsgText);
}

function removeZerosFromEqStruct()
{
	/* 
	 * removes any terms that are zeros from struct for
	 * equations. Also removes leading oper elements if not
	 * the first element in struct or the first element after
	 * the equality sign
	 */
	var equalPtr=findEqualityLocInStruct();
	var adjustLoc=false;
	
	for (var i=elementArray.length-1;i>-1;i--) {
		if (elementArray[i].elemtype == "term" && 
				elementArray[i].numerator==0) {
			if (i==0 || i==equalPtr+1) {
				//bts 011215: do not remove term from left or 
				//	right side if it is the only term
				if ((i==0 && equalPtr!=1) || 
						(i==equalPtr+1 && i!=elementArray.length-1)) {
				// remove the term and following oper
					//bts 011215: set adjustment flag
					elementArray.splice(i,2);
					adjustLoc=true;
				}
			} else {//remove term and preceding oper
				elementArray.splice(i-1,2);
				adjustLoc=true;
			}
			//bts 011215: reset i if struct length adjusted; 
			//	refigure equality oper location
			if (adjustLoc) {
				equalPtr=findEqualityLocInStruct();
				i=elementArray.length;
				adjustLoc=false;
			}

		}
	}	
	return;
}

function addToPosObj(ctr, promptCalcAns)
{
	var objName;
	
	objName = "obj"+ctr;
	objName=new posObj(" ");
	objName.addPosElement(promptCalcAns);
	return(objName);
}

function posObj(promptCalcAns)
{
	this.prompt = promptCalcAns[0];
	this.calcAns=promptCalcAns[1]; 
	this.numTotal=promptCalcAns[2];
	this.fractionPresent=promptCalcAns[3];
	this.lcd=promptCalcAns[4];
	
	this.addPosElement=addPosElement;
	function addPosElement(promptCalcAns)
	{
		this.prompt = promptCalcAns[0];
		this.calcAns=promptCalcAns[1]; 
		this.numTotal=promptCalcAns[2];
		this.fractionPresent=promptCalcAns[3];
		this.lcd=promptCalcAns[4];
	}
} 

function enterEqVarVals()
{
	/*
	 * bts 112014: clone of enterVarVals; modified for equations
	 * 	that have more than 1 variable. For these cases, user can
	 *  enter values but must leave 1 variable blank.
	 */
	var y, aNum, msg;
	var checkBoxId;
	var noAnswer = false;
	
	//vars to reset list of variables with values
	var varList;
	var varVals;
	var hiddenVarList;
	var varListArray=[];
	var blankVarCtr=0;
	var varCtr=0;
	var varToRemove;
	
	hiddenVarList = document.getElementById("hiddenvarlist");
	varList = hiddenVarList.innerHTML;
	varListArray = varList.split(",");
	
	var x = document.getElementById("evaluateexpressionform");
	checkBoxId = "";
		
	for (var i=0;i<x.elements.length-1;i++) {
		if (x.elements[i].tagName == "INPUT") {
			y = x.elements[i].value;
			checkBoxId = "variablecheckBox"+i;
			msg = document.getElementById(checkBoxId);
			if (msg!=null) msg.innerHTML = " ";
			if (y=="" || y==" ") {
				msg.innerHTML = " Enter a value for the variable or "+
					"? to leave the variable with no value.";
				noAnswer = true;
			} else if (y=="?") {
				blankVarCtr++;
				if (blankVarCtr>1) {
					noAnswer=true;
					msg.innerHTML = " Only 1 variable can be left blank";
				}
				// potentially remove this variable from list
				// remove the associated value in getVarVals
				//bts 01222016 save the actual var to remove, not ptr
				var unknownVarToRemove=
					document.getElementById("valuevariablerow"+i).innerHTML.trim();
				//varToRemove=varCtr;	
			} else {
				aNum = "";
				aNum = Number(y);
				if (isNaN(aNum)) {
					msg.innerHTML = " Value must be a number";
					noAnswer = true;
				}
			}
			varCtr++;
		}
	}
	
	if (noAnswer) return false;	
	//remove variable/value? for unset variable
	//bts 12032015: save all variables to special hidden var for 
	//		equation evaluates; remove unset var afterwards
	//bts 12132015: set eqvars to varlistarray if eqvars is blank;
	if (document.getElementById("hiddeneqvariables").innerHTML=="") {
		document.getElementById("hiddeneqvariables").innerHTML=varListArray;
	} 
	
	//bts 01222016: remove matching var from array
	// unknownVarToRemove holds the variable to remove
	//	find unknown var match in varList and remove it using its
	//	index #
	// Add a ? to the eqvalues hidden var for the blank var
	//		using varToRemove to locate the corresponding value
	if (blankVarCtr>0) {
		varToRemove=varListArray.indexOf(unknownVarToRemove); 
		varListArray.splice(varToRemove,1);
		hiddenVarList.innerHTML=varListArray;
		//get eq var values
		var eqVarValsArray=[];
		var eqVarVals=document.getElementById("hiddeneqvalues").innerHTML;
		eqVarValsArray=eqVarVals.split(",");
		//if (varToRemove==eqVarValsArray.length) {
		eqVarValsArray[varToRemove]="?";
		document.getElementById("hiddeneqvalues").innerHTML=eqVarValsArray;
	}
	// bts 10232015: reset equation prompt span to empty space
	//	bts 10262015: comment out TEST?
	//jcs102715 test document.getElementById("equationvarprompt").innerHTML=" ";		
	getVarVals();

	//bts 121014: Check if new equation is solved
	//bts 12242015: check hidden var for 1 step solution condition
	//		move actionIndicator declaration/ clear hidden var
	var actionIndicator;
	if (document.getElementById("hiddeneqevalonestep").innerHTML=="true") {
		actionIndicator=0; //not solved
	} else {//multiple steps for solution
		actionIndicator=checkForEqSolved();
	}
	document.getElementById("hiddeneqevalonestep").innerHTML="false";

	if (actionIndicator==1) {//solved
 	    document.getElementById("getanswerform").reset();            
	    document.getElementById("getanswerform").style.display="none";
	    document.getElementById("workarea").style.display="none";
	   // solved=true;
	    resetAfterSolved(); 
	} else if (actionIndicator>1) {//check for true/false
		document.getElementById("getanswerform").style.display="none";
        document.getElementById("userInstructions").style.display="";
        document.getElementById("whatToDoNextArea").style.display=""; 			
		document.getElementById("operationMenuArea").style.display="none"; 
		actionIndicator=checkForEqSolved();		
	}
	return true;
}

function buildFractionPrompts(beginObj,endObj) 
{
	/*
	 * 112514: builds user prompts for fractions and
	 * handles case of numerator=0
	 * 
	 */
	var promptString;
	var fractString;
	var specialText;
	var changedObjLoc=[];
	var objLoc=0;
	var numeratorZero=false;

	if (elementArray[beginObj].numerator!=0) {
		fractString=String(elementArray[beginObj].numerator)+"/"+
		String(elementArray[beginObj].denominator);
		specialText=setMixNumFractTextEffects(fractString);
		promptString = specialText+elementArray[beginObj+1].string;	
	} else if (elementArray[beginObj].numerator==0) {
		numeratorZero=true;
		fractString="0";
		promptString=fractString+elementArray[beginObj+1].string;
		changedObjLoc[objLoc]=beginObj;
		objLoc++;
		elementArray[beginObj].string="0";
		elementArray[beginObj].numerator=0;
		elementArray[beginObj].denominator=1;
	}
	if (elementArray[endObj].numerator !=0) {
		fractString=String(elementArray[endObj].numerator)+"/"+
			String(elementArray[endObj].denominator);
		specialText=setMixNumFractTextEffects(fractString);
		promptString = promptString+specialText;
	} else if (elementArray[endObj].numerator==0) {
		numeratorZero=true;
		fractString="0";
		promptString=promptString+fractString;
		changedObjLoc[objLoc]=endObj;
		elementArray[endObj].string="0";
		elementArray[endObj].numerator=0;
		elementArray[endObj].denominator=1;
	}
	// write updated elementarray to blackboard to show changing fraction with
	//	zero in numerator to zero
	// highlight changed fraction first
	
	if (numeratorZero) {
		var color = "yellow";
		for (j=changedObjLoc[0];j<changedObjLoc[changedObjLoc.length-1]+1;j++) {
			writeMultHighlight(j,1,elementArray.length,color);
		}
	
		writeToTable(" -- Changed fraction with 0 numerator to 0");
	}
	
	return (promptString);
}

function checkForGrp() 
{
	/*
	 * 08282015: new function: returns positions of all left/right
	 * groupers. Clone of checkForAbsolValBars()
	 * returns an array of left/right grouper positions
	 */
	var grpPos=[];
	for (var i=0;i<elementArray.length;i++) {
		if (elementArray[i].elemtype=="leftgrp" ||
				elementArray[i].elemtype=="rightgrp") 
			grpPos[grpPos.length]=i;
	}	
	return(grpPos);
}

function checkForAbsolValBars()
{
/*
 * checks structure for absol var groupers and
 * returns their positions within structure
 */
	var barPos=[];
	for (var i=0;i<elementArray.length;i++) {
		if (elementArray[i].string=="|") 
			barPos[barPos.length]=i;
	}
	return(barPos);
}

function checkForAbsolValMultVars(absValPos)
{
	/*
	 * bts 012315: checks eqs with multiple absol val bars
	 * 	for variables within these bars. Equation can only
	 * have one absol val bar with a variable.
	 */
	var multVarsFound=false;
	var j, m;
	var varCount=0;
	
	for (var i=0;i<absValPos.length;i=i+2) {
		j=absValPos[i+1];//end bar
		m=absValPos[i]+1;//term after begin batr
		while (m<j) {
			if (elementArray[m].elemtype=="term") {
				if (elementArray[m].variable != null) {
					varCount++;
				}
			}
			m++;
		}
	}
	if (varCount>1) multVarsFound=true;
	return(multVarsFound);
}

function checkForAbsolValVars(absolValPos)
{
	/*
	 * bts 121614: called on alg expns to check if absol value 
	 * delimiters include terms with vars. Returns true if found.
	 */
	var varFound=false;
	//var absolValPos=[];
	var j,m;

	for (var i=0;i<absolValPos.length;i=i+2) {
		// check terms within each set of absol val groupers for vars
		// if one found, then set flag and exit
		j=absolValPos[i+1];
		m=absolValPos[i]+1;
		while (m<j) {
			if (elementArray[m].elemtype=="term") {
				if (elementArray[m].variable != null) {
					varFound=true;
					i=absolValPos.length; //exit
					m=j;
				}
			}
			m++;
		}
	}
	return(varFound);
}

function getAbsValPosNoVars(absValPos)
{
	/*
	 * bts 012315: called on eqs to return absol val bar positions
	 * that do not contain variables.
	 */
	var varFound=false;
	var j,m;
	var newAValPos=[];

	for (var i=0;i<absValPos.length;i=i+2) {
		j=absValPos[i+1];
		m=absValPos[i]+1;
		while (m<j) {
			if (elementArray[m].elemtype=="term") {
				if (elementArray[m].variable != null) {
					varFound=true;
					m=j;
				} 
			}
			m++;
		}
		if (!varFound) {
			newAValPos[newAValPos.length]=absValPos[i];
			newAValPos[newAValPos.length]=absValPos[i+1];			
		}
		varFound=false;
	}
	return(newAValPos);
}

function promptAbsolValThreeTerms(absolValPos) {
	/*
	 * Builds prompt for absol val for eqs/alg expressions when
	 * there are more than 2 terms within absol val bars. 
	 * 	Occurs when absol val
	 *  includes a variable with a coefficient. For checking, program
	 *  substitutes a number for the variable, resulting in multiplying
	 *  the coeff*var and then adding any other terms within absol val bars

	 */
	var userPrompt="";
	var multOperLoc=[];//holds position of multipliers
	var userPromptBuilt=false;
	var multLocAtBegin, multLocAtEnd;
	multLocAtBegin=false;
	multLocAtEnd=false;
	for (i=absolValPos[0];i<absolValPos[1];i=i+1) {
		if (elementArray[i].elemtype=="term") userPrompt=userPrompt+
				elementArray[i].string;
		
		if (elementArray[i].elemtype=="oper") {
			userPrompt=userPrompt+elementArray[i].string;
			if (elementArray[i].string=="*") {
				multOperLoc[multOperLoc.length]=i;
				if (i <=absolValPos[1]/2) multLocAtBegin=true;
				if (i>absolValPos[1]/2) multLocAtEnd=true;
			}
		}
	}
	//if multiplication found, multiply the 2 terms and store result in either
	//first or third elementarray element
	var multLoc;
	var calcAns=0;
	var numArray=[];
	var absolValCaller;
	var fractMultiplyFlag=false;
	var calcLCD;
	var newFractArray=[];
	
	//bts 09022015: 2 new vars for removing 3rd term
	var removeThirdTerm=false;
	var termToRemove;

	if (multOperLoc.length>0) {
		for (i=0;i<multOperLoc.length;i=i+1) {//usual scenario
			multLoc=multOperLoc[i];

			if (elementArray[multLoc-1].denominator==1 &&
					elementArray[multLoc+1].denominator==1) {
				numArray[0]=Number(elementArray[multLoc-1].numerator);
				numArray[1]=elementArray[multLoc].string;
				numArray[2]=Number(elementArray[multLoc+1].numerator);
				absolValCaller=true;				
				calcAns=0+Number(calculateAnswer(numArray,absolValCaller));
			} else {//fraction
				fractMultiplyFlag=true;
				calcLCD=1;//default lcd val for multiply/divide; should not be used in later calculation
				newFractArray[0]=elementArray[multLoc-1].numerator;
				newFractArray[1]=elementArray[multLoc+1].numerator;								
				var expnToSolveArray=buildArray(multLoc-1,multLoc+1);
				var calcFractArray=[];
				calcFractArray=calcFractionAnsFromArray(
						expnToSolveArray,newFractArray,calcLCD,multLoc-1, multLoc+1);

				calcAns=0+Number(calcFractArray[0]);
				//save new denominator value in calcLCD
				//calcLCD=0+Math.abs(Number(calcFractArray[1]));
				calcLCD=0+Number(calcFractArray[1]);
			}
			
			//bts 09022015: remove the multiplier term and * oper element
			//	so that there are only 2 terms w/in absol val bars, 1 operator (+)
			// set up term string for calling function
			if (multLocAtBegin){
				//write calc answer to 1st element within array referenced by absolValPos
				elementArray[multLoc-1].numerator=calcAns;
				elementArray[multLoc].string="+";
				if (fractMultiplyFlag) {
					elementArray[multLoc-1].denominator=calcLCD;
					elementArray[multLoc-1].string=String(calcAns)+"/"+
							String(calcLCD);
				} else {
					elementArray[multLoc-1].string=String(calcAns);
				}
				removeThirdTerm=true;
				termToRemove=multLoc+1;
			} else if (multLocAtEnd){
				//write calc ans to last element
				elementArray[multLoc+1].numerator=calcAns;
				elementArray[multLoc].string="+";
				if (fractMultiplyFlag) {
					elementArray[multLoc+1].denominator=calcLCD;
					elementArray[multLoc+1].string=String(calcAns)+"/"+
							String(calcLCD);
				} else {
					elementArray[multLoc+1].string=String(calcAns);
				}
				removeThirdTerm=true;
				termToRemove=multLoc-1;
			}			
		}
		if (removeThirdTerm) {
			elementArray.splice(termToRemove,2);
		}
	}
	return(userPrompt);
}

function promptForAbsolVal(absolValPos) 
{
	/*
	 * prompts for absolute value for equations/alg expressions
	 * Loop only handles 2 terms within absol val bars.
	 * If there are 3 terms, handles only 1st and 3rd terms.
	 * 
	 * 08262015: calls promptAbsolValThreeTerms to handle more than
	 * 	2 terms in checking phase
	 * 
	 */
	var beginObj, endObj, j, i,m,ptr;
	var color;
	var calcAns=[];
	var userPrompt = [];
	var preprompttext;
	var objPosArray = [];
	var onePrompt, operandTotal;
	var ctr=0;//number of separate prompt fields
	var operFlag;//indicates operator

	//jcs102714 Hide the general highlight
	document.getElementById("generalHighlight").style.display="none";			   	
	document.getElementById("UserInstructionPrompt").innerHTML="";			   	
	document.getElementById("UserInstructionPrompt").style.display="none";				

	//bts 11102015: changed prompt for absolute value
	//preprompttext = "What is the absolute value of: ";
	preprompttext = "How much is: ";
	
	//bts 123014: added new vars for handling calculations using decimals
	var beginObj, endObj;
	var fractFlag=false;
	//bts 022815: added fraction multiply flag; fractFlag now used for add/sub operations
	var fractMultiplyFlag=false;
	var expnToSolve="";
	//bts 020115: added flag for calculate answer
	var absolValCaller=false;
	var numArray=[];
	
	//bts 08262015: check opers within absolvalpos array for multiply
	//	if found and more than 2 terms, need to do multiplication before addition
	// save "old" absolValPos positions in case changed when handling gt 2 terms
	//		so that highlighting is correct; 
	//	adjust highlighting positions by 2 if there were more than 2 terms
	var moreThanTwoTerms=false;
	var holdValPos=absolValPos;
	var userPromptBuilt=false;
	if (absolValPos[1]-absolValPos[0]>4) {//more than 2 terms
		var ansPrompt=promptAbsolValThreeTerms(absolValPos);
		if (ansPrompt) {
			userPromptBuilt=true;
			//bts 11112015: add absol val bars to prompt
			ansPrompt="|"+ansPrompt+"|";
			userPrompt[userPrompt.length]=ansPrompt;
			//bts 09022015: positions of absol val bars may have changed
			absolValPos=checkForAbsolValBars();
			moreThanTwoTerms=true;
		}
	} 
	// get the abs val terms
	// bts 08262015: this loop works when there are 2 terms w/in absol val bars
	for (i=0;i<absolValPos.length;i=i+2) {
		// check terms within each set of absol val groupers for vars
		// if one found, then set flag and exit
		j=absolValPos[i+1];//ending abol val mark
		m=absolValPos[i]+1;//term
		while (m<j) {
			if (elementArray[m].elemtype=="term") {
				beginObj=m;
				if (m==absolValPos[i]+1) {//first prompt
					beginObj=m;
					endObj=j-1;
					if (elementArray[beginObj].denominator==1 &&
							elementArray[endObj].denominator==1) {
						//bts 020115: change calculation of ans to use elementarray numerator
						numArray[0]=Number(elementArray[beginObj].numerator);
						numArray[1]=elementArray[beginObj+1].string;
						numArray[2]=Number(elementArray[endObj].numerator);
						absolValCaller=true;				
						calcAns[ctr]=0+Math.abs
							(Number(calculateAnswer(numArray,absolValCaller)));
					} else {
						//bts 122914: change fractions to lcd
						//	before doing the calculations
						fractFlag=true;
						var denomArray=[];
						var calcLCD;
						var newFractArray=[];
						denomArray = getDenomsForLCD(beginObj,endObj);
						// calculate the lcd using begin,end objects
						// bts 022715: calc lcd if addition/subtraction only
						//if (elementArray[beginObj].denominator != 
						//	elementArray[endObj].denominator) {
						if (elementArray[beginObj+1].string=="+" ||
								elementArray[beginObj+1].string=="-") { 
								//denomArray = getDenomsForLCD(beginObj,endObj);
							calcLCD = calculateLCD(denomArray);
								//call clone of updateDenomsWithLCD to calculate new  
								// fractions based on lcd; do not update structure
							newFractArray=computeFractsWithLCD(calcLCD,beginObj,endObj);
						} else {//multiply or divide calculation
							fractMultiplyFlag=true;
							calcLCD=1;//default lcd val for multiply/divide; should not be used in later calculation
							newFractArray[0]=elementArray[beginObj].numerator;
							newFractArray[1]=elementArray[endObj].numerator;								
						}
						var expnToSolveArray=buildArray(beginObj,endObj);
						var calcFractArray=[];
						calcFractArray=calcFractionAnsFromArray(
								expnToSolveArray,newFractArray,calcLCD,beginObj, endObj);
						if (!fractMultiplyFlag) {//add/subtract fractions save only numerator
							calcAns[ctr]=0+Math.abs(Number(calcFractArray[0]));
						} else {//multiply/divide; save both numerator and denominator
							calcAns[ctr]=0+Math.abs(Number(calcFractArray[0]));
							//save new denominator value in calcLCD
							calcLCD=0+Math.abs(Number(calcFractArray[1]));
						}
					}
					//bts 08262015: check if userPrompt already built
					if (!userPromptBuilt) userPrompt[ctr]= 
						""+elementArray[m].string;
				} else {
					if (!userPromptBuilt) userPrompt[ctr]= 
						userPrompt[ctr]+elementArray[m].string;
				}
			} else if (elementArray[m].elemtype=="oper") {
				if (!userPromptBuilt) userPrompt[ctr]=
					userPrompt[ctr]+elementArray[m].string;
			}
			m++;
		}
		//bts 11102015: modify prompt for absol value
		if (!userPromptBuilt) userPrompt[ctr]="|"+userPrompt[ctr]+"|";
		//increment prompt/calc answer array counter
		ctr++;
	}

	// highlight portion of expression about to be solved before it is changed
	// start with beginObj location thru endObj location
	//bts 090220156: use holdValPos instead of absolValPos
	//		in case we removed 3rd term
	color = "yellow";
	//for (i=0;i<absolValPos.length;i=i+2) {
	//	beginObj = absolValPos[i]+1;
	//	endObj = absolValPos[i+1]-1;
	for (i=0;i<holdValPos.length;i=i+2) {
		beginObj = holdValPos[i]+1;
		endObj = holdValPos[i+1]-1;
		if (moreThanTwoTerms) {
			beginObj=beginObj-2;
			endObj=endObj-2;
		}
		for (j=beginObj;j<endObj+1;j++) {
			writeMultHighlight(j,1,elementArray.length,color);
		}
	}
		
	// remove absol val markers and update structure with answers
	var loopCtr = absolValPos.length-1;
	var calcPtr=absolValPos.length/2-1;
	var ltBarPtr,zeroCtr;
	for (i=loopCtr;i>0;i=i-2) {
		rtBarPtr = absolValPos[i];//points to right absol val marker
		ltBarPtr = absolValPos[i-1];//points to left absol val marker
		//set last term within absol marks to new value
		// then splice out the absol val marks and any other terms/opers
		//for (ptr=rtBarPtr-1;ptr>ltBarPtr;ptr--) {
		ptr = rtBarPtr-1;//points to rightmost term within markers
		elementArray[ptr].numerator = Number(calcAns[calcPtr]);
		if (elementArray[ptr].numerator < 0){
			elementArray[ptr].numerator = elementArray[ptr].numerator*-1;
		} else if (elementArray[ptr].numerator == 0) {
			zeroCtr++;
		}
		//bts 122814: handle calculated fraction answers
		if (fractFlag) {
			elementArray[ptr].string=String(calcAns[calcPtr])+"/"+String(calcLCD);
			elementArray[ptr].denominator=calcLCD;
			calcAns[calcPtr]=String(calcAns[calcPtr])+"/"+String(calcLCD);
		} else {
			elementArray[ptr].string = String(calcAns[calcPtr]);
		}
		// remove right abs marker
		elementArray.splice(rtBarPtr,1);
		// remove left abs marker and term/opers up to updated term
		elementArray.splice(ltBarPtr,ptr-ltBarPtr);
		calcPtr--;
	}
	//if (elementArray.length <= zeroCtr+2) removeZerosFromEqStruct();
	removeZerosFromEqStruct();
		
	// set up for call to display prompts
	var multiplier = "";
	//bts 122214: change callerId so getUserAnswer resumes with doAlgExpSteps
	var callerId = "absolutevalue";
	onePrompt = true;
	var expnOperation = " solving absolute value";
	var introType=0;
		
	if (absolValPos.length > 1) onePrompt = false;
	
	setAnswerPrompt(preprompttext, userPrompt, 
			multiplier,calcAns,objPosArray,operandTotal,
			onePrompt,callerId,expnOperation,introType);
				
	return;
}

function calcFractionAnsFromArray(tempArray,fractNumArray,lcd,beginObj,endObj)	
{
	/*
	 * Cloned from calculateFractionAnswer
	 * Computes answer for fraction operation using passed in
	 * array and lcd vals, not with vals from structure
	 */
	var tempArray;
	var arrayToSolve = [];
	var numerator1, numerator2, denom1, denom2;
	var oper1, oper2;
	var calcAnswerArray=[];

	// tempArray consists of 3 elements, second element is the operator.
	arrayToSolve = checkArrayNumeric(tempArray);
	oper1=arrayToSolve[0];
	oper2=arrayToSolve[2];
	numerator1 = Number(fractNumArray[0]);
	numerator2 = Number(fractNumArray[1]);
	denom1 = Number(elementArray[beginObj].denominator);
	denom2 = Number(elementArray[endObj].denominator);
	
	//bts 022715: do not set denoms eq to lcd
	//if (denom1 != denom2) {
	//	denom1=lcd;
	//	denom2=lcd;
	//}
	// divide operation is treated like multiply since
	// divisor has been flipped
	if (arrayToSolve[1] == "\u00F7") arrayToSolve[1]="*";
	if (arrayToSolve[1]!="*" && denom1 != denom2) {
		denom1=lcd;
		denom2=lcd;
	}
	
	switch(arrayToSolve[1]) // indicates the operator
	{
	case "*":
		calcAnswerArray[0] = numerator1*numerator2;
		calcAnswerArray[1] = denom1*denom2;		
		break;
	case "/":
		//do nothing
		break;
	case "\u00F7":
		//do nothing
		break;	
	case "+": 
		calcAnswerArray[0] = numerator1+numerator2;
		break;
	case "-": 
		calcAnswerArray[0] = numerator1-numerator2;
		break;
	case "^": 
		// bts 1229 -Change exponent calculation; expon value is 2nd term

		var exponVal = Number(elementArray[endObj].string);
		if (exponVal <0){ // exponent is negative so make it positive
						  // and change fraction to reciprocal
			exponVal = Math.abs(exponVal);
		}
		calcAnswerArray[0] = Math.pow(numerator1,exponVal);
		calcAnswerArray[1] = Math.pow(denom1,exponVal);	

		break;
	}
	
	for (var i=0;i<calcAnswerArray.length;i++) {
		if (calcAnswerArray[i]!== 0) {
			calcAnswerArray[i] = Number(calcAnswerArray[i].toFixed(3));
		} 
	}
	return(calcAnswerArray);
}	

function computeFractsWithLCD(lcdVal,beginObj,endObj)
{
	/*
	 * Cloned from updateDenomsWithLCD function
	 * Computes new fract vals: num and denom, but does not
	 * update the structure
	 */
	var i,j;
	var newNumArray = [];
	var multiplierArray = [];
	
	lcdVal = Number(lcdVal);
	beginObj = Number(beginObj);
	endObj=Number(endObj);

	j=0; // counter into fraction arrays
	for (i=beginObj;i<=endObj;i++) {
		if (elementArray[i].elemtype == "term") {
			newNumArray[j] = elementArray[i].numerator*(lcdVal/elementArray[i].denominator);
			j++;
		}		
	}	
	return(newNumArray);
}


function checkTermsWithinAbsolVals(absValPos)
{
	/*
	 * checks number of terms within absol val markers
	 * absValPos array is positions of markers in structure
	 */
	var termCtr=0;
	var tooMany=false;
	var i,j;
	//check each pair of absol val markers for number of terms
	for (i=0;i<absValPos.length;i=i+2) {
		for (j=absValPos[i]+1;j<absValPos[i+1];j++) {
			if (elementArray[j].elemtype=="term") termCtr++;
		}
		if (termCtr>2) {
			tooMany=true;
			i=absValPos.length;//exit outer loop
		} else {
			termCtr=0;
		}
	}
	return(tooMany);
}

function checkForAdditionalVars(barLoc)	
{
	/*
	 * checks structure for additional variable outside of
	 * absol val bars; Called when absol val bars contains variable
	 * -Used for setting up checking of absol val equations
	 */

	var additionalVarFound=false;
	var outsideVars=[];
	var insideVar="";

	for (var i=0;i<elementArray.length;i++) {
		if (elementArray[i].elemtype=="term" &&
				elementArray[i].variable !=null) {
			if (i<barLoc[0]||i>barLoc[1]) {
				outsideVars[outsideVars.length]=elementArray[i].variable;
			} else {
				insideVar=elementArray[i].variable;
			}
		} 
	}
	//see if any outside vars match the inside var
	if (outsideVars.length>0) {
		for (i=0;i<outsideVars.length;i++) {
			if (outsideVars[i]==insideVar) additionalVarFound=true;
		}
	}	
	return(additionalVarFound)
}

function splitEquation()
{
	/*
	 * removes absol val bars from an equation; creates 2 equations
	 * 	1st eq: same as original without absol val bars
	 *  2nd eq: same as orig without bars and reverses signs on opposite side
	 *  	if less than/greater than equality sign, reverses also
	 *  	Stores 2nd equation in hidden var
	 */
	var barLoc=[];
	var i;
	var left, right;
	var errMsgText="";
	var secondExpn="";
	
	var hiddenSecondExpn=document.getElementById("hiddensecondexpn");
	var hiddenAbsValSide=document.getElementById("hiddenabsvalorigside");
	hiddenAbsValSide.innerHTML="";
	
	var equalityLoc=findEqualityLocInStruct();
	barLoc=checkForAbsolValBars();
	for (i=0;i<barLoc.length;i++) {
		if (barLoc[i]<equalityLoc) left=true;
		if (barLoc[i]>equalityLoc) right=true;
	}
	if (right && left) {
		var errCode=49;
		//Absolute values with variables on both sides of the equation 
		//currently not supported.
		errMsgText=errorMsg(errCode,errMsgText);
		displayErrMsg(errMsgText);
		return;
	}
	
	//bts 011514: if absol vals and var both w/in & outside of bars, 
	//	restore orig expn after solving and check both answers
	//	check for vars outside of bars; if found, make sure
	//	orig expn has been saved
	
	//bts 0133115: check eq regardless if additional var outside of 
	//	absol val bars: force additional var flag to true
	//check for additional vars outside of absol val bars
	var additionalVarFound=checkForAdditionalVars(barLoc);
	additionalVarFound=true;
	//if additionalVarFound is true: set flag for doing checking at end
	//bts 012115: set default value for checking equations
	document.getElementById("hiddennocheck").innerHTML="nocheck";

	if (additionalVarFound) {
		document.getElementById("hiddendoeqchecking").innerHTML="checkequation";
	} else {//make sure this is empty if only 1 var in eq
		document.getElementById("hiddendoeqchecking").innerHTML="";
	}

	//set up hidden vals for final answer:side with bars and orig eq oper
	if (left) {
		hiddenAbsValSide.innerHTML="left,"+elementArray[equalityLoc].string;
	} else if (right) {
		hiddenAbsValSide.innerHTML="right,"+elementArray[equalityLoc].string;			
	}

	//bts 020615: if absol val bar preceded/followed by multiply oper, 
	//	change bars to parens
	var changeToParens=false;
	var m,n;
	var checkLeftofBar,checkRightofBar;
	for (i=0;i<barLoc.length-1;i=i+2) {
		m=barLoc[i];//left bar
		n=barLoc[i+1];//right bar
		if ((left && m>0) || (right && m>equalityLoc+1)) checkLeftofBar=true;
		if ((left && n<equalityLoc-1) || 
				(right && n<elementArray.length-2)) checkRightofBar=true;
		//check element to left of bar for oper sign
		if (checkLeftofBar) {
			if (elementArray[m-1].string=="*") changeToParens=true;
		} else if (checkRightofBar) {
			if (elementArray[n+1].string=="*") changeToParens=true;
		}
	}
	//bts 020615: change bars to parens if multiply oper outside of bars	
	//Remove absol var bars for both equations
	
	// insert -1* in front of bar loc parens for 2nd equation 
	//	use code for reversing oper signs on opposite side from absol val bars
	var varToSave=buildSecondEquation(left,barLoc,changeToParens);
	//bts 011815: save variable to hidden field
	if (varToSave)
		hiddenAbsValSide.innerHTML=hiddenAbsValSide.innerHTML+","+varToSave;

	if (changeToParens) {
		for (i=0;i<barLoc.length-1;i=i+2) {
			elementArray[barLoc[i]].string="(";
			elementArray[barLoc[i+1]].string=")";			
		}
		//remove parens surrounding single term
		removeParensFromStruct();
	} else {
		// remove bar loc "parens" if not changeToParens--locations should
		// be the same as when they were absol val bars
		for (i=barLoc.length-1;i>-1;i--) {
			elementArray.splice(barLoc[i],1);
		}
	}
	
	/*
	// get location of equality oper again, since it may have changed
	equalityLoc=findEqualityLocInStruct();

	//make copy for 2nd pass and reverse signs/equality oper on opp side 
	// from abs val markers
	//bts 020615:replace code that reverses opers on side opposite from absol val
	//	bars to code that inserts -1* in front of absol val bars and adds
	//	parens to group together terms added within the bars; parens not needed
	//	if terms within bars are multiplied
	var reverseEq=[];
	var startPt,endPt;
	var reverseSign=1;
	var changeRightSide=false;
	var changeLeftSide=false;
	
	if (left) {// change opers on right side
		startPt=equalityLoc+1;
		endPt=elementArray.length-1;
		changeRightSide=true;
	} else {//change opers on left side
		startPt=0;
		endPt=equalityLoc-1;
		changeLeftSide=true;
	}
	
	//save current structure to a different structure
	var newEl=[];
	var ctr;
	var stringval,elemtype,num,denom,v1,v2,v3,v4,e1,e2,e3,e4;
	var strikenum, strikedenom;
	//bts 011815: save dup absol val variable in separate var
	var varToSave;
	
	for (i=0;i<elementArray.length;i++) {
		reverseSign=1;
		if (changeRightSide) {
			if (i>startPt-1) {
				reverseSign=-1;
			} 
		} else if (changeLeftSide) {
			if (i<endPt+1) {
				reverseSign=-1;
			}
		}
		stringval=elementArray[i].string;
		elemtype=elementArray[i].elemtype;
		num=elementArray[i].numerator;
		denom=elementArray[i].denominator;
		v1=elementArray[i].variable;
		e1=elementArray[i].exponent;
		v2=elementArray[i].variable2;
		e2=elementArray[i].exponent2;		
		v3=elementArray[i].variable3;
		e3=elementArray[i].exponent3;		
		v4=elementArray[i].variable4;
		e4=elementArray[i].exponent4;
		ctr=i;
		if (elemtype=="term") {
			if (num<0) {
				num=num*reverseSign;//reverse value; remove minus sign
				if (reverseSign==-1) {
					if (stringval.charAt(0)=="-") {
						var newstring=stringval.slice(1);
						stringval=newstring;
					}	
				}
			} else if (num>0) {
				num=num*reverseSign;//reverse value; insert minus sign
				if (reverseSign==-1) stringval="-"+stringval;
			}
		}
		if (i==equalityLoc) {			
			stringval=switchOperSign(stringval);
		}

		//bts 011815: save variable to varToSave
		if (v1) varToSave=v1;
			
		newEl=addElementToPrevStep
			(ctr, stringval, elemtype, num, 
			denom,v1,e1,v2,e2,v3,e3,v4,e4,strikenum, strikedenom);
		reverseEq[reverseEq.length]=newEl;
	}
	//bts 011815: save variable to hidden field
	if (varToSave)
		hiddenAbsValSide.innerHTML=hiddenAbsValSide.innerHTML+","+varToSave;

	//build string version of new 2nd equation 
	for (i=0;i<reverseEq.length;i++) {
		secondExpn = secondExpn + reverseEq[i].string;
	}
	secondExpn=formatCompareOper(secondExpn);
	hiddenSecondExpn.innerHTML=secondExpn;
	*/
	
	// write "first" equation with annotation to board
	writeToTable(" -- 1st problem to solve after split");
	
	//bts 020415: check if eq is essentially solved (ie: var=n) after removing bars
	var actionIndicator=checkForEqSolved();
	//check for solved a second time if elementArray length=3
	if (elementArray.length==3) {
		actionIndicator=checkForEqSolved();
	}

	return;
}

function buildSecondEquation(left,barLoc,changeToParens)
{
	/*
	 * Builds 2nd equation when splitting eqs with absol vals and vars
	 * rewrite code to insert -1* in front of absol val bars
	 * no need to reverse opers on opp side.
	 * 
	 * left: if true: absol val bars on left side; else on right side
	 * barLod: pointers to bar locaions
	 * 
	 * changeToParens: if true, change absol val bars to parens for 2nd eq
	 * 					if false, remove absol val bars from 2nd eq
	 */
	var varToSave;
	
	// get location of equality oper again, since it may have changed
	var equalityLoc=findEqualityLocInStruct();

	//bts 020615:replace code that reverses opers on side opposite from absol val
	//	bars to code that inserts -1* in front of absol val bars and adds
	//	parens to group together terms added within the bars; parens not needed
	//	if terms within bars are multiplied
	var reverseEq=[];
	var reverseSign=1;
	var changeRightSide=false;
	var changeLeftSide=false;
	
	if (left) {// change absol var opers on left side
		changeLeftSide=true;
	} else {//change opers on right side
		changeRightSide=true;
	}
	
	//save current structure to a different structure
	var newEl=[];
	var ctr, i;
	var stringval,elemtype,num,denom,v1,v2,v3,v4,e1,e2,e3,e4;
	var strikenum, strikedenom;
	var skipElement=false;
	ctr=0;
	
	for (i=0;i<elementArray.length;i++) {
		reverseSign=1;
		skipElement=false;
		if (i>=barLoc[0] && i<=barLoc[1]) {
			reverseSign=-1;
		}
		stringval=elementArray[i].string;
		elemtype=elementArray[i].elemtype;
		num=elementArray[i].numerator;
		denom=elementArray[i].denominator;
		v1=elementArray[i].variable;
		e1=elementArray[i].exponent;
		v2=elementArray[i].variable2;
		e2=elementArray[i].exponent2;		
		v3=elementArray[i].variable3;
		e3=elementArray[i].exponent3;		
		v4=elementArray[i].variable4;
		e4=elementArray[i].exponent4;
		if (elemtype=="leftgrp" || elemtype=="rightgrp") {
			if (changeToParens) {
				if (stringval=="|" && elemtype=="leftgrp") stringval="(";
				if (stringval=="|" && elemtype=="rightgrp") stringval=")";
			} else if (!changeToParens) {
				//do not write out absol val elements
				//skip this element
				if (stringval=="|") skipElement=true;				
			}
		}
		//ctr=i;
		if (!skipElement) {
			ctr++;
			if (elemtype=="term") {
				if (num<0) {
					num=num*reverseSign;//reverse value; remove minus sign
					if (reverseSign==-1) {
						if (stringval.charAt(0)=="-") {
							var newstring=stringval.slice(1);
							stringval=newstring;
						}	
					}
				} else if (num>0) {
					num=num*reverseSign;//reverse value; insert minus sign
					if (reverseSign==-1) stringval="-"+stringval;
				}
			}
			//bts 030415: do not reverse equality sign
			//if (i==equalityLoc) {			
			//	stringval=switchOperSign(stringval);
			//}
	
			//bts 011815: save variable to varToSave
			if (v1) varToSave=v1;
				
			newEl=addElementToPrevStep
				(ctr, stringval, elemtype, num, 
				denom,v1,e1,v2,e2,v3,e3,v4,e4,strikenum, strikedenom);
			reverseEq[reverseEq.length]=newEl;
		}//end of skip code
	}

	var secondExpn="";
	//build string version of new 2nd equation 
	for (i=0;i<reverseEq.length;i++) {
		secondExpn = secondExpn + reverseEq[i].string;
	}
	secondExpn=formatCompareOper(secondExpn);
	var hiddenSecondExpn=document.getElementById("hiddensecondexpn");
	hiddenSecondExpn.innerHTML=secondExpn;	
	return(varToSave);
}


function switchOperSign(sign)
{
	/*
	 * returns the opposite equality oper sign from the one passed in
	 */
	var newsign;
	switch(sign) 
	{
 	  case "\u003c": //less than: <
 		 newsign="\u003e";
 	 	break;
 	  case 	"\u003e": // greater than: ">"
 		 newsign="\u003c";
 	 	break;
 	  case "\u2264": // <=
 		 newsign="\u2265";
 	 	break;
 	  case "\u2265": // >=
 		 newsign="\u2264";
 	 	break;	
 	  default:
 		 newsign="=";
 	  	break;
	}

	return(newsign);
}

function includeVarPortion(answerString)
{
	/*
	 * Adds var portion when testing user answer against calc answer
	 * 
	 * bts 09282015: include any vars, exponents when setting
	 * equivalent flag to true/false
	 */
	var varPortion="";
	var slashPtr=answerString.indexOf("/");
	if (slashPtr == -1) {
		slashPtr=0;
	} else {
		slashPtr++;
	}
	for (var i=slashPtr;i<answerString.length;i++) {
		if (isNaN(answerString[i]) && 
				(answerString[i]!="-" || answerString[i]!="/")) {
			//found variable/exponent portion of answer
			varPortion=answerString.slice(i);
			i=answerString.length+1;
		}		
	}
	return(varPortion);
}

//jcs010115 new functions to test equivalent answers
function calcEquiv(userAns,calcAns) {
	/*
	 * Functions for testing fractions
	 * bts 09282015: add call to includeVarPortion for equivalency test
	 * 
	 */
	var varPortionUser="";
	var varPortionCalc="";
	varPortionUser=includeVarPortion(userAns);
	varPortionCalc=includeVarPortion(calcAns);
	
	var equivalent;

	if (varPortionUser == varPortionCalc) {
		//do numeric tests
		var userEquiv=findEquivValue (userAns);
		var calcEquiv=findEquivValue (calcAns);
		
		if (userEquiv==calcEquiv) {		//if equivalent values are equal   	
			equivalent=true;
		} else 
			equivalent=false;
	} else {
		//var portions are not equiv
		equivalent=false;
	}
	return (equivalent);
}

function findEquivValue(answerString) {	
	var numerator="";
	var denominator="";
	var numerString="";
	var denomString="";
	var currentChar;
	var i=0;
	var coeffFlag=true;
	var slashPtr = answerString.indexOf("/");
	var answerLength=answerString.length;
	//jcs040715 changed from array to regular var
	var equivValue;
	answerString=String(answerString);
	
	if (slashPtr>-1) {
		while (i<slashPtr) {
			currentChar=answerString.charAt(i);
			if (i==0) {
				if ((currentChar=="-")||(!isNaN(currentChar))) {
					numerator=currentChar;
				} else {
					numerator="1";
					numerString=currentChar;
					coeffFlag=false;
				}
			} else {
				if (!isNaN(currentChar)&&(coeffFlag)) 
					numerator=numerator+currentChar;
				else {
					numerString=numerString+currentChar;
					coeffFlag=false;	
				}							
			}
			i++;
		}
	} else {
		currentChar=answerString.charAt(i);
		while (i<answerString.length) {
			numerString=numerString+currentChar;
			i++;
		}
	} 
	
	if (slashPtr>-1) {
		i=slashPtr+1;
		coeffFlag=true;
		while (i<answerString.length) {
			currentChar=answerString.charAt(i);
			if (i==slashPtr+1) {
				if ((currentChar=="-")||(!isNaN(currentChar)))  {
					denominator=currentChar;
				} else {
					denominator="1";
					denomString=denomString+currentChar;
					coeffFlag=false;
				}
			} else {
				if (!isNaN(currentChar)&&(coeffFlag)) 
					denominator=denominator+currentChar;
				else {
					denomString=denomString+currentChar;
					coeffFlag=false;
				}
			}
			i++;
		}
	}
	
	if (slashPtr>-1) {
		equivValue=Number(numerator)/Number(denominator);
	}
	else {
		equivValue=Number(numerString); //jcs040715 test
	}
return(equivValue);
}

function addAstForAbsolValMult(absolValPos)
{
	/*
	 * checks equations with absol vals for implied multiplication
	 * if found, inserts asterisk into structure
	 * 
	 */
	
	var i,j,m;
	var holdElement;
	var addAstFlag=false;
	var addAstLoc=[];
	var eqLoc=findEqualityLocInStruct();
	
	addAstFlag=false;
	for (i=0;i<absolValPos.length;i=i+2) {
		j=absolValPos[i];//first bar loc
		m=absolValPos[i+1];//second bar loc
		if (j>0 || j>eqLoc+1) {
			//not first element on left or right side
			if (elementArray[j-1].elemtype=="term") {
				//insert asterisk
				addAstFlag=true;
				addAstLoc[addAstLoc.length]=j;
			}
		}
		if (m<eqLoc-2 || m<elementArray.length-2) {
			//check for implied multiply after absol val bars
			if (elementArray[m+1].elemtype=="term") {
				//insert asterisk
				addAstFlag=true;
				addAstLoc[addAstLoc.length]=m+1;
			}			
		}
		
	}

	// create new element for multiply oper add it to structure
	if (addAstFlag) {
		ptr=addAstLoc.length-1;
		while (ptr>-1) {
			holdElement = new pe(" ");
			var elemtype = "oper";
			var operString = "*";
			holdElement.addElement(operString,elemtype);
			//add new oper element between term and absol val bar
			//splice inserts element in front of ptr element
			elementArray.splice(addAstLoc[ptr],0,holdElement);
			ptr--;
		}
		//redisplay the expression with added asterisk
		writeToTable(" -- Added asterisk");
		//bts 020815: change orig expn to expn with added asterisk
		origExp=buildStrPart(0,elementArray.length-1);
		origExp=parseString(origExp,1);
	}
	
	return;
}

function checkForCombinableTerms(idxStart,idxEnd)
{
	/*
	 * checks structure for terms that are not constrained by multiplier oper
	 * and may still be combined;
	 * Called from combinetermcheck if a single multiply oper is found
	 * 
	 */
	var multPosFlag=[];
	var i;
	var termCount=0;
	var termLoc=-1;
	var multLoc=-99;
	var skipGroup=false;
	var skipElCnt=1;
	var remEl;
	var multOperFlag=false;

	for (i=idxStart;i<idxEnd+1;i++) {
		if (skipGroup) {
			skipElCnt++;
		}
		if (elementArray[i].elemtype == "leftgrp" ||
				elementArray[i].elemtype == "rightgrp") {
			if (elementArray[i].elemtype == "leftgrp") {
				skipElCnt=1;
				skipGroup=true;
			}
			if (elementArray[i].elemtype == "rightgrp") {
				skipGroup=false;
			}
		}
		
		if (!skipGroup) {
			if (elementArray[i].elemtype == "term") {
				termLoc=i;
				termCount++;
				multPosFlag[multPosFlag.length]=termLoc;
				//bts 021115 redo if logic below; change to 2 if blocks
				//	and use idxStart for 1st element on left or right side
				if (i==idxStart || multOperFlag) { 
					if ((termLoc==multLoc+skipElCnt) ||
						(termLoc==multLoc+1) ||
						(termLoc==multLoc-1)) {//term comes after or before multiply oper
					termCount--;
					remEl=multPosFlag.pop();//remove last entry in array
					}
				}
				skipElCnt=1;
			}
			if (elementArray[i].elemtype == "oper") {
				if (elementArray[i].string == "*" || 
						elementArray[i].string == "\u00F7") {
					multLoc=i;
					multOperFlag=true;
					if (termLoc==multLoc-skipElCnt ||
							termLoc==multLoc-1) {
						//term precedesmult oper
						termCount--;
						remEl=multPosFlag.pop();
					}				
				} else {
					multLoc=-1;
					multOperFlag=false;
				} 			
			}
		}
	}
	if (multPosFlag.length<2) multPosFlag[0]=-1;	
	return(multPosFlag);
}

function checkForAddMultiplyTerms(idxStart,idxEnd)
{
	/*
	 * checks structure for terms separated by add/subtract opers
	 * and for which multiplier term can be applied.
	 * Returns array of term locations
	 * 
	 * Called by eqMultiplyBothSides
	 * 
	 */
	var multPosFlag=[];
	var i;
	var termCount=0;
	var termLoc=-1;
	var multLoc=-99;
	var skipGroup=false;
	var skipElCnt=1;
	var remEl;
	var multOperFlag=false;

	for (i=idxStart;i<idxEnd+1;i++) {
		if (skipGroup) {
			skipElCnt++;
		}
		if (elementArray[i].elemtype == "leftgrp" ||
				elementArray[i].elemtype == "rightgrp") {
			if (elementArray[i].elemtype == "leftgrp") {
				skipElCnt=1;
				skipGroup=true;
			}
			if (elementArray[i].elemtype == "rightgrp") {
				skipGroup=false;
			}
		}
		
		if (!skipGroup) {
			if (elementArray[i].elemtype == "term") {
				termLoc=i;
				termCount++;
				multPosFlag[multPosFlag.length]=termLoc;
				if (i==idxStart || multOperFlag) { 
					if ((termLoc==multLoc+skipElCnt) ||
							(termLoc==multLoc+1)) {//term after multiply oper
						//(termLoc==multLoc+1) ||
						//(termLoc==multLoc-1)) {
					termCount--;
					remEl=multPosFlag.pop();//remove last entry in array
					}
				}
				skipElCnt=1;
			}
			if (elementArray[i].elemtype == "oper") {
				if (elementArray[i].string == "*" || 
						elementArray[i].string == "\u00F7") {
					multLoc=i;
					multOperFlag=true;
					// don't skip term if not preceded by *
					//if (termLoc==multLoc-skipElCnt) {
					//if (termLoc==multLoc-skipElCnt ||
					//		termLoc==multLoc-1) {
						//term precedesmult oper
					//	termCount--;
					//	remEl=multPosFlag.pop();
					//}				
				} else {
					multLoc=-1;
					multOperFlag=false;
				} 			
			}
		}
	}
	return(multPosFlag);
}

function loadAudioHighlight()
{
	/*
	 * 022515: Loads audio tip snippets for simple numeric expressions
	 * 
	 * - Determines next tip based on elementArray structure
	 * - Loads and plays tip
	 */
	var operatorPointer;
	var beginPoint=0;
	var endPoint=elementArray.length-1;
	var i;
	var parensFound=false;
	var audioFileToLoad="";
	
	//check for parens
	for (i=0;i<elementArray.length-1;i++) {
		if (elementArray[i].elemtype=="leftgrp") {
			parensFound=true;
			if (elementArray[i].string=="|" && 
					elementArray[i+2].string!="|") {
				//load absol val audio
				audioFileToLoad="en6";//absol val w/in parens
			} else if (elementArray[i].string !="|") {
				//load parens only audio
				audioFileToLoad="en7";
			}
		}
	}
	
	if (!parensFound) {
		//pointer to highest level operator, from left to right, in expression
		operatorPointer=checkOperators(beginPoint, endPoint);
		var oper= elementArray[operatorPointer].string;
		switch (oper) {
		case "^":
			audioFileToLoad="en8";
			break;
		case "*":
			audioFileToLoad="en9";
			break;
		}
	}
	if (audioFileToLoad !="") findAudio(audioFileToLoad);
	return;
}

//jcs022815 new function for loading audio file into voice over and setting autoplay
function findAudio(audioCode) {
	
	
	if (document.getElementById("turnAudioOnButton").style.display=="none") {
			

	var audioHint=document.getElementById("voiceOver");
	var hintSource="sound/"+audioCode;
	var hiddenFile = "hidden"+audioCode;	
	var firstTime=document.getElementById(hiddenFile);
	
	//jcs040615 test
	if ((firstTime.innerHTML=="")||(firstTime.innerHTML=="playme")) {
		hintSource="sound/"+audioCode+".mp3";
	} else {
		hintSource="sound/"+audioCode+"2.mp3";
	}
		
	if ((firstTime.innerHTML=="")&&(document.getElementById("turnAudioOffButton").style.display=="")) {
	    audioHint.autoplay=true;
		firstTime.innerHTML="alreadyPlayed";
	} 
	
	audioHint.src=hintSource;
	}

	return;

}

function repositionEqFractionDenom()
{
	/*
	 * bts 031915: new function
	 * Called when hidden element hiddeneqfractionexpn = equation, indicating
	 * a fraction in the equation or alg expn with a complex numerator
	 * Repositions the structure to:
	 * 	- remove the / oper element
	 * 	- Adds the denom value as a new fraction term at the beginning
	 *  - Adds a new * oper element 
	 *  
	 *  Calling routine (confirmPoly) writes updated expression/eq to board
	 *  
	 *  Modified 4/11/15:
	 *  Handle complex denominator
	 */
	var tempTermObj=[];
	var newEl=[];
	var ctr;
	var stringval,elemtype,num,denom,v1,v2,v3,v4,e1,e2,e3,e4;
	var strikenum, strikedenom;
	var numStartLoc, grpPtr;
	
	var i;
	
	//bts 041115: new vars for denom fraction and fixing bug
	var insertPt;
	var denomFract=false;
	var numFract=false;
	
	var denomFractLoc=[];//start/end pts--left/right groupers--for complex denom fracts
	
	//bts 041215 add error code
	var errMsgText="";
	var errorCode;
	var errorLocale="";
	var errorCond;
	
	var equalityLoc=findEqualityLocInStruct();
	//set default value for equalityLoc if this is not an equation
	if (equalityLoc==undefined) equalityLoc=-1;
	
	//check first for denom fractions; if found, check for cross-multiply
	// do not reformat num fractions if denom fractions are found	
	
	// bts 042415: if complex denom fractions found, user needs to
	// use the cross product fraction input form
	for (i=0;i<elementArray.length-1;i++) {
		if (elementArray[i].elemtype=="oper" && 
				elementArray[i].string=="/") {
			grpPtr=i+1;
			if  (elementArray[grpPtr].elemtype=="term" &&
					elementArray[grpPtr].variable != null) {
				//special case: no parens, variable in denom & single term
				denomFract=true;
				denomFractLoc[denomFractLoc.length]=grpPtr;
				denomFractLoc[denomFractLoc.length]=grpPtr;
			}

			if (elementArray[grpPtr].elemtype=="leftgrp") {
					denomFractLoc[denomFractLoc.length]=grpPtr;//leftgrp pos
				while (elementArray[grpPtr].elemtype!="rightgrp" &&
						(grpPtr<elementArray.length-1 || grpPtr<equalityLoc)) {
					grpPtr++;					
				}
				if (grpPtr<elementArray.length || 
							grpPtr<equalityLoc) {
					denomFract=true;
					denomFractLoc[denomFractLoc.length]=grpPtr;//rightgrp pos
				} 
			}
		}		
	}
	// bts 042415: if complex denom fract or var in denom, exit
	if (denomFract) {
		//user must use cross product fraction entry form
		errMsgText="";
		errorCode=51;
		errorLocale="entry";
		errMsgText=errorMsg(errorCode,errMsgText);
		displayErrMsg(errMsgText, errorLocale);
		return(errMsgText);	
		/*
		if (equalityLoc>-1) {//equation
			if (denomFractLoc.length>3) errorCond=true;	
			if (denomFractLoc.length>2) {
				if (denomFractLoc[0]>equalityLoc ||
						denomFractLoc[2]<equalityLoc) errorCond=true;
			}
			if (!errorCond) 
				errorCond=checkCrossMultiply(equalityLoc,denomFractLoc);

			if (errorCond) errorCode=51;//cannot cross multiply with this expression
		} else if (equalityLoc==-1) {
			errorCode=52;//cannot have complex denom for alg expn
			errorCond=true;
		}
		
		if (errorCond) {
			errorLocale="";
			errMsgText=errorMsg(errorCode,errMsgText);
			displayErrMsg(errMsgText, errorLocale);
		}
		return(errMsgText);	
		*/
	} 
	
	//check for complex fraction in numerator
	for (i=0;i<elementArray.length-1;i++) {
		if (elementArray[i].elemtype=="oper" && 
				elementArray[i].string=="/") {
			// bts 032115: find location for start of numerator
			grpPtr=i-1;
			if (elementArray[grpPtr].elemtype=="rightgrp") {
				//find prev leftgrp
				while (elementArray[grpPtr].elemtype!="leftgrp" &&
						(grpPtr>-1 || grpPtr>equalityLoc)) {
					grpPtr--;					
				}
				if (grpPtr<0) {
					grpPtr=0;
				} else if (grpPtr==equalityLoc) {
					grpPtr=equalityLoc+1;
				} 
				insertPt=grpPtr;
				numFract=true;
			}
	
			
			if (numFract) {//write new numerator
				tempTermObj=elementArray.splice(i,2);
				tempTermObj[0].string="*";
				tempTermObj[1].denominator=tempTermObj[1].numerator;
				tempTermObj[1].numerator=1;
				tempTermObj[1].string="1/"+String(tempTermObj[1].denominator);
				//tempTermObj.reverse();
				//moved for loop to here for complex numerators
				for (ctr=0;ctr<2;ctr++) {
					newEl=addElementToPrevStep(ctr, tempTermObj[ctr].string, 
							tempTermObj[ctr].elemtype, tempTermObj[ctr].numerator, 
							tempTermObj[ctr].denominator,tempTermObj[ctr].variable,
							tempTermObj[ctr].exponent,tempTermObj[ctr].variable2,
							tempTermObj[ctr].exponent2,tempTermObj[ctr].variable3,
							tempTermObj[ctr].exponent3,tempTermObj[ctr].variable4,
							tempTermObj[ctr].exponent4,tempTermObj[ctr].strikenum, 
							tempTermObj[ctr].strikedenom);
					//bts 041115: use insertPt not grpPtr
					//elementArray.splice(grpPtr,0,newEl);
					elementArray.splice(insertPt,0,newEl);
				}
				numFract=false;
			}
		}
	}
	return(errMsgText);
}

function checkCrossMultiply(equalityLoc,denomFractLoc)
{
	/*
	 * NOT USED ANYMORE
	 * Checks if equation with complex denom fraction meets parameters
	 * for cross-multiplying. 
	 * If so, reformats the structure 
	 * Otherwise, returns errorCond=true.
	 */
	var errorCond=false;
	var i,j;
	var checkStart,checkEnd;
	var checkSide;//1=left side only;2=right side only;3=both sides
	
	if (denomFractLoc.length>3) checkSide=3;//both sides
	
	for (i=0;i<denomFractLoc.length-1;i++) {
		if	(denomFractLoc[i]>equalityLoc) {
			checkStart=equalityLoc+1;
			checkEnd=elementArray.length-1;
			if (i<2||denomFractLoc.length<3) checkSide=2; //right side only
		} else if (denomFractLoc[i]<equalityLoc) {
			checkStart=0;
			checkEnd=equalityLoc-1;
			if (i<2||denomFractLoc.length<3) checkSide=1; //leftt side only
		}
		if (i==0 || i==2) { 
				//(denomFractLoc[i]>0 || 
			for (j=checkStart;j<checkEnd;j++){
				if ((elementArray[j].elemtype=="term" &&
						elementArray[j].variable != null) ||
						(elementArray[j].elemtype=="oper" &&
								(elementArray[j].string != "*" &&
								elementArray[j].string != "/"))) {
					//not allowed
					errorCond=true;
				} 
			}			
		} else if (i==1 || i==3) {//check subsequent els		
			checkEnd=Math.max(elementArray.length-1,equalityLoc-1);
			for (j=denomFractLoc[i]+1;j<checkEnd;j++) {
				if ((elementArray[j].elemtype=="term" &&
						elementArray[j].variable != null) ||
						(elementArray[j].elemtype=="oper" &&
						(elementArray[j].string != "*" &&
								elementArray[j].string != "/"))) {
					//not allowed
					errorCond=true;
				}
			}
		}			
	}
	//no errors, reformat equation for cross multiply
	if (!errorCond) {
		//rebuild struct for cross multiply:
		//	left side numerator w right side denom
		//	right side num w left side denom
		var tempLeftArray=[];
		var tempRightArray=[];
		var firstEl,secondEl;
		
		if (checkSide==3) {//do right side and left side
			tempRightArray=elementArray.slice(denomFractLoc[2],
					denomFractLoc[3]-denomFractLoc[2]+1);
			elementArray[denomFractLoc[2]-1].string="*";
			
			elementArray.splice(denomFractLoc[2],
					denomFractLoc[3]-denomFractLoc[2]+1,
					elementArray[denomFractLoc[0]],
					elementArray[denomFractLoc[1]-denomFractLoc[0]+1]);
			elementArray[denomFractLoc[0]-1].string="*";
			elementArray.splice(denomFractLoc[0],
					denomFractLoc[1]-denomFractLoc[0]+1,
					tempRightArray);			
		} else if (checkSide==2) {//fraction on right side only
			firstEl=denomFractLoc[0];
			secondEl=denomFractLoc[1];
			elementArray[firstEl-1].string="*";
			tempRightArray=elementArray.slice(firstEl-1,
					secondEl+1);
			//add denom trerm to left side
			elementArray.splice(equalityLoc-1,0,tempRightArray);		
			
			elementArray.splice(firstEl,
					denomFractLoc[1]-denomFractLoc[0]+1,
					elementArray[denomFractLoc[0]],
					elementArray[denomFractLoc[1]-denomFractLoc[0]+1]);
			elementArray[denomFractLoc[0]-1].string="*";
		}		
	}	
	return(errorCond);
}

function removeMultByOneFromStruct()
{
	/*
	 * bts 11092015
	 * Removes multiplication by 1 from structure
	 */
	var equalPtr=findEqualityLocInStruct();
	var adjustLoc;
	var operLoc=0;//loc of * oper to remove, relative to term
	var startPt=0;
	var noDisplay=true;
	
	if (equalPtr==undefined) equalPtr=-1;
	
	for (var i=elementArray.length-1;i>-1;i--) {
		adjustLoc=false;
		if (elementArray[i].elemtype == "term" && 
				elementArray[i].variable==null &&
				elementArray[i].numerator==1 &&
				elementArray[i].denominator==1) {//term is = 1, no vars
				operLoc=testOneTermForRemoval(i,equalPtr);
				// remove the term and preceding or following *
				if (operLoc>0) {
					startPt=Math.min(i,operLoc);
					elementArray.splice(startPt,2);
					adjustLoc=true;
				}

			//bts 011215: reset i if struct length adjusted; 
			//	refigure equality oper location
			if (adjustLoc) {
				removeParensAfterAdd(false,false,noDisplay);
				equalPtr=findEqualityLocInStruct();
				if (equalPtr==undefined) equalPtr=-1;
				i=elementArray.length;
				adjustLoc=false;
			}
		}
	}		
	return;
}

function testOneTermForRemoval(pos,eqOperPos)
{
	/*
	 * 040615: tests if term of val 1 meets rules for removal from struct
	 * returns non-zero value if term should be removed
	 * pos: position of term within structure
	 * eqOperPos: position of equality oper if equation or undefined 
	 * 
	 * remove=0: don't remove term
	 * remove=>0: mult/div follows: no need to do multiply oper so remove
	 * 		remove value indicates position of operation element
	 */
	var remove=0;
	var firstTerm=false;
	var lastTerm=false;
	
	if (pos==0 || pos==eqOperPos+1) firstTerm=true; // no preceding term
	if (pos==elementArray.length-1 || pos==eqOperPos-1) lastTerm=true;
	
	if (firstTerm) {
 		if (!lastTerm) {
 			if (elementArray[pos+1].string=="*"  ||
					elementArray[pos+1].string=="\u00F7") {
 				remove=pos+1;
 			}
 		}
	} else {//not first term
		if (elementArray[pos-1].string=="*" ||
					elementArray[pos-1].string=="\u00F7") {//multiply,divide
				remove=pos-1;
		} 			
	}
	
	return(remove);	
}



function removeZerosFromStruct()
{
	/* 
	 * BTS 040615: new function based on removeZerosFromStruct()
	 * 	Tests if term w/ zero val should be removed and removes it
	 *  Display updated expression/equation or return flag indicating 
	 *  	term was removed?
	 *  
	 * removes any terms that are zeros from struct for
	 * equations. Also removes leading oper elements if not
	 * the first element in struct or the first element after
	 * the equality sign
	 */
	var equalPtr=findEqualityLocInStruct();
	var adjustLoc=false;
	var removeZeroTerm=false;
	var endProblem=false;
	
	if (equalPtr==undefined) equalPtr=-1;
	
	for (var i=elementArray.length-1;i>-1;i--) {
		if (elementArray[i].elemtype == "term" && 
				elementArray[i].numerator==0) {
			if (i==0 || i==equalPtr+1) {
				//do not remove term from left,right side if only term
				if ((i==0 && equalPtr!=1) || 
						(i==equalPtr+1 && i!=elementArray.length-1)) {
					// test if term should be removed
					removeZeroTerm=testZeroTermForRemoval(i,equalPtr);
					// remove the term and following oper
					if (removeZeroTerm) {
						adjustLoc=updateBoardforZeroRemoval(removeZeroTerm,i);
						if (removeZeroTerm !=1) {
							elementArray.splice(i,2);
							adjustLoc=true;
						}
					}
				}
			} else {//remove term and preceding oper
				// test if term should be removed
				removeZeroTerm=testZeroTermForRemoval(i,equalPtr);
				if (removeZeroTerm) {
					adjustLoc=updateBoardforZeroRemoval(removeZeroTerm,i);
					if (removeZeroTerm !=1) {
						elementArray.splice(i-1,2);
						adjustLoc=true;
					}
				}
			}
			//bts 011215: reset i if struct length adjusted; 
			//	refigure equality oper location
			if (adjustLoc) {
				equalPtr=findEqualityLocInStruct();
				if (equalPtr==undefined) equalPtr=-1;
				i=elementArray.length;
				adjustLoc=false;
			}

		}
	}	
	return(endProblem);
}

function updateBoardforZeroRemoval(removeCondition,pos) 
{
	/* 
	 * update board display of expn/equation depending on 0 term removal 
	 * conditions
	 */
	var adjustLoc;
	var color="orange";
	
	switch (removeCondition)
	{
	case 1: //
		writeToTable(" -- Current expression with 0 value");
		writeMultHighlight(pos, 1, elementArray.length,color);
		elementArray.splice(pos,2);
		adjustLoc=true;
		break;
	case 2: //
		writeToTable(" -- Need to remove 0 value");
		writeMultHighlight(pos, 1, elementArray.length,color);
		break;
	case 3: //divide by 0 not allowed
		writeToTable(" -- Divide by 0 not allowed");
		writeMultHighlight(pos, 1, elementArray.length,color);
		break;
	default:
		break;
	}
	return(adjustLoc);
}

function testZeroTermForRemoval(pos,eqOperPos)
{
	/*
	 * 040615: tests if zero term meets rules for removal from struct
	 * returns non-zero value if term should be removed
	 * pos: position of zero term within structure
	 * eqOperPos: position of equality oper if equation or undefined 
	 * 
	 * remove=0: don't remove term
	 * remove=1: mult/div follows: display n+0*n, then n+0..., then n=n
	 * remove=2: display expn with 0 term and then remove automatically
	 * remove=3: divide by 0 not allowed.
	 */
	var remove=0;
	var firstTerm=false;
	var lastTerm=false;
	
	if (pos==0 || pos==eqOperPos+1) firstTerm=true; // no preceding term
	if (pos==elementArray.length-1 || pos==eqOperPos-1) lastTerm=true;
	if (firstTerm || 
			elementArray[pos-1].string=="+" || 
			elementArray[pos-1].string=="-" ||
			elementArray[pos-1].string=="*") {
		if (!lastTerm) {
			if (elementArray[pos+1].string=="*" ||
					elementArray[pos+1].string=="\u00F7") {//multiply,divide
				remove=1;
			} else if (elementArray[pos+1].string=="+" ||
					elementArray[pos+1].string=="-" ||
					pos+1==eqOperPos) {
				remove=2;				
			} else {
				remove=0;
			}
		} else if (lastTerm) {
			if (elementArray[pos-1].string=="*") {//multiply
				remove=1;
			} else if (elementArray[pos-1].string=="\u00F7") {
				remove=3; //divide by zero not allowed
			} else if (elementArray[pos-1].string=="+" ||
					elementArray[pos-1].string=="-" ||
					(pos-1==eqOperPos && eqOperPos != -1)) {
				remove=2;				
			} else {
				remove=0;
			}		
		}
	} else if (!firstTerm) {
		if (elementArray[pos-1].string=="*") remove=1;
		if (elementArray[pos-1].string=="\u00F7") {
			remove=3;//divide by 0 not allowed; exit
		}		
	}
	
	return(remove);	
}

function handleProportionInput()
{
	/*
	 * 042215: formats 4 proportion numerator/denominator entries
	 */
	var proportionExpn="";
	
	// get 4 entry fields data
	var num1=document.getElementById("numerator1field").value;
	var num2=document.getElementById("numerator2field").value;
	var denom1=document.getElementById("denominator1field").value;
	var denom2=document.getElementById("denominator2field").value;
	
	// display equation as user entered it in blackboard
	var eqString;
	var formatText="";
	
	if (num1=="") num1="1";
	if (num2=="") num2="1";
	if (denom1=="") denom1="1";
	if (denom2=="") denom2="1";
	
	// check if num/denom is constant number or complex
	if (isNaN(num1) && num1.indexOf("(")==-1) num1="("+num1+")";
	if (isNaN(num2) && num2.indexOf("(")==-1) num2="("+num2+")";
	if (isNaN(denom1) && denom1.indexOf("(")==-1) denom1="("+denom1+")";
	if (isNaN(denom2) && denom2.indexOf("(")==-1) denom2="("+denom2+")";
	
	// this formatting may be too small
	/*
	formatText = formatText.concat(num1.sup(),"/");
	formatText=formatText.concat(denom1.sub());
	formatText=formatText+"=";
	formatText = formatText.concat(num2.sup(),"/");
	formatText=formatText.concat(denom2.sub());
	writeToTableProportion(formatText,"Original proportion equation");
	*/
	eqString=num1+"/"+denom1+"="+num2+"/"+denom2;		
	writeToTableSpecial(eqString,"Original proportion");
	
	//	reposition equation to show cross product changes
	//		buildStructure will build elementArray
	var tempStr="";
	if (denom2 !="1") {
		if (num1 != "1") {
			denom2=denom2+"*";
		} else {//num1=1, remove it, remove parens from denom, no asterisk
			num1="";
			denom2=denom2.replace("(","");
			denom2=denom2.replace(")","");
		}
	} else {
		denom2="";
		num1=num1.replace("(","");
		num1=num1.replace(")","");
	}
	if (denom1 !="1") {
		if (num2 != "1") {
			denom1=denom1+"*";
		} else {//num2=1 remove it, remove parens from denom, no asterisk
			num2="";
			denom1=denom1.replace("(","");
			denom1=denom1.replace(")","");
		}
	} else {//denom1=1
		denom1="";
		num2=num2.replace("(","");
		num2=num2.replace(")","");
	}
	//proportionExpn=denom2+"*"+num1+"="+denom1+"*"+num2;
	proportionExpn=denom2+num1+"="+denom1+num2;
	
	return(proportionExpn);
}

function writeToTableProportion(eqText,annot)
{
	
	// write text to a table. Create new table for each row of data
	// add a new row
	var i=0;
	var textincell;
	var rownode=document.createElement("tr");
	var tableElementStart=document.getElementById("expnTable");
	var tableElement=document.createElement("table");
	tableElementStart.appendChild(tableElement);
	tableElement.appendChild(rownode);
	var cellnode;

	cellnode=document.createElement("td");
	//if (negNum) specialText=specialText.fontcolor("red").bold();
	textincell=document.createTextNode(eqText);
	cellnode.appendChild(textincell);
	cellnode.innerHTML=eqText;
	rownode.appendChild(cellnode);
		
	// write out annotation
	// bts 0417: change -- of annotation to mdash
	var mdashPtr = annot.indexOf("--");
	if (mdashPtr > -1) { 
		annot="	&mdash; "+ annot.substring(mdashPtr+2);
	} else {
		annot="	&mdash; "+ annot;
	}
		
	cellnode=document.createElement("td");
	cellnode.style.whiteSpace="nowrap";
	textincell=document.createTextNode(annot);
	//specialText = annot;
	cellnode.style.cssText="font-weight: bold;font-family: Bradley Hand ITC";			
	cellnode.appendChild(textincell);
	cellnode.innerHTML=annot;
	rownode.appendChild(cellnode);

	return;
}

//bts 072015: Geometry functions
function displayCanvas()
{
	/*
	 * displays the canvas and draws the x,y axis
	 * canvas width,height set in mainwindow
	 */
	
	var w=200;//canvas width
	var ht=200;//canvas height
	var yLen, xLen;
	var lineColor;
	
	yLen=200;
	xLen=200;
	
	var blue="#0000FF";
	var red="#FF0000";
	var black="#000000";
	
	var canvas = document.getElementById("geometryCanvas");
	canvas.width=xLen;
	canvas.height=yLen;

	var ctx = canvas.getContext("2d");
	ctx.font = "12px Arial";
	//draw y axis
	ctx.beginPath();
	ctx.moveTo(xLen/2,0);
	ctx.lineTo(xLen/2,yLen/2);
	ctx.strokeStyle=black;
	ctx.stroke(); //draw positive portion

	ctx.beginPath();
	ctx.moveTo(xLen/2,yLen/2);
	ctx.lineTo(xLen/2,yLen);
	ctx.strokeStyle=red;//draw neg portion in red
	ctx.stroke(); 

	ctx.strokeStyle=black;
	ctx.strokeText("x",0,yLen/2+1);
	//draw x axis
	ctx.beginPath();
	ctx.moveTo(xLen/2,yLen/2);
	ctx.lineTo(xLen,yLen/2);
	ctx.stroke();
	ctx.strokeText("y",xLen/2+1,yLen);

	ctx.beginPath();
	ctx.moveTo(yLen/2,yLen/2);
	ctx.lineTo(0,yLen/2);
	ctx.strokeStyle=red;//draw neg portion of x axis in red
	ctx.stroke(); 

	//add in tick marks, etc.
	ctx.font = "8px Arial";
	ctx.strokeStyle=blue;
	//ctx.strokeText("0,0",xLen/2-10,yLen/2);
	
	var markLoc=xLen;
	var factor=xLen/10;
	var offset=4;
	ctx.lineWide=.25;
	
	for (var i=xLen*-1; i<markLoc;i=i+factor) {
		ctx.beginPath();
		ctx.moveTo(xLen/2-offset,i);
		ctx.lineTo(xLen/2+offset,i);
		ctx.stroke(); 		
	}

	return;
}

/*
 * checkStorage file contains functions for saving session data
 * prior to sending to the server/database
 */

function openStorageObject(login)
/*
 * browser supports session storage
 */
{
	if (!login) return;
	if (typeof(Storage) != "undefined") {
	  // Store
		localStorage.clear();
		//bts 01032017: comment out date
		var datetime=new Date().toDateString(); 
		localStorage.setItem("line1000",datetime);
		//localStorage.setItem("line1000"," ");
		//sessionStorage.setItem("username", login);
		//localStorage.timestamp=(new Date()).toUTCString();
	  // Retrieve
	  //displayErrMsg(localStorage.getItem();
	} else {
		if (document.getElementById("noStorageMessage").innerHTML == "")
			document.getElementById("noStorageMessage").innerHTML = "Your browser does not support Web " +
				"Storage. Problem data will not be saved";
	}
	return;
}

function writeToStorage(textString)
/*
 * writes a line of data to localStorage
 * Write to special textarea for homework lines
 */
{
	var lineCtr;
	var num=0;
	var i;
	var newLineKey;
	var highNum=0;
	
	var hwLine;
	
	//var hwLine = document.getElementById("tswcomments");
	//hwLine.value = hwLine.value+textString+"\n";
	
	if (typeof(Storage) != "undefined") {
		for (i=0;i < localStorage.length;i++) {
			var keyName = localStorage.key(i);
			var dataValue = localStorage.getItem(keyName);
			if (keyName.indexOf("line")>-1) {
				lineCtr = keyName.slice(4);
				if (Number(lineCtr) > highNum){
					highNum= Number(lineCtr);
					num = Number(lineCtr)+1;
					newLineKey = "line"+String(num);
				}
			}
		}
	}
	//hwLine.value = hwLine.value+newLineKey+" "+textString+"\n";
	localStorage.setItem(newLineKey, textString);	
	return;
}

function sendToServer()
{
	/*
	 * send data to the server
	*/
	
	var xmlhttp=new XMLHttpRequest();
	
	var i;
	if (typeof(Storage) != "undefined") {	
		for (i=0;i < localStorage.length;i++) {
			var keyName = localStorage.key(i);
			var dataValue = localStorage.getItem(keyName);
			xmlhttp.open("GET","testfilewrite.php?q="+keyName+dataValue,true);
			xmlhttp.send();			
			//requestObj.setRequestHeader("Content-Type","text/plain");
			//requestObj.send(dataValue);
		}
	}
	
	return;
}

function pasuser(form) {
	/*
	 * bts 0725
	 * This function currently not called. Called by a login html page
	 * Username hardcoded in firstTime function for now
	 */
	if (form.id.value!="") { 
		if (form.pass.value=="MathAssister") { 
			openStorageObject(form.id.value);
			//window.location.replace="mainwindow.html" 
			location="testMainWindow.html";
		} else {
			alert("Invalid Password");
		} 
	} else { 
		form.id.value="TestCase";
		openStorageObject(form.id.value);
		//alert("You must enter a user ID");
		location="testMainWindow.html";
	}
}

function saveHW()
{
	/*
	 * Read localStorage 
	 * Write each line to hidden element homeworklines in sendhomework form
	 * display sendhomework form for additional comments, name, email address
	 * Attach sendhomework form to email
	 * send
	 */
	var hwLine;
	var homeWork;
	var keyName;
	var dataValue;
	var keyValue;
	var line="line";
	var keyNum;
	
	//alert("In saveHW function.How did we get here? ");
	
	//document.getElementById("sendhomeworkform").style.display="";
	homeWork = document.getElementById("homeworklines");

	// initialize keyName to 1000
	keyName = line+"1000";
	var continueLoop=true;

	if (typeof(Storage) != "undefined") {
			//var keyName = localStorage.key(i);
		while (continueLoop) {
			dataValue = localStorage.getItem(keyName);
			if (dataValue == "" || dataValue == undefined) {
				continueLoop=false;
			} else {
				hwLine=document.createElement("p");
				hwLine.innerHTML = dataValue+"\n";
				homeWork.appendChild(hwLine);
				
				keyNum = keyName.slice(4);
				keyValue = Number(keyNum)+ 1;
				keyName = line+String(keyValue);
			}
		}		
	} else {
		alert("Cannot save your homework.");
	}
	document.getElementById("saveworkform").style.display="none";
	document.getElementById("sendhomeworkform").style.display="";

	return;
}

function writeGaveUpMsg(extraText)
{
	/*
	 * sets up gave up msg for hw tracking
	 */
	var gaveUpMsg="  Gave up ";
	if (extraText==undefined) extraText=" ";
	gaveUpMsg=gaveUpMsg+extraText;
	writeToStorage(gaveUpMsg.fontcolor("red").bold());

	return;
}


function writeWrongAns(j,userAns,ansTable)
{
	/*
	 * Gets the prompt from specified answer table for a wrong
	 * answer and writes prompt+incorrect answer to storage
	 * Parameters: prompt index, incorrect user answer,
	 * 			table indicator
	 * 
	 * bts 08092015: added ansTable parameter for prompt text
	 * 	ansTable indicates either the table to reference
	 *  or indicates the element holding the prompt data:
	 * 		default = all purpose getuseranswer table row element
	 * 		lcd = lcd conversion table row element
	 * 		commondenom = common denominator element
	 * 		tomixednum = improper fract to mixed number conversion
	 * 
	 * 	j is either the index into the specific table or 
	 *  it contains the prompt text from a form element
	 */
	
	//var ansTable;
	var rowPtr;
	var rowID;
	var promptTextPtr, promptText;
	var commentText="  X".fontcolor("red").bold();
	var skipTable=false;
	
	//set up correct answer table
	switch (ansTable)
	{
	case "default"://getuseranswer general table
		//rowID="row";
		promptTextPtr="row"+String(j)+"prompt"+String(j);
		break;
	case "lcd"://common denom conversion table
		//rowID="converttolcdrow";
		promptTextPtr="converttolcdrow"+String(j)+
				"prompt"+String(j);
		break;
	case "commondenom": //common denominator
		skipTable=true;
		promptText="Enter a common denominator for "+j+":  ";
		break;
	case "tomixednum"://convert improper fract to mixed num
		skipTable=true;
		promptText="Mixed number entered incorrectly for "+j+":  ";
		break;
	case "cancelfraction"://cancel fraction number
		skipTable=true;
		promptText="Incorrect common factor for "+j+":  ";
		break;
	case "simplifylastfraction"://simplify last fraction
		skipTable=true;
		promptText="Incorrect common factor entered:   ";
		break;
		
	case "mixedtoimproper": //mixed number to improper fraction
		skipTable=true;
		//special case to set up prompt for improper # conversion		
		promptTextPtr="mixnumrow"+String(j)+"mixnumprompt"+
						String(j);
		promptText=document.getElementById(promptTextPtr).innerHTML+
					" to an improper fraction:   ";
		break;
	default://general getuseranswer table
		promptTextPtr="row"+String(j)+"prompt"+String(j);
		//rowID="row";
		break;
	}

	if (!skipTable) {
		//rowPtr=rowID+String(j);//row identifier within table
		//promptTextPtr=rowPtr+"prompt"+String(j);//prompt cell id
		promptText=document.getElementById(promptTextPtr).innerHTML
					+":  ";
	}
	
	writeToStorage(promptText+" "+String(userAns)+" "+commentText);
	
	return;
}


//bts 01142016: declare hwWindow as global var
var hwWindow;
function checkHWWindow()
{
	/*
	 * Checks if hwWindow open or closed. If open, close it.
	 */
    if (hwWindow) {
        if (!hwWindow.closed) { 
            hwWindow.close();
        }
    } 
	return;
}

function displayHW(fromMobile)
{
	/*
	 * function to display student's work in 
	 * separate html page/window 
	 * 
	 * 2/24/2017: added parameter indicating coming from mobile version;
	 * 	if mobile caller, use different version of window open
	 */
	var fileName="";

	var hwLine,hwTextArea;
	var keyName;
	var dataValue;
	var keyValue;
	var line="line";
	var keyNum;
	var continueLoop=true;
	
	//check if mobile version is caller
	if (fromMobile) {
		document.getElementById("tswcomments").style.display="none";
		var textOutput=document.getElementById("mobileHW");
		// initialize keyName to 1000
		keyName = line+"1000";

		if (typeof(Storage) != "undefined") {
			while (continueLoop) {
				dataValue = localStorage.getItem(keyName);
				if (dataValue == "" || dataValue == undefined) {
					continueLoop=false;
				} else {
					if (dataValue.indexOf("Problem:")!=-1) {
						//create heading line
						hwLine=document.createElement("h4");
					} else if (dataValue.indexOf("solved")!=-1) {
						//do not prefix with -- spaces
						hwLine=document.createElement("p");
					} else {
						hwLine=document.createElement("p");
						//add spaces for indentation
						dataValue=" -- "+dataValue;
					}
					hwLine.value = dataValue;
					//hwLine.innerHTML = dataValue+"\<br>";
					hwLine.innerHTML = dataValue;
					textOutput.appendChild(hwLine);
					
					keyNum = keyName.slice(4);
					keyValue = Number(keyNum)+ 1;
					keyName = line+String(keyValue);
				}
			}
		} else {
			//hwWindow.document.write("Unable to save homework");
			hwLine.innerHTML = "Unable to save homework";
			textOutput.appendChild(hwLine);
		}
		window.location.assign("#pagetwo");		
	} else {
		//do laptop version
		//check if showwork window is open. Close it if open
		checkHWWindow();
	
	// bts 01142016: change window object to global; use hwWindow
	//	rather than w
		hwWindow = window.open(fileName,"showwork","toolbar=no, " +
			"location=no, directories=no, status=no, menubar=no, " +
			"scrollbars=yes, resizable=no, copyhistory=yes, width=500, height=600");
	
	    //bts 01122016: use open document with text and replace parameters
	    hwWindow.document.open();
		//hwWindow.document.open("text/html", "replace");
		hwWindow.document.write("<html><body>");
		hwWindow.document.write("<h1>Your Current Work</h1>");
	    
		// initialize keyName to 1000
		keyName = line+"1000";
	
		if (typeof(Storage) != "undefined") {
			while (continueLoop) {
				dataValue = localStorage.getItem(keyName);
				if (dataValue == "" || dataValue == undefined) {
					continueLoop=false;
				} else {
					if (dataValue.indexOf("Problem:")!=-1) {
						//create heading line
						hwLine=document.createElement("h2");
					} else if (dataValue.indexOf("solved")!=-1) {
						//do not prefix with -- spaces
						hwLine=document.createElement("p");
					} else {
						hwLine=document.createElement("p");
						//add spaces for indentation
						dataValue=" -- "+dataValue;
					}
					hwLine.innerHTML = dataValue+"\<br>";
					hwWindow.document.write(hwLine.innerHTML);
					
					keyNum = keyName.slice(4);
					keyValue = Number(keyNum)+ 1;
					keyName = line+String(keyValue);
				}
			}
		} else {
			hwWindow.document.write("<p>Unable to save homework");		
		}
		
		//bts 01122016: close html body tags, then close document
		hwWindow.document.write("</body></html>");
		hwWindow.document.close();
    
		//bts 08092015: clear local storage and textarea if hw submitted
		//	gray out submit hw button
	    // bts 08142015: leave all work in storage regardless if
	    //	user has displayed work
	    // openStorageObject("TestUser");//clears local storage
		document.getElementById("displayhw").style.display="none";
	}
	return;
}

//jcs090215 Subtraction test
function eqSubtractBothSides()
{
	/*
	 * Based on eqAddBothSides
	 * Adds the entered term from both sides of the 
	 * equation. User then must simplify equation by selecting from
	 * simplification menu options
	 * 
	 *  - Find equality sign location
	 *  - add term to end of left and right sides
	 * 
	 * 	equationOper: indicates addition or subtraction
	 *  equationTerm: term/value to add or subtract
	 *  expnOperation: text indicating operation performed (for blackboard)
	 */
	
	var startLoc=0;
	var endLoc=elementArray.length-1;
	var equalitySignLoc=findEqualityLocInStruct();
	
	var newExpn=[];
	var arrayExpn=[];
	var expnString,expnStringRight;
	
	//jcs090215 Subtraction test
	operation="+";
	expnOperation="Subtracted a term from each side";
	var equationField=document.getElementById("subtractFromBothSidesField");
//	equationField.innerHTML="-"+equationField.innerHTML;
	var equationTerm=equationField.value;

	// bts 11092015: make sure entered term is lower case
	equationTerm=equationTerm.toLowerCase();
	
	//bts 08212015: allow only 1 term
	//	handle fractions correctly for automatically combine terms option
	// check for operators and slash symbol in equationTerm;matchoption 3
	var operArray=[];
	var fractFound,fractLoc;
	var minusSignFound;
	var negNumber;
	var errorCode,errMsgText;
	//bts 082521015: use match option 17: operators without caret ^ symbol
	operArray=parseString(equationTerm,17);
	if (operArray!==null) {
		//oper or slash or both found in entered term
		//check for slash indicating fraction and leading minus sign
		fractLoc=equationTerm.indexOf("/");
		if (fractLoc>-1) fractFound=true;
		minusSignFound=equationTerm.indexOf("-");
		if (minusSignFound>0) {
			//sign is oper, not negative indicator
			errorCode=54;
			errMsgText=errorMsg(errorCode,errMsgText);
		} else if (minusSignFound==0) {
			//neg number
			negNumber=true;
		}
		if (!errMsgText) {
			if (operArray.length>2) {
				errorCode=54;
				errMsgText=errorMsg(errorCode,errMsgText);				
			} else if (operArray.length==2) {
				if (negNumber && fractFound) {
					//no error so continue
				} else {
					errorCode=54;
					errMsgText=errorMsg(errorCode,errMsgText);					
				}
			} else if (operArray.length==1) {
				if ((negNumber && fractFound) || 
						(!negNumber && !fractFound)) {
					errorCode=54;
					errMsgText=errorMsg(errorCode,errMsgText);										
				}
			}
		}
		if (errMsgText) {
			displayErrMsg(errMsgText);
			equationTerm="";//so we go back to menu
		}
	}
	
	//bts 08032015: pass var of added term to gettermtocombine to
	//	skip prompting for this term 
	var varInTerm="";
	// extract the string portion of equationTerm, if any
	var varStrLen=0;
	varStrLen=equationTerm.length;
	//bts 08212015:allow single constant that is fraction or negative
	//	use parseString instead of isNaN, matchoption 4: letters only
	newExpn=parseString(equationTerm,4);
	if (newExpn!==null) {
		if (newExpn.length==1) {
			varInTerm=newExpn[0];
		} else {
			errorCode=55;
			errMsgText=errorMsg(errorCode,errMsgText);					
			displayErrMsg(errMsgText);
			equationTerm="";//so we go back to menu
		}
	}
	
	if (equationTerm=="" || equationTerm==" " || equationTerm==null) {
		document.getElementById("equationMenu").selectedIndex=0;
		document.getElementById("subtractFromBothSidesArea").style.display="none";
		document.getElementById("operationMenuArea").style.display="";
		document.getElementById("subtractFromBothSidesField").value="";
		//jcs080615 test
		displayTip("equation");
		return;
	}
	
	//bts 08212015: only build structure if legal term entered
	// then fall into combining constants/terms 
	expnString=buildStrPart(startLoc,equalitySignLoc-1);
	expnStringRight=buildStrPart(equalitySignLoc,endLoc);
	//jcs121014 expnString=expnString.concat(equationOper);
//jcs090115 test
//	expnString=expnString.concat("+");
	expnString=expnString.concat("-");
	expnString=expnString.concat(equationTerm)+expnStringRight+
			"-"+equationTerm;	
	arrayExpn=parseString(expnString,1); //convert new expn string to array
	//bts 08212015: removed var for errMsgText
	errMsgText=buildStructure(arrayExpn,elementArray);
	
	
	if (errMsgText) {
		alert("Error building structure.");
	} else {
		writeToTable(expnOperation);	//jcs111814 reset equation menu
		document.getElementById("equationMenu").selectedIndex=0;
		//jcs121014 new
		document.getElementById("subtractFromBothSidesArea").style.display="none";
		displayTip("afteraddtobothsides");
		document.getElementById("operationMenuArea").style.display="";
		document.getElementById("subtractFromBothSidesField").value="";
	}
	
	//pass expnString as 1st parameter
	// be sure menu area is not displayed
	document.getElementById("operationMenuArea").style.display="none";

	errMsgText=getTermToCombine(expnString,varInTerm);
	if (errMsgText=="combineconstants") {
		eqCombineConstants(expnString);
	} 

	return;
}

//bts 11202015: new functions for xy points problems
function doXYProblem()
{
	/*
	 * Called from main window when user selects option to do
	 * an equation plotting x,y points
	 */
	
	//resetClearData(); //start a new problem
	selExpType=50; // new exp type code
	equationFlag=true;
	
	/*
	 * get equation once for new problem: must be in this format: y=mx+b
	 * force x,y variables only
	 * display table for x,y value inputs
	 * always leave 1 variable blank; set other variable
	 * prompt for answer automatically, without going thru menu options
	 * allow use of menu options to select next operation 
	 * display results in side bar (when x=?, y=n)
	 * repeat with new x or y values for same equation until done
	 * 
	 */
	var errMsgText="";
	var errorCode;
	var errorFlag=false;
	var errorLocale="entry";
	
	var equationEntry=document.getElementById("problementryfield");
	var equationString=equationEntry.value;
	var xfield=document.getElementById("xfield").value;
	var yfield=document.getElementById("yfield").value;
	
	equationString.toLowerCase();
	if (equationString.indexOf("x")==-1 ||
			equationString.indexOf("y")==-1 ||
			equationString.indexOf("=")==-1) {
		errorCode=57; //must have x,y vars and = sign
		errMsgText=errorMsg(errorCode,errMsgText);
		displayErrMsg(errMsgText, errorLocale);
		errorFlag=true;
	}
	
	return;
}

//jcs121315 new function for changing problem type display
function changeProblemType(){	
	var type=document.getElementById("problemTypeMenu").selectedIndex;
	document.getElementById("fracentry").style.display="none";
	document.getElementById("stdentry").style.display="none";
	document.getElementById("stdentryhelp").style.display="none";
	document.getElementById("evalentryhelp").style.display="none";
	document.getElementById("proportionentryhelp").style.display="none";
	switch (type)
	{
	case 0: //standard type
		document.getElementById("stdentry").style.display="";
		document.getElementById("stdentryhelp").style.display="";
		document.getElementById("hiddenproblemtype").innerHTML="stdentry";
		break;

	case 1: //evaluate		
		document.getElementById("stdentry").style.display="";
		document.getElementById("hiddenproblemtype").innerHTML="eval";
		document.getElementById("evalentryhelp").style.display="";
		//selExpType=22;
		break;

	case 2: //proportion
		document.getElementById("fracentry").style.display="";
		document.getElementById("proportionentryhelp").style.display="";
		document.getElementById("hiddenproblemtype").innerHTML="proportion";
		break;
	}

}

function restartApp()
{
	/*
	 * called from restartApp button to restart the app in bad situations
	 */
    var doReload = confirm("Click OK to restart the app. Your work " +
    		"\n to this point displays in a separate window. \nTo save it, select and copy it to a file. \n "+
    			"\n Otherwise, press Cancel to return to the app.");
    if (doReload) {	
    	displayHW();
    	location.reload();
    }
    return;
}

function percentConvert(expnString) {
	/*
	 * Prompts user to convert percent term to decimal or fraction
	 * Called when user enters an expression/equation that includes % sign
	 * 
	 * Calculates decimal/fraction equivalents for percent term
	 * Displays form to prompt for user answer
	 * Returns expression string with equivalent value substituted for % value
	 */
	var percentLoc, termStartLoc;
	var termCorrect=false;
	var termIsFraction=false;
	var i=1;
	var termString="";
	var anotherPercent=true;//while loop to catch all occurrences
	
	var pctString, pctFractString;
	pctString=parseString(expnString,18); //test for dd%
	pctFractString=parseString(expnString,19);//fraction %

	percentLoc=expnString.indexOf("%");
	if (percentLoc>0) {		
		//is percent term correct: preceded by numeric
		while (i<=percentLoc) {
			termStartLoc=percentLoc-i;
			if (!isNaN(expnString[percentLoc-i])) {
				//number
				i++;
				termCorrect=true;
			} else if (charAt(expnString[percentLoc-i])=="/") {
				termIsFraction=true;
				termCorrect=true;
				i++;
			}
		}
	}
	if (termCorrect) {
		//extract the substring with percent term; may be fraction
		termString=expnString.slice(termStartLoc,percentLoc);
	}
		
		
	
	return(expnString);
}
